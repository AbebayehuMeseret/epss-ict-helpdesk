<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('ADMIN');
$pageTitle = 'WhatsApp Log';
$pdo = db();

/* ---------- Actions ---------- */
$ok = ''; $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf($_POST['csrf'] ?? null)) {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'retry') {
            $id = (int)$_POST['id'];
            $pdo->prepare("UPDATE whatsapp_log SET status='QUEUED', response=NULL WHERE id=? AND status='FAILED'")
                ->execute([$id]);
            audit('RetryWhatsApp','whatsapp_log',$id,'Retry WhatsApp message');
            $ok = 'Message re-queued.';

        } elseif ($action === 'retry_all_failed') {
            $n = $pdo->exec("UPDATE whatsapp_log SET status='QUEUED', response=NULL WHERE status='FAILED'");
            audit('RetryAllWhatsApp','whatsapp_log',null,"Re-queued $n failed messages");
            $ok = "$n failed messages re-queued.";

        } elseif ($action === 'delete_failed') {
            $n = $pdo->exec("DELETE FROM whatsapp_log WHERE status='FAILED'");
            audit('DeleteWhatsApp','whatsapp_log',null,"Deleted $n failed messages");
            $ok = "$n failed messages deleted.";

        } elseif ($action === 'dispatch_now') {
            require_once __DIR__ . '/../includes/whatsapp.php';
            $r = dispatch_whatsapp_queue(50);
            audit('DispatchWhatsApp','whatsapp_log',null,
                  "Dispatched: sent={$r['sent']} failed={$r['failed']}");
            $ok = "Dispatch complete — sent {$r['sent']}, failed {$r['failed']}.";
        }
    } catch (Throwable $e) {
        $error = app_exception_message($e);
    }
}

/* ---------- Filters ---------- */
$filterStatus = $_GET['status'] ?? '';
$q = trim($_GET['q'] ?? '');

$sql = "SELECT w.*, u.full_name, t.ticket_number
        FROM whatsapp_log w
        LEFT JOIN users u   ON u.id = w.user_id
        LEFT JOIN tickets t ON t.id = w.ticket_id
        WHERE 1=1";
$params = [];
if ($filterStatus !== '') { $sql .= " AND w.status=?";         $params[] = $filterStatus; }
if ($q !== '') {
    $sql .= " AND (w.phone LIKE ? OR w.message LIKE ? OR t.ticket_number LIKE ? OR u.full_name LIKE ?)";
    $like = "%$q%";
    array_push($params, $like, $like, $like, $like);
}
$sql .= " ORDER BY w.created_at DESC LIMIT 1000";
$stmt = $pdo->prepare($sql); $stmt->execute($params);
$rows = $stmt->fetchAll();

/* ---------- Stats ---------- */
$stats = [
    'sent'   => (int)$pdo->query("SELECT COUNT(*) FROM whatsapp_log WHERE status='SENT'")->fetchColumn(),
    'queued' => (int)$pdo->query("SELECT COUNT(*) FROM whatsapp_log WHERE status='QUEUED'")->fetchColumn(),
    'failed' => (int)$pdo->query("SELECT COUNT(*) FROM whatsapp_log WHERE status='FAILED'")->fetchColumn(),
    'total'  => (int)$pdo->query("SELECT COUNT(*) FROM whatsapp_log")->fetchColumn(),
    'today'  => (int)$pdo->query("SELECT COUNT(*) FROM whatsapp_log WHERE DATE(created_at)=CURDATE()")->fetchColumn(),
];

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:#0070f2; --sap-brand-dark:#0057d2;
    --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500;
    --sap-negative:#aa0808; --sap-neutral:#5b738b;
    --sap-shadow:0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
  }
  body, .main-content { background:var(--sap-bg) !important;
    font-family:"72","72full",Arial,Helvetica,sans-serif !important; color:var(--sap-text); }
  .sap-page-header { display:flex; justify-content:space-between; align-items:flex-start;
    margin-bottom:1rem; flex-wrap:wrap; gap:.75rem; }
  .sap-page-title { font-size:1.625rem; font-weight:400; margin:0; }
  .sap-breadcrumb { font-size:.8125rem; color:var(--sap-text-muted); margin-bottom:.25rem; }

  .sap-status { display:inline-flex; align-items:center; gap:.3rem;
    font-size:.72rem; font-weight:600; padding:.25rem .65rem;
    border-radius:.75rem; white-space:nowrap; border:1px solid transparent; }
  .sap-status.is-good     { background:#f1fdf6; color:var(--sap-positive); border-color:#d6f0e0; }
  .sap-status.is-critical { background:#fff8f1; color:var(--sap-critical); border-color:#fbe0c8; }
  .sap-status.is-bad      { background:#fef4f4; color:var(--sap-negative); border-color:#f7d2d2; }
  .sap-status.is-info     { background:#eaf4ff; color:var(--sap-brand);    border-color:#cfe2f8; }
  .sap-status.is-neutral  { background:#f4f5f7; color:var(--sap-neutral);  border-color:#e4e7eb; }

  .sap-tile { background:var(--sap-tile); border-radius:.75rem;
    box-shadow:var(--sap-shadow); padding:1rem 1.15rem;
    position:relative; overflow:hidden; height:100%; }
  .sap-tile::before { content:""; position:absolute; top:0; left:0; right:0; height:3px;
    background:var(--sap-brand); }
  .sap-tile.is-good::before     { background: var(--sap-positive); }
  .sap-tile.is-critical::before { background: var(--sap-critical); }
  .sap-tile.is-bad::before      { background: var(--sap-negative); }
  .sap-tile.is-info::before     { background: var(--sap-brand); }
  .sap-tile-head { font-size:.72rem; text-transform:uppercase; letter-spacing:.04em;
    color:var(--sap-text-muted); font-weight:600; margin-bottom:.35rem;
    display:flex; align-items:center; gap:.4rem; }
  .sap-tile-value { font-family:"72Mono","Courier New",monospace; font-size:2rem;
    font-weight:600; line-height:1.05; }
  .sap-tile-foot { font-size:.72rem; color:var(--sap-text-muted); margin-top:.35rem; }

  .sap-card { background:var(--sap-tile); border-radius:.75rem;
    box-shadow:var(--sap-shadow); overflow:hidden; }
  .sap-card-header { padding:.75rem 1.15rem; border-bottom:1px solid var(--sap-border-soft);
    display:flex; justify-content:space-between; align-items:center; gap:.5rem; flex-wrap:wrap; }
  .sap-card-header .title { font-size:.875rem; font-weight:600; }
  .sap-card-body { padding:1rem 1.15rem; }

  .sap-filterbar { background:var(--sap-tile); border-radius:.75rem .75rem 0 0;
    box-shadow:var(--sap-shadow); padding:.85rem 1rem;
    border-bottom:1px solid var(--sap-border-soft); }
  .sap-filterbar-row { display:flex; gap:.5rem; flex-wrap:wrap; align-items:center; }
  .sap-search-wrap { position:relative; flex:1 1 300px; min-width:220px; }
  .sap-search-wrap i { position:absolute; left:.75rem; top:50%; transform:translateY(-50%);
    color:var(--sap-text-muted); font-size:.9rem; pointer-events:none; }
  .sap-search-wrap input { width:100%; font-size:.875rem; padding:.55rem 1rem .55rem 2.2rem;
    border-radius:.5rem; border:1px solid var(--sap-border); background:#fff;
    color:var(--sap-text); font-family:inherit; }
  .sap-search-wrap input:focus { outline:none; border-color:var(--sap-brand);
    box-shadow:0 0 0 3px rgba(0,112,242,.15); }
  .sap-filterbar select { font-size:.8125rem; padding:.5rem 2rem .5rem .65rem;
    border-radius:.5rem; border:1px solid var(--sap-border); background:#fff;
    font-family:inherit; min-width:160px; }

  .sap-btn { display:inline-flex; align-items:center; gap:.35rem;
    font-size:.8125rem; font-weight:500; border-radius:.5rem;
    padding:.45rem .8rem; border:1px solid transparent; background:transparent;
    color:var(--sap-brand); cursor:pointer; line-height:1; text-decoration:none;
    white-space:nowrap; font-family:inherit; }
  .sap-btn:hover { background:#eaf4ff; color:var(--sap-brand-dark); }
  .sap-btn.sap-btn-emphasized { background:var(--sap-brand); color:#fff; }
  .sap-btn.sap-btn-emphasized:hover { background:var(--sap-brand-dark); color:#fff; }
  .sap-btn.sap-btn-outline { border-color:var(--sap-border); background:#fff; }
  .sap-btn.sap-btn-outline:hover { border-color:var(--sap-brand); background:#eaf4ff; }
  .sap-btn.sap-btn-icon { padding:.4rem .5rem; }

  table.sap-table { width:100%; border-collapse:separate; border-spacing:0;
    font-size:.8125rem; margin:0; }
  table.sap-table thead th { background:#f5f6f7; border-bottom:1px solid var(--sap-border);
    font-weight:600; color:var(--sap-text-muted); text-align:left;
    padding:.6rem .75rem; text-transform:uppercase;
    font-size:.68rem; letter-spacing:.04em; white-space:nowrap; }
  table.sap-table tbody td { padding:.6rem .75rem;
    border-bottom:1px solid var(--sap-border-soft); vertical-align:top; }
  table.sap-table tbody tr:last-child td { border-bottom:0; }
  table.sap-table tbody tr:hover { background:#f8fbff; }

  .sap-phone { font-family:"72Mono","Courier New",monospace; font-size:.78rem; white-space:nowrap; }
  .sap-ticket-num { font-family:"72Mono","Courier New",monospace; font-weight:600;
    color:var(--sap-brand); text-decoration:none; white-space:nowrap; }
  .sap-ticket-num:hover { color:var(--sap-brand-dark); text-decoration:underline; }

  .sap-msg-preview { max-width:420px;
    white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .sap-msg-full { display:none; margin-top:.35rem;
    padding:.5rem .65rem; background:#f5f6f7; border-radius:.35rem;
    font-size:.75rem; line-height:1.5; white-space:pre-wrap;
    color:var(--sap-text-muted); }
  .sap-msg-row.open .sap-msg-full { display:block; }
  .sap-msg-toggle { color:var(--sap-brand); cursor:pointer; font-size:.7rem;
    text-decoration:underline; background:none; border:0; padding:0; }

  .sap-response { max-width:180px; font-size:.7rem; color:var(--sap-text-muted);
    white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }

  .sap-empty { text-align:center; padding:2.5rem 1rem; color:var(--sap-text-muted); }
  .sap-empty .bi { font-size:2.2rem; opacity:.4; display:block; margin-bottom:.5rem; }

  .dataTables_wrapper .dataTables_length,
  .dataTables_wrapper .dataTables_filter { display:none; }
  .dataTables_wrapper .dataTables_info,
  .dataTables_wrapper .dataTables_paginate { padding:.65rem 1rem; font-size:.78rem; }
  .dataTables_wrapper .dataTables_paginate .paginate_button.current {
    background:var(--sap-brand) !important; color:#fff !important;
    border-color:var(--sap-brand) !important; border-radius:.35rem !important; }
</style>

<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb">
      <i class="bi bi-house-door"></i> Home / Administration / <strong>WhatsApp Log</strong>
    </div>
    <h1 class="sap-page-title">WhatsApp Log</h1>
  </div>
  <div class="d-flex gap-2 flex-wrap">
    <span class="sap-status is-info"><i class="bi bi-whatsapp"></i> <?= number_format($stats['total']) ?> total</span>
    <span class="sap-status is-good"><i class="bi bi-check-circle"></i> <?= number_format($stats['sent']) ?> sent</span>
    <span class="sap-status is-critical"><i class="bi bi-clock"></i> <?= number_format($stats['queued']) ?> queued</span>
    <span class="sap-status <?= $stats['failed'] > 0 ? 'is-bad' : 'is-neutral' ?>">
      <i class="bi bi-x-circle"></i> <?= number_format($stats['failed']) ?> failed
    </span>
  </div>
</div>

<?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>

<!-- Stat tiles -->
<div class="row g-3 mb-3">
  <div class="col-6 col-md-3 col-lg">
    <div class="sap-tile is-info">
      <div class="sap-tile-head"><i class="bi bi-collection"></i> Total</div>
      <div class="sap-tile-value"><?= number_format($stats['total']) ?></div>
      <div class="sap-tile-foot">All messages</div>
    </div>
  </div>
  <div class="col-6 col-md-3 col-lg">
    <div class="sap-tile is-good">
      <div class="sap-tile-head"><i class="bi bi-check-circle"></i> Sent</div>
      <div class="sap-tile-value"><?= number_format($stats['sent']) ?></div>
      <div class="sap-tile-foot">Delivered to WA-AKG</div>
    </div>
  </div>
  <div class="col-6 col-md-3 col-lg">
    <div class="sap-tile is-critical">
      <div class="sap-tile-head"><i class="bi bi-clock-history"></i> Queued</div>
      <div class="sap-tile-value"><?= number_format($stats['queued']) ?></div>
      <div class="sap-tile-foot">Waiting for dispatcher</div>
    </div>
  </div>
  <div class="col-6 col-md-3 col-lg">
    <div class="sap-tile is-bad">
      <div class="sap-tile-head"><i class="bi bi-x-circle"></i> Failed</div>
      <div class="sap-tile-value"><?= number_format($stats['failed']) ?></div>
      <div class="sap-tile-foot">Check response</div>
    </div>
  </div>
  <div class="col-6 col-md-3 col-lg">
    <div class="sap-tile is-info">
      <div class="sap-tile-head"><i class="bi bi-calendar-day"></i> Today</div>
      <div class="sap-tile-value"><?= number_format($stats['today']) ?></div>
      <div class="sap-tile-foot">Created today</div>
    </div>
  </div>
</div>

<!-- Filter bar -->
<div class="sap-filterbar">
  <form class="sap-filterbar-row" method="get">
    <div class="sap-search-wrap">
      <i class="bi bi-search"></i>
      <input name="q" placeholder="Search phone, message, ticket, or user…" value="<?= e($q) ?>">
    </div>
    <select name="status" onchange="this.form.submit()">
      <option value="">All statuses</option>
      <option value="SENT"   <?= $filterStatus === 'SENT'   ? 'selected' : '' ?>>Sent</option>
      <option value="QUEUED" <?= $filterStatus === 'QUEUED' ? 'selected' : '' ?>>Queued</option>
      <option value="FAILED" <?= $filterStatus === 'FAILED' ? 'selected' : '' ?>>Failed</option>
    </select>
    <button class="sap-btn sap-btn-emphasized" type="submit">
      <i class="bi bi-funnel"></i> Apply
    </button>
    <?php if ($q || $filterStatus): ?>
      <a href="whatsapp_log.php" class="sap-btn sap-btn-outline">
        <i class="bi bi-x-circle"></i> Clear
      </a>
    <?php endif; ?>
  </form>
</div>

<!-- Toolbar -->
<div class="sap-card-header" style="background:#fff;border-bottom:1px solid var(--sap-border-soft)">
  <div class="title">
    <i class="bi bi-whatsapp" style="color:var(--sap-brand)"></i> Message History
    <span style="font-size:.8125rem;color:var(--sap-text-muted);font-weight:400">
      · <?= count($rows) ?> row<?= count($rows) === 1 ? '' : 's' ?>
    </span>
  </div>
  <div class="d-flex gap-2 flex-wrap">
    <form method="post" class="d-inline"
          onsubmit="return confirm('Dispatch all queued messages now?');">
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
      <input type="hidden" name="action" value="dispatch_now">
      <button class="sap-btn sap-btn-emphasized">
        <i class="bi bi-send"></i> Dispatch Now
      </button>
    </form>
    <?php if ($stats['failed'] > 0): ?>
      <form method="post" class="d-inline"
            onsubmit="return confirm('Re-queue all <?= $stats['failed'] ?> failed messages?');">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="action" value="retry_all_failed">
        <button class="sap-btn sap-btn-outline">
          <i class="bi bi-arrow-clockwise"></i> Retry all failed
        </button>
      </form>
      <form method="post" class="d-inline"
            onsubmit="return confirm('Permanently delete all <?= $stats['failed'] ?> failed messages?');">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="action" value="delete_failed">
        <button class="sap-btn sap-btn-outline" style="color:var(--sap-negative);">
          <i class="bi bi-trash"></i> Delete failed
        </button>
      </form>
    <?php endif; ?>
  </div>
</div>

<!-- Table -->
<div class="sap-card" style="border-radius:0 0 .75rem .75rem">
  <?php if (!$rows): ?>
    <div class="sap-empty">
      <i class="bi bi-whatsapp"></i>
      <div>No WhatsApp messages <?= ($q || $filterStatus) ? 'match your filters' : 'yet' ?>.</div>
      <div style="font-size:.82rem;margin-top:.35rem">
        <?php if ($q || $filterStatus): ?>
          <a href="whatsapp_log.php" class="sap-ticket-num">Clear filters</a> to see all messages.
        <?php else: ?>
          Messages are logged when a ticket triggers a WhatsApp notification.
        <?php endif; ?>
      </div>
    </div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="sap-table" id="waTable">
        <thead>
          <tr>
            <th style="width:130px">When</th>
            <th>User</th>
            <th>Phone</th>
            <th>Ticket</th>
            <th>Message</th>
            <th>Status</th>
            <th>Response</th>
            <th style="text-align:right">Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($rows as $r): ?>
          <tr class="sap-msg-row">
            <td>
              <small><?= e(date('Y-m-d', strtotime($r['created_at']))) ?><br>
              <span class="text-muted"><?= e(date('H:i:s', strtotime($r['created_at']))) ?></span></small>
            </td>
            <td><?= e($r['full_name'] ?? '—') ?></td>
            <td><span class="sap-phone"><?= e($r['phone']) ?></span></td>
            <td>
              <?php if ($r['ticket_number']): ?>
                <a class="sap-ticket-num" href="../admin/ticket_view.php?id=<?= (int)$r['ticket_id'] ?>">
                  <?= e($r['ticket_number']) ?>
                </a>
              <?php else: ?>
                <span class="text-muted">—</span>
              <?php endif; ?>
            </td>
            <td>
              <div class="sap-msg-preview" title="<?= e($r['message']) ?>">
                <?= e(mb_substr($r['message'], 0, 80)) ?><?= mb_strlen($r['message']) > 80 ? '…' : '' ?>
              </div>
              <?php if (mb_strlen($r['message']) > 80): ?>
                <button type="button" class="sap-msg-toggle">Show full</button>
              <?php endif; ?>
              <div class="sap-msg-full"><?= e($r['message']) ?></div>
            </td>
            <td>
              <?php
              $cls = $r['status'] === 'SENT' ? 'is-good'
                   : ($r['status'] === 'QUEUED' ? 'is-critical' : 'is-bad');
              $icon = $r['status'] === 'SENT' ? 'check-circle'
                    : ($r['status'] === 'QUEUED' ? 'clock' : 'x-circle');
              ?>
              <span class="sap-status <?= $cls ?>">
                <i class="bi bi-<?= $icon ?>"></i> <?= e($r['status']) ?>
              </span>
              <?php if ($r['sent_at']): ?>
                <div style="font-size:.68rem;color:var(--sap-text-muted);margin-top:.15rem">
                  <?= e(date('H:i', strtotime($r['sent_at']))) ?>
                </div>
              <?php endif; ?>
            </td>
            <td>
              <div class="sap-response" title="<?= e($r['response'] ?? '') ?>">
                <?= e(mb_substr($r['response'] ?? '', 0, 60)) ?>
              </div>
            </td>
            <td style="text-align:right">
              <?php if ($r['status'] === 'FAILED'): ?>
                <form method="post" class="d-inline">
                  <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                  <input type="hidden" name="action" value="retry">
                  <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                  <button class="sap-btn sap-btn-icon sap-btn-outline" title="Retry">
                    <i class="bi bi-arrow-clockwise"></i>
                  </button>
                </form>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<script>
document.querySelectorAll('.sap-msg-toggle').forEach(btn => {
  btn.addEventListener('click', () => {
    const row = btn.closest('.sap-msg-row');
    const open = row.classList.toggle('open');
    btn.textContent = open ? 'Hide' : 'Show full';
  });
});

document.addEventListener('DOMContentLoaded', () => {
  if (window.jQuery && $.fn.dataTable && document.getElementById('waTable')) {
    const $t = jQuery('#waTable');
    if (!$.fn.dataTable.isDataTable($t)) {
      $t.DataTable({
        paging: true, pageLength: 50, lengthChange: false,
        searching: false, info: true, order: [],
        columnDefs: [{ orderable: false, targets: [4, 6, 7] }],
        language: {
          info: 'Showing _START_ to _END_ of _TOTAL_ messages',
          infoEmpty: 'No messages',
          zeroRecords: 'No matching messages',
          paginate: { previous: '‹', next: '›' },
          emptyTable: 'No WhatsApp messages'
        }
      });
    }
  }
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>