<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('ADMIN');
$pageTitle = 'Departments';
$pdo = db(); $error = $ok = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf($_POST['csrf'] ?? null)) {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'create') {
            $stmt = $pdo->prepare("INSERT INTO departments (department_code,department_name,description) VALUES (?,?,?)");
            $stmt->execute([trim($_POST['code']), trim($_POST['name']), $_POST['description'] ?: null]);
            audit('CreateDepartment','departments',(int)$pdo->lastInsertId(), $_POST['name']);
            $ok = 'Department created.';

        } elseif ($action === 'update') {
            $id = (int)$_POST['id'];
            $stmt = $pdo->prepare("UPDATE departments SET department_code=?, department_name=?, description=? WHERE id=?");
            $stmt->execute([
                trim($_POST['code']),
                trim($_POST['name']),
                $_POST['description'] ?: null,
                $id,
            ]);
            audit('UpdateDepartment','departments',$id,'Updated department ' . $_POST['name']);
            $ok = 'Department updated.';

        } elseif ($action === 'toggle') {
            $id = (int)$_POST['id'];
            $pdo->prepare("UPDATE departments SET status=IF(status='ACTIVE','INACTIVE','ACTIVE') WHERE id=?")
                ->execute([$id]);
            audit('ToggleDepartment','departments',$id,'Toggled');
            $ok = 'Status updated.';

        } elseif ($action === 'delete') {
            $id = (int)$_POST['id'];
            $users = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE department_id=" . $id)->fetchColumn();
            $ticks = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE department_id=" . $id)->fetchColumn();
            if ($users > 0 || $ticks > 0) {
                throw new RuntimeException(
                    "Cannot delete this department: $users user(s) and $ticks ticket(s) still reference it. " .
                    "Deactivate it instead."
                );
            }
            $name = $pdo->query("SELECT department_name FROM departments WHERE id=" . $id)->fetchColumn();
            $pdo->prepare("DELETE FROM departments WHERE id=?")->execute([$id]);
            audit('DeleteDepartment','departments',$id,'Deleted department ' . ($name ?: '#' . $id));
            $ok = 'Department deleted.';
        }
    } catch (Throwable $e) { $error = app_exception_message($e); }
}

$rows = $pdo->query("
    SELECT d.*,
        (SELECT COUNT(*) FROM users   u WHERE u.department_id = d.id) AS user_count,
        (SELECT COUNT(*) FROM tickets t WHERE t.department_id = d.id) AS ticket_count
    FROM departments d
    ORDER BY d.department_name
")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<!-- ================= SAP Fiori Horizon theme ================= -->
<style>
  :root {
    --sap-brand:        #0070f2;
    --sap-brand-dark:   #0057d2;
    --sap-bg:           #f5f6f7;
    --sap-tile:         #ffffff;
    --sap-text:         #1d2d3e;
    --sap-text-muted:   #556b82;
    --sap-border:       #d9d9d9;
    --sap-border-soft:  #eaecf0;
    --sap-positive:     #256f3a;
    --sap-critical:     #e76500;
    --sap-negative:     #aa0808;
    --sap-neutral:      #5b738b;
    --sap-shadow:       0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
    --sap-shadow-hover: 0 0 0 1px rgba(34,53,72,.15), 0 8px 24px 0 rgba(34,53,72,.12);
  }

  body, .main-content {
    background: var(--sap-bg) !important;
    font-family: "72", "72full", Arial, Helvetica, sans-serif !important;
    color: var(--sap-text);
  }

  /* SAP page header */
  .sap-page-header {
    display: flex; align-items: flex-start; justify-content: space-between;
    margin-bottom: 1rem;
  }
  .sap-page-title { font-size: 1.625rem; font-weight: 400; margin: 0; }
  .sap-breadcrumb { font-size: .8125rem; color: var(--sap-text-muted); margin-bottom: .25rem; }

  /* SAP Toolbar */
  .sap-toolbar {
    display: flex; align-items: center; justify-content: space-between;
    background: var(--sap-tile);
    border-radius: .75rem .75rem 0 0;
    padding: .5rem .75rem;
    box-shadow: var(--sap-shadow);
    border-bottom: 1px solid var(--sap-border-soft);
    flex-wrap: wrap; gap: .5rem;
  }
  .sap-toolbar-title {
    font-size: .875rem; font-weight: 600;
    display: flex; align-items: center; gap: .4rem;
  }
  .sap-toolbar-title .bi { color: var(--sap-brand); }
  .sap-toolbar-actions { display: flex; gap: .25rem; align-items: center; flex-wrap: wrap; }

  /* SAP flat button */
  .sap-btn {
    display: inline-flex; align-items: center; gap: .35rem;
    font-size: .8125rem; font-weight: 500;
    border-radius: .5rem;
    padding: .35rem .7rem;
    border: 1px solid transparent;
    background: transparent;
    color: var(--sap-brand);
    transition: background .15s, box-shadow .15s, color .15s;
    cursor: pointer;
    line-height: 1;
    text-decoration: none;
  }
  .sap-btn:hover { background: #eaf4ff; color: var(--sap-brand-dark); }
  .sap-btn:focus-visible { outline: 2px solid var(--sap-brand); outline-offset: 2px; }
  .sap-btn.sap-btn-emphasized {
    background: var(--sap-brand); color: #fff;
    box-shadow: 0 1px 2px rgba(34,53,72,.15);
  }
  .sap-btn.sap-btn-emphasized:hover { background: var(--sap-brand-dark); color: #fff; }
  .sap-btn.sap-btn-negative { color: var(--sap-negative); }
  .sap-btn.sap-btn-negative:hover { background: #fef4f4; color: var(--sap-negative); }
  .sap-btn.sap-btn-icon { padding: .35rem .5rem; }

  /* SAP Table */
  .sap-table-wrap {
    background: var(--sap-tile);
    border-radius: 0 0 .75rem .75rem;
    box-shadow: var(--sap-shadow);
    overflow: hidden;
  }
  table.sap-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    font-size: .8125rem;
    margin: 0;
  }
  table.sap-table thead th {
    background: #f5f6f7;
    border-bottom: 1px solid var(--sap-border);
    font-weight: 600;
    color: var(--sap-text-muted);
    text-align: left;
    padding: .6rem .75rem;
    white-space: nowrap;
    text-transform: uppercase;
    font-size: .7rem;
    letter-spacing: .04em;
  }
  table.sap-table tbody td {
    padding: .65rem .75rem;
    border-bottom: 1px solid var(--sap-border-soft);
    vertical-align: middle;
    color: var(--sap-text);
  }
  table.sap-table tbody tr:last-child td { border-bottom: 0; }
  table.sap-table tbody tr { transition: background .12s; }
  table.sap-table tbody tr:hover { background: #f8fbff; }

  /* SAP ObjectStatus pill */
  .sap-status {
    display: inline-flex; align-items: center; gap: .25rem;
    font-size: .7rem; font-weight: 600;
    padding: .1rem .5rem;
    border-radius: .75rem;
    background: #f1fdf6; color: var(--sap-positive);
    border: 1px solid #d6f0e0;
    white-space: nowrap;
  }
  .sap-status.is-inactive { background: #f4f5f7; color: var(--sap-neutral); border-color: #e4e7eb; }
  .sap-status.is-info     { background: #eaf4ff; color: var(--sap-brand);   border-color: #cfe2f8; }

  /* Count chip */
  .sap-count {
    display: inline-flex; align-items: center; gap: .25rem;
    font-size: .72rem; font-weight: 600;
    padding: .12rem .5rem;
    border-radius: .75rem;
    background: #eef2f7; color: var(--sap-text-muted);
    border: 1px solid #e4e7eb;
    white-space: nowrap;
  }
  .sap-count .bi { font-size: .68rem; }
  .sap-count.has-value { background: #eaf4ff; color: var(--sap-brand); border-color: #cfe2f8; }

  /* Department code chip */
  .sap-code {
    display: inline-block;
    font-family: "72Mono", "Courier New", monospace;
    font-size: .72rem; font-weight: 600;
    padding: .1rem .45rem;
    border-radius: .35rem;
    background: #f4f5f7; color: #354a5f;
    border: 1px solid #e4e7eb;
  }

  /* Department name cell */
  .sap-dept-name {
    font-weight: 600; color: var(--sap-text); line-height: 1.2;
  }
  .sap-dept-desc {
    font-size: .75rem; color: var(--sap-text-muted); margin-top: .15rem;
  }

  /* Empty state */
  .sap-empty {
    text-align: center; padding: 2.5rem 1rem; color: var(--sap-text-muted);
  }
  .sap-empty .bi { font-size: 2rem; opacity: .4; }

  /* Modals */
  .modal-content { border-radius: .75rem; border: 0; box-shadow: var(--sap-shadow-hover); }
  .modal-header  { border-bottom: 1px solid var(--sap-border-soft); }
  .modal-footer  { border-top: 1px solid var(--sap-border-soft); }
  .form-label    { font-size: .8125rem; font-weight: 500; color: var(--sap-text); }
  .form-control:focus, .form-select:focus {
    border-color: var(--sap-brand);
    box-shadow: 0 0 0 2px rgba(0,112,242,.15);
  }

  @media (prefers-reduced-motion: reduce) {
    table.sap-table tbody tr { transition: none !important; }
  }
</style>

<!-- ================= Page header ================= -->
<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb">
      <i class="bi bi-house-door"></i> Home / Administration / <strong>Departments</strong>
    </div>
    <h1 class="sap-page-title">Departments</h1>
  </div>
  <div class="d-flex align-items-center gap-2 flex-wrap">
    <span class="sap-status is-info">
      <i class="bi bi-building"></i> <?= count($rows) ?> department<?= count($rows) === 1 ? '' : 's' ?>
    </span>
    <span class="sap-status is-info">
      <i class="bi bi-check-circle"></i>
      <?= count(array_filter($rows, fn($r) => $r['status'] === 'ACTIVE')) ?> active
    </span>
  </div>
</div>

<?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<?php if ($ok): ?><div class="alert alert-success"><?= $ok ?></div><?php endif; ?>

<!-- ================= Toolbar ================= -->
<div class="sap-toolbar">
  <div class="sap-toolbar-title">
    <i class="bi bi-building"></i> All Departments
  </div>
  <div class="sap-toolbar-actions">
    <button class="sap-btn sap-btn-emphasized"
            data-bs-toggle="modal" data-bs-target="#newDept">
      <i class="bi bi-plus-lg"></i> Add Department
    </button>
  </div>
</div>

<!-- ================= Table ================= -->
<div class="sap-table-wrap">
  <?php if (!$rows): ?>
    <div class="sap-empty">
      <i class="bi bi-building-x"></i>
      <div class="mt-2">No departments yet. Click <strong>Add Department</strong> to begin.</div>
    </div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="sap-table">
        <thead>
          <tr>
            <th>Code</th>
            <th>Department</th>
            <th>Description</th>
            <th>Users</th>
            <th>Tickets</th>
            <th>Status</th>
            <th style="text-align:right;">Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($rows as $d): ?>
          <tr>
            <td><span class="sap-code"><?= e($d['department_code']) ?></span></td>
            <td><div class="sap-dept-name"><?= e($d['department_name']) ?></div></td>
            <td>
              <?php if (!empty($d['description'])): ?>
                <div class="sap-dept-desc"><?= e($d['description']) ?></div>
              <?php else: ?>
                <span class="text-muted">—</span>
              <?php endif; ?>
            </td>
            <td>
              <span class="sap-count <?= (int)$d['user_count'] > 0 ? 'has-value' : '' ?>">
                <i class="bi bi-people"></i> <?= (int)$d['user_count'] ?>
              </span>
            </td>
            <td>
              <span class="sap-count <?= (int)$d['ticket_count'] > 0 ? 'has-value' : '' ?>">
                <i class="bi bi-ticket-detailed"></i> <?= (int)$d['ticket_count'] ?>
              </span>
            </td>
            <td>
              <span class="sap-status <?= $d['status'] === 'ACTIVE' ? '' : 'is-inactive' ?>">
                <i class="bi bi-<?= $d['status'] === 'ACTIVE' ? 'check-circle' : 'circle' ?>"></i>
                <?= e($d['status']) ?>
              </span>
            </td>
            <td style="text-align:right;">
              <div class="d-inline-flex gap-1">
                <button class="sap-btn sap-btn-icon"
                        title="Edit department"
                        data-bs-toggle="modal" data-bs-target="#editDept"
                        data-id="<?= (int)$d['id'] ?>"
                        data-code="<?= e($d['department_code']) ?>"
                        data-name="<?= e($d['department_name']) ?>"
                        data-description="<?= e($d['description'] ?? '') ?>">
                  <i class="bi bi-pencil"></i>
                </button>
                <form method="post" class="d-inline"
                      onsubmit="return confirm('Toggle status for this department?')">
                  <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                  <input type="hidden" name="action" value="toggle">
                  <input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
                  <button class="sap-btn sap-btn-icon"
                          title="<?= $d['status'] === 'ACTIVE' ? 'Deactivate' : 'Activate' ?>">
                    <i class="bi bi-power"></i>
                  </button>
                </form>
                <button class="sap-btn sap-btn-icon sap-btn-negative"
                        title="Delete department"
                        data-bs-toggle="modal" data-bs-target="#deleteDept"
                        data-id="<?= (int)$d['id'] ?>"
                        data-name="<?= e($d['department_name']) ?>"
                        data-users="<?= (int)$d['user_count'] ?>"
                        data-tickets="<?= (int)$d['ticket_count'] ?>">
                  <i class="bi bi-trash"></i>
                </button>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<!-- ================= Add Department Modal ================= -->
<div class="modal fade" id="newDept"><div class="modal-dialog"><div class="modal-content">
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="create">
<div class="modal-header">
  <h5 class="modal-title"><i class="bi bi-plus-circle text-primary"></i> Add Department</h5>
  <button class="btn-close" data-bs-dismiss="modal" type="button"></button>
</div>
<div class="modal-body">
  <div class="mb-3">
    <label class="form-label">Code *</label>
    <input name="code" class="form-control" required maxlength="30"
           placeholder="e.g. FIN, HR, ICT">
    <small class="text-muted">Short unique code used on reports and imports.</small>
  </div>
  <div class="mb-3">
    <label class="form-label">Name *</label>
    <input name="name" class="form-control" required maxlength="150"
           placeholder="e.g. Finance">
  </div>
  <div class="mb-3">
    <label class="form-label">Description</label>
    <textarea name="description" class="form-control" rows="2"
              placeholder="Optional — what this department does"></textarea>
  </div>
</div>
<div class="modal-footer">
  <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Cancel</button>
  <button class="sap-btn sap-btn-emphasized">Create Department</button>
</div>
</form>
</div></div></div>

<!-- ================= Edit Department Modal ================= -->
<div class="modal fade" id="editDept"><div class="modal-dialog"><div class="modal-content">
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="update">
<input type="hidden" name="id" id="editId">
<div class="modal-header">
  <h5 class="modal-title"><i class="bi bi-pencil text-primary"></i> Edit Department</h5>
  <button class="btn-close" data-bs-dismiss="modal" type="button"></button>
</div>
<div class="modal-body">
  <div class="mb-3">
    <label class="form-label">Code *</label>
    <input name="code" id="editCode" class="form-control" required maxlength="30">
    <small class="text-muted">Must be unique across all departments.</small>
  </div>
  <div class="mb-3">
    <label class="form-label">Name *</label>
    <input name="name" id="editName" class="form-control" required maxlength="150">
  </div>
  <div class="mb-3">
    <label class="form-label">Description</label>
    <textarea name="description" id="editDescription" class="form-control" rows="2"></textarea>
  </div>
</div>
<div class="modal-footer">
  <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Cancel</button>
  <button class="sap-btn sap-btn-emphasized">Save Changes</button>
</div>
</form>
</div></div></div>

<!-- ================= Delete Department Modal ================= -->
<div class="modal fade" id="deleteDept"><div class="modal-dialog"><div class="modal-content">
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="delete">
<input type="hidden" name="id" id="dd_id">
<div class="modal-header" style="background:#fef4f4">
  <h5 class="modal-title"><i class="bi bi-exclamation-triangle text-danger"></i> Delete Department</h5>
  <button class="btn-close" data-bs-dismiss="modal" type="button"></button>
</div>
<div class="modal-body">
  <p>Delete <strong id="dd_name">this department</strong>?</p>
  <div class="alert alert-warning small mb-0" id="dd_warning">
    This action cannot be undone.
  </div>
</div>
<div class="modal-footer">
  <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Cancel</button>
  <button class="btn btn-danger"><i class="bi bi-trash"></i> Delete</button>
</div>
</form>
</div></div></div>

<script>
/* Populate Edit Department modal */
document.getElementById('editDept').addEventListener('show.bs.modal', function (ev) {
  const b = ev.relatedTarget;
  document.getElementById('editId').value          = b.dataset.id;
  document.getElementById('editCode').value        = b.dataset.code;
  document.getElementById('editName').value        = b.dataset.name;
  document.getElementById('editDescription').value = b.dataset.description;
});

/* Populate Delete Department modal — dynamic warning based on usage */
document.getElementById('deleteDept').addEventListener('show.bs.modal', function (ev) {
  const b = ev.relatedTarget;
  document.getElementById('dd_id').value = b.dataset.id;
  document.getElementById('dd_name').textContent = b.dataset.name;

  const users   = parseInt(b.dataset.users   || '0', 10);
  const tickets = parseInt(b.dataset.tickets || '0', 10);
  const w = document.getElementById('dd_warning');

  if (users === 0 && tickets === 0) {
    w.innerHTML = 'This department has no users or tickets. It can be safely deleted.';
    w.className = 'alert alert-info small mb-0';
  } else {
    w.innerHTML = 'This department has <strong>' + users +
                  '</strong> user(s) and <strong>' + tickets +
                  '</strong> ticket(s). Deletion will be <strong>blocked</strong> until those are reassigned or the department is deactivated instead.';
    w.className = 'alert alert-warning small mb-0';
  }
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
