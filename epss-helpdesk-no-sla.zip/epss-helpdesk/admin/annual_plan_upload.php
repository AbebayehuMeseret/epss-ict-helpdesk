<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/annual_report.php';

$u = require_role('ADMIN');
$pageTitle = 'Annual Plan Upload';
$pdo = db();
$ok = ''; $error = '';

$ecYear = (int)($_POST['ec_year'] ?? $_GET['year'] ?? annual_ec_current_year());
if ($ecYear < 2010 || $ecYear > 2100) $ecYear = annual_ec_current_year();

$KPI_KEYS = [
    'resolution_pct' => 'Networking & ICT Support (%)',
    'dept_pct'       => 'Supply Chain Technology Coverage (%)',
    'pm_pct'         => 'Server Manageability (%)',
];

/* Upload folder — outside webroot is safer, but keep it simple: */
$uploadDir = __DIR__ . '/../storage/annual_plans';
if (!is_dir($uploadDir) && !@mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) {
    $error = 'Could not create upload folder: ' . $uploadDir;
}

/* ---------- Helpers ---------- */

function apu_extract_csv(string $path): array {
    $fh = fopen($path, 'r');
    if (!$fh) return [];
    $header = fgetcsv($fh);
    $header = array_map(static fn($v) => strtolower(trim((string)$v)), $header ?: []);
    if (!in_array('kpi_key', $header, true) || !in_array('target_value', $header, true)) {
        fclose($fh);
        return [];
    }
    $idx = array_flip($header);
    $out = [];
    while (($line = fgetcsv($fh)) !== false) {
        $key = strtolower(trim((string)($line[$idx['kpi_key']] ?? '')));
        $val = trim((string)($line[$idx['target_value']] ?? ''));
        $unit = isset($idx['unit']) ? trim((string)($line[$idx['unit']] ?? '%')) : '%';
        if ($key !== '' && is_numeric($val)) {
            $out[$key] = ['value' => (float)$val, 'unit' => $unit ?: '%'];
        }
    }
    fclose($fh);
    return $out;
}

/**
 * Parse a "KPI text" file (TXT/DOCX/PDF best-effort) for lines that look like
 * `Name: 95%` or `Name 95`. Nothing is guaranteed — the admin confirms.
 */
function apu_extract_text(string $text): array {
    $aliases = [
        'resolution_pct' => ['networking', 'ict support', 'support request'],
        'dept_pct'       => ['supply chain', 'process supported', 'department'],
        'pm_pct'         => ['server', 'preventive', 'maintenance'],
    ];
    $out = [];
    foreach (preg_split('/\R/u', $text) as $line) {
        $line = trim($line);
        if ($line === '' || !preg_match('/(\d{1,3}(?:\.\d+)?)\s*%?/u', $line, $m)) continue;
        $val = (float)$m[1];
        if ($val < 0 || $val > 100) continue;
        $lower = strtolower($line);
        foreach ($aliases as $key => $needles) {
            foreach ($needles as $n) {
                if (str_contains($lower, $n)) {
                    $out[$key] = ['value' => $val, 'unit' => '%'];
                    break 2;
                }
            }
        }
    }
    return $out;
}

function apu_extract_docx(string $path): string {
    // DOCX is a ZIP of XML; use ZipArchive if available.
    if (!class_exists('ZipArchive')) return '';
    $zip = new ZipArchive();
    if ($zip->open($path) !== true) return '';
    $xml = $zip->getFromName('word/document.xml');
    $zip->close();
    if ($xml === false) return '';
    $xml = str_replace(['</w:p>', '<w:tab/>', '<w:br/>'], ["\n", "\t", "\n"], $xml);
    return trim(strip_tags($xml));
}

function apu_extract_pdf(string $path): string {
    // Best-effort: only works if the PDF has uncompressed text.
    $data = @file_get_contents($path);
    if ($data === false) return '';
    // Extract strings inside parentheses from PDF text operators, e.g. (…)
    if (preg_match_all('/\((?:\\\\.|[^\\\\)])+\)/', $data, $m)) {
        $text = '';
        foreach ($m[0] as $s) {
            $text .= substr($s, 1, -1) . "\n";
        }
        return trim($text);
    }
    return '';
}

/* ---------- POST ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf($_POST['csrf'] ?? null)) {
    $action = $_POST['action'] ?? '';

    try {
        /* --- 1. Upload the plan document --- */
        if ($action === 'upload') {
            if (!isset($_FILES['plan']) || $_FILES['plan']['error'] !== UPLOAD_ERR_OK) {
                throw new RuntimeException('No file uploaded, or upload failed.');
            }
            if ($_FILES['plan']['size'] > 10 * 1024 * 1024) {
                throw new RuntimeException('File too large (max 10 MB).');
            }

            $orig = $_FILES['plan']['name'];
            $tmp  = $_FILES['plan']['tmp_name'];
            $ext  = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
            if ($ext === '') {
                throw new RuntimeException('File has no extension.');
            }

            // Accept any common document type; block executables/scripts.
            $banned = ['exe','bat','cmd','sh','js','php','phtml','php3','php4','php5','phar','scr','vbs','jar','msi','com','ps1'];
            if (in_array($ext, $banned, true)) {
                throw new RuntimeException("Files of type .{$ext} are not allowed.");
            }

            $safeBase = preg_replace('/[^a-z0-9._-]+/i', '_', pathinfo($orig, PATHINFO_FILENAME));
            $stored   = date('Ymd_His') . '_' . $ecYear . '_' . $safeBase . '.' . $ext;
            $dest     = $uploadDir . '/' . $stored;

            if (!move_uploaded_file($tmp, $dest)) {
                throw new RuntimeException('Could not move uploaded file.');
            }

            // Try to parse targets automatically based on file type.
            $extracted = [];
            $parseMode = 'none';

            if (in_array($ext, ['csv', 'txt'], true)) {
                if ($ext === 'csv') {
                    $extracted = apu_extract_csv($dest);
                } else {
                    $extracted = apu_extract_text((string)file_get_contents($dest));
                }
                $parseMode = $extracted ? 'auto' : 'manual';
            } elseif ($ext === 'docx') {
                $text = apu_extract_docx($dest);
                $extracted = apu_extract_text($text);
                $parseMode = $extracted ? 'auto' : 'manual';
            } elseif ($ext === 'pdf') {
                $text = apu_extract_pdf($dest);
                $extracted = apu_extract_text($text);
                $parseMode = $extracted ? 'auto' : 'manual';
            } else {
                // xlsx, doc, jpg, png, etc. → manual entry only
                $parseMode = 'manual';
            }

            // Record the upload itself
            audit('UploadAnnualPlanDocument', 'annual_plan_targets', $ecYear,
                  "Uploaded {$orig} ({$ext}, " . number_format($_FILES['plan']['size'] / 1024, 0)
                  . " KB) for {$ecYear} E.C. → stored as {$stored}");

            // If we extracted targets, save them straight away
            if ($extracted) {
                $n = annual_plan_targets_save($ecYear, $extracted, (int)$u['id'], $orig);
                $ok = "Uploaded {$orig}. Auto-extracted and saved {$n} target(s). "
                    . "Review the values below and adjust if needed.";
            } else {
                $ok = "Uploaded {$orig}. "
                    . ($parseMode === 'manual'
                        ? "Targets couldn't be auto-extracted from a .{$ext} file — enter them below."
                        : "No targets were detected — enter them below.");
            }
        }

        /* --- 2. Save targets (manual or confirmed) --- */
        elseif ($action === 'save_targets') {
            $manual = [];
            foreach ($KPI_KEYS as $k => $lbl) {
                if (isset($_POST['target'][$k]) && $_POST['target'][$k] !== '' && is_numeric($_POST['target'][$k])) {
                    $manual[$k] = ['value' => (float)$_POST['target'][$k], 'unit' => '%'];
                }
            }
            $src = trim((string)($_POST['source_label'] ?? ''));
            $n = annual_plan_targets_save($ecYear, $manual, (int)$u['id'], $src);
            audit('SaveAnnualPlanTargets', 'annual_plan_targets', $ecYear,
                  "Saved {$n} targets for {$ecYear} E.C.");
            $ok = "Saved {$n} target(s).";
        }
    } catch (Throwable $e) {
        $error = app_exception_message($e);
    }
}

/* ---------- Load state ---------- */
$targets = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM annual_plan_targets WHERE ec_year = ? ORDER BY kpi_key");
    $stmt->execute([$ecYear]);
    $targets = $stmt->fetchAll();
} catch (Throwable $e) {
    $error = $error ?: $e->getMessage();
}
$byKey = [];
foreach ($targets as $t) $byKey[$t['kpi_key']] = $t;

/* Recent uploads on disk */
$recent = [];
if (is_dir($uploadDir)) {
    foreach (scandir($uploadDir) as $f) {
        if ($f === '.' || $f === '..') continue;
        if (str_contains($f, '_' . $ecYear . '_')) {
            $recent[] = ['file' => $f, 'mtime' => filemtime($uploadDir . '/' . $f)];
        }
    }
    usort($recent, static fn($a, $b) => $b['mtime'] <=> $a['mtime']);
    $recent = array_slice($recent, 0, 10);
}

include __DIR__ . '/../includes/header.php';
?>

<div class="container py-4" style="max-width:1000px">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <div>
      <h1 class="h4 mb-0">Annual Plan Upload — <?= (int)$ecYear ?> E.C.</h1>
      <p class="text-muted mb-0 small">
        Upload the branch's annual ICT plan. Structured files (CSV / TXT) are auto-parsed.
        Other formats are stored and you confirm targets below.
      </p>
    </div>
    <a href="annual_report.php?year=<?= (int)$ecYear ?>" class="btn btn-outline-secondary btn-sm">
      <i class="bi bi-arrow-left"></i> Back to Annual Report
    </a>
  </div>

  <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
  <?php if ($ok):    ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>

  <!-- ============ 1. Upload document ============ -->
  <div class="card mb-4">
    <div class="card-header"><strong><i class="bi bi-cloud-upload"></i> Upload plan document</strong></div>
    <div class="card-body">
      <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="action" value="upload">
        <div class="row g-3">
          <div class="col-md-3">
            <label class="form-label">E.C. Year</label>
            <input type="number" name="ec_year" class="form-control"
                   min="2010" max="2100" value="<?= (int)$ecYear ?>">
          </div>
          <div class="col-md-9">
            <label class="form-label">Plan file (any document type, max 10 MB)</label>
            <input type="file" name="plan" class="form-control" required
                   accept=".csv,.txt,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.odt,.ods,.rtf,.png,.jpg,.jpeg,.gif,.zip">
            <div class="form-text">
              Accepted: <strong>CSV, TXT, PDF, DOC, DOCX, XLS, XLSX, PPT, PPTX, ODT, ODS, RTF, PNG, JPG, ZIP</strong>.
              Auto-parsing works best for <code>.csv</code>. Other files are stored and you confirm targets below.
            </div>
          </div>
          <div class="col-12">
            <button class="btn btn-primary">
              <i class="bi bi-cloud-upload"></i> Upload
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>

  <!-- ============ 2. Confirm / enter targets ============ -->
  <div class="card mb-4">
    <div class="card-header">
      <strong><i class="bi bi-bullseye"></i> Plan targets for <?= (int)$ecYear ?> E.C.</strong>
    </div>
    <div class="card-body">
      <form method="post">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="action" value="save_targets">
        <input type="hidden" name="ec_year" value="<?= (int)$ecYear ?>">
        <input type="hidden" name="source_label" value="manual-confirm">

        <div class="row g-3">
          <?php foreach ($KPI_KEYS as $k => $lbl):
              $cur = $byKey[$k]['target_value'] ?? ''; ?>
            <div class="col-md-6">
              <label class="form-label"><?= e($lbl) ?></label>
              <input type="number" step="0.01" min="0" max="100"
                     name="target[<?= e($k) ?>]" class="form-control"
                     value="<?= $cur !== '' ? e((string)$cur) : '' ?>"
                     placeholder="—">
            </div>
          <?php endforeach; ?>
          <div class="col-12">
            <button class="btn btn-primary">
              <i class="bi bi-save"></i> Save Targets
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>

  <!-- ============ 3. Recent uploads ============ -->
  <?php if ($recent): ?>
    <div class="card mb-4">
      <div class="card-header"><strong><i class="bi bi-folder2-open"></i> Recent plan uploads</strong></div>
      <table class="table table-sm mb-0">
        <thead><tr>
          <th>File</th><th>Uploaded</th>
        </tr></thead>
        <tbody>
          <?php foreach ($recent as $r): ?>
            <tr>
              <td><code><?= e($r['file']) ?></code></td>
              <td><?= e(date('M j, Y H:i', (int)$r['mtime'])) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>

  <!-- ============ 4. Stored targets ============ -->
  <div class="card">
    <div class="card-header"><strong>Currently stored targets</strong></div>
    <?php if (!$targets): ?>
      <div class="card-body text-muted">No targets uploaded for this year yet.</div>
    <?php else: ?>
      <table class="table table-sm mb-0">
        <thead><tr>
          <th>KPI key</th><th class="text-end">Target</th>
          <th>Unit</th><th>Source</th><th>Updated</th>
        </tr></thead>
        <tbody>
          <?php foreach ($targets as $t): ?>
            <tr>
              <td><code><?= e($t['kpi_key']) ?></code></td>
              <td class="text-end"><?= number_format((float)$t['target_value'], 2) ?></td>
              <td><?= e($t['unit']) ?></td>
              <td><?= e($t['source_file'] ?: '—') ?></td>
              <td><?= e($t['updated_at']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>