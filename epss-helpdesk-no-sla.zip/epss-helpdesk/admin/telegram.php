<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/telegram.php';
$u = require_role('ADMIN');
$pageTitle = 'Telegram Bot';
$pdo = db();
$ok = ''; $error = ''; $info = '';

function tg_mask(string $t): string { return strlen($t) > 12 ? substr($t, 0, 6) . '…' . substr($t, -4) : '••••'; }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'poll_ajax' && verify_csrf($_POST['csrf'] ?? null)) {
    header('Content-Type: application/json');
    try { echo json_encode(['ok' => true, 'n' => tg_poll_once(0)]); }
    catch (Throwable $e) { echo json_encode(['ok' => false, 'error' => app_exception_message($e)]); }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf($_POST['csrf'] ?? null)) {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'save') {
            tg_save_setting('tg_enabled', !empty($_POST['tg_enabled']) ? '1' : '0');
            tg_save_setting('tg_bot_username', ltrim(trim($_POST['tg_bot_username'] ?? ''), '@'));
            tg_save_setting('tg_public_url', rtrim(trim($_POST['tg_public_url'] ?? ''), '/'));
            $newToken = trim($_POST['tg_bot_token'] ?? '');
            if ($newToken !== '') tg_save_setting('tg_bot_token', $newToken);     // blank = keep current
            $newSecret = trim($_POST['tg_webhook_secret'] ?? '');
            if ($newSecret !== '') {
                if (!preg_match('/^[A-Za-z0-9_-]{16,256}$/', $newSecret)) throw new RuntimeException('Secret: 16–256 chars, letters/digits/_/- only.');
                tg_save_setting('tg_webhook_secret', $newSecret);
            }
            audit('SaveTelegramSettings', 'system_settings', 0, 'Telegram settings updated');
            $ok = 'Settings saved.';
            header('Location: telegram.php?saved=1'); exit;

        } elseif ($action === 'getme') {
            $r = tg_api('getMe', []);
            if (!$r['ok']) throw new RuntimeException('Bot check failed: ' . $r['error']);
            $b = json_decode($r['response'], true)['result'] ?? [];
            $info = 'Bot OK — ' . ($b['first_name'] ?? '') . ' (@' . ($b['username'] ?? '') . ')';

        } elseif ($action === 'use_polling') {
            $r = tg_api('deleteWebhook', ['drop_pending_updates' => false]);   // getUpdates is blocked while a webhook exists
            if (!$r['ok']) throw new RuntimeException($r['error']);
            tg_save_setting('tg_mode', 'polling');
            audit('TelegramPolling', 'system_settings', 0, 'Switched to polling mode');
            $ok = 'Polling mode on. Run the worker (see below) or use “Check messages now”.';

        } elseif ($action === 'poll_now') {
            $n = tg_poll_once(0);
            $ok = $n ? "Processed {$n} new message(s)." : 'No new messages.';

        } elseif ($action === 'set_commands') {
            $r = tg_api('setMyCommands', ['commands' => tg_bot_commands()]);
            if (!$r['ok']) throw new RuntimeException('setMyCommands failed: ' . $r['error']);
            tg_save_setting('tg_commands_set', date('Y-m-d H:i'));
            $ok = 'Command menu updated — staff now see /tickets, /pending, /employees, /users, /counts, /help in Telegram.';

        } elseif ($action === 'set_webhook') {
            $base = tg_setting('tg_public_url');
            if (!preg_match('#^https://#i', $base)) throw new RuntimeException('Set a public HTTPS base URL first (Telegram rejects http/localhost).');
            $url = $base . '/api/telegram_webhook.php';
            $r = tg_api('setWebhook', ['url' => $url, 'secret_token' => tg_setting('tg_webhook_secret'),
                                       'allowed_updates' => ['message', 'callback_query'], 'drop_pending_updates' => true]);
            if (!$r['ok']) throw new RuntimeException('setWebhook failed: ' . $r['error']);
            tg_save_setting('tg_mode', 'webhook');
            audit('SetTelegramWebhook', 'system_settings', 0, $url);
            $ok = 'Webhook registered: ' . $url;

        } elseif ($action === 'webhook_info') {
            $r = tg_api('getWebhookInfo', []);
            if (!$r['ok']) throw new RuntimeException($r['error']);
            $w = json_decode($r['response'], true)['result'] ?? [];
            $info = 'Webhook URL: ' . ($w['url'] ?: '(none)') . ' | pending: ' . ($w['pending_update_count'] ?? 0)
                  . (!empty($w['last_error_message']) ? ' | last error: ' . $w['last_error_message'] : '');

        } elseif ($action === 'delete_webhook') {
            $r = tg_api('deleteWebhook', []);
            if (!$r['ok']) throw new RuntimeException($r['error']);
            $ok = 'Webhook removed.';

        } elseif ($action === 'test_user') {
            $uid = (int)($_POST['user_id'] ?? 0);
            $row = $pdo->prepare("SELECT full_name FROM users WHERE id=? AND telegram_chat_id IS NOT NULL");
            $row->execute([$uid]);
            $name = $row->fetchColumn();
            if (!$name) throw new RuntimeException('That user has not linked Telegram.');
            $sent = telegram_notify_user($uid, "🧪 <b>Test message</b>\nHello " . tg_esc($name) . ", Telegram notifications from the EPSS ICT Helpdesk are working.");
            if (!$sent) throw new RuntimeException('Send failed — see the log below.');
            $ok = "Test message sent to {$name}.";

        } elseif ($action === 'unlink_user') {
            $pdo->prepare("UPDATE users SET telegram_chat_id=NULL, telegram_link_token=NULL WHERE id=?")->execute([(int)$_POST['user_id']]);
            audit('UnlinkTelegram', 'users', (int)$_POST['user_id'], 'Admin unlinked Telegram');
            $ok = 'User unlinked.';

        } elseif ($action === 'retry_failed') {
            $r = dispatch_telegram_failed(50);
            $ok = "Retry done — sent {$r['sent']}, failed {$r['failed']}.";
        }
    } catch (Throwable $e) { $error = app_exception_message($e); }
}
if (isset($_GET['saved'])) $ok = 'Settings saved.';

$token  = tg_setting('tg_bot_token');
$tokenSet = $token !== '' && !str_starts_with($token, 'PUT-');
/* ---------------- Bot connections: every staff member, linked or not ---------------- */
$cxRoles = ['ADMIN','BRANCH_MANAGER','TEAM_LEADER','ICT_STAFF','EMPLOYEE'];
$cxRoleLabel = [
    'ADMIN'          => 'Administrator',
    'BRANCH_MANAGER' => 'Branch Manager',
    'TEAM_LEADER'    => 'Team Leader',
    'ICT_STAFF'      => 'ICT Staff',
    'EMPLOYEE'       => 'Employee',
];
$cxRole = $_GET['cx_role'] ?? '';
$cxLink = $_GET['cx_link'] ?? '';
$cxQ    = trim($_GET['cx_q'] ?? '');

$cxWhere  = "WHERE u.status='ACTIVE'";
$cxParams = [];
if ($cxRole !== '' && in_array($cxRole, ['ADMIN','BRANCH_MANAGER','TEAM_LEADER','ICT_STAFF','EMPLOYEE'], true)) {
    $cxWhere .= " AND u.role = ?";
    $cxParams[] = $cxRole;
}
if ($cxQ !== '') {
    $cxWhere .= " AND (u.full_name LIKE ? OR u.username LIKE ? OR u.phone LIKE ? OR d.department_name LIKE ?)";
    $like = "%$cxQ%";
    array_push($cxParams, $like, $like, $like, $like);
}

/* Linked / total for the current role+search (ignores the link filter so the
   numbers stay a stable reference while the admin narrows the table) */
$cxStats = $pdo->prepare("SELECT COUNT(*) total,
                                  SUM(u.telegram_chat_id IS NOT NULL) linked,
                                  SUM(u.telegram_chat_id IS NULL AND (u.phone IS NULL OR u.phone='')) no_phone
                           FROM users u LEFT JOIN departments d ON d.id=u.department_id $cxWhere");
$cxStats->execute($cxParams);
$cxStats = $cxStats->fetch(PDO::FETCH_ASSOC);

$sql = "SELECT u.id, u.full_name, u.username, u.role, u.phone, u.telegram_chat_id,
               d.department_name,
               MAX(l.sent_at) AS last_sent,
               SUM(l.status='FAILED') AS failed_count
        FROM users u
        LEFT JOIN departments d  ON d.id = u.department_id
        LEFT JOIN telegram_log l ON l.user_id = u.id
        $cxWhere
        GROUP BY u.id, u.full_name, u.username, u.role, u.phone,
                 u.telegram_chat_id, d.department_name";
if ($cxLink === 'linked') $sql .= " HAVING u.telegram_chat_id IS NOT NULL";
if ($cxLink === 'none')   $sql .= " HAVING u.telegram_chat_id IS NULL";
$sql .= " ORDER BY (u.telegram_chat_id IS NULL),
                  FIELD(u.role,'ADMIN','BRANCH_MANAGER','TEAM_LEADER','ICT_STAFF','EMPLOYEE'),
                  u.full_name";
$stmt = $pdo->prepare($sql);
$stmt->execute($cxParams);
$users = $stmt->fetchAll();

$log    = $pdo->query("SELECT l.*, u.full_name, t.ticket_number FROM telegram_log l
                       LEFT JOIN users u ON u.id=l.user_id LEFT JOIN tickets t ON t.id=l.ticket_id
                       ORDER BY l.id DESC LIMIT 30")->fetchAll();
$failedCount = (int)$pdo->query("SELECT COUNT(*) FROM telegram_log WHERE status='FAILED'")->fetchColumn();
$guessUrl = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? '') . BASE_URL;

include __DIR__ . '/../includes/header.php';
?>
<div class="mb-3">
  <h1 class="h3 mb-0"><i class="bi bi-telegram"></i> Telegram Bot</h1>
  <div class="text-muted small">Control the notification bot, check linked users and send test messages.</div>
</div>

<?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<?php if ($ok):    ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<?php if ($info):  ?><div class="alert alert-info"><?= e($info) ?></div><?php endif; ?>

<div class="row g-3">
  <div class="col-lg-5">
    <div class="card mb-3">
      <div class="card-header">Bot settings</div>
      <div class="card-body">
        <form method="post">
          <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="action" value="save">
          <div class="form-check form-switch mb-3">
            <input class="form-check-input" type="checkbox" name="tg_enabled" id="tgen" value="1" <?= tg_setting('tg_enabled','0')==='1'?'checked':'' ?>>
            <label class="form-check-label" for="tgen"><strong>Notifications enabled</strong></label>
          </div>
          <div class="mb-3">
            <label class="form-label">Bot token</label>
            <input type="password" name="tg_bot_token" class="form-control" autocomplete="new-password"
                   placeholder="<?= $tokenSet ? 'Saved: ' . e(tg_mask($token)) . ' (leave blank to keep)' : 'Paste token from @BotFather' ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Bot username</label>
            <div class="input-group"><span class="input-group-text">@</span>
              <input type="text" name="tg_bot_username" class="form-control" value="<?= e(tg_setting('tg_bot_username')) ?>"></div>
          </div>
          <div class="mb-3">
            <label class="form-label">Public HTTPS base URL <span class="text-muted">(only for webhook mode — leave empty on a local server)</span></label>
            <input type="text" name="tg_public_url" class="form-control" value="<?= e(tg_setting('tg_public_url')) ?>"
                   placeholder="https://helpdesk.example.com/epss-helpdesk">
            <div class="form-text">Telegram can only reach public HTTPS. This server sees itself as <code><?= e($guessUrl) ?></code>.</div>
          </div>
          <div class="mb-3">
            <label class="form-label">Webhook secret</label>
            <input type="password" name="tg_webhook_secret" class="form-control" autocomplete="new-password" placeholder="Leave blank to keep current">
            <div class="form-text">If you change it, press “Register webhook” again.</div>
          </div>
          <button class="btn btn-primary">Save settings</button>
        </form>
      </div>
    </div>

    <div class="card mb-3">
      <div class="card-header d-flex justify-content-between">
        <span>Bot control</span>
        <span class="badge bg-<?= tg_setting('tg_mode','polling')==='webhook'?'info':'primary' ?>">Mode: <?= e(tg_setting('tg_mode','polling')) ?></span>
      </div>
      <div class="card-body">
        <div class="d-flex flex-wrap gap-2 mb-3">
          <?php foreach ([['getme','Check bot','btn-outline-primary'],['use_polling','Use polling (local server)','btn-success'],
                          ['poll_now','Check messages now','btn-outline-success'],['set_commands','Update command menu','btn-outline-primary'],
                          ['webhook_info','Webhook status','btn-outline-secondary']] as [$a,$l,$c]): ?>
            <form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="action" value="<?= $a ?>"><button class="btn btn-sm <?= $c ?>"><?= $l ?></button></form>
          <?php endforeach; ?>
        </div>
        <div class="form-check form-switch mb-2">
          <input class="form-check-input" type="checkbox" id="autoPoll">
          <label class="form-check-label" for="autoPoll">Auto-check for new messages every 4 s while this page is open</label>
        </div>
        <div class="small text-muted">
          <strong>Local server:</strong> press “Use polling”, then keep <code>tools/start_telegram_worker.bat</code> running
          (or <code>php tools/telegram_worker.php</code>) so linking works any time. Sending notifications never needs the worker.
        </div>
        <details class="mt-2"><summary class="small">What staff can do in the bot (lists)</summary>
          <table class="table table-sm mt-2 mb-0">
            <thead><tr><th>Command</th><th>What it returns</th></tr></thead>
            <tbody class="small">
              <tr><td><code>/tickets</code></td><td>Employee: my tickets · Team Leader: my team · ICT: the ICT queue · Admin: all tickets. Add <code>open</code>, <code>closed</code> or <code>all</code>.</td></tr>
              <tr><td><code>/pending</code></td><td>Tickets waiting on someone — approvals to give (TL), approved not yet picked up (ICT), my tickets awaiting approval (employee).</td></tr>
              <tr><td><code>/employees</code></td><td>Staff directory with role, department, position and phone (phone hidden from plain employees). Filter with <code>/employees finance</code>.</td></tr>
              <tr><td><code>/users</code></td><td><strong>Administrator only.</strong> Everyone connected to the bot — name, role, department, chat id, last message and failed sends. The panel below is the same view plus the people who have <em>not</em> linked.</td></tr>
              <tr><td><code>/counts</code></td><td>How many tickets in each status, scoped to the role.</td></tr>
              <tr><td><code>/me</code>, <code>/help</code>, <code>/menu</code></td><td>Profile, command help, and the button menu.</td></tr>
            </tbody>
          </table>
          <div class="small text-muted mt-2">Press <strong>Update command menu</strong> after changing these so Telegram shows the list in its blue menu.</div>
        </details>

        <details class="mt-2"><summary class="small">Webhook mode (public HTTPS only)</summary>
          <div class="d-flex gap-2 mt-2">
            <?php foreach ([['set_webhook','Register webhook','btn-outline-success'],['delete_webhook','Remove webhook','btn-outline-danger']] as [$a,$l,$c]): ?>
              <form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="action" value="<?= $a ?>"><button class="btn btn-sm <?= $c ?>"><?= $l ?></button></form>
            <?php endforeach; ?>
          </div>
        </details>
      </div>
    </div>
    </div>
  </div>

  <div class="col-lg-7">
    <div class="card mb-3">
      <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
        <span>Bot connections — all staff</span>
        <span class="small">
          <span class="badge bg-success"><?= (int)$cxStats['linked'] ?> linked</span>
          <span class="badge bg-secondary"><?= (int)($cxStats['total'] - $cxStats['linked']) ?> not linked</span>
          <?php if ((int)$cxStats['no_phone']): ?>
            <span class="badge bg-danger"><?= (int)$cxStats['no_phone'] ?> without a phone</span>
          <?php endif; ?>
        </span>
      </div>
      <div class="card-body pb-2">
        <form class="row g-2" method="get">
          <div class="col-12 col-md-5">
            <input type="search" name="cx_q" class="form-control form-control-sm"
                   placeholder="Search name, username, phone or department…"
                   value="<?= e($cxQ) ?>" autocomplete="off">
          </div>
          <div class="col-6 col-md-3">
            <select name="cx_role" class="form-select form-select-sm">
              <option value="">All roles</option>
              <?php foreach ($cxRoles as $r): ?>
                <option value="<?= $r ?>" <?= $cxRole === $r ? 'selected' : '' ?>><?= e($cxRoleLabel[$r]) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-6 col-md-2">
            <select name="cx_link" class="form-select form-select-sm">
              <option value="">Linked + not</option>
              <option value="linked" <?= $cxLink === 'linked' ? 'selected' : '' ?>>Linked</option>
              <option value="none"   <?= $cxLink === 'none'   ? 'selected' : '' ?>>Not linked</option>
            </select>
          </div>
          <div class="col-12 col-md-2 d-flex gap-1">
            <button class="btn btn-sm btn-outline-primary flex-grow-1"><i class="bi bi-search"></i></button>
            <?php if ($cxQ !== '' || $cxRole !== '' || $cxLink !== ''): ?>
              <a class="btn btn-sm btn-outline-secondary" href="telegram.php" title="Clear filters"><i class="bi bi-x-circle"></i></a>
            <?php endif; ?>
          </div>
        </form>
      </div>
      <div class="table-responsive" style="max-height:420px;overflow:auto">
        <table class="table table-sm align-middle mb-0">
          <thead><tr>
            <th style="position:sticky;top:0;background:#fff;z-index:1">Name</th>
            <th style="position:sticky;top:0;background:#fff;z-index:1">Role</th>
            <th style="position:sticky;top:0;background:#fff;z-index:1">Department</th>
            <th style="position:sticky;top:0;background:#fff;z-index:1">Phone (profile)</th>
            <th style="position:sticky;top:0;background:#fff;z-index:1">Telegram</th>
            <th class="text-end" style="position:sticky;top:0;background:#fff;z-index:1">Actions</th>
          </tr></thead>
          <tbody>
          <?php foreach ($users as $r): ?>
            <tr>
              <td><?= e($r['full_name']) ?>
                <div class="small text-muted">@<?= e($r['username']) ?></div></td>
              <td><small><?= e($cxRoleLabel[$r['role']] ?? $r['role']) ?></small></td>
              <td><small><?= $r['department_name'] ? e($r['department_name']) : '—' ?></small></td>
              <td><?= $r['phone'] ? e($r['phone']) : '<span class="text-danger small">missing</span>' ?></td>
              <td>
                <?php if ($r['telegram_chat_id']): ?>
                  <span class="badge bg-success">Linked</span>
                  <div class="small text-muted">
                    <code><?= e((string)$r['telegram_chat_id']) ?></code>
                    <?php if ($r['last_sent']): ?>
                      · last msg <?= e(date('d M Y H:i', strtotime($r['last_sent']))) ?>
                    <?php endif; ?>
                    <?php if ((int)$r['failed_count']): ?>
                      · <span class="text-warning"><?= (int)$r['failed_count'] ?> failed send<?= (int)$r['failed_count'] === 1 ? '' : 's' ?></span>
                    <?php endif; ?>
                  </div>
                <?php elseif (!$r['phone']): ?>
                  <span class="badge bg-secondary">Not linked</span>
                  <div class="small text-danger">No phone on profile — the bot matches by phone, so add one first.</div>
                <?php else: ?>
                  <span class="badge bg-secondary">Not linked</span>
                  <div class="small text-muted">Has not sent /start to the bot yet.</div>
                <?php endif; ?>
              </td>
              <td class="text-end">
                <?php if ($r['telegram_chat_id']): ?>
                  <form method="post" class="d-inline"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="test_user"><input type="hidden" name="user_id" value="<?= (int)$r['id'] ?>">
                    <button class="btn btn-sm btn-outline-primary">Send test</button></form>
                  <form method="post" class="d-inline" onsubmit="return confirm('Unlink this user?')"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="unlink_user"><input type="hidden" name="user_id" value="<?= (int)$r['id'] ?>">
                    <button class="btn btn-sm btn-outline-danger">Unlink</button></form>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; if (!$users): ?>
            <tr><td colspan="6" class="text-center text-muted py-3">
              <?= ($cxQ !== '' || $cxRole !== '' || $cxLink !== '')
                    ? 'No staff match these filters.'
                    : 'No active users yet.' ?>
            </td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
      <div class="card-footer small text-muted">
        To link: the user opens <strong>@<?= e(tg_setting('tg_bot_username')) ?></strong>, sends /start and taps “Share my phone number”.
        The number must match the phone saved on their profile. Linked staff and employees can also confirm a resolved ticket from the bot.
      </div>
    </div>

    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        <span>Recent messages</span>
        <?php if ($failedCount): ?>
          <form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="retry_failed">
            <button class="btn btn-sm btn-outline-warning">Retry <?= $failedCount ?> failed</button></form>
        <?php endif; ?>
      </div>
      <div class="table-responsive">
        <table class="table table-sm mb-0">
          <thead><tr><th>Time</th><th>To</th><th>Ticket</th><th>Status</th><th>Detail</th></tr></thead>
          <tbody>
          <?php foreach ($log as $l): ?>
            <tr>
              <td class="small"><?= e($l['created_at']) ?></td>
              <td><?= e($l['full_name'] ?? '—') ?></td>
              <td><?= e($l['ticket_number'] ?? '—') ?></td>
              <td><span class="badge bg-<?= $l['status']==='SENT'?'success':'danger' ?>"><?= e($l['status']) ?></span></td>
              <td class="small text-muted"><?= $l['status']==='FAILED' ? e(mb_substr((string)$l['response'],0,80)) : '' ?></td>
            </tr>
          <?php endforeach; if (!$log): ?><tr><td colspan="5" class="text-center text-muted py-3">No messages yet.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<script>
(function () {
  const box = document.getElementById('autoPoll'); let timer = null;
  const csrf = <?= json_encode(csrf_token()) ?>;
  async function poll() {
    try {
      const fd = new FormData(); fd.append('csrf', csrf); fd.append('action', 'poll_ajax');
      const r = await (await fetch('telegram.php', {method: 'POST', body: fd})).json();
      if (r.ok && r.n > 0) location.reload();
    } catch (e) {}
  }
  box.addEventListener('change', () => {
    if (box.checked) { poll(); timer = setInterval(poll, 4000); sessionStorage.setItem('tgAuto', '1'); }
    else { clearInterval(timer); sessionStorage.removeItem('tgAuto'); }
  });
  if (sessionStorage.getItem('tgAuto')) { box.checked = true; box.dispatchEvent(new Event('change')); }
})();
</script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
