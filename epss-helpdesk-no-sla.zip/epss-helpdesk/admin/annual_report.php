<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/annual_report.php';

$u = require_role('ADMIN');
$pageTitle = 'Annual ICT Report';
$pdo = db();

$ecYear = (int)($_POST['ec_year'] ?? $_GET['year'] ?? annual_ec_current_year());
if ($ecYear < 2010 || $ecYear > 2100) {
    $ecYear = annual_ec_current_year();
}

$ok = '';
$error = '';
$posted = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $posted = [
        'presenter'       => trim((string)($_POST['presenter'] ?? '')),
        'report_date'     => (string)($_POST['report_date'] ?? date('Y-m-d')),
        'overview'        => trim((string)($_POST['overview'] ?? '')),
        'work_done_notes' => trim((string)($_POST['work_done_notes'] ?? '')),
        'impact_notes'    => trim((string)($_POST['impact_notes'] ?? '')),
        'challenges'      => trim((string)($_POST['challenges'] ?? '')),
        'recommendations' => trim((string)($_POST['recommendations'] ?? '')),
        'conclusion'      => trim((string)($_POST['conclusion'] ?? '')),
    ];
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $posted['report_date'])) {
        $posted['report_date'] = date('Y-m-d');
    }

    if (!verify_csrf($_POST['csrf'] ?? null)) {
        $error = 'Your session expired. Please try again.';
    } else {
        try {
            annual_report_save($ecYear, $posted, (int)$u['id']);
            audit('UpdateAnnualReport', 'annual_ict_reports', $ecYear,
                  "Annual ICT report for {$ecYear} E.C.");
            $ok = 'Report details saved.';

            if (($_POST['download'] ?? '') === 'pdf') {
                redirect(BASE_URL . '/admin/annual_report_pdf.php?year=' . $ecYear);
            }
        } catch (Throwable $e) {
            $error = app_exception_message($e);
        }
    }
}

$narr = annual_report_values($ecYear);
if ($posted !== null && $error !== '' && !empty($_POST)) {
    foreach (['presenter', 'report_date', 'overview', 'work_done_notes', 'impact_notes',
              'challenges', 'recommendations', 'conclusion'] as $key) {
        if (isset($posted[$key])) $narr[$key] = $posted[$key];
    }
}

$report = annual_report_data($ecYear, $narr);
$slides = annual_report_slide_html($report);

$currentEc = annual_ec_current_year();
$years = range($currentEc - 5, $currentEc + 1);
if (!in_array($ecYear, $years, true)) {
    $years[] = $ecYear;
    sort($years);
}

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:#0070f2; --sap-brand-dark:#0057d2;
    --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500;
    --sap-negative:#aa0808;
    --sap-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
  }
  body, .main-content { background: var(--sap-bg) !important;
    font-family: "72","72full",Arial,Helvetica,sans-serif !important; color: var(--sap-text); }

  .sap-page-header { display:flex; align-items:flex-start; justify-content:space-between;
    margin-bottom:1rem; flex-wrap:wrap; gap:.75rem; }
  .sap-page-title { font-size:1.625rem; font-weight:400; margin:0; }
  .sap-breadcrumb { font-size:.8125rem; color:var(--sap-text-muted); margin-bottom:.25rem; }

  .sap-message { display:flex; align-items:flex-start; gap:.6rem; padding:.75rem 1rem;
    border-radius:.5rem; font-size:.8125rem; line-height:1.4; margin-bottom:.75rem;
    border-left:3px solid; }
  .sap-message.is-success { background:#f1fdf6; color:var(--sap-positive); border-left-color:var(--sap-positive); }
  .sap-message.is-error   { background:#fef4f4; color:var(--sap-negative); border-left-color:var(--sap-negative); }
  .sap-message.is-info    { background:#eaf4ff; color:#0a4a9c; border-left-color:var(--sap-brand); }

  .sap-card { background:var(--sap-tile); border-radius:.75rem; box-shadow:var(--sap-shadow);
    overflow:hidden; margin-bottom:1rem; }
  .sap-card-header { padding:.85rem 1.15rem; border-bottom:1px solid var(--sap-border-soft);
    font-size:.875rem; font-weight:600; display:flex; align-items:center; gap:.45rem; }
  .sap-card-header .bi { color:var(--sap-brand); }
  .sap-card-body { padding:1rem 1.15rem; }

  .sap-form-label { display:block; font-size:.7rem; text-transform:uppercase;
    letter-spacing:.04em; font-weight:600; color:var(--sap-text-muted); margin-bottom:.3rem; }
  .sap-form-control { width:100%; font-size:.86rem; font-family:inherit; color:var(--sap-text);
    background:#fff; border:1px solid var(--sap-border); border-radius:.5rem;
    padding:.5rem .7rem; outline:none; resize:vertical; }
  .sap-form-control:focus { border-color:var(--sap-brand); box-shadow:0 0 0 3px rgba(0,112,242,.15); }

  .sap-btn { display:inline-flex; align-items:center; gap:.4rem; font-size:.8125rem;
    font-weight:500; border-radius:.5rem; padding:.5rem .9rem; border:1px solid transparent;
    background:transparent; color:var(--sap-brand); cursor:pointer; line-height:1;
    text-decoration:none; white-space:nowrap; font-family:inherit; }
  .sap-btn:hover { background:#eaf4ff; color:var(--sap-brand-dark); }
  .sap-btn.sap-btn-emphasized { background:var(--sap-brand); color:#fff; }
  .sap-btn.sap-btn-emphasized:hover { background:var(--sap-brand-dark); color:#fff; }
  .sap-btn.sap-btn-outline { border-color:var(--sap-border); background:#fff; }

  .ar-stats { display:grid; grid-template-columns:repeat(auto-fit,minmax(165px,1fr));
    gap:.75rem; margin-bottom:1rem; }
  .ar-stat { background:#fff; border-radius:.75rem; box-shadow:var(--sap-shadow); padding:.9rem 1rem; }
  .ar-stat-label { font-size:.66rem; text-transform:uppercase; letter-spacing:.05em;
    font-weight:600; color:var(--sap-text-muted); }
  .ar-stat-value { font-size:1.45rem; font-weight:600; color:var(--sap-brand-dark); line-height:1.2; }
  .ar-stat-sub { font-size:.72rem; color:var(--sap-text-muted); }

  .ar-period { background:#f5f8fc; border:1px solid #dbe7f7; border-radius:.5rem;
    padding:.55rem .7rem; font-size:.8rem; }

  .ar-actions { display:flex; gap:.6rem; flex-wrap:wrap; align-items:center; margin-bottom:1.25rem; }

  .ar-preview-head { display:flex; align-items:center; justify-content:space-between;
    gap:.75rem; flex-wrap:wrap; margin:1.5rem 0 .75rem; }
  .ar-preview-title { font-size:1.05rem; font-weight:600; margin:0; }
  .ar-preview-note { font-size:.75rem; color:var(--sap-text-muted); }

  /* ---------------- Slide preview ---------------- */
  .report-preview { background:#e6ebf1; border-radius:.85rem; padding:1.25rem; }
  .report-preview .slide { position:relative; width:100%; max-width:1000px; aspect-ratio:16/9;
    margin:0 auto 1.25rem; padding:3rem 3.5rem; background:#fff; color:#1d2d3e;
    border-radius:.6rem; box-shadow:0 4px 18px rgba(34,53,72,.14); overflow:hidden;
    box-sizing:border-box; }
  .report-preview .slide:last-child { margin-bottom:0; }
  .report-preview .slide-cover { background:linear-gradient(135deg,#0a2a5e 0%,#123f7a 100%); color:#fff; }
  .cover-kicker { font-size:.72rem; letter-spacing:.18em; text-transform:uppercase;
    color:#9fc3ff; font-weight:600; }
  .cover-title { font-size:2.7rem; font-weight:700; line-height:1.05; margin:.9rem 0 0; }
  .cover-year { font-size:1.9rem; font-weight:600; color:#ffd166; margin-top:.55rem; }
  .cover-branch { font-size:1rem; color:#dbe7f7; margin-top:.45rem; }
  .cover-meta { position:absolute; left:3.5rem; right:3.5rem; bottom:2.2rem;
    border-top:1px solid #3c5f92; padding-top:.9rem; border-collapse:collapse; }
  .cover-meta td { width:50%; vertical-align:top; }
  .cover-meta span { display:block; font-size:.6rem; letter-spacing:.12em;
    text-transform:uppercase; color:#9fc3ff; margin-bottom:.25rem; }
  .cover-meta strong { font-size:1rem; font-weight:500; }

  .report-preview .slide-eyebrow { font-size:.66rem; letter-spacing:.14em;
    text-transform:uppercase; color:var(--sap-brand); font-weight:700; }
  .report-preview h2 { font-size:1.65rem; font-weight:600; margin:.35rem 0 1.1rem;
    color:#0a2a5e; border-left:5px solid var(--sap-brand); padding-left:.85rem; line-height:1.15; }
  .slide-list { margin:0; padding-left:1.2rem; }
  .slide-list li { font-size:.92rem; line-height:1.55; margin-bottom:.55rem; }
  .slide-caption { font-size:.72rem; color:var(--sap-text-muted); margin-top:.85rem; }
  .slide-foot { position:absolute; left:3.5rem; right:3.5rem; bottom:1rem;
    border-top:1px solid var(--sap-border-soft); padding-top:.4rem;
    font-size:.62rem; color:#7a8ba0; }

  .dept-table { width:100%; border-collapse:collapse; }
  .dept-table td { width:50%; padding:.5rem .75rem; font-size:.9rem;
    border-bottom:1px solid var(--sap-border-soft); }

  .kpi-table { width:100%; border-collapse:separate; border-spacing:.55rem; }
  .kpi-card { width:50%; background:#f5f8fc; border-left:4px solid var(--sap-brand);
    padding:.8rem 1rem; vertical-align:top; }
  .kpi-value { font-size:1.9rem; font-weight:700; color:var(--sap-brand); line-height:1; }
  .kpi-label { font-size:.78rem; font-weight:600; margin-top:.35rem; line-height:1.3; }
  .kpi-note { font-size:.66rem; color:var(--sap-text-muted); margin-top:.25rem; }

  .stat-strip { width:100%; border-collapse:collapse; margin-bottom:1rem; }
  .stat-strip td { background:#eaf4ff; border-right:4px solid #fff;
    text-align:center; padding:.55rem .3rem; }
  .stat-strip td:last-child { border-right:0; }
  .stat-strip strong { display:block; font-size:1.15rem; color:var(--sap-brand-dark); line-height:1; }
  .stat-strip span { display:block; font-size:.58rem; color:var(--sap-text-muted);
    margin-top:.2rem; text-transform:uppercase; letter-spacing:.05em; }

  .closing-line { margin-top:1rem; font-size:.82rem; color:#0a2a5e;
    border-top:1px solid var(--sap-border-soft); padding-top:.6rem; }

  @media (max-width: 900px) {
    .report-preview .slide { aspect-ratio:auto; min-height:420px; padding:2rem; }
    .report-preview h2 { font-size:1.35rem; }
    .cover-title { font-size:2rem; }
    .cover-meta { left:2rem; right:2rem; bottom:1.5rem; }
    .slide-foot { left:2rem; right:2rem; }
  }
</style>

<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb"><i class="bi bi-house-door"></i> Home / <strong>Annual ICT Report</strong></div>
    <h1 class="sap-page-title">Annual ICT Report</h1>
  </div>
  <form method="get" class="d-flex align-items-center gap-2">
    <label for="year" class="text-nowrap" style="font-size:.78rem;color:var(--sap-text-muted)">E.C. year</label>
    <select id="year" name="year" class="sap-form-control" style="width:auto"
            onchange="this.form.submit()">
      <?php foreach ($years as $y): ?>
        <option value="<?= (int)$y ?>" <?= $y === $ecYear ? 'selected' : '' ?>><?= (int)$y ?> E.C.</option>
      <?php endforeach; ?>
    </select>
  </form>
</div>

<?php if ($error): ?>
  <div class="sap-message is-error"><i class="bi bi-exclamation-circle"></i><span><?= e($error) ?></span></div>
<?php endif; ?>
<?php if ($ok): ?>
  <div class="sap-message is-success"><i class="bi bi-check-circle"></i><span><?= e($ok) ?></span></div>
<?php endif; ?>

<div class="sap-message is-info">
  <i class="bi bi-info-circle"></i>
  <span>
    Figures are calculated live from this helpdesk for
    <strong><?= e(date('M j, Y', strtotime($report['range_start']))) ?></strong> –
    <strong><?= e(date('M j, Y', strtotime($report['range_end']))) ?></strong>
    (<?= (int)$ecYear ?> E.C.). Narrative sections accept one bullet per line.
  </span>
</div>

<div class="ar-stats">
  <div class="ar-stat">
    <div class="ar-stat-label">Support requests</div>
    <div class="ar-stat-value"><?= number_format((float)$report['tickets_total']) ?></div>
    <div class="ar-stat-sub"><?= number_format((float)$report['tickets_closed']) ?> completed</div>
  </div>
  <div class="ar-stat">
    <div class="ar-stat-label">Avg resolution time</div>
    <div class="ar-stat-value"><?= number_format((float)$report['avg_hours'], 1) ?> hrs</div>
    <div class="ar-stat-sub">From approval to closure</div>
  </div>
  <div class="ar-stat">
    <div class="ar-stat-label">PM completion</div>
    <div class="ar-stat-value"><?= number_format((float)$report['pm_pct'], 1) ?>%</div>
    <div class="ar-stat-sub"><?= (int)$report['pm_approved'] ?> approved checklists</div>
  </div>
  <div class="ar-stat">
    <div class="ar-stat-label">Department coverage</div>
    <div class="ar-stat-value"><?= (int)$report['dept_covered'] ?> / <?= (int)$report['dept_active'] ?></div>
    <div class="ar-stat-sub">Active departments supported</div>
  </div>
</div>

<form method="post">
  <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
  <input type="hidden" name="ec_year" value="<?= (int)$ecYear ?>">

  <div class="sap-card">
    <div class="sap-card-header"><i class="bi bi-sliders"></i> Report details</div>
    <div class="sap-card-body">
      <div class="row g-3">
        <div class="col-md-5">
          <label class="sap-form-label">Presented by</label>
          <input name="presenter" class="sap-form-control"
                 value="<?= e($narr['presenter']) ?>" maxlength="150">
        </div>
        <div class="col-md-3">
          <label class="sap-form-label">Report date</label>
          <input type="date" name="report_date" class="sap-form-control"
                 value="<?= e($narr['report_date']) ?>">
        </div>
        <div class="col-md-4">
          <label class="sap-form-label">Reporting period</label>
          <div class="ar-period">
            <?= e(date('M j, Y', strtotime($report['range_start']))) ?> –
            <?= e(date('M j, Y', strtotime($report['range_end']))) ?><br>
            <strong><?= (int)$ecYear ?> E.C.</strong>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="sap-card">
    <div class="sap-card-header"><i class="bi bi-pencil-square"></i> Narrative sections</div>
    <div class="sap-card-body">
      <div class="row g-3">
        <div class="col-lg-6">
          <label class="sap-form-label">Overview of ICT support</label>
          <textarea name="overview" class="sap-form-control" rows="5"><?= e($narr['overview']) ?></textarea>
        </div>
        <div class="col-lg-6">
          <label class="sap-form-label">Challenges encountered</label>
          <textarea name="challenges" class="sap-form-control" rows="5"><?= e($narr['challenges']) ?></textarea>
        </div>
        <div class="col-lg-6">
          <label class="sap-form-label">Additional work done notes (optional)</label>
          <textarea name="work_done_notes" class="sap-form-control" rows="4"
                    placeholder="One bullet per line; added after the calculated work summary"><?= e($narr['work_done_notes']) ?></textarea>
        </div>
        <div class="col-lg-6">
          <label class="sap-form-label">Additional impact notes (optional)</label>
          <textarea name="impact_notes" class="sap-form-control" rows="4"
                    placeholder="One bullet per line; added after the calculated impact summary"><?= e($narr['impact_notes']) ?></textarea>
        </div>
        <div class="col-lg-6">
          <label class="sap-form-label">Recommendations and future plans</label>
          <textarea name="recommendations" class="sap-form-control" rows="6"><?= e($narr['recommendations']) ?></textarea>
        </div>
        <div class="col-lg-6">
          <label class="sap-form-label">Conclusion</label>
          <textarea name="conclusion" class="sap-form-control" rows="6"><?= e($narr['conclusion']) ?></textarea>
        </div>
      </div>
    </div>
  </div>

  <div class="ar-actions">
    <button type="submit" class="sap-btn sap-btn-emphasized">
      <i class="bi bi-check2-circle"></i> Save &amp; Preview
    </button>
    <button type="submit" name="download" value="pdf" class="sap-btn sap-btn-outline">
      <i class="bi bi-file-earmark-pdf"></i> Save &amp; Download PDF
    </button>
    <a href="<?= BASE_URL ?>/admin/annual_report_pdf.php?year=<?= (int)$ecYear ?>"
       class="sap-btn sap-btn-outline" target="_blank" rel="noopener">
      <i class="bi bi-download"></i> Download saved PDF
    </a>
  </div>
</form>

<div class="ar-preview-head">
  <div>
    <h2 class="ar-preview-title">Report preview — <?= (int)$ecYear ?> E.C.</h2>
    <div class="ar-preview-note">Nine slides, matching the annual ICT report format.</div>
  </div>
</div>

<div class="report-preview">
  <?= $slides ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
