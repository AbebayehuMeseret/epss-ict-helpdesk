<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('ADMIN');
$pageTitle = 'Priorities';
$pdo = db(); $ok = ''; $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf($_POST['csrf'] ?? null)) {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'create') {
            $pdo->prepare("INSERT INTO priorities (name,level,color)
                           VALUES (?,?,?)")
                ->execute([
                    trim($_POST['name']),
                    (int)$_POST['level'],
                    $_POST['color'],
                ]);
            $newId = (int)$pdo->lastInsertId();
            audit('CreatePriority','priorities',$newId,'Created priority ' . $_POST['name']);
            $ok = 'Priority added.';

        } elseif ($action === 'update') {
            $id = (int)$_POST['id'];
            $pdo->prepare("UPDATE priorities SET name=?, level=?, color=? WHERE id=?")
                ->execute([
                    trim($_POST['name']),
                    (int)$_POST['level'],
                    $_POST['color'],
                    $id,
                ]);
            audit('UpdatePriority','priorities',$id,'Updated priority ' . $_POST['name']);
            $ok = 'Priority updated.';

        } elseif ($action === 'toggle') {
            $id = (int)$_POST['id'];
            $pdo->prepare("UPDATE priorities SET status=IF(status='ACTIVE','INACTIVE','ACTIVE') WHERE id=?")
                ->execute([$id]);
            audit('TogglePriority','priorities',$id,'Status toggled');
            $ok = 'Status updated.';

        } elseif ($action === 'delete') {
            $id = (int)$_POST['id'];
            $used = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE priority_id=" . $id)->fetchColumn();
            if ($used > 0) {
                throw new RuntimeException(
                    "Cannot delete this priority: $used ticket(s) still reference it. " .
                    "Deactivate it instead."
                );
            }
            $name = $pdo->query("SELECT name FROM priorities WHERE id=" . $id)->fetchColumn();
            $pdo->prepare("DELETE FROM priorities WHERE id=?")->execute([$id]);
            audit('DeletePriority','priorities',$id,'Deleted priority ' . ($name ?: '#' . $id));
            $ok = 'Priority deleted.';
        }
    } catch (Throwable $e) { $error = app_exception_message($e); }
}

$rows = $pdo->query("
    SELECT p.*,
           (SELECT COUNT(*) FROM tickets t WHERE t.priority_id = p.id) AS ticket_count
    FROM priorities p
    ORDER BY p.level
")->fetchAll();

/* Colour token → SAP Horizon-adjacent hex (used for swatch + badge) */
function prio_hex(string $color): string {
    return match ($color) {
        'danger'    => '#aa0808',
        'warning'   => '#e76500',
        'info'      => '#0070f2',
        'primary'   => '#0057d2',
        'success'   => '#256f3a',
        'secondary' => '#5b738b',
        'dark'      => '#354a5f',
        default     => '#5b738b',
    };
}

/* Human-friendly duration: 90 → "1 h 30 m" */
function human_minutes(int $m): string {
    if ($m < 60)  return $m . ' min';
    $h = intdiv($m, 60);
    $r = $m % 60;
    return $r ? "{$h} h {$r} min" : "{$h} h";
}

include __DIR__ . '/../includes/header.php';
?>

<!-- ================= SAP Fiori Horizon theme ================= -->
<style>
  :root {
    --sap-brand:        #0070f2;
    --sap-brand-dark:   #0057d2;
    --sap-bg:           #f5f6f7;
    --sap-tile:         #ffffff;
    --sap-text:         #1d2d3e;
    --sap-text-muted:   #556b82;
    --sap-border:       #d9d9d9;
    --sap-border-soft:  #eaecf0;
    --sap-positive:     #256f3a;
    --sap-critical:     #e76500;
    --sap-negative:     #aa0808;
    --sap-neutral:      #5b738b;
    --sap-shadow:       0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
    --sap-shadow-hover: 0 0 0 1px rgba(34,53,72,.15), 0 8px 24px 0 rgba(34,53,72,.12);
  }

  body, .main-content {
    background: var(--sap-bg) !important;
    font-family: "72", "72full", Arial, Helvetica, sans-serif !important;
    color: var(--sap-text);
  }

  .sap-page-header {
    display: flex; align-items: flex-start; justify-content: space-between;
    margin-bottom: 1rem;
  }
  .sap-page-title { font-size: 1.625rem; font-weight: 400; margin: 0; }
  .sap-breadcrumb { font-size: .8125rem; color: var(--sap-text-muted); margin-bottom: .25rem; }

  /* SAP Toolbar */
  .sap-toolbar {
    display: flex; align-items: center; justify-content: space-between;
    background: var(--sap-tile);
    border-radius: .75rem .75rem 0 0;
    padding: .5rem .75rem;
    box-shadow: var(--sap-shadow);
    border-bottom: 1px solid var(--sap-border-soft);
    flex-wrap: wrap; gap: .5rem;
  }
  .sap-toolbar-title {
    font-size: .875rem; font-weight: 600;
    display: flex; align-items: center; gap: .4rem;
  }
  .sap-toolbar-title .bi { color: var(--sap-brand); }
  .sap-toolbar-actions { display: flex; gap: .25rem; align-items: center; flex-wrap: wrap; }

  /* SAP flat button */
  .sap-btn {
    display: inline-flex; align-items: center; gap: .35rem;
    font-size: .8125rem; font-weight: 500;
    border-radius: .5rem;
    padding: .35rem .7rem;
    border: 1px solid transparent;
    background: transparent;
    color: var(--sap-brand);
    transition: background .15s, box-shadow .15s, color .15s;
    cursor: pointer;
    line-height: 1;
    text-decoration: none;
  }
  .sap-btn:hover { background: #eaf4ff; color: var(--sap-brand-dark); }
  .sap-btn:focus-visible { outline: 2px solid var(--sap-brand); outline-offset: 2px; }
  .sap-btn.sap-btn-emphasized {
    background: var(--sap-brand); color: #fff;
    box-shadow: 0 1px 2px rgba(34,53,72,.15);
  }
  .sap-btn.sap-btn-emphasized:hover { background: var(--sap-brand-dark); color: #fff; }
  .sap-btn.sap-btn-negative { color: var(--sap-negative); }
  .sap-btn.sap-btn-negative:hover { background: #fef4f4; color: var(--sap-negative); }
  .sap-btn.sap-btn-icon { padding: .35rem .5rem; }

  /* SAP Table */
  .sap-table-wrap {
    background: var(--sap-tile);
    border-radius: 0 0 .75rem .75rem;
    box-shadow: var(--sap-shadow);
    overflow: hidden;
  }
  table.sap-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    font-size: .8125rem;
    margin: 0;
  }
  table.sap-table thead th {
    background: #f5f6f7;
    border-bottom: 1px solid var(--sap-border);
    font-weight: 600;
    color: var(--sap-text-muted);
    text-align: left;
    padding: .6rem .75rem;
    white-space: nowrap;
    text-transform: uppercase;
    font-size: .7rem;
    letter-spacing: .04em;
  }
  table.sap-table tbody td {
    padding: .7rem .75rem;
    border-bottom: 1px solid var(--sap-border-soft);
    vertical-align: middle;
    color: var(--sap-text);
  }
  table.sap-table tbody tr:last-child td { border-bottom: 0; }
  table.sap-table tbody tr { transition: background .12s; }
  table.sap-table tbody tr:hover { background: #f8fbff; }

  /* Priority chip */
  .sap-prio {
    display: inline-flex; align-items: center; gap: .4rem;
    font-size: .72rem; font-weight: 600;
    padding: .2rem .6rem;
    border-radius: .75rem;
    color: #fff;
    white-space: nowrap;
  }
  .sap-prio .swatch {
    width: 8px; height: 8px; border-radius: 50%;
    background: rgba(255,255,255,.7);
  }

  /* Level chip */
  .sap-level {
    display: inline-flex; align-items: center; justify-content: center;
    width: 22px; height: 22px; border-radius: 50%;
    background: #eef2f7; color: var(--sap-text-muted);
    font-size: .7rem; font-weight: 700;
    border: 1px solid #e4e7eb;
  }

  /* Time cell */
  .sap-time {
    font-family: "72Mono", "Courier New", monospace;
    font-weight: 600; color: var(--sap-text);
  }
  .sap-time-sub {
    font-size: .7rem; color: var(--sap-text-muted); margin-top: .1rem;
  }

  /* ObjectStatus pill */
  .sap-status {
    display: inline-flex; align-items: center; gap: .25rem;
    font-size: .7rem; font-weight: 600;
    padding: .1rem .5rem;
    border-radius: .75rem;
    background: #f1fdf6; color: var(--sap-positive);
    border: 1px solid #d6f0e0;
    white-space: nowrap;
  }
  .sap-status.is-inactive { background: #f4f5f7; color: var(--sap-neutral); border-color: #e4e7eb; }
  .sap-status.is-info     { background: #eaf4ff; color: var(--sap-brand);   border-color: #cfe2f8; }

  /* Count chip */
  .sap-count {
    display: inline-flex; align-items: center; gap: .25rem;
    font-size: .72rem; font-weight: 600;
    padding: .12rem .5rem;
    border-radius: .75rem;
    background: #eef2f7; color: var(--sap-text-muted);
    border: 1px solid #e4e7eb;
    white-space: nowrap;
  }
  .sap-count .bi { font-size: .68rem; }
  .sap-count.has-value { background: #eaf4ff; color: var(--sap-brand); border-color: #cfe2f8; }

  /* Empty state */
  .sap-empty {
    text-align: center; padding: 2.5rem 1rem; color: var(--sap-text-muted);
  }
  .sap-empty .bi { font-size: 2rem; opacity: .4; }

  /* Modals */
  .modal-content { border-radius: .75rem; border: 0; box-shadow: var(--sap-shadow-hover); }
  .modal-header  { border-bottom: 1px solid var(--sap-border-soft); }
  .modal-footer  { border-top: 1px solid var(--sap-border-soft); }
  .form-label    { font-size: .8125rem; font-weight: 500; color: var(--sap-text); }
  .form-control:focus, .form-select:focus {
    border-color: var(--sap-brand);
    box-shadow: 0 0 0 2px rgba(0,112,242,.15);
  }

  /* Colour picker preview */
  .sap-swatch-preview {
    display: inline-flex; align-items: center; gap: .5rem;
    padding: .35rem .7rem; border-radius: .5rem;
    background: #f5f6f7; border: 1px solid var(--sap-border-soft);
    font-size: .8125rem; color: var(--sap-text);
  }
  .sap-swatch-preview .dot {
    width: 12px; height: 12px; border-radius: 50%;
  }

  @media (prefers-reduced-motion: reduce) {
    table.sap-table tbody tr { transition: none !important; }
  }
</style>

<!-- ================= Page header ================= -->
<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb">
      <i class="bi bi-house-door"></i> Home / Configuration / <strong>Priorities</strong>
    </div>
    <h1 class="sap-page-title">Priorities</h1>
  </div>
  <div class="d-flex align-items-center gap-2 flex-wrap">
    <span class="sap-status is-info">
      <i class="bi bi-flag"></i> <?= count($rows) ?> priorit<?= count($rows) === 1 ? 'y' : 'ies' ?>
    </span>
    <span class="sap-status is-info">
      <i class="bi bi-check-circle"></i>
      <?= count(array_filter($rows, fn($r) => $r['status'] === 'ACTIVE')) ?> active
    </span>
  </div>
</div>

<?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<?php if ($ok): ?><div class="alert alert-success"><?= $ok ?></div><?php endif; ?>

<!-- ================= Toolbar ================= -->
<div class="sap-toolbar">
  <div class="sap-toolbar-title">
    <i class="bi bi-speedometer2"></i> Priority Levels
  </div>
  <div class="sap-toolbar-actions">
    <button class="sap-btn sap-btn-emphasized"
            data-bs-toggle="modal" data-bs-target="#newP">
      <i class="bi bi-plus-lg"></i> Add Priority
    </button>
  </div>
</div>

<!-- ================= Table ================= -->
<div class="sap-table-wrap">
  <?php if (!$rows): ?>
    <div class="sap-empty">
      <i class="bi bi-flag"></i>
      <div class="mt-2">No priorities defined yet. Click <strong>Add Priority</strong> to begin.</div>
    </div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="sap-table">
        <thead>
          <tr>
            <th style="width:60px">Level</th>
            <th>Priority</th>
            <th>Tickets</th>
            <th>Status</th>
            <th style="text-align:right;">Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($rows as $p):
            $hex = prio_hex($p['color']);
        ?>
          <tr>
            <td>
              <span class="sap-level"><?= (int)$p['level'] ?></span>
            </td>
            <td>
              <span class="sap-prio" style="background:<?= $hex ?>">
                <span class="swatch"></span>
                <?= e($p['name']) ?>
              </span>
            </td>
            <td>
              <span class="sap-count <?= (int)$p['ticket_count'] > 0 ? 'has-value' : '' ?>">
                <i class="bi bi-ticket-detailed"></i> <?= (int)$p['ticket_count'] ?>
              </span>
            </td>
            <td>
              <span class="sap-status <?= $p['status'] === 'ACTIVE' ? '' : 'is-inactive' ?>">
                <i class="bi bi-<?= $p['status'] === 'ACTIVE' ? 'check-circle' : 'circle' ?>"></i>
                <?= e($p['status']) ?>
              </span>
            </td>
            <td style="text-align:right;">
              <div class="d-inline-flex gap-1">
                <button class="sap-btn sap-btn-icon"
                        title="Edit priority"
                        data-bs-toggle="modal" data-bs-target="#editP"
                        data-id="<?= (int)$p['id'] ?>"
                        data-name="<?= e($p['name']) ?>"
                        data-level="<?= (int)$p['level'] ?>"
                        data-color="<?= e($p['color']) ?>">
                  <i class="bi bi-pencil"></i>
                </button>
                <form method="post" class="d-inline"
                      onsubmit="return confirm('Toggle status for this priority?')">
                  <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                  <input type="hidden" name="action" value="toggle">
                  <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                  <button class="sap-btn sap-btn-icon"
                          title="<?= $p['status'] === 'ACTIVE' ? 'Deactivate' : 'Activate' ?>">
                    <i class="bi bi-power"></i>
                  </button>
                </form>
                <button class="sap-btn sap-btn-icon sap-btn-negative"
                        title="Delete priority"
                        data-bs-toggle="modal" data-bs-target="#deleteP"
                        data-id="<?= (int)$p['id'] ?>"
                        data-name="<?= e($p['name']) ?>"
                        data-tickets="<?= (int)$p['ticket_count'] ?>">
                  <i class="bi bi-trash"></i>
                </button>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<!-- ================= Add Priority Modal ================= -->
<div class="modal fade" id="newP"><div class="modal-dialog"><div class="modal-content">
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="create">
<div class="modal-header">
  <h5 class="modal-title"><i class="bi bi-plus-circle text-primary"></i> Add Priority</h5>
  <button class="btn-close" data-bs-dismiss="modal" type="button"></button>
</div>
<div class="modal-body row g-3">
  <div class="col-md-8">
    <label class="form-label">Name *</label>
    <input name="name" class="form-control" required maxlength="50"
           placeholder="e.g. Critical">
  </div>
  <div class="col-md-4">
    <label class="form-label">Level *</label>
    <input type="number" name="level" value="1" min="1" max="99" class="form-control" required>
    <small class="text-muted">1 = lowest priority.</small>
  </div>
  <div class="col-md-6">
    <label class="form-label">Colour</label>
    <select name="color" id="newColor" class="form-select">
      <option value="secondary">Grey (secondary)</option>
      <option value="info">Blue (info)</option>
      <option value="primary">Dark Blue (primary)</option>
      <option value="warning">Orange (warning)</option>
      <option value="danger">Red (danger)</option>
      <option value="success">Green (success)</option>
      <option value="dark">Charcoal (dark)</option>
    </select>
  </div>
  <div class="col-md-6">
    <label class="form-label">Preview</label>
    <div>
      <span class="sap-swatch-preview">
        <span class="dot" id="newColorDot" style="background:#5b738b"></span>
        <span id="newColorName">Grey</span>
      </span>
    </div>
  </div>
</div>
<div class="modal-footer">
  <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Cancel</button>
  <button class="sap-btn sap-btn-emphasized">Create Priority</button>
</div>
</form>
</div></div></div>

<!-- ================= Edit Priority Modal ================= -->
<div class="modal fade" id="editP"><div class="modal-dialog"><div class="modal-content">
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="update">
<input type="hidden" name="id" id="ep_id">
<div class="modal-header">
  <h5 class="modal-title"><i class="bi bi-pencil text-primary"></i> Edit Priority</h5>
  <button class="btn-close" data-bs-dismiss="modal" type="button"></button>
</div>
<div class="modal-body row g-3">
  <div class="col-md-8">
    <label class="form-label">Name *</label>
    <input name="name" id="ep_name" class="form-control" required maxlength="50">
  </div>
  <div class="col-md-4">
    <label class="form-label">Level *</label>
    <input type="number" name="level" id="ep_level" min="1" max="99" class="form-control" required>
  </div>
  <div class="col-md-6">
    <label class="form-label">Colour</label>
    <select name="color" id="ep_color" class="form-select">
      <option value="secondary">Grey (secondary)</option>
      <option value="info">Blue (info)</option>
      <option value="primary">Dark Blue (primary)</option>
      <option value="warning">Orange (warning)</option>
      <option value="danger">Red (danger)</option>
      <option value="success">Green (success)</option>
      <option value="dark">Charcoal (dark)</option>
    </select>
  </div>
  <div class="col-md-6">
    <label class="form-label">Preview</label>
    <div>
      <span class="sap-swatch-preview">
        <span class="dot" id="ep_color_dot" style="background:#5b738b"></span>
        <span id="ep_color_name">Grey</span>
      </span>
    </div>
  </div>
</div>
<div class="modal-footer">
  <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Cancel</button>
  <button class="sap-btn sap-btn-emphasized">Save Changes</button>
</div>
</form>
</div></div></div>

<!-- ================= Delete Priority Modal ================= -->
<div class="modal fade" id="deleteP"><div class="modal-dialog"><div class="modal-content">
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="delete">
<input type="hidden" name="id" id="dp_id">
<div class="modal-header" style="background:#fef4f4">
  <h5 class="modal-title"><i class="bi bi-exclamation-triangle text-danger"></i> Delete Priority</h5>
  <button class="btn-close" data-bs-dismiss="modal" type="button"></button>
</div>
<div class="modal-body">
  <p>Delete <strong id="dp_name">this priority</strong>?</p>
  <div class="alert alert-warning small mb-0" id="dp_warning">
    This action cannot be undone.
  </div>
</div>
<div class="modal-footer">
  <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Cancel</button>
  <button class="btn btn-danger"><i class="bi bi-trash"></i> Delete</button>
</div>
</form>
</div></div></div>

<script>
/* ---- Colour map used by the preview widgets ---- */
const COLOR_HEX = {
  secondary: '#5b738b',
  info:      '#0070f2',
  primary:   '#0057d2',
  warning:   '#e76500',
  danger:    '#aa0808',
  success:   '#256f3a',
  dark:      '#354a5f'
};
const COLOR_LABEL = {
  secondary: 'Grey',     info: 'Blue',
  primary:   'Dark Blue',warning: 'Orange',
  danger:    'Red',      success: 'Green',
  dark:      'Charcoal'
};

/* ---- Add-modal colour preview ---- */
(function () {
  const sel = document.getElementById('newColor');
  const dot = document.getElementById('newColorDot');
  const lbl = document.getElementById('newColorName');
  if (!sel) return;
  function sync() {
    const v = sel.value;
    dot.style.background = COLOR_HEX[v] || '#5b738b';
    lbl.textContent = COLOR_LABEL[v] || v;
  }
  sel.addEventListener('change', sync);
  sync();
})();

/* ---- Populate Edit modal ---- */
document.getElementById('editP').addEventListener('show.bs.modal', function (ev) {
  const b = ev.relatedTarget;
  document.getElementById('ep_id').value    = b.dataset.id;
  document.getElementById('ep_name').value  = b.dataset.name;
  document.getElementById('ep_level').value = b.dataset.level;
  document.getElementById('ep_color').value = b.dataset.color;

  const v = b.dataset.color;
  document.getElementById('ep_color_dot').style.background = COLOR_HEX[v] || '#5b738b';
  document.getElementById('ep_color_name').textContent     = COLOR_LABEL[v] || v;
});

/* ---- Live preview inside Edit modal when colour changes ---- */
document.getElementById('ep_color').addEventListener('change', function () {
  const v = this.value;
  document.getElementById('ep_color_dot').style.background = COLOR_HEX[v] || '#5b738b';
  document.getElementById('ep_color_name').textContent     = COLOR_LABEL[v] || v;
});

/* ---- Populate Delete modal with usage-aware warning ---- */
document.getElementById('deleteP').addEventListener('show.bs.modal', function (ev) {
  const b = ev.relatedTarget;
  document.getElementById('dp_id').value = b.dataset.id;
  document.getElementById('dp_name').textContent = b.dataset.name;

  const tickets = parseInt(b.dataset.tickets || '0', 10);
  const w = document.getElementById('dp_warning');
  if (tickets === 0) {
    w.innerHTML = 'This priority has no tickets. It can be safely deleted.';
    w.className = 'alert alert-info small mb-0';
  } else {
    w.innerHTML = 'This priority is referenced by <strong>' + tickets +
                  '</strong> ticket(s). Deletion will be <strong>blocked</strong> until those are reassigned or the priority is deactivated instead.';
    w.className = 'alert alert-warning small mb-0';
  }
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
