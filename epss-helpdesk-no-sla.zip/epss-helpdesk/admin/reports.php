<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../reports/kpi_calculator.php';
$u = require_role('ADMIN');
$pageTitle = 'Reports';

$pdo = db();

/* ===================== Filters ===================== */
/* Default window: the last 12 months up to today. A month-to-date default hid
   every ticket logged before the current month, so the report looked empty. */
$defaultFrom = date('Y-m-01', strtotime('-11 months'));
$defaultTo   = date('Y-m-d');
$from   = $_GET['from']        ?? $defaultFrom;
$to     = $_GET['to']          ?? $defaultTo;
$catId  = (int)($_GET['category_id'] ?? 0);
$deptId = (int)($_GET['department_id'] ?? 0);
$status = $_GET['status']      ?? '';

/* ===================== Ticket data ===================== */
$sql = "SELECT t.*, c.category_name, d.department_name, p.name AS priority_name, p.color AS priority_color,
               req.full_name AS requester_name,
               tl.full_name  AS tl_name,
               tech.full_name AS tech_name
        FROM tickets t
        JOIN categories c ON c.id=t.category_id
        JOIN priorities p ON p.id=t.priority_id
        JOIN users req    ON req.id=t.requester_id
        LEFT JOIN users tl   ON tl.id=t.team_leader_id
        LEFT JOIN users tech ON tech.id=t.assigned_technician_id
        LEFT JOIN departments d ON d.id=t.department_id
        WHERE t.created_at BETWEEN ? AND ?";
$params = [$from . ' 00:00:00', $to . ' 23:59:59'];
if ($catId)  { $sql .= " AND t.category_id=?";   $params[] = $catId; }
if ($deptId) { $sql .= " AND t.department_id=?"; $params[] = $deptId; }
if ($status) { $sql .= " AND t.status=?";        $params[] = $status; }
$sql .= " ORDER BY t.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

/* ===================== Summary stats ===================== */
$total    = count($rows);
$closed   = count(array_filter($rows, fn($r) => $r['status'] === 'CLOSED'));
$open     = count(array_filter($rows, fn($r) => !in_array($r['status'], ['CLOSED','REJECTED','CANCELLED'], true)));
$rejected = count(array_filter($rows, fn($r) => $r['status'] === 'REJECTED'));

/* Average resolution time */
$totalSec = 0; $countRes = 0;
foreach ($rows as $r) {
    if ($r['closed_at'] && $r['team_leader_approved_at']) {
        $totalSec += strtotime($r['closed_at']) - strtotime($r['team_leader_approved_at']);
        $countRes++;
    }
}
$avgResHrs = $countRes ? round($totalSec / $countRes / 3600, 2) : 0;

/* Group by category */
$byCat = [];
foreach ($rows as $r) {
    $k = $r['category_name'];
    $byCat[$k] ??= ['total'=>0,'closed'=>0,'open'=>0];
    $byCat[$k]['total']++;
    if ($r['status']==='CLOSED') $byCat[$k]['closed']++;
    elseif (!in_array($r['status'],['REJECTED','CANCELLED'],true)) $byCat[$k]['open']++;
}

/* ===================== Preventive Maintenance summary ===================== */
$pmStmt = $pdo->prepare("
    SELECT c.id, c.technician_name, c.quarter_label, c.checklist_date,
           COUNT(i.id) AS items_total, SUM(i.done) AS items_done
    FROM pm_checklists c
    LEFT JOIN pm_checklist_items i ON i.checklist_id = c.id
    WHERE c.checklist_date BETWEEN ? AND ?
    GROUP BY c.id ORDER BY c.checklist_date DESC LIMIT 10
");
$pmStmt->execute([$from, $to]);
$pmRows = $pmStmt->fetchAll();

$pmOverallDone = 0; $pmOverallTotal = 0;
foreach ($pmRows as $p) {
    $pmOverallDone  += (int)$p['items_done'];
    $pmOverallTotal += (int)$p['items_total'];
}
$pmCompletion = $pmOverallTotal ? round($pmOverallDone / $pmOverallTotal * 100, 1) : 0;

/* ===================== WhatsApp summary ===================== */
$waStats = [
    'sent'   => (int)$pdo->query("SELECT COUNT(*) FROM whatsapp_log WHERE status='SENT' AND created_at BETWEEN '$from 00:00:00' AND '$to 23:59:59'")->fetchColumn(),
    'queued' => (int)$pdo->query("SELECT COUNT(*) FROM whatsapp_log WHERE status='QUEUED' AND created_at BETWEEN '$from 00:00:00' AND '$to 23:59:59'")->fetchColumn(),
    'failed' => (int)$pdo->query("SELECT COUNT(*) FROM whatsapp_log WHERE status='FAILED' AND created_at BETWEEN '$from 00:00:00' AND '$to 23:59:59'")->fetchColumn(),
];

/* ===================== AI Assistant summary ===================== */
$aiStats = [
    'total'    => (int)$pdo->query("SELECT COUNT(*) FROM ai_conversations WHERE created_at BETWEEN '$from 00:00:00' AND '$to 23:59:59'")->fetchColumn(),
    'helpful'  => (int)$pdo->query("SELECT COUNT(*) FROM ai_conversations WHERE helpful=1 AND created_at BETWEEN '$from 00:00:00' AND '$to 23:59:59'")->fetchColumn(),
    'kb_based' => (int)$pdo->query("SELECT COUNT(*) FROM ai_conversations WHERE matched_kb_id IS NOT NULL AND created_at BETWEEN '$from 00:00:00' AND '$to 23:59:59'")->fetchColumn(),
];

/* Filter dropdown data */
$cats  = $pdo->query("SELECT * FROM categories ORDER BY category_name")->fetchAll();
$depts = $pdo->query("SELECT * FROM departments ORDER BY department_name")->fetchAll();

/* Query string builder for exports */
$qs = http_build_query([
    'from'          => $from,
    'to'            => $to,
    'category_id'   => $catId,
    'department_id' => $deptId,
    'status'        => $status,
]);

include __DIR__ . '/../includes/header.php';
?>

<!-- ================= SAP Fiori Horizon theme ================= -->
<style>
  :root {
    --sap-brand:#0070f2; --sap-brand-dark:#0057d2;
    --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500;
    --sap-negative:#aa0808; --sap-neutral:#5b738b;
    --sap-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
    --sap-shadow-hover: 0 0 0 1px rgba(34,53,72,.15), 0 8px 24px 0 rgba(34,53,72,.12);
  }
  body, .main-content { background: var(--sap-bg) !important;
    font-family: "72","72full",Arial,Helvetica,sans-serif !important; color: var(--sap-text); }

  .sap-page-header { display:flex; align-items:flex-start; justify-content:space-between;
    margin-bottom:1rem; flex-wrap:wrap; gap:.75rem; }
  .sap-page-title { font-size:1.625rem; font-weight:400; margin:0; }
  .sap-breadcrumb { font-size:.8125rem; color:var(--sap-text-muted); margin-bottom:.25rem; }

  .sap-status { display:inline-flex; align-items:center; gap:.3rem;
    font-size:.72rem; font-weight:600; padding:.25rem .65rem;
    border-radius:.75rem; white-space:nowrap; border:1px solid transparent; }
  .sap-status.is-info     { background:#eaf4ff; color:var(--sap-brand);    border-color:#cfe2f8; }
  .sap-status.is-critical { background:#fff8f1; color:var(--sap-critical); border-color:#fbe0c8; }
  .sap-status.is-good     { background:#f1fdf6; color:var(--sap-positive); border-color:#d6f0e0; }
  .sap-status.is-bad      { background:#fef4f4; color:var(--sap-negative); border-color:#f7d2d2; }
  .sap-status.is-neutral  { background:#f4f5f7; color:var(--sap-neutral);  border-color:#e4e7eb; }

  /* Filter bar */
  .sap-filterbar { background: var(--sap-tile); border-radius: .75rem;
    box-shadow: var(--sap-shadow); padding: .85rem 1rem; margin-bottom: 1rem; }
  .sap-filterbar-row { display: flex; gap: .5rem; flex-wrap: wrap; align-items: flex-end; }
  .sap-form-label { font-size: .7rem; text-transform: uppercase; letter-spacing: .04em;
    color: var(--sap-text-muted); font-weight: 600; margin-bottom: .2rem; display: block; }
  .sap-filterbar input, .sap-filterbar select {
    font-size: .8125rem; padding: .45rem .65rem; border-radius: .5rem;
    border: 1px solid var(--sap-border); background: #fff; min-width: 140px;
    color: var(--sap-text); font-family: inherit; }
  .sap-filterbar select { appearance: none;
    background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'><path fill='%23556b82' d='M3 5l3 3 3-3z'/></svg>");
    background-repeat: no-repeat; background-position: right .6rem center; padding-right: 2rem; }
  .sap-filterbar input:focus, .sap-filterbar select:focus {
    outline: none; border-color: var(--sap-brand);
    box-shadow: 0 0 0 3px rgba(0,112,242,.15); }

  /* Buttons */
  .sap-btn { display: inline-flex; align-items: center; gap: .4rem;
    font-size: .8125rem; font-weight: 500; border-radius: .5rem;
    padding: .45rem .8rem; border: 1px solid transparent; background: transparent;
    color: var(--sap-brand); cursor: pointer; line-height: 1; text-decoration: none;
    white-space: nowrap; transition: background .15s, color .15s; font-family: inherit; }
  .sap-btn:hover { background: #eaf4ff; color: var(--sap-brand-dark); }
  .sap-btn:focus-visible { outline: 2px solid var(--sap-brand); outline-offset: 2px; }
  .sap-btn.sap-btn-emphasized { background: var(--sap-brand); color: #fff;
    box-shadow: 0 1px 2px rgba(34,53,72,.15); }
  .sap-btn.sap-btn-emphasized:hover { background: var(--sap-brand-dark); color: #fff; }
  .sap-btn.sap-btn-success { color: var(--sap-positive); }
  .sap-btn.sap-btn-success:hover { background:#f1fdf6; color: var(--sap-positive); }
  .sap-btn.sap-btn-danger  { color: var(--sap-negative); }
  .sap-btn.sap-btn-danger:hover { background:#fef4f4; color: var(--sap-negative); }

  /* Section header */
  .sap-section { display: flex; align-items: center; justify-content: space-between;
    margin: 1.25rem 0 .5rem; flex-wrap: wrap; gap: .5rem; }
  .sap-section-title { font-size: .95rem; font-weight: 600;
    display: flex; align-items: center; gap: .4rem; }
  .sap-section-title .bi { color: var(--sap-brand); }

  /* KPI tiles */
  .sap-tile { background: var(--sap-tile); border-radius: .75rem;
    box-shadow: var(--sap-shadow); padding: .85rem 1rem;
    position: relative; overflow: hidden; height: 100%;
    transition: box-shadow .2s, transform .2s; }
  .sap-tile:hover { box-shadow: var(--sap-shadow-hover); transform: translateY(-2px); }
  .sap-tile::before { content: ""; position: absolute; top: 0; left: 0; right: 0; height: 3px;
    background: var(--sap-brand); }
  .sap-tile.is-good::before     { background: var(--sap-positive); }
  .sap-tile.is-critical::before { background: var(--sap-critical); }
  .sap-tile.is-bad::before      { background: var(--sap-negative); }
  .sap-tile.is-neutral::before  { background: var(--sap-neutral); }
  .sap-tile-label { font-size: .68rem; text-transform: uppercase; letter-spacing: .04em;
    color: var(--sap-text-muted); font-weight: 600; margin-bottom: .25rem;
    display: flex; align-items: center; gap: .35rem; }
  .sap-tile-value { font-family: "72Mono","Courier New",monospace;
    font-size: 1.6rem; font-weight: 600; line-height: 1.05;
    letter-spacing: -.02em; font-variant-numeric: tabular-nums; color: var(--sap-text); }
  .sap-tile-value .unit { font-size: .8rem; font-weight: 500; color: var(--sap-text-muted);
    margin-left: .1rem; font-family: "72", Arial, sans-serif; }

  /* Table */
  .sap-table-wrap { background: var(--sap-tile); border-radius: .75rem;
    box-shadow: var(--sap-shadow); overflow: hidden; margin-bottom: 1rem; }
  table.sap-table { width: 100%; border-collapse: separate; border-spacing: 0;
    font-size: .8125rem; margin: 0; }
  table.sap-table thead th { background: #f5f6f7;
    border-bottom: 1px solid var(--sap-border);
    font-weight: 600; color: var(--sap-text-muted);
    text-align: left; padding: .55rem .7rem; white-space: nowrap;
    text-transform: uppercase; font-size: .68rem; letter-spacing: .04em; }
  table.sap-table tbody td { padding: .55rem .7rem;
    border-bottom: 1px solid var(--sap-border-soft);
    vertical-align: middle; color: var(--sap-text); }
  table.sap-table tbody tr:last-child td { border-bottom: 0; }
  table.sap-table tbody tr { transition: background .12s; }
  table.sap-table tbody tr:hover { background: #f8fbff; }
  table.sap-table tfoot td { padding: .55rem .7rem; background: #f5f6f7;
    border-top: 1px solid var(--sap-border); font-weight: 600; font-size: .78rem; }
  .sap-num { text-align: right; font-variant-numeric: tabular-nums; }

  .sap-ticket-num { font-family: "72Mono","Courier New",monospace;
    font-weight: 600; color: var(--sap-brand); text-decoration: none; white-space: nowrap; }
  .sap-ticket-num:hover { color: var(--sap-brand-dark); text-decoration: underline; }

  .sap-prio { display: inline-flex; align-items: center; gap: .3rem;
    font-size: .7rem; font-weight: 600; padding: .15rem .55rem;
    border-radius: .75rem; color: #fff; white-space: nowrap; }

  .sap-empty { text-align: center; padding: 2.5rem 1rem; color: var(--sap-text-muted); font-size: .82rem; }
  .sap-empty .bi { font-size: 2.2rem; opacity: .4; display: block; margin-bottom: .5rem; }

  /* Print header */
  .print-header { display: none; text-align: center; margin-bottom: 1rem; }
  .print-header .org  { font-size: 1rem; font-weight: 600; }
  .print-header .sub  { font-size: .82rem; color: var(--sap-text); }
  .print-header .meta { font-size: .72rem; color: var(--sap-text-muted); }

  @media print {
    body, .main-content { background:#fff !important; }
    .sidebar, .navbar, footer, .no-print,
    .sap-filterbar, .sap-btn { display: none !important; }
    .main-content { margin-left: 0 !important; }
    .print-header { display: block; }
    .sap-tile, .sap-table-wrap { box-shadow: none !important;
      border: 1px solid #d9d9d9 !important; page-break-inside: avoid; }
    table.sap-table { font-size: 10px; }
    table.sap-table thead th { background: #f0f3f7 !important;
      -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    .sap-status, .sap-prio { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  }

  @media (prefers-reduced-motion: reduce) {
    .sap-tile, table.sap-table tbody tr, .sap-btn { transition: none !important; }
  }
</style>

<!-- ================= Page header ================= -->
<div class="sap-page-header screen-header">
  <div>
    <div class="sap-breadcrumb"><i class="bi bi-house-door"></i> Home / <strong>Reports</strong></div>
    <h1 class="sap-page-title">Reports</h1>
  </div>
  <div class="d-flex gap-2 flex-wrap no-print">
    <span class="sap-status is-info"><i class="bi bi-calendar3"></i> <?= e($from) ?> → <?= e($to) ?></span>
    <span class="sap-status is-info"><i class="bi bi-ticket-detailed"></i> <?= number_format($total) ?> tickets</span>
  </div>
</div>

<!-- ================= Print header ================= -->
<div class="print-header">
  <div class="org">ETHIOPIAN PHARMACEUTICALS SUPPLY SERVICE</div>
  <div class="sub">ADAMA BRANCH — ICT HELPDESK REPORT</div>
  <div class="meta">
    Period: <?= e($from) ?> → <?= e($to) ?> ·
    Generated <?= date('Y-m-d H:i') ?> by <?= e($u['full_name']) ?>
  </div>
</div>

<!-- ================= Filter bar ================= -->
<div class="sap-filterbar no-print">
  <form class="sap-filterbar-row">
    <div>
      <label class="sap-form-label">From</label>
      <input type="date" name="from" value="<?= e($from) ?>">
    </div>
    <div>
      <label class="sap-form-label">To</label>
      <input type="date" name="to" value="<?= e($to) ?>">
    </div>
    <div>
      <label class="sap-form-label">Category</label>
      <select name="category_id">
        <option value="">All categories</option>
        <?php foreach ($cats as $c): ?>
          <option value="<?= (int)$c['id'] ?>" <?= $catId==$c['id']?'selected':'' ?>>
            <?= e($c['category_name']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <label class="sap-form-label">Department</label>
      <select name="department_id">
        <option value="">All departments</option>
        <?php foreach ($depts as $d): ?>
          <option value="<?= (int)$d['id'] ?>" <?= $deptId==$d['id']?'selected':'' ?>>
            <?= e($d['department_name']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <label class="sap-form-label">Status</label>
      <select name="status">
        <option value="">All statuses</option>
        <?php foreach ([
          'PENDING_TEAM_LEADER_APPROVAL','APPROVED_FOR_ICT','IN_PROGRESS',
          'WAITING_FOR_INFORMATION','WAITING_FOR_PARTS',
          'RESOLVED_PENDING_REQUESTER_CONFIRMATION','CLOSED','REJECTED'
        ] as $s): ?>
          <option value="<?= $s ?>" <?= $status===$s?'selected':'' ?>>
            <?= e(str_replace('_',' ', $s)) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="d-flex gap-1">
      <button class="sap-btn sap-btn-emphasized"><i class="bi bi-funnel"></i> Apply</button>
      <?php if ($from !== $defaultFrom || $to !== $defaultTo || $catId || $deptId || $status): ?>
        <a class="sap-btn" href="reports.php"><i class="bi bi-x-circle"></i> Clear</a>
      <?php endif; ?>
    </div>
  </form>
</div>

<!-- ================= Export buttons ================= -->
<div class="sap-section no-print">
  <div class="sap-section-title"><i class="bi bi-download"></i> Export this report</div>
  <div class="d-flex gap-1 flex-wrap">
    <button onclick="window.print()" class="sap-btn">
      <i class="bi bi-printer"></i> Print
    </button>
    <a class="sap-btn sap-btn-success"
       href="<?= BASE_URL ?>/reports/export_tickets.php?<?= $qs ?>&fmt=csv">
      <i class="bi bi-file-earmark-spreadsheet"></i> CSV
    </a>
    <a class="sap-btn sap-btn-success"
       href="<?= BASE_URL ?>/reports/export_tickets.php?<?= $qs ?>&fmt=xls">
      <i class="bi bi-file-earmark-excel"></i> Excel
    </a>
    <a class="sap-btn sap-btn-danger"
       href="<?= BASE_URL ?>/reports/export_tickets.php?<?= $qs ?>&fmt=pdf">
      <i class="bi bi-file-earmark-pdf"></i> PDF
    </a>
  </div>
</div>

<!-- ================= Report shortcuts ================= -->
<div class="sap-section no-print">
  <div class="sap-section-title"><i class="bi bi-bookmarks"></i> Specialised reports</div>
</div>
<div class="row g-3 mb-3">
  <div class="col-md-6 col-lg-3">
    <a href="<?= BASE_URL ?>/reports/kpi_report.php?from=<?= e($from) ?>&to=<?= e($to) ?>"
       class="sap-tile is-info" style="text-decoration:none;color:inherit;">
      <div class="sap-tile-label"><i class="bi bi-graph-up"></i> KPI Report</div>
      <div style="font-size:.78rem;color:var(--sap-text-muted);margin-top:.35rem">
        Target vs Achievement per category
      </div>
    </a>
  </div>
  <div class="col-md-6 col-lg-3">
    <a href="<?= BASE_URL ?>/reports/pm_report.php?year=<?= date('Y') ?>&quarter=<?= (int)ceil(date('n')/3) ?>"
       class="sap-tile is-good" style="text-decoration:none;color:inherit;">
      <div class="sap-tile-label"><i class="bi bi-clipboard-check"></i> Preventive Maintenance</div>
      <div style="font-size:.78rem;color:var(--sap-text-muted);margin-top:.35rem">
        Quarterly checklist completion report
      </div>
    </a>
  </div>
  <div class="col-md-6 col-lg-3">
    <a href="<?= BASE_URL ?>/admin/whatsapp_log.php"
       class="sap-tile is-critical" style="text-decoration:none;color:inherit;">
      <div class="sap-tile-label"><i class="bi bi-whatsapp"></i> WhatsApp Log</div>
      <div style="font-size:.78rem;color:var(--sap-text-muted);margin-top:.35rem">
        Notification delivery history
      </div>
    </a>
  </div>
  <div class="col-md-6 col-lg-3">
    <a href="<?= BASE_URL ?>/admin/audit_logs.php"
       class="sap-tile is-neutral" style="text-decoration:none;color:inherit;">
      <div class="sap-tile-label"><i class="bi bi-shield-check"></i> Audit Logs</div>
      <div style="font-size:.78rem;color:var(--sap-text-muted);margin-top:.35rem">
        Every system action tracked
      </div>
    </a>
  </div>
</div>

<!-- ================= Overview tiles ================= -->
<div class="sap-section">
  <div class="sap-section-title"><i class="bi bi-speedometer2"></i> Ticket Overview</div>
</div>
<div class="row g-3 mb-3">
  <?php
  $tiles = [
    ['Total',          $total,             'neutral',  'ticket-detailed'],
    ['Closed',         $closed,            'good',     'check2-all'],
    ['Open',           $open,              'info',     'hourglass'],
    ['Rejected',       $rejected,          'bad',      'x-circle'],
    ['Avg Resolution', $avgResHrs,         'neutral',  'clock-history', 'h'],
  ];
  foreach ($tiles as $t):
    $label = $t[0]; $val = $t[1]; $tone = $t[2]; $icon = $t[3]; $unit = $t[4] ?? '';
  ?>
    <div class="col-6 col-md-4 col-lg-3 col-xl">
      <div class="sap-tile is-<?= $tone ?>">
        <div class="sap-tile-label"><i class="bi bi-<?= $icon ?>"></i> <?= e($label) ?></div>
        <div class="sap-tile-value">
          <?= is_numeric($val) ? number_format((float)$val, strpos((string)$val, '.') !== false ? 2 : 0) : e((string)$val) ?>
          <?php if ($unit): ?><span class="unit"><?= e($unit) ?></span><?php endif; ?>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- ================= Category summary ================= -->
<div class="sap-section">
  <div class="sap-section-title"><i class="bi bi-tags"></i> Summary by Category</div>
</div>
<div class="sap-table-wrap">
  <div class="table-responsive">
    <table class="sap-table">
      <thead>
        <tr>
          <th>Category</th>
          <th class="sap-num">Total</th>
          <th class="sap-num">Closed</th>
          <th class="sap-num">Open</th>
        </tr>
      </thead>
      <tbody>
      <?php if (!$byCat): ?>
        <tr><td colspan="4" class="text-center text-muted" style="padding:1.5rem">No data for this period.</td></tr>
      <?php else: foreach ($byCat as $name => $v): ?>
        <tr>
          <td><?= e($name) ?></td>
          <td class="sap-num"><?= (int)$v['total'] ?></td>
          <td class="sap-num"><?= (int)$v['closed'] ?></td>
          <td class="sap-num"><?= (int)$v['open'] ?></td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ================= Preventive Maintenance summary ================= -->
<?php if ($pmRows): ?>
<div class="sap-section">
  <div class="sap-section-title"><i class="bi bi-clipboard-check"></i> Preventive Maintenance — Recent Submissions</div>
  <span class="sap-status <?= $pmCompletion >= 90 ? 'is-good' : ($pmCompletion >= 70 ? 'is-critical' : 'is-bad') ?>">
    <i class="bi bi-check-circle"></i> <?= number_format($pmCompletion, 1) ?>% completion
  </span>
</div>
<div class="sap-table-wrap">
  <div class="table-responsive">
    <table class="sap-table">
      <thead>
        <tr>
          <th>Quarter</th>
          <th>Date</th>
          <th>Technician</th>
          <th class="sap-num">Items Done</th>
          <th class="sap-num">Completion</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($pmRows as $p):
          $pct = (int)$p['items_total'] ? round((int)$p['items_done'] / (int)$p['items_total'] * 100) : 0;
      ?>
        <tr>
          <td><strong><?= e($p['quarter_label']) ?></strong></td>
          <td><?= e(date('M j, Y', strtotime($p['checklist_date']))) ?></td>
          <td><?= e($p['technician_name']) ?></td>
          <td class="sap-num"><?= (int)$p['items_done'] ?> / <?= (int)$p['items_total'] ?></td>
          <td class="sap-num">
            <span class="sap-status <?= $pct >= 90 ? 'is-good' : ($pct >= 70 ? 'is-critical' : 'is-bad') ?>">
              <?= $pct ?>%
            </span>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<!-- ================= Communication & AI summary ================= -->
<div class="sap-section">
  <div class="sap-section-title"><i class="bi bi-chat-dots"></i> Communication &amp; AI Assistant (this period)</div>
</div>
<div class="row g-3 mb-3">
  <div class="col-6 col-md-3">
    <div class="sap-tile is-good">
      <div class="sap-tile-label"><i class="bi bi-whatsapp"></i> WhatsApp Sent</div>
      <div class="sap-tile-value"><?= number_format($waStats['sent']) ?></div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="sap-tile is-critical">
      <div class="sap-tile-label"><i class="bi bi-clock-history"></i> WhatsApp Queued</div>
      <div class="sap-tile-value"><?= number_format($waStats['queued']) ?></div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="sap-tile is-info">
      <div class="sap-tile-label"><i class="bi bi-robot"></i> AI Questions</div>
      <div class="sap-tile-value"><?= number_format($aiStats['total']) ?></div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="sap-tile is-good">
      <div class="sap-tile-label"><i class="bi bi-hand-thumbs-up"></i> AI Helpful</div>
      <div class="sap-tile-value"><?= number_format($aiStats['helpful']) ?></div>
    </div>
  </div>
</div>

<!-- ================= Detailed ticket table ================= -->
<div class="sap-section">
  <div class="sap-section-title"><i class="bi bi-list-ul"></i> Detailed Tickets</div>
  <span class="sap-status is-info"><?= number_format(count($rows)) ?> row<?= count($rows)===1?'':'s' ?></span>
</div>

<div class="sap-table-wrap">
  <?php if (!$rows): ?>
    <div class="sap-empty">
      <i class="bi bi-inbox"></i>
      No tickets were created between <strong><?= e($from) ?></strong> and <strong><?= e($to) ?></strong>
      with the current filters. Widen the period to include older tickets.
    </div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="sap-table" id="reportTable">
        <thead>
          <tr>
            <th>Ticket #</th><th>Subject</th><th>Requester</th>
            <th>Dept</th><th>Category</th><th>Priority</th><th>Status</th>
            <th>Team Leader</th><th>Technician</th>
            <th>Created</th><th>Closed</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($rows as $r):
            $hex = match ($r['priority_color']) {
                'danger'=>'#aa0808','warning'=>'#e76500','info'=>'#0070f2',
                'primary'=>'#0057d2','success'=>'#256f3a','secondary'=>'#5b738b',
                'dark'=>'#354a5f', default=>'#5b738b' };
        ?>
          <tr>
            <td>
              <a class="sap-ticket-num" href="<?= BASE_URL ?>/admin/ticket_view.php?id=<?= (int)$r['id'] ?>">
                <?= e($r['ticket_number']) ?>
              </a>
            </td>
            <td><?= e($r['subject']) ?></td>
            <td><?= e($r['requester_name']) ?></td>
            <td><?= e($r['department_name'] ?? '—') ?></td>
            <td><?= e($r['category_name']) ?></td>
            <td><span class="sap-prio" style="background:<?= e($hex) ?>"><?= e($r['priority_name']) ?></span></td>
            <td><?= status_badge($r['status']) ?></td>
            <td><?= e($r['tl_name'] ?? '—') ?></td>
            <td><?= e($r['tech_name'] ?? '—') ?></td>
            <td><small class="text-muted"><?= e(date('Y-m-d H:i', strtotime($r['created_at']))) ?></small></td>
            <td><small class="text-muted"><?= $r['closed_at'] ? e(date('Y-m-d H:i', strtotime($r['closed_at']))) : '—' ?></small></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>