<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('ADMIN');
$pageTitle = 'Categories';
$pdo = db(); $error = $ok = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf($_POST['csrf'] ?? null)) {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'create_cat') {
            $pdo->prepare("INSERT INTO categories (category_name,description) VALUES (?,?)")
                ->execute([trim($_POST['name']), $_POST['description'] ?: null]);
            audit('CreateCategory','categories',(int)$pdo->lastInsertId(), $_POST['name']);
            $ok = 'Category created.';
        } elseif ($action === 'create_sub') {
            $pdo->prepare("INSERT INTO subcategories (category_id,name,description) VALUES (?,?,?)")
                ->execute([(int)$_POST['category_id'], trim($_POST['name']), $_POST['description'] ?: null]);
            audit('CreateSubcategory','subcategories',(int)$pdo->lastInsertId(), $_POST['name']);
            $ok = 'Subcategory created.';
        } elseif ($action === 'update_cat') {
            $id = (int)$_POST['id'];
            $pdo->prepare("UPDATE categories SET category_name=?, description=? WHERE id=?")
                ->execute([trim($_POST['name']), $_POST['description'] ?: null, $id]);
            audit('UpdateCategory','categories',$id,'Updated category ' . $_POST['name']);
            $ok = 'Category updated.';
        } elseif ($action === 'update_sub') {
            $id = (int)$_POST['id'];
            $pdo->prepare("UPDATE subcategories SET name=?, description=? WHERE id=?")
                ->execute([trim($_POST['name']), $_POST['description'] ?: null, $id]);
            audit('UpdateSubcategory','subcategories',$id,'Updated subcategory ' . $_POST['name']);
            $ok = 'Subcategory updated.';
        } elseif ($action === 'toggle_cat') {
            $pdo->prepare("UPDATE categories SET status=IF(status='ACTIVE','INACTIVE','ACTIVE') WHERE id=?")
                ->execute([(int)$_POST['id']]);
            audit('ToggleCategory','categories',(int)$_POST['id'],'Toggled');
            $ok = 'Category status updated.';
        } elseif ($action === 'toggle_sub') {
            $pdo->prepare("UPDATE subcategories SET status=IF(status='ACTIVE','INACTIVE','ACTIVE') WHERE id=?")
                ->execute([(int)$_POST['id']]);
            audit('ToggleSubcategory','subcategories',(int)$_POST['id'],'Toggled');
            $ok = 'Subcategory status updated.';
        } elseif ($action === 'delete_cat') {
            $id = (int)$_POST['id'];
            // Refuse deletion if the category has tickets or subcategories attached
            $used = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE category_id=" . $id)->fetchColumn();
            $subs = (int)$pdo->query("SELECT COUNT(*) FROM subcategories WHERE category_id=" . $id)->fetchColumn();
            if ($used > 0 || $subs > 0) {
                throw new RuntimeException(
                    "Cannot delete this category: $used ticket(s) and $subs subcategory(ies) still reference it. " .
                    "Deactivate it instead, or remove the subcategories first."
                );
            }
            $name = $pdo->query("SELECT category_name FROM categories WHERE id=" . $id)->fetchColumn();
            $pdo->prepare("DELETE FROM categories WHERE id=?")->execute([$id]);
            audit('DeleteCategory','categories',$id,'Deleted category ' . ($name ?: '#' . $id));
            $ok = 'Category deleted.';
        } elseif ($action === 'delete_sub') {
            $id = (int)$_POST['id'];
            $used = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE subcategory_id=" . $id)->fetchColumn();
            if ($used > 0) {
                throw new RuntimeException(
                    "Cannot delete this subcategory: $used ticket(s) still reference it. " .
                    "Deactivate it instead."
                );
            }
            $name = $pdo->query("SELECT name FROM subcategories WHERE id=" . $id)->fetchColumn();
            $pdo->prepare("DELETE FROM subcategories WHERE id=?")->execute([$id]);
            audit('DeleteSubcategory','subcategories',$id,'Deleted subcategory ' . ($name ?: '#' . $id));
            $ok = 'Subcategory deleted.';
        }
    } catch (Throwable $e) {
        $error = app_exception_message($e);
    }
}

$cats = $pdo->query("
    SELECT c.*,
           (SELECT COUNT(*) FROM tickets t WHERE t.category_id = c.id) AS ticket_count,
           (SELECT COUNT(*) FROM subcategories s WHERE s.category_id = c.id) AS sub_count
    FROM categories c
    ORDER BY c.category_name
")->fetchAll();

$subs = $pdo->query("
    SELECT s.*,
           (SELECT COUNT(*) FROM tickets t WHERE t.subcategory_id = s.id) AS ticket_count
    FROM subcategories s
    ORDER BY s.category_id, s.name
")->fetchAll();
$subByCat = [];
foreach ($subs as $s) $subByCat[$s['category_id']][] = $s;

include __DIR__ . '/../includes/header.php';
?>

<!-- ================= SAP Fiori Horizon theme ================= -->
<style>
  :root {
    --sap-brand:        #0070f2;
    --sap-brand-dark:   #0057d2;
    --sap-bg:           #f5f6f7;
    --sap-tile:         #ffffff;
    --sap-text:         #1d2d3e;
    --sap-text-muted:   #556b82;
    --sap-border:       #d9d9d9;
    --sap-border-soft:  #eaecf0;
    --sap-positive:     #256f3a;
    --sap-critical:     #e76500;
    --sap-negative:     #aa0808;
    --sap-neutral:      #5b738b;
    --sap-shadow:       0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
    --sap-shadow-hover: 0 0 0 1px rgba(34,53,72,.15), 0 8px 24px 0 rgba(34,53,72,.12);
  }

  body, .main-content {
    background: var(--sap-bg) !important;
    font-family: "72", "72full", Arial, Helvetica, sans-serif !important;
    color: var(--sap-text);
  }

  /* SAP page header */
  .sap-page-header {
    display: flex; align-items: flex-start; justify-content: space-between;
    margin-bottom: 1rem;
  }
  .sap-page-title { font-size: 1.625rem; font-weight: 400; margin: 0; }
  .sap-breadcrumb { font-size: .8125rem; color: var(--sap-text-muted); margin-bottom: .25rem; }

  /* SAP Toolbar (top of list) */
  .sap-toolbar {
    display: flex; align-items: center; justify-content: space-between;
    background: var(--sap-tile);
    border-radius: .75rem .75rem 0 0;
    padding: .5rem .75rem;
    box-shadow: var(--sap-shadow);
    border-bottom: 1px solid var(--sap-border-soft);
  }
  .sap-toolbar-title {
    font-size: .875rem; font-weight: 600;
    display: flex; align-items: center; gap: .4rem;
  }
  .sap-toolbar-title .bi { color: var(--sap-brand); }
  .sap-toolbar-actions { display: flex; gap: .25rem; }

  /* SAP button (transparent "ghost" variant used in toolbars) */
  .sap-btn {
    display: inline-flex; align-items: center; gap: .35rem;
    font-size: .8125rem; font-weight: 500;
    border-radius: .5rem;
    padding: .3rem .7rem;
    border: 1px solid transparent;
    background: transparent;
    color: var(--sap-brand);
    transition: background .15s, box-shadow .15s, color .15s;
    cursor: pointer;
    line-height: 1;
  }
  .sap-btn:hover { background: #eaf4ff; color: var(--sap-brand-dark); }
  .sap-btn:focus-visible { outline: 2px solid var(--sap-brand); outline-offset: 2px; }
  .sap-btn.sap-btn-emphasized {
    background: var(--sap-brand); color: #fff;
    box-shadow: 0 1px 2px rgba(34,53,72,.15);
  }
  .sap-btn.sap-btn-emphasized:hover { background: var(--sap-brand-dark); color: #fff; }
  .sap-btn.sap-btn-negative { color: var(--sap-negative); }
  .sap-btn.sap-btn-negative:hover { background: #fef4f4; color: var(--sap-negative); }
  .sap-btn.sap-btn-icon { padding: .35rem .5rem; }

  /* SAP List container */
  .sap-list {
    background: var(--sap-tile);
    border-radius: 0 0 .75rem .75rem;
    box-shadow: var(--sap-shadow);
    overflow: hidden;
  }

  /* SAP List Item */
  .sap-li {
    padding: .85rem 1rem;
    border-bottom: 1px solid var(--sap-border-soft);
    transition: background .12s;
    animation: sapFadeUp .35s cubic-bezier(.2,.8,.2,1) both;
  }
  .sap-li:last-child { border-bottom: 0; }
  .sap-li:hover { background: #f8fbff; }

  .sap-li-head {
    display: flex; align-items: flex-start; justify-content: space-between;
    gap: .75rem;
  }
  .sap-li-title {
    font-size: .9375rem; font-weight: 600; color: var(--sap-text);
    display: flex; align-items: center; gap: .5rem;
  }
  .sap-li-title .bi-folder2-open { color: var(--sap-brand); }
  .sap-li-desc {
    font-size: .8125rem; color: var(--sap-text-muted); margin-top: .15rem;
    line-height: 1.35;
  }
  .sap-li-actions { display: flex; gap: .2rem; flex-shrink: 0; }

  /* SAP Object Status (tag / badge) */
  .sap-status {
    display: inline-flex; align-items: center; gap: .25rem;
    font-size: .7rem; font-weight: 600;
    padding: .1rem .5rem;
    border-radius: .75rem;
    background: #f1fdf6; color: var(--sap-positive);
    border: 1px solid #d6f0e0;
  }
  .sap-status.is-inactive { background: #f4f5f7; color: var(--sap-neutral); border-color: #e4e7eb; }
  .sap-status.is-count    { background: #eaf4ff; color: var(--sap-brand); border-color: #cfe2f8; }

  /* SAP sub-list (subcategories under each category) */
  .sap-sublist {
    list-style: none; margin: .75rem 0 0;
    padding: .5rem .75rem;
    background: #fafbfc;
    border-radius: .5rem;
    border: 1px solid var(--sap-border-soft);
  }
  .sap-sublist li {
    display: flex; align-items: center; justify-content: space-between;
    padding: .35rem .25rem;
    border-bottom: 1px dashed #e8ebee;
    font-size: .8125rem;
  }
  .sap-sublist li:last-child { border-bottom: 0; }
  .sap-sublist li:hover { background: #f2f6fb; border-radius: .35rem; }
  .sap-sublist .sub-name { color: var(--sap-text); font-weight: 500; }
  .sap-sublist .sub-actions { display: flex; gap: .15rem; }

  /* SAP "Add" trailing row button inside the list */
  .sap-list-add {
    display: flex; align-items: center; justify-content: center; gap: .35rem;
    padding: .6rem 1rem; font-size: .8125rem; font-weight: 500;
    color: var(--sap-brand); cursor: pointer;
    border-top: 1px solid var(--sap-border-soft);
    background: var(--sap-tile);
    transition: background .12s;
  }
  .sap-list-add:hover { background: #eaf4ff; }

  /* SAP count badge on category title */
  .sap-count {
    display: inline-flex; align-items: center; gap: .25rem;
    font-size: .7rem; font-weight: 600;
    padding: .1rem .5rem;
    border-radius: .75rem;
    background: #eef2f7; color: var(--sap-text-muted);
    border: 1px solid #e4e7eb;
  }
  .sap-count .bi { font-size: .65rem; }

  @keyframes sapFadeUp {
    from { opacity: 0; transform: translateY(6px); }
    to   { opacity: 1; transform: translateY(0); }
  }

  /* Modal cleanup — SAP-style flat */
  .modal-content { border-radius: .75rem; border: 0; box-shadow: var(--sap-shadow-hover); }
  .modal-header   { border-bottom: 1px solid var(--sap-border-soft); }
  .modal-footer   { border-top: 1px solid var(--sap-border-soft); }
  .form-label     { font-size: .8125rem; font-weight: 500; color: var(--sap-text); }
  .form-control:focus, .form-select:focus {
    border-color: var(--sap-brand);
    box-shadow: 0 0 0 2px rgba(0,112,242,.15);
  }
</style>

<!-- ================= Page header ================= -->
<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb">
      <i class="bi bi-house-door"></i> Home / Configuration / <strong>Categories</strong>
    </div>
    <h1 class="sap-page-title">Categories &amp; Subcategories</h1>
  </div>
  <div class="d-flex align-items-center gap-2">
    <span class="sap-status is-count">
      <i class="bi bi-diagram-3"></i> <?= count($cats) ?> categories
    </span>
    <span class="sap-status is-count">
      <i class="bi bi-list-ul"></i> <?= count($subs) ?> subcategories
    </span>
  </div>
</div>

<?php if ($error): ?>
  <div class="alert alert-danger"><?= e($error) ?></div>
<?php endif; ?>
<?php if ($ok): ?>
  <div class="alert alert-success"><?= e($ok) ?></div>
<?php endif; ?>

<div class="row g-3">
  <div class="col-lg-8 col-xl-7">

    <!-- SAP toolbar -->
    <div class="sap-toolbar">
      <div class="sap-toolbar-title">
        <i class="bi bi-tags"></i> Category Hierarchy
      </div>
      <div class="sap-toolbar-actions">
        <button class="sap-btn sap-btn-emphasized"
                data-bs-toggle="modal" data-bs-target="#newCat">
          <i class="bi bi-plus-lg"></i> Add Category
        </button>
      </div>
    </div>

    <!-- SAP list -->
    <div class="sap-list">
      <?php if (!$cats): ?>
        <div class="text-center text-muted small py-5">
          <i class="bi bi-inbox" style="font-size:2rem;opacity:.4"></i>
          <div class="mt-2">No categories yet. Click <strong>Add Category</strong> to begin.</div>
        </div>
      <?php else: foreach ($cats as $i => $c): ?>
        <div class="sap-li" style="animation-delay: <?= $i * 30 ?>ms">

          <div class="sap-li-head">
            <div>
              <div class="sap-li-title">
                <i class="bi bi-folder2-open"></i>
                <?= e($c['category_name']) ?>
                <span class="sap-status <?= $c['status']==='ACTIVE' ? '' : 'is-inactive' ?>">
                  <i class="bi bi-<?= $c['status']==='ACTIVE' ? 'check-circle' : 'circle' ?>"></i>
                  <?= $c['status']==='ACTIVE' ? 'Active' : 'Inactive' ?>
                </span>
                <span class="sap-count" title="Tickets in this category">
                  <i class="bi bi-ticket-detailed"></i> <?= (int)$c['ticket_count'] ?>
                </span>
                <span class="sap-count" title="Subcategories under this category">
                  <i class="bi bi-diagram-2"></i> <?= (int)$c['sub_count'] ?>
                </span>
              </div>
              <?php if (!empty($c['description'])): ?>
                <div class="sap-li-desc"><?= e($c['description']) ?></div>
              <?php endif; ?>
            </div>

            <div class="sap-li-actions">
              <button class="sap-btn sap-btn-icon"
                      title="Add subcategory"
                      data-bs-toggle="modal" data-bs-target="#newSub"
                      data-cat="<?= (int)$c['id'] ?>"
                      data-catname="<?= e($c['category_name']) ?>">
                <i class="bi bi-plus-lg"></i>
              </button>
              <button class="sap-btn sap-btn-icon"
                      title="Edit category"
                      data-bs-toggle="modal" data-bs-target="#editCat"
                      data-id="<?= (int)$c['id'] ?>"
                      data-name="<?= e($c['category_name']) ?>"
                      data-description="<?= e($c['description'] ?? '') ?>">
                <i class="bi bi-pencil"></i>
              </button>
              <form method="post" class="d-inline">
                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="action" value="toggle_cat">
                <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                <button class="sap-btn sap-btn-icon"
                        title="<?= $c['status']==='ACTIVE' ? 'Deactivate' : 'Activate' ?>">
                  <i class="bi bi-power"></i>
                </button>
              </form>
              <button class="sap-btn sap-btn-icon sap-btn-negative"
                      title="Delete category"
                      data-bs-toggle="modal" data-bs-target="#deleteCat"
                      data-id="<?= (int)$c['id'] ?>"
                      data-name="<?= e($c['category_name']) ?>"
                      data-tickets="<?= (int)$c['ticket_count'] ?>"
                      data-subs="<?= (int)$c['sub_count'] ?>">
                <i class="bi bi-trash"></i>
              </button>
            </div>
          </div>

          <?php if (!empty($subByCat[$c['id']])): ?>
            <ul class="sap-sublist">
              <?php foreach ($subByCat[$c['id']] as $s): ?>
                <li>
                  <span class="sub-name">
                    <i class="bi bi-<?= $s['status']==='ACTIVE' ? 'dot' : 'circle' ?>"
                       style="color:<?= $s['status']==='ACTIVE' ? '#256f3a' : '#5b738b' ?>"></i>
                    <?= e($s['name']) ?>
                    <?php if ((int)$s['ticket_count'] > 0): ?>
                      <span class="sap-count ms-1" title="Tickets in this subcategory">
                        <?= (int)$s['ticket_count'] ?>
                      </span>
                    <?php endif; ?>
                  </span>
                  <span class="sub-actions">
                    <button class="sap-btn sap-btn-icon"
                            title="Edit subcategory"
                            data-bs-toggle="modal" data-bs-target="#editSub"
                            data-id="<?= (int)$s['id'] ?>"
                            data-name="<?= e($s['name']) ?>"
                            data-description="<?= e($s['description'] ?? '') ?>">
                      <i class="bi bi-pencil"></i>
                    </button>
                    <form method="post" class="d-inline">
                      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                      <input type="hidden" name="action" value="toggle_sub">
                      <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
                      <button class="sap-btn sap-btn-icon"
                              title="<?= $s['status']==='ACTIVE' ? 'Deactivate' : 'Activate' ?>">
                        <i class="bi bi-power"></i>
                      </button>
                    </form>
                    <button class="sap-btn sap-btn-icon sap-btn-negative"
                            title="Delete subcategory"
                            data-bs-toggle="modal" data-bs-target="#deleteSub"
                            data-id="<?= (int)$s['id'] ?>"
                            data-name="<?= e($s['name']) ?>"
                            data-tickets="<?= (int)$s['ticket_count'] ?>">
                      <i class="bi bi-trash"></i>
                    </button>
                  </span>
                </li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </div>
      <?php endforeach; endif; ?>
    </div>

  </div>

  <!-- SAP Analytical sidebar — plain guidance panel -->
  <div class="col-lg-4 col-xl-5">
    <div class="sap-toolbar" style="border-radius:.75rem;border-bottom:0">
      <div class="sap-toolbar-title"><i class="bi bi-info-circle"></i> Guidelines</div>
    </div>
    <div class="sap-list p-3">
      <ul class="small mb-0" style="padding-left:1rem;color:var(--sap-text-muted);line-height:1.7">
        <li>Categories group tickets by support area (Network, Hardware, …).</li>
        <li><strong>Subcategories</strong> narrow a request further (e.g. <em>Printer</em> under <em>Hardware Support</em>).</li>
        <li>Deactivate a category rather than delete it if it has ever been used by a ticket — the history stays intact.</li>
        <li>Deleting is only allowed when <em>0</em> tickets and <em>0</em> subcategories reference the row.</li>
        <li>Toggle the status badge to hide a category from new ticket forms without losing reporting data.</li>
      </ul>
    </div>
  </div>
</div>

<!-- ================= Add Category Modal ================= -->
<div class="modal fade" id="newCat"><div class="modal-dialog"><div class="modal-content">
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="create_cat">
<div class="modal-header">
  <h5 class="modal-title"><i class="bi bi-plus-circle text-primary"></i> Add Category</h5>
  <button class="btn-close" data-bs-dismiss="modal" type="button"></button>
</div>
<div class="modal-body">
  <div class="mb-3"><label class="form-label">Name *</label>
    <input name="name" class="form-control" required maxlength="100"></div>
  <div class="mb-3"><label class="form-label">Description</label>
    <textarea name="description" class="form-control" rows="3"></textarea></div>
</div>
<div class="modal-footer">
  <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Cancel</button>
  <button class="sap-btn sap-btn-emphasized">Create</button>
</div>
</form>
</div></div></div>

<!-- ================= Edit Category Modal ================= -->
<div class="modal fade" id="editCat"><div class="modal-dialog"><div class="modal-content">
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="update_cat">
<input type="hidden" name="id" id="ec_id">
<div class="modal-header">
  <h5 class="modal-title"><i class="bi bi-pencil text-primary"></i> Edit Category</h5>
  <button class="btn-close" data-bs-dismiss="modal" type="button"></button>
</div>
<div class="modal-body">
  <div class="mb-3"><label class="form-label">Name *</label>
    <input name="name" id="ec_name" class="form-control" required maxlength="100"></div>
  <div class="mb-3"><label class="form-label">Description</label>
    <textarea name="description" id="ec_description" class="form-control" rows="3"></textarea></div>
</div>
<div class="modal-footer">
  <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Cancel</button>
  <button class="sap-btn sap-btn-emphasized">Save</button>
</div>
</form>
</div></div></div>

<!-- ================= Add Subcategory Modal ================= -->
<div class="modal fade" id="newSub"><div class="modal-dialog"><div class="modal-content">
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="create_sub">
<input type="hidden" name="category_id" id="subCatId">
<div class="modal-header">
  <h5 class="modal-title"><i class="bi bi-plus-circle text-primary"></i> Add Subcategory</h5>
  <button class="btn-close" data-bs-dismiss="modal" type="button"></button>
</div>
<div class="modal-body">
  <p class="small text-muted mb-3">Parent category:
    <strong id="subCatName">—</strong></p>
  <div class="mb-3"><label class="form-label">Name *</label>
    <input name="name" class="form-control" required maxlength="100"></div>
  <div class="mb-3"><label class="form-label">Description</label>
    <textarea name="description" class="form-control" rows="3"></textarea></div>
</div>
<div class="modal-footer">
  <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Cancel</button>
  <button class="sap-btn sap-btn-emphasized">Create</button>
</div>
</form>
</div></div></div>

<!-- ================= Edit Subcategory Modal ================= -->
<div class="modal fade" id="editSub"><div class="modal-dialog"><div class="modal-content">
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="update_sub">
<input type="hidden" name="id" id="es_id">
<div class="modal-header">
  <h5 class="modal-title"><i class="bi bi-pencil text-primary"></i> Edit Subcategory</h5>
  <button class="btn-close" data-bs-dismiss="modal" type="button"></button>
</div>
<div class="modal-body">
  <div class="mb-3"><label class="form-label">Name *</label>
    <input name="name" id="es_name" class="form-control" required maxlength="100"></div>
  <div class="mb-3"><label class="form-label">Description</label>
    <textarea name="description" id="es_description" class="form-control" rows="3"></textarea></div>
</div>
<div class="modal-footer">
  <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Cancel</button>
  <button class="sap-btn sap-btn-emphasized">Save</button>
</div>
</form>
</div></div></div>

<!-- ================= Delete Category Modal ================= -->
<div class="modal fade" id="deleteCat"><div class="modal-dialog"><div class="modal-content">
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="delete_cat">
<input type="hidden" name="id" id="dc_id">
<div class="modal-header" style="background:#fef4f4">
  <h5 class="modal-title"><i class="bi bi-exclamation-triangle text-danger"></i> Delete Category</h5>
  <button class="btn-close" data-bs-dismiss="modal" type="button"></button>
</div>
<div class="modal-body">
  <p>Delete <strong id="dc_name">this category</strong>?</p>
  <div class="alert alert-warning small mb-0" id="dc_warning">
    This action cannot be undone.
  </div>
</div>
<div class="modal-footer">
  <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Cancel</button>
  <button class="btn btn-danger"><i class="bi bi-trash"></i> Delete</button>
</div>
</form>
</div></div></div>

<!-- ================= Delete Subcategory Modal ================= -->
<div class="modal fade" id="deleteSub"><div class="modal-dialog"><div class="modal-content">
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="delete_sub">
<input type="hidden" name="id" id="ds_id">
<div class="modal-header" style="background:#fef4f4">
  <h5 class="modal-title"><i class="bi bi-exclamation-triangle text-danger"></i> Delete Subcategory</h5>
  <button class="btn-close" data-bs-dismiss="modal" type="button"></button>
</div>
<div class="modal-body">
  <p>Delete <strong id="ds_name">this subcategory</strong>?</p>
  <div class="alert alert-warning small mb-0" id="ds_warning">
    This action cannot be undone.
  </div>
</div>
<div class="modal-footer">
  <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Cancel</button>
  <button class="btn btn-danger"><i class="bi bi-trash"></i> Delete</button>
</div>
</form>
</div></div></div>

<script>
/* Populate Edit Category modal */
document.getElementById('editCat').addEventListener('show.bs.modal', e => {
  const b = e.relatedTarget;
  document.getElementById('ec_id').value          = b.dataset.id;
  document.getElementById('ec_name').value        = b.dataset.name;
  document.getElementById('ec_description').value = b.dataset.description;
});

/* Populate Add Subcategory modal */
document.getElementById('newSub').addEventListener('show.bs.modal', e => {
  const b = e.relatedTarget;
  document.getElementById('subCatId').value = b.dataset.cat;
  document.getElementById('subCatName').textContent = b.dataset.catname || '—';
});

/* Populate Edit Subcategory modal */
document.getElementById('editSub').addEventListener('show.bs.modal', e => {
  const b = e.relatedTarget;
  document.getElementById('es_id').value          = b.dataset.id;
  document.getElementById('es_name').value        = b.dataset.name;
  document.getElementById('es_description').value = b.dataset.description;
});

/* Delete Category modal — reflect counts in the warning */
document.getElementById('deleteCat').addEventListener('show.bs.modal', e => {
  const b = e.relatedTarget;
  document.getElementById('dc_id').value = b.dataset.id;
  document.getElementById('dc_name').textContent = b.dataset.name;
  const tickets = parseInt(b.dataset.tickets || '0', 10);
  const subs    = parseInt(b.dataset.subs    || '0', 10);
  const w = document.getElementById('dc_warning');
  if (tickets === 0 && subs === 0) {
    w.innerHTML = 'This category has no tickets or subcategories. It can be safely deleted.';
    w.className = 'alert alert-info small mb-0';
  } else {
    w.innerHTML = 'This category has <strong>' + tickets +
                  '</strong> ticket(s) and <strong>' + subs +
                  '</strong> subcategory(ies). Deletion will be <strong>blocked</strong> until those are removed or the category is deactivated instead.';
    w.className = 'alert alert-warning small mb-0';
  }
});

/* Delete Subcategory modal — reflect counts */
document.getElementById('deleteSub').addEventListener('show.bs.modal', e => {
  const b = e.relatedTarget;
  document.getElementById('ds_id').value = b.dataset.id;
  document.getElementById('ds_name').textContent = b.dataset.name;
  const tickets = parseInt(b.dataset.tickets || '0', 10);
  const w = document.getElementById('ds_warning');
  if (tickets === 0) {
    w.innerHTML = 'This subcategory has no tickets. It can be safely deleted.';
    w.className = 'alert alert-info small mb-0';
  } else {
    w.innerHTML = 'This subcategory has <strong>' + tickets +
                  '</strong> ticket(s). Deletion will be <strong>blocked</strong> until those are removed or it is deactivated instead.';
    w.className = 'alert alert-warning small mb-0';
  }
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
