<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('ADMIN');

$pdo = db();
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { app_fail('E-REQ-400', 'Invalid ticket id.'); }

$stmt = $pdo->prepare("SELECT t.*, c.category_name, sc.name AS subcat_name,
    p.name AS priority_name, p.color AS priority_color,
    req.full_name AS requester_name, d.department_name,
    tl.full_name AS tl_name, tech.full_name AS tech_name
    FROM tickets t
    JOIN categories c ON c.id=t.category_id
    LEFT JOIN subcategories sc ON sc.id=t.subcategory_id
    JOIN priorities p ON p.id=t.priority_id
    JOIN users req ON req.id=t.requester_id
    LEFT JOIN departments d ON d.id=t.department_id
    LEFT JOIN users tl ON tl.id=t.team_leader_id
    LEFT JOIN users tech ON tech.id=t.assigned_technician_id
    WHERE t.id=?");
$stmt->execute([$id]);
$t = $stmt->fetch();
if (!$t) { app_fail('E-TKT-404'); }

$pageTitle = $t['ticket_number'];

$history = $pdo->prepare("SELECT h.*, u.full_name FROM ticket_history h
    JOIN users u ON u.id=h.user_id WHERE h.ticket_id=? ORDER BY h.created_at");
$history->execute([$id]); $history = $history->fetchAll();

$attachments = $pdo->prepare("SELECT * FROM ticket_attachments WHERE ticket_id=? ORDER BY uploaded_at");
$attachments->execute([$id]); $attachments = $attachments->fetchAll();

$comments = $pdo->prepare("SELECT c.*, u.full_name FROM ticket_comments c
    JOIN users u ON u.id=c.user_id WHERE c.ticket_id=? ORDER BY c.created_at");
$comments->execute([$id]); $comments = $comments->fetchAll();

$work = $pdo->prepare("SELECT w.*, u.full_name FROM ticket_work_logs w
    JOIN users u ON u.id=w.technician_id WHERE w.ticket_id=? ORDER BY w.created_at DESC");
$work->execute([$id]); $work = $work->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="d-flex justify-content-between align-items-start mb-3">
  <div>
    <h4 class="mb-1"><?= e($t['ticket_number']) ?> — <?= e($t['subject']) ?></h4>
    <div class="text-muted small">Opened <?= e(date('Y-m-d H:i', strtotime($t['created_at']))) ?></div>
  </div>
  <div class="d-flex gap-2">
    <?= status_badge($t['status']) ?>
    <a href="<?= BASE_URL ?>/admin/tickets.php" class="btn btn-outline-secondary btn-sm">
      <i class="bi bi-arrow-left"></i> Back
    </a>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-8">
    <div class="card mb-3"><div class="card-body small">
      <div class="row g-2">
        <div class="col-md-4"><strong>Requester:</strong> <?= e($t['requester_name']) ?></div>
        <div class="col-md-4"><strong>Department:</strong> <?= e($t['department_name'] ?? '-') ?></div>
        <div class="col-md-4"><strong>Team Leader:</strong> <?= e($t['tl_name'] ?? '-') ?></div>
        <div class="col-md-4"><strong>Category:</strong> <?= e($t['category_name']) ?></div>
        <div class="col-md-4"><strong>Subcategory:</strong> <?= e($t['subcat_name'] ?? '-') ?></div>
        <div class="col-md-4"><strong>Priority:</strong>
          <span class="badge bg-<?= e($t['priority_color']) ?>"><?= e($t['priority_name']) ?></span></div>
        <div class="col-md-4"><strong>Location:</strong> <?= e($t['location'] ?? '-') ?></div>
        <div class="col-md-4"><strong>Asset:</strong> <?= e($t['asset_number'] ?? '-') ?></div>
        <div class="col-md-4"><strong>Technician:</strong> <?= e($t['tech_name'] ?? '-') ?></div>
        <div class="col-md-4"><strong>Approved:</strong>
          <?= $t['team_leader_approved_at'] ? e(date('Y-m-d H:i', strtotime($t['team_leader_approved_at']))) : '-' ?></div>
        <div class="col-md-4"><strong>Closed:</strong>
          <?= $t['closed_at'] ? e(date('Y-m-d H:i', strtotime($t['closed_at']))) : '-' ?></div>
      </div>
      <hr>
      <h6>Description</h6>
      <p style="white-space:pre-wrap"><?= e($t['description']) ?></p>

      <?php if (!empty($t['rejection_reason'])): ?>
        <div class="alert alert-danger mb-2">
          <strong>Rejection Reason:</strong> <?= e($t['rejection_reason']) ?>
        </div>
      <?php endif; ?>
      <?php if (!empty($t['clarification_reason'])): ?>
        <div class="alert alert-warning mb-2">
          <strong>Clarification:</strong> <?= e($t['clarification_reason']) ?>
        </div>
      <?php endif; ?>
      <?php if (!empty($t['verification_comment'])): ?>
        <div class="alert alert-success mb-0">
          <strong>Requester Confirmation Comment:</strong> <?= e($t['verification_comment']) ?>
        </div>
      <?php endif; ?>
    </div></div>

    <?php if ($work): ?>
      <div class="card mb-3"><div class="card-body">
        <h6>ICT Work Logs</h6>
        <?php foreach ($work as $w): ?>
          <div class="border rounded p-2 mb-2 small">
            <div class="text-muted">
              <?= e($w['full_name']) ?> · <?= e(date('Y-m-d H:i', strtotime($w['created_at']))) ?>
            </div>
            <div><strong>Diagnosis:</strong> <?= e($w['diagnosis'] ?? '-') ?></div>
            <div><strong>Action Taken:</strong> <?= e($w['action_taken'] ?? '-') ?></div>
            <div><strong>Root Cause:</strong> <?= e($w['root_cause'] ?? '-') ?></div>
            <div><strong>Resolution:</strong> <?= e($w['resolution'] ?? '-') ?></div>
          </div>
        <?php endforeach; ?>
      </div></div>
    <?php endif; ?>

    <div class="card"><div class="card-body">
      <h6>Timeline</h6>
      <?php if (!$history): ?>
        <p class="text-muted small mb-0">No history entries.</p>
      <?php else: ?>
        <ul class="timeline">
          <?php foreach ($history as $h): ?>
            <li>
              <strong><?= e($h['action']) ?></strong>
              <small class="text-muted ms-2">
                <?= e($h['full_name']) ?> · <?= e(date('Y-m-d H:i', strtotime($h['created_at']))) ?>
              </small>
              <?php if ($h['comment']): ?>
                <div class="small"><?= nl2br(e($h['comment'])) ?></div>
              <?php endif; ?>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div></div>
  </div>

  <div class="col-lg-4">
    <div class="card mb-3"><div class="card-body">
      <h6>Attachments</h6>
      <?php if (!$attachments): ?>
        <p class="small text-muted mb-0">None.</p>
      <?php else: foreach ($attachments as $a): ?>
        <div class="small mb-1">
          <a href="<?= UPLOAD_URL . e($a['stored_name']) ?>" target="_blank">
            <i class="bi bi-paperclip"></i> <?= e($a['file_name']) ?>
          </a>
          <div class="text-muted"><?= e($a['file_type']) ?> · <?= number_format($a['file_size']/1024,1) ?> KB</div>
        </div>
      <?php endforeach; endif; ?>
    </div></div>

    <div class="card"><div class="card-body">
      <h6>Comments</h6>
      <?php if (!$comments): ?>
        <p class="small text-muted mb-0">None.</p>
      <?php else: foreach ($comments as $c): ?>
        <div class="small border-bottom pb-2 mb-2">
          <strong><?= e($c['full_name']) ?></strong>
          <span class="text-muted"><?= e(date('Y-m-d H:i', strtotime($c['created_at']))) ?></span>
          <div><?= nl2br(e($c['comment'])) ?></div>
        </div>
      <?php endforeach; endif; ?>
    </div></div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
