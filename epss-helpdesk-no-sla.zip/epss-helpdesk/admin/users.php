<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('ADMIN');
$pageTitle = 'User Management';

$pdo = db();
$error = $ok = '';

/* Default password for every new user and every reset */
if (!defined('DEFAULT_PASSWORD')) {
    define('DEFAULT_PASSWORD', 'pass@123');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf($_POST['csrf'] ?? null)) {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'create') {
            $role   = $_POST['role'];
            $deptId = $_POST['department_id']  ?: null;
            $tlId   = $_POST['team_leader_id'] ?: null;

            if (in_array($role, ['TEAM_LEADER','BRANCH_MANAGER'], true) && !$deptId) {
                throw new RuntimeException('Team Leader / Branch Manager must have a department.');
            }
            if ($role === 'EMPLOYEE' && !$tlId) {
                throw new RuntimeException('Employee must have a Team Leader or Branch Manager.');
            }

            $temp = DEFAULT_PASSWORD;
            $hash = password_hash($temp, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users
                (employee_id,full_name,username,email,phone,password_hash,role,department_id,team_leader_id,position,must_change_password)
                VALUES (?,?,?,?,?,?,?,?,?,?,1)");
            $stmt->execute([
                $_POST['employee_id'] ?: null,
                trim($_POST['full_name']),
                trim($_POST['username']),
                $_POST['email']    ?: null,
                $_POST['phone']    ?: null,
                $hash, $role, $deptId, $tlId,
                $_POST['position'] ?: null,
            ]);
            $newId = (int)$pdo->lastInsertId();
            audit('CreateUser','users',$newId,'Created user ' . $_POST['username']);
            $ok = "User created. Default password: <strong>" . e(DEFAULT_PASSWORD) . "</strong> — the user must change it on first login.";

        } elseif ($action === 'update') {
            $id     = (int)$_POST['id'];
            $role   = $_POST['role'];
            $deptId = $_POST['department_id']  ?: null;
            $tlId   = $_POST['team_leader_id'] ?: null;

            if (in_array($role, ['TEAM_LEADER','BRANCH_MANAGER'], true) && !$deptId) {
                throw new RuntimeException('Team Leader / Branch Manager must have a department.');
            }
            if ($role === 'EMPLOYEE' && !$tlId) {
                throw new RuntimeException('Employee must have a Team Leader or Branch Manager.');
            }
            if ($id === (int)$u['id'] && $role !== 'ADMIN') {
                throw new RuntimeException('You cannot remove your own Administrator role.');
            }

            $pdo->prepare("UPDATE users SET
                employee_id=?, full_name=?, username=?, email=?, phone=?,
                role=?, department_id=?, team_leader_id=?, position=?
                WHERE id=?")->execute([
                $_POST['employee_id'] ?: null,
                trim($_POST['full_name']),
                trim($_POST['username']),
                $_POST['email']    ?: null,
                $_POST['phone']    ?: null,
                $role, $deptId, $tlId,
                $_POST['position'] ?: null,
                $id,
            ]);
            audit('UpdateUser','users',$id,'Updated user ' . $_POST['username']);
            $ok = 'User updated.';

        } elseif ($action === 'toggle_status') {
            $id = (int)$_POST['id'];
            $pdo->prepare("UPDATE users SET status = IF(status='ACTIVE','INACTIVE','ACTIVE') WHERE id=? AND id<>?")
                ->execute([$id, $u['id']]);
            audit('ToggleUserStatus','users',$id,'Status toggled');
            $ok = 'Status updated.';

        } elseif ($action === 'reset_password') {
            $id   = (int)$_POST['id'];
            $temp = DEFAULT_PASSWORD;
            $pdo->prepare("UPDATE users SET password_hash=?, must_change_password=1, failed_login_attempts=0, locked_until=NULL WHERE id=?")
                ->execute([password_hash($temp, PASSWORD_DEFAULT), $id]);
            audit('ResetPassword','users',$id,'Password reset');
            $ok = "Password reset. Default password: <strong>" . e(DEFAULT_PASSWORD) . "</strong> — the user must change it on next login.";
        }
    } catch (Throwable $e) {
        $error = app_exception_message($e);
    }
}

/* ------------------ Dropdown data ------------------ */
$depts = $pdo->query("
    SELECT * FROM departments
    WHERE status='ACTIVE'
    ORDER BY department_name
")->fetchAll();

$tls = $pdo->query("
    SELECT u.*, d.department_name
    FROM users u
    LEFT JOIN departments d ON d.id=u.department_id
    WHERE u.role IN ('TEAM_LEADER','BRANCH_MANAGER')
      AND u.status='ACTIVE'
    ORDER BY u.full_name
")->fetchAll();

/* ------------------ Filters ------------------ */
$q          = trim($_GET['q'] ?? '');
$filterRole = $_GET['role'] ?? '';
$filterLink = $_GET['link'] ?? '';

/* ------------------ List ------------------ */
$sql = "SELECT u.*, d.department_name AS dept_name, tl.full_name AS tl_name
        FROM users u
        LEFT JOIN departments d ON d.id=u.department_id
        LEFT JOIN users tl ON tl.id=u.team_leader_id
        WHERE 1=1";
$params = [];

if ($q !== '') {
    $sql .= " AND (
        u.full_name   LIKE ?
     OR u.username    LIKE ?
     OR u.employee_id LIKE ?
     OR u.email       LIKE ?
     OR u.phone       LIKE ?
     OR u.position    LIKE ?
     OR d.department_name LIKE ?
    )";
    $like = "%$q%";
    array_push($params, $like, $like, $like, $like, $like, $like, $like);
}
if ($filterRole) {
    $sql .= " AND u.role = ?";
    $params[] = $filterRole;
}
if ($filterLink === 'linked') {
    $sql .= " AND u.telegram_chat_id IS NOT NULL";
} elseif ($filterLink === 'none') {
    $sql .= " AND u.telegram_chat_id IS NULL";
}
$sql .= " ORDER BY u.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

/* How many of the current list have linked the notification bot */
$linkedCount = count(array_filter($users, fn($x) => $x['telegram_chat_id'] !== null));
$noPhoneCount = count(array_filter($users,
    fn($x) => $x['telegram_chat_id'] === null && ($x['phone'] === null || $x['phone'] === '')));

include __DIR__ . '/../includes/header.php';
?>

<!-- ================= SAP Fiori Horizon theme ================= -->
<style>
  :root {
    --sap-brand:        #0070f2;
    --sap-brand-dark:   #0057d2;
    --sap-bg:           #f5f6f7;
    --sap-tile:         #ffffff;
    --sap-text:         #1d2d3e;
    --sap-text-muted:   #556b82;
    --sap-border:       #d9d9d9;
    --sap-border-soft:  #eaecf0;
    --sap-positive:     #256f3a;
    --sap-critical:     #e76500;
    --sap-negative:     #aa0808;
    --sap-neutral:      #5b738b;
    --sap-shadow:       0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
    --sap-shadow-hover: 0 0 0 1px rgba(34,53,72,.15), 0 8px 24px 0 rgba(34,53,72,.12);
  }

  body, .main-content {
    background: var(--sap-bg) !important;
    font-family: "72", "72full", Arial, Helvetica, sans-serif !important;
    color: var(--sap-text);
  }

  .sap-page-header {
    display: flex; align-items: flex-start; justify-content: space-between;
    margin-bottom: 1rem;
  }
  .sap-page-title { font-size: 1.625rem; font-weight: 400; margin: 0; }
  .sap-breadcrumb { font-size: .8125rem; color: var(--sap-text-muted); margin-bottom: .25rem; }

  /* ---------- Filter bar ---------- */
  .sap-filterbar {
    background: var(--sap-tile);
    border-radius: .75rem .75rem 0 0;
    box-shadow: var(--sap-shadow);
    padding: .85rem 1rem;
    border-bottom: 1px solid var(--sap-border-soft);
  }
  .sap-filterbar-row {
    display: flex; gap: .5rem; flex-wrap: wrap; align-items: center;
  }
  .sap-search-wrap {
    position: relative;
    flex: 1 1 340px;
    min-width: 260px;
  }
  .sap-search-wrap i {
    position: absolute;
    left: .75rem; top: 50%;
    transform: translateY(-50%);
    color: var(--sap-text-muted);
    font-size: .9rem;
    pointer-events: none;
    transition: color .15s;
  }
  .sap-search-wrap input {
    width: 100%;
    font-size: .875rem;
    padding: .55rem 2.4rem .55rem 2.2rem;
    border-radius: .55rem;
    border: 1px solid var(--sap-border);
    background: #fff;
    color: var(--sap-text);
    font-family: inherit;
    transition: border-color .15s, box-shadow .15s;
  }
  .sap-search-wrap input::placeholder { color: #98a9bb; }
  .sap-search-wrap input:focus {
    outline: none;
    border-color: var(--sap-brand);
    box-shadow: 0 0 0 3px rgba(0,112,242,.15);
  }
  .sap-search-wrap:focus-within i { color: var(--sap-brand); }
  .sap-search-clear {
    position: absolute;
    right: .55rem; top: 50%;
    transform: translateY(-50%);
    border: 0; background: transparent;
    color: var(--sap-text-muted);
    font-size: .95rem;
    line-height: 1;
    padding: .25rem;
    border-radius: .35rem;
    cursor: pointer;
    transition: background .15s, color .15s;
    display: none;
  }
  .sap-search-clear.show { display: inline-flex; }
  .sap-search-clear:hover { background: #f2f5f8; color: var(--sap-negative); }

  .sap-filterbar select {
    font-size: .8125rem;
    border: 1px solid var(--sap-border);
    background: #fff;
    border-radius: .55rem;
    padding: .5rem 2rem .5rem .65rem;
    color: var(--sap-text);
    appearance: none;
    background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'><path fill='%23556b82' d='M3 5l3 3 3-3z'/></svg>");
    background-repeat: no-repeat;
    background-position: right .5rem center;
    font-family: inherit;
    min-width: 160px;
  }
  .sap-filterbar select:focus {
    outline: none;
    border-color: var(--sap-brand);
    box-shadow: 0 0 0 3px rgba(0,112,242,.15);
  }

  .sap-toolbar {
    display: flex; align-items: center; justify-content: space-between;
    background: var(--sap-tile);
    padding: .5rem .75rem;
    border-bottom: 1px solid var(--sap-border-soft);
    flex-wrap: wrap; gap: .5rem;
  }
  .sap-toolbar-title {
    font-size: .875rem; font-weight: 600;
    display: flex; align-items: center; gap: .4rem;
  }
  .sap-toolbar-title .bi { color: var(--sap-brand); }
  .sap-toolbar-info { font-size: .8125rem; color: var(--sap-text-muted); }
  .sap-toolbar-actions { display: flex; gap: .25rem; align-items: center; flex-wrap: wrap; }

  .sap-btn {
    display: inline-flex; align-items: center; gap: .35rem;
    font-size: .8125rem; font-weight: 500;
    border-radius: .5rem;
    padding: .35rem .7rem;
    border: 1px solid transparent;
    background: transparent;
    color: var(--sap-brand);
    transition: background .15s, box-shadow .15s, color .15s;
    cursor: pointer;
    line-height: 1;
    text-decoration: none;
  }
  .sap-btn:hover { background: #eaf4ff; color: var(--sap-brand-dark); }
  .sap-btn:focus-visible { outline: 2px solid var(--sap-brand); outline-offset: 2px; }
  .sap-btn.sap-btn-emphasized {
    background: var(--sap-brand); color: #fff;
    box-shadow: 0 1px 2px rgba(34,53,72,.15);
  }
  .sap-btn.sap-btn-emphasized:hover { background: var(--sap-brand-dark); color: #fff; }
  .sap-btn.sap-btn-negative { color: var(--sap-negative); }
  .sap-btn.sap-btn-negative:hover { background: #fef4f4; color: var(--sap-negative); }
  .sap-btn.sap-btn-icon { padding: .35rem .5rem; }

  .sap-table-wrap {
    background: var(--sap-tile);
    border-radius: 0 0 .75rem .75rem;
    box-shadow: var(--sap-shadow);
    overflow: hidden;
  }
  table.sap-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    font-size: .8125rem;
    margin: 0;
  }
  table.sap-table thead th {
    background: #f5f6f7;
    border-bottom: 1px solid var(--sap-border);
    font-weight: 600;
    color: var(--sap-text-muted);
    text-align: left;
    padding: .6rem .75rem;
    white-space: nowrap;
    text-transform: uppercase;
    font-size: .7rem;
    letter-spacing: .04em;
  }
  table.sap-table tbody td {
    padding: .65rem .75rem;
    border-bottom: 1px solid var(--sap-border-soft);
    vertical-align: middle;
    color: var(--sap-text);
  }
  table.sap-table tbody tr:last-child td { border-bottom: 0; }
  table.sap-table tbody tr { transition: background .12s; }
  table.sap-table tbody tr:hover { background: #f8fbff; }

  /* Search match highlight */
  mark.sap-hl {
    background: #fff2b8;
    color: inherit;
    padding: 0 .1em;
    border-radius: .2em;
  }

  .sap-status {
    display: inline-flex; align-items: center; gap: .25rem;
    font-size: .7rem; font-weight: 600;
    padding: .1rem .5rem;
    border-radius: .75rem;
    background: #f1fdf6; color: var(--sap-positive);
    border: 1px solid #d6f0e0;
    white-space: nowrap;
  }
  .sap-status.is-inactive { background: #f4f5f7; color: var(--sap-neutral); border-color: #e4e7eb; }
  .sap-status.is-info     { background: #eaf4ff; color: var(--sap-brand);   border-color: #cfe2f8; }

  .sap-role {
    display: inline-flex; align-items: center; gap: .3rem;
    font-size: .7rem; font-weight: 600;
    padding: .15rem .55rem;
    border-radius: .75rem;
    white-space: nowrap;
  }
  .sap-role.role-ADMIN          { background:#f4f5f7; color:#354a5f; }
  .sap-role.role-BRANCH_MANAGER { background:#f0e6ff; color:#5b21b6; }
  .sap-role.role-TEAM_LEADER    { background:#eaf4ff; color:var(--sap-brand); }
  .sap-role.role-ICT_STAFF      { background:#f1fdf6; color:var(--sap-positive); }
  .sap-role.role-EMPLOYEE       { background:#fff8f1; color:var(--sap-critical); }

  .sap-avatar {
    width: 34px; height: 34px;
    border-radius: 50%;
    background: var(--sap-brand);
    color: #fff;
    display: inline-flex; align-items: center; justify-content: center;
    font-weight: 600; font-size: .85rem;
    flex-shrink: 0;
  }
  .sap-avatar.role-ADMIN          { background:#354a5f; }
  .sap-avatar.role-BRANCH_MANAGER { background:#7c4dff; }
  .sap-avatar.role-TEAM_LEADER    { background:var(--sap-brand); }
  .sap-avatar.role-ICT_STAFF      { background:var(--sap-positive); }
  .sap-avatar.role-EMPLOYEE       { background:var(--sap-critical); }

  .sap-user-cell { display: flex; align-items: center; gap: .6rem; }
  .sap-user-name { font-weight: 600; color: var(--sap-text); line-height: 1.15; }
  .sap-user-sub  { font-size: .72rem; color: var(--sap-text-muted); }

  .sap-empty { text-align: center; padding: 2.5rem 1rem; color: var(--sap-text-muted); }
  .sap-empty .bi { font-size: 2rem; opacity: .4; }
  .sap-empty-title { font-weight: 600; font-size: 1rem; color: var(--sap-text); margin-top: .5rem; }
  .sap-empty-hint  { font-size: .82rem; margin-top: .25rem; }

  .modal-content { border-radius: .75rem; border: 0; box-shadow: var(--sap-shadow-hover); }
  .modal-header  { border-bottom: 1px solid var(--sap-border-soft); }
  .modal-footer  { border-top: 1px solid var(--sap-border-soft); }
  .form-label    { font-size: .8125rem; font-weight: 500; color: var(--sap-text); }
  .form-control:focus, .form-select:focus {
    border-color: var(--sap-brand);
    box-shadow: 0 0 0 2px rgba(0,112,242,.15);
  }

  @media (prefers-reduced-motion: reduce) {
    table.sap-table tbody tr { transition: none !important; }
  }
</style>

<!-- ================= Page header ================= -->
<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb">
      <i class="bi bi-house-door"></i> Home / Administration / <strong>User Management</strong>
    </div>
    <h1 class="sap-page-title">User Management</h1>
  </div>
  <div class="d-flex align-items-center gap-2 flex-wrap">
    <span class="sap-status is-info">
      <i class="bi bi-people"></i> <?= count($users) ?> user<?= count($users) === 1 ? '' : 's' ?>
    </span>
    <?php if ($filterRole): ?>
      <span class="sap-status is-info">
        <i class="bi bi-funnel"></i> <?= e(str_replace('_',' ', $filterRole)) ?>
      </span>
    <?php endif; ?>
    <?php if ($filterLink): ?>
      <span class="sap-status is-info">
        <i class="bi bi-telegram"></i> <?= $filterLink === 'linked' ? 'Linked to bot' : 'Not linked' ?>
      </span>
    <?php endif; ?>
    <?php if ($q !== ''): ?>
      <span class="sap-status is-info">
        <i class="bi bi-search"></i> "<?= e($q) ?>"
      </span>
    <?php endif; ?>
  </div>
</div>

<?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<?php if ($ok): ?><div class="alert alert-success"><?= $ok ?></div><?php endif; ?>

<!-- ================= Filter bar (search + role) ================= -->
<div class="sap-filterbar">
  <form class="sap-filterbar-row" method="get" id="usersFilterForm">
    <div class="sap-search-wrap">
      <i class="bi bi-search"></i>
      <input type="search"
             name="q"
             id="userSearch"
             placeholder="Search by name, username, employee ID, email, phone, position or department…"
             value="<?= e($q) ?>"
             autocomplete="off"
             spellcheck="false">
      <button type="button"
              class="sap-search-clear<?= $q !== '' ? ' show' : '' ?>"
              id="clearSearch"
              title="Clear search"
              aria-label="Clear search">
        <i class="bi bi-x-circle-fill"></i>
      </button>
    </div>

    <select name="role" onchange="this.form.submit()">
      <option value="">All Roles</option>
      <?php foreach (['ADMIN','BRANCH_MANAGER','TEAM_LEADER','EMPLOYEE','ICT_STAFF'] as $r): ?>
        <option value="<?= $r ?>" <?= $filterRole === $r ? 'selected' : '' ?>>
          <?= e(str_replace('_',' ', $r)) ?>
        </option>
      <?php endforeach; ?>
    </select>

    <select name="link" onchange="this.form.submit()">
      <option value="">Bot: everyone</option>
      <option value="linked" <?= $filterLink === 'linked' ? 'selected' : '' ?>>Bot: linked only</option>
      <option value="none"   <?= $filterLink === 'none'   ? 'selected' : '' ?>>Bot: not linked</option>
    </select>

    <button class="sap-btn sap-btn-emphasized" type="submit">
      <i class="bi bi-search"></i> Search
    </button>

    <?php if ($q !== '' || $filterRole || $filterLink): ?>
      <a class="sap-btn" href="users.php">
        <i class="bi bi-x-circle"></i> Clear
      </a>
    <?php endif; ?>
  </form>
</div>

<!-- ================= Toolbar ================= -->
<div class="sap-toolbar">
  <div class="sap-toolbar-title">
    <i class="bi bi-person-lines-fill"></i> User List
    <span class="sap-toolbar-info">
      · <?= count($users) ?> row<?= count($users) === 1 ? '' : 's' ?>
      <?= ($q || $filterRole || $filterLink) ? ' (filtered)' : '' ?>
      · <i class="bi bi-telegram"></i> <?= $linkedCount ?> linked to bot,
        <?= count($users) - $linkedCount ?> not<?= $noPhoneCount
            ? " ({$noPhoneCount} with no phone — they cannot link until ICT adds one)"
            : '' ?>
    </span>
  </div>
  <div class="sap-toolbar-actions">
    <button class="sap-btn sap-btn-emphasized"
            data-bs-toggle="modal" data-bs-target="#newUserModal">
      <i class="bi bi-person-plus"></i> Add User
    </button>
  </div>
</div>

<!-- ================= Table ================= -->
<div class="sap-table-wrap">
  <?php if (!$users): ?>
    <div class="sap-empty">
      <i class="bi bi-person-x"></i>
      <div class="sap-empty-title">
        <?= ($q || $filterRole || $filterLink) ? 'No users match your search' : 'No users yet' ?>
      </div>
      <div class="sap-empty-hint">
        <?php if ($q || $filterRole || $filterLink): ?>
          Try a different name, or
          <a class="sap-btn" style="padding:0;display:inline" href="users.php">clear the filters</a>.
        <?php else: ?>
          Click <strong>Add User</strong> to create the first user.
        <?php endif; ?>
      </div>
    </div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="sap-table">
        <thead>
          <tr>
            <th>User</th>
            <th>Employee ID</th>
            <th>Role</th>
            <th>Department</th>
            <th>Team Leader / Branch Manager</th>
            <th>Status</th>
            <th>Notification bot</th>
            <th style="text-align:right;">Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php
        /* Helper to highlight the search term in a string */
        $hl = function (?string $text) use ($q) {
            $text = (string)$text;
            if ($q === '') return e($text);
            // Use a multibyte-safe case-insensitive replace
            $pattern = '/' . preg_quote($q, '/') . '/iu';
            $escaped = e($text);
            $escapedQ = e($q);
            return preg_replace(
                '/' . preg_quote($escapedQ, '/') . '/iu',
                '<mark class="sap-hl">$0</mark>',
                $escaped
            ) ?: $escaped;
        };

        foreach ($users as $x): ?>
          <tr>
            <td>
              <div class="sap-user-cell">
                <div class="sap-avatar role-<?= e($x['role']) ?>">
                  <?= e(strtoupper(mb_substr($x['full_name'], 0, 1))) ?>
                </div>
                <div>
                  <div class="sap-user-name"><?= $hl($x['full_name']) ?></div>
                  <div class="sap-user-sub">@<?= $hl($x['username']) ?></div>
                </div>
              </div>
            </td>
            <td><?= $x['employee_id'] ? $hl($x['employee_id']) : '—' ?></td>
            <td>
              <span class="sap-role role-<?= e($x['role']) ?>">
                <?= e(str_replace('_',' ', $x['role'])) ?>
              </span>
            </td>
            <td><?= $x['dept_name'] ? $hl($x['dept_name']) : '—' ?></td>
            <td><?= e($x['tl_name'] ?? '—') ?></td>
            <td>
              <span class="sap-status <?= $x['status'] === 'ACTIVE' ? '' : 'is-inactive' ?>">
                <i class="bi bi-<?= $x['status'] === 'ACTIVE' ? 'check-circle' : 'circle' ?>"></i>
                <?= e($x['status']) ?>
              </span>
            </td>
            <td>
              <?php if ($x['telegram_chat_id']): ?>
                <span class="sap-status" title="Chat id <?= e((string)$x['telegram_chat_id']) ?>">
                  <i class="bi bi-telegram"></i> Linked
                </span>
                <div class="sap-user-sub"><?= e((string)$x['telegram_chat_id']) ?></div>
              <?php else: ?>
                <span class="sap-status is-inactive"><i class="bi bi-telegram"></i> Not linked</span>
                <?php if ($x['phone'] === null || $x['phone'] === ''): ?>
                  <div class="sap-user-sub" style="color:var(--sap-negative)">
                    <i class="bi bi-exclamation-triangle"></i> no phone — cannot link
                  </div>
                <?php endif; ?>
              <?php endif; ?>
            </td>
            <td style="text-align:right;">
              <div class="d-inline-flex gap-1">
                <button class="sap-btn sap-btn-icon"
                        title="Edit user"
                        data-bs-toggle="modal" data-bs-target="#editUser"
                        data-id="<?= (int)$x['id'] ?>"
                        data-full_name="<?= e($x['full_name']) ?>"
                        data-employee_id="<?= e($x['employee_id'] ?? '') ?>"
                        data-username="<?= e($x['username']) ?>"
                        data-email="<?= e($x['email'] ?? '') ?>"
                        data-phone="<?= e($x['phone'] ?? '') ?>"
                        data-position="<?= e($x['position'] ?? '') ?>"
                        data-role="<?= e($x['role']) ?>"
                        data-department_id="<?= (int)($x['department_id'] ?? 0) ?>"
                        data-team_leader_id="<?= (int)($x['team_leader_id'] ?? 0) ?>">
                  <i class="bi bi-pencil"></i>
                </button>
                <?php if ((int)$x['id'] !== (int)$u['id']): ?>
                  <form method="post" class="d-inline"
                        onsubmit="return confirm('Toggle status for this user?')">
                    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="toggle_status">
                    <input type="hidden" name="id" value="<?= (int)$x['id'] ?>">
                    <button class="sap-btn sap-btn-icon" title="Toggle status">
                      <i class="bi bi-power"></i>
                    </button>
                  </form>
                <?php endif; ?>
                <form method="post" class="d-inline"
                      onsubmit="return confirm('Reset this user\'s password to the default?')">
                  <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                  <input type="hidden" name="action" value="reset_password">
                  <input type="hidden" name="id" value="<?= (int)$x['id'] ?>">
                  <button class="sap-btn sap-btn-icon" title="Reset password">
                    <i class="bi bi-key"></i>
                  </button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<!-- ================= Add User Modal ================= -->
<div class="modal fade" id="newUserModal"><div class="modal-dialog modal-lg"><div class="modal-content">
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="create">
<div class="modal-header">
  <h5 class="modal-title"><i class="bi bi-person-plus text-primary"></i> Add New User</h5>
  <button class="btn-close" data-bs-dismiss="modal" type="button"></button>
</div>
<div class="modal-body row g-3">
  <div class="col-md-6"><label class="form-label">Full Name *</label>
    <input name="full_name" class="form-control" required maxlength="150"></div>
  <div class="col-md-6"><label class="form-label">Employee ID</label>
    <input name="employee_id" class="form-control" maxlength="50"></div>
  <div class="col-md-6"><label class="form-label">Username *</label>
    <input name="username" class="form-control" required maxlength="100"></div>
  <div class="col-md-6"><label class="form-label">Email</label>
    <input type="email" name="email" class="form-control" maxlength="150"></div>
  <div class="col-md-6"><label class="form-label">Phone</label>
    <input name="phone" class="form-control" maxlength="30"></div>
  <div class="col-md-6"><label class="form-label">Position</label>
    <input name="position" class="form-control" maxlength="100"></div>
  <div class="col-md-6"><label class="form-label">Role *</label>
    <select name="role" id="roleSelect" class="form-select" required>
      <option value="">-- Select --</option>
      <option value="ADMIN">Administrator</option>
      <option value="BRANCH_MANAGER">Branch Manager</option>
      <option value="TEAM_LEADER">Team Leader</option>
      <option value="EMPLOYEE">Employee</option>
      <option value="ICT_STAFF">ICT Staff</option>
    </select></div>
  <div class="col-md-6"><label class="form-label">Department</label>
    <select name="department_id" id="deptSelect" class="form-select">
      <option value="">-- Select --</option>
      <?php foreach ($depts as $d): ?>
        <option value="<?= (int)$d['id'] ?>"><?= e($d['department_name']) ?></option>
      <?php endforeach; ?>
    </select></div>
  <div class="col-md-6" id="tlWrap"><label class="form-label">Team Leader / Branch Manager</label>
    <select name="team_leader_id" id="tlSelect" class="form-select">
      <option value="">-- Select --</option>
      <?php foreach ($tls as $t): ?>
        <option value="<?= (int)$t['id'] ?>" data-dept="<?= (int)$t['department_id'] ?>">
          <?= e($t['full_name']) ?> (<?= e(str_replace('_',' ', $t['role'])) ?>)
        </option>
      <?php endforeach; ?>
    </select>
    <small class="text-muted">Required for Employees. Team Leaders and Branch Managers can both be chosen.</small></div>
  <div class="col-md-12">
    <div class="alert alert-info py-2 px-3 mb-0" style="font-size:.8125rem">
      <i class="bi bi-info-circle"></i>
      Default password for new users: <strong><?= e(DEFAULT_PASSWORD) ?></strong>.
      The user will be required to change it on first login.
    </div>
  </div>
</div>
<div class="modal-footer">
  <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Cancel</button>
  <button class="sap-btn sap-btn-emphasized">Create User</button>
</div>
</form>
</div></div></div>

<!-- ================= Edit User Modal ================= -->
<div class="modal fade" id="editUser"><div class="modal-dialog modal-lg"><div class="modal-content">
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="update">
<input type="hidden" name="id" id="eu_id">
<div class="modal-header">
  <h5 class="modal-title"><i class="bi bi-pencil text-primary"></i> Edit User</h5>
  <button class="btn-close" data-bs-dismiss="modal" type="button"></button>
</div>
<div class="modal-body row g-3">
  <div class="col-md-6"><label class="form-label">Full Name *</label>
    <input name="full_name" id="eu_full_name" class="form-control" required maxlength="150"></div>
  <div class="col-md-6"><label class="form-label">Employee ID</label>
    <input name="employee_id" id="eu_employee_id" class="form-control" maxlength="50"></div>
  <div class="col-md-6"><label class="form-label">Username *</label>
    <input name="username" id="eu_username" class="form-control" required maxlength="100"></div>
  <div class="col-md-6"><label class="form-label">Email</label>
    <input type="email" name="email" id="eu_email" class="form-control" maxlength="150"></div>
  <div class="col-md-6"><label class="form-label">Phone</label>
    <input name="phone" id="eu_phone" class="form-control" maxlength="30"></div>
  <div class="col-md-6"><label class="form-label">Position</label>
    <input name="position" id="eu_position" class="form-control" maxlength="100"></div>
  <div class="col-md-6"><label class="form-label">Role *</label>
    <select name="role" id="eu_role" class="form-select" required>
      <option value="ADMIN">Administrator</option>
      <option value="BRANCH_MANAGER">Branch Manager</option>
      <option value="TEAM_LEADER">Team Leader</option>
      <option value="EMPLOYEE">Employee</option>
      <option value="ICT_STAFF">ICT Staff</option>
    </select></div>
  <div class="col-md-6"><label class="form-label">Department</label>
    <select name="department_id" id="eu_department_id" class="form-select">
      <option value="">-- Select --</option>
      <?php foreach ($depts as $d): ?>
        <option value="<?= (int)$d['id'] ?>"><?= e($d['department_name']) ?></option>
      <?php endforeach; ?>
    </select></div>
  <div class="col-md-6"><label class="form-label">Team Leader / Branch Manager</label>
    <select name="team_leader_id" id="eu_team_leader_id" class="form-select">
      <option value="">-- Select --</option>
      <?php foreach ($tls as $t): ?>
        <option value="<?= (int)$t['id'] ?>" data-dept="<?= (int)$t['department_id'] ?>">
          <?= e($t['full_name']) ?> (<?= e(str_replace('_',' ', $t['role'])) ?>)
        </option>
      <?php endforeach; ?>
    </select>
    <small class="text-muted">Required for Employees.</small></div>
</div>
<div class="modal-footer">
  <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Cancel</button>
  <button class="sap-btn sap-btn-emphasized">Save Changes</button>
</div>
</form>
</div></div></div>

<script>
/* ---------- Department ↔ Team Leader filtering for Add modal ---------- */
(function () {
  const role    = document.getElementById('roleSelect');
  const dept    = document.getElementById('deptSelect');
  const tl      = document.getElementById('tlSelect');
  const tlWrap  = document.getElementById('tlWrap');

  function filterTLs() {
    const deptId = dept.value;
    [...tl.options].forEach(o => {
      if (!o.value) return;
      o.hidden = deptId && o.dataset.dept !== deptId;
    });
  }
  dept.addEventListener('change', filterTLs);
  role.addEventListener('change', () => {
    tlWrap.style.opacity = role.value === 'EMPLOYEE' ? '1' : '.5';
  });
  filterTLs();
})();

/* ---------- Populate Edit modal ---------- */
document.getElementById('editUser').addEventListener('show.bs.modal', e => {
  const b = e.relatedTarget;
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.value = v || ''; };
  set('eu_id',            b.dataset.id);
  set('eu_full_name',     b.dataset.full_name);
  set('eu_employee_id',   b.dataset.employee_id);
  set('eu_username',      b.dataset.username);
  set('eu_email',         b.dataset.email);
  set('eu_phone',         b.dataset.phone);
  set('eu_position',      b.dataset.position);
  set('eu_role',          b.dataset.role);
  set('eu_department_id', b.dataset.department_id || '');
  set('eu_team_leader_id',b.dataset.team_leader_id || '');
});

/* ---------- Search box: clear button, live filter, "/" shortcut ---------- */
(function () {
  const form   = document.getElementById('usersFilterForm');
  const input  = document.getElementById('userSearch');
  const clear  = document.getElementById('clearSearch');
  const role   = form.querySelector('select[name="role"]');

  /* Show/hide the small clear icon inside the input */
  function syncClearButton() {
    if (input.value.trim() !== '') clear.classList.add('show');
    else clear.classList.remove('show');
  }
  input.addEventListener('input', syncClearButton);
  syncClearButton();

  /* Clear the input and submit (keeps the current role filter) */
  clear.addEventListener('click', () => {
    input.value = '';
    syncClearButton();
    form.submit();
  });

  /* Press "/" anywhere on the page to focus the search box */
  document.addEventListener('keydown', e => {
    const tag = (document.activeElement?.tagName || '').toLowerCase();
    const typing = tag === 'input' || tag === 'textarea' || tag === 'select' ||
                   document.activeElement?.isContentEditable;
    if (e.key === '/' && !typing) {
      e.preventDefault();
      input.focus();
      input.select();
    }
    if (e.key === 'Escape' && document.activeElement === input) {
      input.value = '';
      syncClearButton();
      form.submit();
    }
  });

  /* Auto-submit the form when the role dropdown changes */
  if (role) role.addEventListener('change', () => form.submit());

  /* Enter key inside the search box submits the form (default browser behaviour
     already does this since we're inside a form, but we add it explicitly
     so the role select doesn't interfere) */
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      e.preventDefault();
      form.submit();
    }
  });
})();
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>