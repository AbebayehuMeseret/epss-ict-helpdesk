<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('ADMIN');
$pageTitle = 'Admin Dashboard';

$pdo = db();

/* ===================== KPI COUNTS ===================== */
$stats = [
  'total'      => (int)$pdo->query("SELECT COUNT(*) FROM tickets")->fetchColumn(),
  'pending'    => (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status='PENDING_TEAM_LEADER_APPROVAL'")->fetchColumn(),
  'approved'   => (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status IN ('APPROVED_FOR_ICT','ASSIGNED_TO_ICT')")->fetchColumn(),
  'rejected'   => (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status='REJECTED'")->fetchColumn(),
  'inprogress' => (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status IN ('IN_PROGRESS','ASSIGNED_TO_ICT')")->fetchColumn(),
  'waiting'    => (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status IN ('WAITING_FOR_INFORMATION','WAITING_FOR_PARTS')")->fetchColumn(),
  'resolved'   => (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status='RESOLVED_PENDING_REQUESTER_CONFIRMATION'")->fetchColumn(),
  'closed'     => (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status='CLOSED'")->fetchColumn(),
];

/* ===================== CHART DATA ===================== */

/* 1. Tickets by Category */
$byCat = $pdo->query("SELECT c.category_name, COUNT(t.id) cnt
    FROM categories c LEFT JOIN tickets t ON t.category_id = c.id
    GROUP BY c.id ORDER BY cnt DESC")->fetchAll();

/* 2. Tickets by Status */
$byStatus = $pdo->query("SELECT status, COUNT(*) cnt FROM tickets
    GROUP BY status ORDER BY cnt DESC")->fetchAll();

/* 3. Tickets by Department */
$byDept = $pdo->query("SELECT d.department_name, COUNT(t.id) cnt
    FROM departments d LEFT JOIN tickets t ON t.department_id = d.id
    GROUP BY d.id HAVING cnt > 0 ORDER BY cnt DESC")->fetchAll();

/* 4. Monthly Trend (last 12 months) */
$monthly = $pdo->query("SELECT DATE_FORMAT(created_at,'%Y-%m') ym, COUNT(*) cnt
    FROM tickets WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
    GROUP BY ym ORDER BY ym")->fetchAll();

/* 5. Tickets by Priority */
$byPriority = $pdo->query("SELECT p.name, p.color, COUNT(t.id) cnt
    FROM priorities p LEFT JOIN tickets t ON t.priority_id = p.id
    GROUP BY p.id ORDER BY p.level")->fetchAll();

/* 6. Status distribution for polar area */
$polarLabels = array_map(fn($r) => str_replace('_',' ', $r['status']), $byStatus);
$polarData   = array_map(fn($r) => (int)$r['cnt'], $byStatus);

/* 7. Monthly Created vs Closed */
$createdRows = $pdo->query("SELECT DATE_FORMAT(created_at,'%Y-%m') ym, COUNT(*) cnt
    FROM tickets WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
    GROUP BY ym ORDER BY ym")->fetchAll();
$closedRows = $pdo->query("SELECT DATE_FORMAT(closed_at,'%Y-%m') ym, COUNT(*) cnt
    FROM tickets WHERE closed_at IS NOT NULL AND closed_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
    GROUP BY ym ORDER BY ym")->fetchAll();

$createdMap = [];
foreach ($createdRows as $r) $createdMap[$r['ym']] = (int)$r['cnt'];
$closedMap  = [];
foreach ($closedRows as $r) $closedMap[$r['ym']] = (int)$r['cnt'];

$allMonths = array_values(array_unique(array_merge(array_keys($createdMap), array_keys($closedMap))));
sort($allMonths);
$createdSeries = array_map(fn($m) => $createdMap[$m] ?? 0, $allMonths);
$closedSeries  = array_map(fn($m) => $closedMap[$m]  ?? 0, $allMonths);

/* 8. Top 5 Requesters */
$topRequesters = $pdo->query("SELECT u.full_name, COUNT(t.id) cnt
    FROM users u JOIN tickets t ON t.requester_id = u.id
    GROUP BY u.id ORDER BY cnt DESC LIMIT 5")->fetchAll();

/* 9. Avg Resolution by Category (radar) */
$avgByCat = $pdo->query("SELECT c.category_name,
        AVG(TIMESTAMPDIFF(MINUTE, t.ict_started_at, t.closed_at)) AS avg_min
    FROM categories c
    JOIN tickets t ON t.category_id = c.id
    WHERE t.closed_at IS NOT NULL AND t.ict_started_at IS NOT NULL
    GROUP BY c.id ORDER BY c.category_name")->fetchAll();

$radarLabels = array_map(fn($r) => $r['category_name'], $avgByCat);
$radarData   = array_map(fn($r) => round(((float)$r['avg_min']) / 60, 2), $avgByCat);

/* ===================== AVG RESOLUTION ===================== */
$avg = $pdo->query("SELECT AVG(TIMESTAMPDIFF(MINUTE, ict_started_at, closed_at)) FROM tickets WHERE closed_at IS NOT NULL AND ict_started_at IS NOT NULL")->fetchColumn();
$avgHrs = $avg ? round($avg/60, 1) : 0;

include __DIR__ . '/../includes/header.php';
?>

<!-- ================= SAP Fiori Horizon theme CSS ================= -->
<style>
  :root {
    --sap-brand:        #2c3e50;
    --sap-brand-mid:    #34495e;
    --sap-brand-dark:   #1a252f;

    --sap-bg:           #f5f6f7;
    --sap-tile:         #ffffff;
    --sap-text:         #1d2d3e;
    --sap-text-muted:   #556b82;
    --sap-border:       #d9d9d9;

    --sap-positive:     #256f3a;
    --sap-critical:     #e76500;
    --sap-negative:     #aa0808;
    --sap-neutral:      #5b738b;

    --sap-shadow:       0 0 0 1px rgba(44,62,80,.10), 0 2px 8px 0 rgba(44,62,80,.06);
    --sap-shadow-hover: 0 0 0 1px rgba(44,62,80,.15), 0 8px 24px 0 rgba(44,62,80,.14);
  }

  body, .main-content {
    background: var(--sap-bg) !important;
    font-family: "72", "72full", Arial, Helvetica, sans-serif !important;
    color: var(--sap-text);
    -webkit-font-smoothing: antialiased;
  }

  .sap-page-header {
    display: flex; align-items: center; justify-content: space-between;
    margin-bottom: 1rem;
  }
  .sap-page-title {
    font-size: 1.625rem; font-weight: 400; letter-spacing: -.01em;
    margin: 0; color: var(--sap-text);
  }
  .sap-breadcrumb {
    font-size: .8125rem; color: var(--sap-text-muted); margin-bottom: .25rem;
  }

  /* ---------------- KPI Tiles ---------------- */
  .sap-tile {
    background: var(--sap-tile);
    border-radius: .75rem;
    box-shadow: var(--sap-shadow);
    padding: 1rem 1.25rem;
    transition: box-shadow .2s ease, transform .2s ease;
    opacity: 0; transform: translateY(12px);
    animation: sapFadeUp .5s cubic-bezier(.2,.8,.2,1) forwards;
    height: 100%;
    position: relative;
    overflow: hidden;
  }
  .sap-tile:hover { box-shadow: var(--sap-shadow-hover); transform: translateY(-2px); }
  .sap-tile-label {
    font-size: .8125rem; color: var(--sap-text-muted); margin-bottom: .25rem;
    display: flex; align-items: center; gap: .4rem;
  }
  .sap-tile-value {
    font-size: 2rem; font-weight: 600; color: var(--sap-brand);
    line-height: 1.1; letter-spacing: -.02em;
    font-variant-numeric: tabular-nums;
  }
  .sap-tile-foot { font-size: .75rem; color: var(--sap-text-muted); margin-top: .35rem; }

  .sap-tile::before {
    content: ""; position: absolute; top: 0; left: 0; right: 0; height: 3px;
    background: var(--sap-brand);
  }
  .sap-tile.is-good::before     { background: var(--sap-positive); }
  .sap-tile.is-critical::before { background: var(--sap-critical); }
  .sap-tile.is-bad::before      { background: var(--sap-negative); }
  .sap-tile.is-neutral::before  { background: var(--sap-brand-mid); }

  .sap-object-number {
    font-family: "72Mono", "Courier New", monospace;
    font-weight: 600;
  }

  /* ---------------- Cards ---------------- */
  .sap-card {
    background: var(--sap-tile);
    border-radius: .75rem;
    box-shadow: var(--sap-shadow);
    border: none;
    overflow: hidden;
    opacity: 0; transform: translateY(12px);
    animation: sapFadeUp .55s cubic-bezier(.2,.8,.2,1) forwards;
    animation-delay: .15s;
    margin-bottom: 1rem;
  }
  .sap-card-header {
    padding: .75rem 1.25rem;
    border-bottom: 1px solid var(--sap-border);
    font-size: .875rem; font-weight: 600; color: var(--sap-text);
    display: flex; align-items: center; justify-content: space-between;
    background: var(--sap-tile);
  }
  .sap-card-header .bi { color: var(--sap-brand); }
  .sap-card-body { padding: 1rem 1.25rem; }

  @keyframes sapFadeUp { to { opacity: 1; transform: translateY(0); } }

  .sap-tile:nth-child(1)  { animation-delay: .00s; }
  .sap-tile:nth-child(2)  { animation-delay: .05s; }
  .sap-tile:nth-child(3)  { animation-delay: .10s; }
  .sap-tile:nth-child(4)  { animation-delay: .15s; }
  .sap-tile:nth-child(5)  { animation-delay: .20s; }
  .sap-tile:nth-child(6)  { animation-delay: .25s; }
  .sap-tile:nth-child(7)  { animation-delay: .30s; }
  .sap-tile:nth-child(8)  { animation-delay: .35s; }
  .sap-tile:nth-child(9)  { animation-delay: .40s; }
  .sap-tile:nth-child(10) { animation-delay: .45s; }

  .sap-chart-wrap { position: relative; height: 260px; }
  .sap-chart-wrap.tall { height: 320px; }

  /* ---------------- Progress bar ---------------- */
  .sap-progress {
    height: 6px; border-radius: 3px; background: #e5e5e5;
    overflow: hidden; margin-top: .5rem;
  }
  .sap-progress > span {
    display: block; height: 100%; width: 0;
    background: var(--sap-brand);
    transition: width 1.2s cubic-bezier(.2,.8,.2,1);
  }
  .sap-progress.is-good > span     { background: var(--sap-positive); }
  .sap-progress.is-critical > span { background: var(--sap-critical); }
  .sap-progress.is-bad > span      { background: var(--sap-negative); }

  /* ---------------- Pills ---------------- */
  .sap-pill {
    display: inline-flex; align-items: center; gap: .3rem;
    padding: .15rem .55rem; border-radius: 1rem;
    font-size: .75rem; font-weight: 500;
    background: #eaf0f6; color: var(--sap-brand);
  }
  .sap-pill.is-good     { background: #f1fdf6; color: var(--sap-positive); }
  .sap-pill.is-critical { background: #fff8f1; color: var(--sap-critical); }
  .sap-pill.is-bad      { background: #fef4f4; color: var(--sap-negative); }

  /* ---------------- Section labels ---------------- */
  .sap-section-label {
    font-size: .75rem; text-transform: uppercase; letter-spacing: .06em;
    color: var(--sap-brand);
    font-weight: 700;
    margin: 1rem 0 .5rem;
    display: flex; align-items: center; gap: .4rem;
  }
  .sap-section-label::before {
    content: "";
    display: inline-block;
    width: 3px; height: 12px;
    background: var(--sap-brand);
    border-radius: 2px;
  }

  /* ---------------- Empty state ---------------- */
  .sap-empty-dash { text-align: center; padding: 2.75rem 1.25rem; }
  .sap-empty-dash .bi {
    font-size: 2.4rem; opacity: .35; color: var(--sap-brand);
  }
  .sap-empty-dash .title {
    font-weight: 600; font-size: 1.05rem; color: var(--sap-text); margin-top: .75rem;
  }
  .sap-empty-dash .subtitle {
    color: var(--sap-text-muted); font-size: .84rem; margin-top: .35rem;
    max-width: 520px; margin-left: auto; margin-right: auto; line-height: 1.55;
  }
  .sap-empty-dash .actions {
    margin-top: 1.1rem; display: flex; gap: .5rem;
    justify-content: center; flex-wrap: wrap;
  }
  .sap-empty-btn {
    display: inline-flex; align-items: center; gap: .4rem;
    font-size: .8125rem; font-weight: 500;
    border-radius: .5rem; padding: .55rem .95rem;
    border: 1px solid transparent; background: transparent;
    color: var(--sap-brand); text-decoration: none; line-height: 1;
    transition: background .15s, color .15s;
  }
  .sap-empty-btn:hover { background: #eaf0f6; color: var(--sap-brand-dark); }
  .sap-empty-btn.is-emphasized {
    background: var(--sap-brand); color: #fff;
    box-shadow: 0 1px 2px rgba(44,62,80,.20);
  }
  .sap-empty-btn.is-emphasized:hover {
    background: var(--sap-brand-dark); color: #fff;
  }

  @media (prefers-reduced-motion: reduce) {
    .sap-tile, .sap-card { animation: none !important; opacity: 1 !important; transform: none !important; }
    .sap-progress > span { transition: none !important; }
  }
</style>

<!-- ================= Page header ================= -->
<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb">
      <i class="bi bi-house-door"></i> Home / Analytics / <strong>ICT Helpdesk Overview</strong>
    </div>
    <h1 class="sap-page-title">ICT Helpdesk Overview</h1>
  </div>
  <div class="d-flex align-items-center gap-2">
    <span class="sap-pill"><i class="bi bi-calendar3"></i> <?= date('d M Y') ?></span>
    <span class="sap-pill is-good"><i class="bi bi-circle-fill" style="font-size:.5rem"></i> Live</span>
  </div>
</div>

<?php if ((int)$stats['total'] === 0): ?>
  <div class="sap-card">
    <div class="sap-card-body sap-empty-dash">
      <i class="bi bi-inbox"></i>
      <div class="title">No tickets in the system yet</div>
      <div class="subtitle">
        The dashboard counters, charts, and KPIs will populate automatically
        as soon as the first ticket is submitted by an employee.
      </div>
      <div class="actions">
        <a href="<?= BASE_URL ?>/admin/users.php" class="sap-empty-btn">
          <i class="bi bi-people"></i> Manage Users
        </a>
        <a href="<?= BASE_URL ?>/admin/tickets.php" class="sap-empty-btn is-emphasized">
          <i class="bi bi-ticket-detailed"></i> View All Tickets
        </a>
      </div>
    </div>
  </div>
<?php endif; ?>

<!-- ================= KPI Tiles ================= -->
<div class="sap-section-label">Key Performance Indicators</div>
<div class="row g-3 mb-3">
  <?php
  $cards = [
    ['Total Tickets',     $stats['total'],      'neutral',  'ticket-detailed',      'All tickets'],
    ['Pending Approval',  $stats['pending'],    'critical', 'hourglass-split',      'Awaiting Team Leader'],
    ['Approved',          $stats['approved'],   'good',     'check2-circle',        'Approved for ICT'],
    ['Rejected',          $stats['rejected'],   'bad',      'x-circle',             'Rejected by Team Leader'],
    ['In Progress',       $stats['inprogress'], 'neutral',  'tools',                'Being handled by ICT'],
    ['Waiting',           $stats['waiting'],    'neutral',  'pause-circle',         'Waiting for info/parts'],
    ['Pending Confirm',   $stats['resolved'],   'critical', 'patch-check',          'Awaiting requester confirmation'],
    ['Closed',            $stats['closed'],     'good',     'check2-all',           'Confirmed & closed'],
  ];
  foreach ($cards as [$label, $val, $kind, $icon, $foot]): ?>
    <div class="col-6 col-md-4 col-lg-3 col-xl-2">
      <div class="sap-tile is-<?= $kind ?>">
        <div class="sap-tile-label">
          <i class="bi bi-<?= $icon ?>"></i> <?= e($label) ?>
        </div>
        <div class="sap-tile-value sap-object-number" data-count="<?= (int)$val ?>">0</div>
        <div class="sap-tile-foot"><?= e($foot) ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- ================= Avg Resolution ================= -->
<div class="sap-section-label">Resolution Time</div>
<div class="row g-3 mb-3">
  <div class="col-lg-6">
    <div class="sap-card h-100">
      <div class="sap-card-header">
        <span><i class="bi bi-clock-history"></i> Average Resolution Time</span>
        <span class="sap-pill"><i class="bi bi-stopwatch"></i> Hours</span>
      </div>
      <div class="sap-card-body">
        <div class="d-flex align-items-baseline gap-2">
          <div class="sap-tile-value sap-object-number" data-count="<?= $avgHrs ?>" data-decimals="1">0</div>
          <div class="text-muted small">hrs</div>
        </div>
        <div class="small text-muted mt-1">
          Measured from ICT start to ticket closure, across all closed tickets.
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ================= CHARTS — ROW 1 ================= -->
<div class="sap-section-label">Analytics — Overview</div>
<div class="row g-3">
  <div class="col-lg-6">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-tags"></i> Tickets by Category</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartCategory"></canvas></div></div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-diagram-3"></i> Tickets by Status</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartStatus"></canvas></div></div>
    </div>
  </div>
</div>

<!-- ================= CHARTS — ROW 2 ================= -->
<div class="sap-section-label">Analytics — Distributions</div>
<div class="row g-3">
  <div class="col-lg-4">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-flag"></i> Tickets by Priority</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartPriority"></canvas></div></div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-pie-chart"></i> Status Share</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartPolar"></canvas></div></div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-person-lines-fill"></i> Top 5 Requesters</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartTopReq"></canvas></div></div>
    </div>
  </div>
</div>

<!-- ================= CHARTS — ROW 3 ================= -->
<div class="sap-section-label">Analytics — Trends &amp; Performance</div>
<div class="row g-3">
  <div class="col-lg-8">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-graph-up"></i> Monthly Created vs Closed</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartCreatedVsClosed"></canvas></div></div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-bullseye"></i> Avg Resolution by Category</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartRadar"></canvas></div></div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-building"></i> Tickets by Department</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartDept"></canvas></div></div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-graph-up-arrow"></i> Monthly Ticket Trend</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartMonthly"></canvas></div></div>
    </div>
  </div>
</div>

<script>
/* ========== Data from PHP ========== */
const catLabels     = <?= json_encode(array_column($byCat,'category_name')) ?>;
const catData       = <?= json_encode(array_map('intval', array_column($byCat,'cnt'))) ?>;

const statusLabels  = <?= json_encode(array_map(fn($r)=>str_replace('_',' ', $r['status']), $byStatus)) ?>;
const statusData    = <?= json_encode(array_map('intval', array_column($byStatus,'cnt'))) ?>;

const deptLabels    = <?= json_encode(array_column($byDept,'department_name')) ?>;
const deptData      = <?= json_encode(array_map('intval', array_column($byDept,'cnt'))) ?>;

const monthlyLabels = <?= json_encode(array_column($monthly,'ym')) ?>;
const monthlyData   = <?= json_encode(array_map('intval', array_column($monthly,'cnt'))) ?>;

const priorityLabels = <?= json_encode(array_column($byPriority,'name')) ?>;
const priorityData   = <?= json_encode(array_map('intval', array_column($byPriority,'cnt'))) ?>;
const priorityColors = <?= json_encode(array_map(fn($r)=>'#'.ltrim(match($r['color']){
    'danger'=>'bb0000','warning'=>'e76500','info'=>'0070f2','primary'=>'0057d2',
    'success'=>'256f3a','secondary'=>'5b738b','dark'=>'354a5f',
    default=>'5b738b'}, '#'), $byPriority)) ?>;

const polarLabels = <?= json_encode($polarLabels) ?>;
const polarData   = <?= json_encode($polarData) ?>;

const cvMonths  = <?= json_encode($allMonths) ?>;
const cvCreated = <?= json_encode($createdSeries) ?>;
const cvClosed  = <?= json_encode($closedSeries) ?>;

const topReqLabels = <?= json_encode(array_column($topRequesters,'full_name')) ?>;
const topReqData   = <?= json_encode(array_map('intval', array_column($topRequesters,'cnt'))) ?>;

const radarLabels = <?= json_encode($radarLabels) ?>;
const radarData   = <?= json_encode($radarData) ?>;

/* ========== SAP colors — dark blue primary ========== */
const SAP = {
  brand:      '#2c3e50',
  brandMid:   '#34495e',
  brandDark:  '#1a252f',
  positive:   '#256f3a',
  critical:   '#e76500',
  negative:   '#aa0808',
  neutral:    '#5b738b',
  palette:    ['#2c3e50','#34495e','#4a5f78','#256f3a','#e76500','#5b738b','#7858a0','#0070f2'],
  grid:       '#e5e5e5',
  text:       '#556b82'
};

/* ========== Count-up animation ========== */
function animateCount(el) {
  const target   = parseFloat(el.dataset.count || '0');
  const decimals = parseInt(el.dataset.decimals || '0', 10);
  const duration = 900;
  let done = false;

  const render = (v) => {
    el.textContent = decimals ? v.toFixed(decimals) : Math.round(v).toLocaleString();
  };

  const finalise = () => {
    if (done) return;
    done = true;
    clearTimeout(fallback);
    render(target);
    el.dataset.value = String(target);
  };

  /* The tile markup ships a literal "0". Guarantee the real count replaces it
     even when requestAnimationFrame is throttled away (hidden/background tab,
     reduced motion, print) — otherwise the dashboard shows 0 for everything. */
  const fallback = setTimeout(finalise, 1200);

  if (document.visibilityState !== 'visible' ||
      window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    finalise();
    return;
  }

  const start = performance.now();
  const tick = (now) => {
    if (done) return;
    const t = Math.min(1, (now - start) / duration);
    render(target * (1 - Math.pow(1 - t, 3)));
    if (t < 1) requestAnimationFrame(tick); else finalise();
  };
  requestAnimationFrame(tick);
}

/* ========== Init ==========
   This inline block is emitted before includes/footer.php loads Chart.js from
   the CDN, so touching `Chart` at the top level threw a ReferenceError and
   killed the whole script — every KPI tile stayed at 0 and no chart was drawn.
   The counters now run first (they never need Chart.js) and the Chart.js
   defaults are applied inside the handler, behind a guard. */
document.addEventListener('DOMContentLoaded', () => {

  /* KPI counters */
  document.querySelectorAll('.sap-tile-value[data-count]').forEach(animateCount);

  /* SLA progress bar */
  document.querySelectorAll('.sap-progress > span[data-width]').forEach((el, i) => {
    setTimeout(() => { el.style.width = el.dataset.width + '%'; }, 300 + i * 120);
  });

  /* Chart.js global defaults (only when the CDN script actually loaded) */
  if (typeof Chart !== 'undefined') {
    Chart.defaults.font.family = "'72', Arial, Helvetica, sans-serif";
    Chart.defaults.font.size = 12;
    Chart.defaults.color = SAP.text;

    /* Animation defaults — every chart animates on load */
    Chart.defaults.animation = {
      duration: 1200,
      easing: 'easeOutQuart'
    };
    Chart.defaults.animations = {
      x:      { type: 'number', easing: 'easeOutQuart', duration: 1200, from: NaN },
      y:      { type: 'number', easing: 'easeOutQuart', duration: 1200, from: NaN },
      radius: { type: 'number', easing: 'easeOutQuart', duration: 1200, from: 0 },
      colors: { type: 'color',  easing: 'easeOutQuart', duration: 1200 }
    };
  }

  /* Skip chart construction cleanly when Chart.js could not be loaded */
  const stagger = (fn, delay) => setTimeout(() => { if (typeof Chart !== 'undefined') fn(); }, delay);

  /* ---------- 1. Tickets by Category — animated horizontal bar ---------- */
  stagger(() => new Chart(document.getElementById('chartCategory'), {
    type: 'bar',
    data: {
      labels: catLabels,
      datasets: [{
        label: 'Tickets', data: catData,
        backgroundColor: SAP.brand,
        hoverBackgroundColor: SAP.brandMid,
        borderRadius: 4, barThickness: 18
      }]
    },
    options: {
      indexAxis: 'y', responsive: true, maintainAspectRatio: false,
      animation: { duration: 1400, easing: 'easeOutQuart' },
      plugins: { legend: { display: false } },
      scales: {
        x: { beginAtZero: true, grid: { color: SAP.grid }, ticks: { precision: 0 } },
        y: { grid: { display: false } }
      }
    }
  }), 150);

  /* ---------- 2. Tickets by Status — animated doughnut pie ---------- */
  stagger(() => new Chart(document.getElementById('chartStatus'), {
    type: 'doughnut',
    data: {
      labels: statusLabels,
      datasets: [{
        data: statusData,
        backgroundColor: [
          '#2c3e50', '#34495e', '#4a5f78', '#256f3a', '#e76500',
          '#5b738b', '#7858a0', '#0070f2', '#aa0808', '#0097b2'
        ],
        borderColor: '#fff', borderWidth: 2, hoverOffset: 8
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: {
        duration: 1400,
        animateRotate: true,
        animateScale: true,
        easing: 'easeOutQuart'
      },
      cutout: '62%',
      plugins: {
        legend: { position: 'right', labels: { boxWidth: 10, padding: 10, font: { size: 10 } } }
      }
    }
  }), 300);

  /* ---------- 3. Tickets by Priority — animated pie ---------- */
  stagger(() => new Chart(document.getElementById('chartPriority'), {
    type: 'pie',
    data: {
      labels: priorityLabels,
      datasets: [{
        data: priorityData,
        backgroundColor: priorityColors,
        borderColor: '#fff', borderWidth: 2, hoverOffset: 8
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: {
        duration: 1400,
        animateRotate: true,
        animateScale: true,
        easing: 'easeOutQuart'
      },
      plugins: {
        legend: { position: 'bottom', labels: { boxWidth: 10, padding: 10, font: { size: 11 } } }
      }
    }
  }), 450);

  /* ---------- 4. Status Share — animated polar area ---------- */
  stagger(() => new Chart(document.getElementById('chartPolar'), {
    type: 'polarArea',
    data: {
      labels: polarLabels,
      datasets: [{
        data: polarData,
        backgroundColor: [
          '#2c3e50', '#34495e', '#4a5f78', '#256f3a', '#e76500',
          '#5b738b', '#7858a0', '#0070f2', '#aa0808', '#0097b2'
        ],
        borderColor: '#fff', borderWidth: 2
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: {
        duration: 1400,
        animateRotate: true,
        animateScale: true,
        easing: 'easeOutQuart'
      },
      plugins: {
        legend: { position: 'bottom', labels: { boxWidth: 10, padding: 8, font: { size: 10 } } }
      },
      scales: { r: { beginAtZero: true, grid: { color: SAP.grid }, ticks: { backdropColor: 'transparent' } } }
    }
  }), 600);

  /* ---------- 5. Top 5 Requesters — animated horizontal bar ---------- */
  stagger(() => new Chart(document.getElementById('chartTopReq'), {
    type: 'bar',
    data: {
      labels: topReqLabels,
      datasets: [{
        label: 'Tickets', data: topReqData,
        backgroundColor: SAP.brandMid,
        borderRadius: 4, barThickness: 18
      }]
    },
    options: {
      indexAxis: 'y', responsive: true, maintainAspectRatio: false,
      animation: { duration: 1400, easing: 'easeOutQuart' },
      plugins: { legend: { display: false } },
      scales: {
        x: { beginAtZero: true, grid: { color: SAP.grid }, ticks: { precision: 0 } },
        y: { grid: { display: false } }
      }
    }
  }), 750);

  /* ---------- 6. Monthly Created vs Closed — animated dual line ---------- */
  stagger(() => new Chart(document.getElementById('chartCreatedVsClosed'), {
    type: 'line',
    data: {
      labels: cvMonths,
      datasets: [
        {
          label: 'Created', data: cvCreated,
          borderColor: SAP.brand, backgroundColor: 'rgba(44,62,80,.12)',
          fill: true, tension: .35,
          pointRadius: 3, pointBackgroundColor: SAP.brand,
          pointBorderColor: '#fff', pointBorderWidth: 2
        },
        {
          label: 'Closed', data: cvClosed,
          borderColor: SAP.positive, backgroundColor: 'rgba(37,111,58,.12)',
          fill: true, tension: .35,
          pointRadius: 3, pointBackgroundColor: SAP.positive,
          pointBorderColor: '#fff', pointBorderWidth: 2
        }
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: { duration: 1600, easing: 'easeOutQuart' },
      plugins: { legend: { position: 'bottom' } },
      scales: {
        y: { beginAtZero: true, grid: { color: SAP.grid }, ticks: { precision: 0 } },
        x: { grid: { display: false } }
      }
    }
  }), 900);

  /* ---------- 7. Avg Resolution by Category — animated radar ---------- */
  stagger(() => new Chart(document.getElementById('chartRadar'), {
    type: 'radar',
    data: {
      labels: radarLabels,
      datasets: [{
        label: 'Avg hrs',
        data: radarData,
        borderColor: SAP.brand,
        backgroundColor: 'rgba(44,62,80,.20)',
        pointBackgroundColor: SAP.brand,
        pointBorderColor: '#fff',
        pointRadius: 4
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: { duration: 1400, easing: 'easeOutQuart' },
      plugins: { legend: { display: false } },
      scales: {
        r: {
          beginAtZero: true, grid: { color: SAP.grid },
          angleLines: { color: SAP.grid }, ticks: { backdropColor: 'transparent' }
        }
      }
    }
  }), 1050);

  /* ---------- 8. Tickets by Department — animated vertical bar ---------- */
  stagger(() => new Chart(document.getElementById('chartDept'), {
    type: 'bar',
    data: {
      labels: deptLabels,
      datasets: [{
        label: 'Tickets', data: deptData,
        backgroundColor: SAP.brand,
        hoverBackgroundColor: SAP.brandMid,
        borderRadius: 4, maxBarThickness: 42
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: { duration: 1400, easing: 'easeOutQuart' },
      plugins: { legend: { display: false } },
      scales: {
        y: { beginAtZero: true, grid: { color: SAP.grid }, ticks: { precision: 0 } },
        x: { grid: { display: false } }
      }
    }
  }), 1200);

  /* ---------- 9. Monthly Ticket Trend — animated line ---------- */
  stagger(() => new Chart(document.getElementById('chartMonthly'), {
    type: 'line',
    data: {
      labels: monthlyLabels,
      datasets: [{
        label: 'Tickets', data: monthlyData,
        borderColor: SAP.brand, backgroundColor: 'rgba(44,62,80,.12)',
        fill: true, tension: .35,
        pointRadius: 3, pointBackgroundColor: SAP.brand,
        pointBorderColor: '#fff', pointBorderWidth: 2
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: { duration: 1600, easing: 'easeOutQuart' },
      plugins: { legend: { display: false } },
      scales: {
        y: { beginAtZero: true, grid: { color: SAP.grid }, ticks: { precision: 0 } },
        x: { grid: { display: false } }
      }
    }
  }), 1350);
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
