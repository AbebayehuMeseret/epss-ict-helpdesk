<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('ADMIN');

echo '<pre style="padding:1rem;background:#f5f5f5;font-family:monospace">';
echo "Admin logged in: " . $u['username'] . "\n\n";

echo "whatsapp_log table: ";
try {
    $n = (int)db()->query("SELECT COUNT(*) FROM whatsapp_log")->fetchColumn();
    echo "EXISTS ($n rows)\n";
} catch (Throwable $e) {
    echo "MISSING — " . $e->getMessage() . "\n";
}

echo "\nincludes/whatsapp.php: ";
echo file_exists(__DIR__ . '/../includes/whatsapp.php') ? "EXISTS\n" : "MISSING\n";

echo "dispatch_whatsapp_queue(): ";
require_once __DIR__ . '/../includes/whatsapp.php';
echo function_exists('dispatch_whatsapp_queue') ? "OK\n" : "MISSING\n";

echo "\nSettings:\n";
echo "  wa_enabled    = " . setting('wa_enabled', '0') . "\n";
echo "  wa_api_url    = " . setting('wa_api_url', '') . "\n";
echo "  wa_api_key    = " . (setting('wa_api_key', '') ? '(set)' : '(empty)') . "\n";
echo '</pre>';