<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('ADMIN');
$pageTitle = 'System Settings';
$pdo = db(); $ok = ''; $error = '';

$editable = [
    'org_name','branch_name','system_name',
    'ticket_prefix','ticket_year',
    'timezone',
    'work_start','work_end','work_days',
    'max_upload_size','allowed_ext',
    'kpi_default_target',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf($_POST['csrf'] ?? null)) {
    try {
        // --- Validate numeric settings before writing ---
        $numericKeys = [
            'kpi_default_target',
            'max_upload_size',
            'ticket_year',
        ];
        foreach ($numericKeys as $k) {
            if (!array_key_exists($k, $_POST)) continue;
            $v = $_POST[$k];
            if ($v === '' || !is_numeric($v)) {
                throw new RuntimeException("Invalid value for '{$k}' — must be a number.");
            }
        }

        $stmt = $pdo->prepare("UPDATE system_settings SET setting_value=? WHERE setting_key=?");

        // For settings that may not yet exist in the table, fall back to INSERT.
        $insert = $pdo->prepare("INSERT INTO system_settings (setting_key, setting_value)
                                 SELECT ?, ?
                                 WHERE NOT EXISTS (SELECT 1 FROM system_settings WHERE setting_key=?)");

        foreach ($editable as $k) {
            if (!array_key_exists($k, $_POST)) continue;
            $stmt->execute([$_POST[$k], $k]);
            if ($stmt->rowCount() === 0) {
                $insert->execute([$k, $_POST[$k], $k]);
            }
        }

        audit('UpdateSettings', 'settings', 0, 'Settings updated');
        $ok = 'Settings saved.';
    } catch (Throwable $e) {
        $error = app_exception_message($e);
    }
}

$settings = [];
foreach ($pdo->query("SELECT * FROM system_settings")->fetchAll() as $s) {
    $settings[$s['setting_key']] = $s['setting_value'];
}
$get = fn($k, $d = '') => $settings[$k] ?? $d;

/* Curated timezone list (Africa/Addis_Ababa first, then common zones) */
$tzList = [
    'Africa/Addis_Ababa'  => 'Africa/Addis_Ababa (EAT, UTC+3)',
    'Africa/Nairobi'      => 'Africa/Nairobi',
    'Africa/Khartoum'     => 'Africa/Khartoum',
    'Africa/Djibouti'     => 'Africa/Djibouti',
    'Africa/Mogadishu'    => 'Africa/Mogadishu',
    'Africa/Cairo'        => 'Africa/Cairo',
    'Africa/Johannesburg' => 'Africa/Johannesburg',
    'UTC'                 => 'UTC',
    'Europe/London'       => 'Europe/London',
    'Europe/Paris'        => 'Europe/Paris',
    'Asia/Dubai'          => 'Asia/Dubai',
    'Asia/Riyadh'         => 'Asia/Riyadh',
    'America/New_York'    => 'America/New_York',
    'America/Los_Angeles' => 'America/Los_Angeles',
];

include __DIR__ . '/../includes/header.php';
?>

<!-- ================= SAP Fiori Horizon theme ================= -->
<style>
  :root {
    --sap-brand:        #0070f2;
    --sap-brand-dark:   #0057d2;
    --sap-bg:           #f5f6f7;
    --sap-tile:         #ffffff;
    --sap-text:         #1d2d3e;
    --sap-text-muted:   #556b82;
    --sap-border:       #d9d9d9;
    --sap-border-soft:  #eaecf0;
    --sap-positive:     #256f3a;
    --sap-critical:     #e76500;
    --sap-negative:     #aa0808;
    --sap-neutral:      #5b738b;
    --sap-shadow:       0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
    --sap-shadow-hover: 0 0 0 1px rgba(34,53,72,.15), 0 8px 24px 0 rgba(34,53,72,.12);
  }

  body, .main-content {
    background: var(--sap-bg) !important;
    font-family: "72", "72full", Arial, Helvetica, sans-serif !important;
    color: var(--sap-text);
  }

  .sap-page-header {
    display: flex; align-items: flex-start; justify-content: space-between;
    margin-bottom: 1rem;
  }
  .sap-page-title { font-size: 1.625rem; font-weight: 400; margin: 0; }
  .sap-breadcrumb { font-size: .8125rem; color: var(--sap-text-muted); margin-bottom: .25rem; }

  /* SAP tab strip */
  .sap-tabs {
    display: flex; gap: 0;
    background: var(--sap-tile);
    border-radius: .75rem .75rem 0 0;
    box-shadow: var(--sap-shadow);
    border-bottom: 1px solid var(--sap-border);
    padding: 0 .5rem;
    overflow-x: auto;
    scrollbar-width: thin;
  }
  .sap-tab {
    display: inline-flex; align-items: center; gap: .4rem;
    padding: .75rem 1rem;
    font-size: .8125rem; font-weight: 500;
    color: var(--sap-text-muted);
    background: transparent;
    border: 0;
    border-bottom: 2px solid transparent;
    cursor: pointer;
    white-space: nowrap;
    transition: color .15s, border-color .15s, background .15s;
  }
  .sap-tab:hover { color: var(--sap-text); background: #f8fbff; }
  .sap-tab.active {
    color: var(--sap-brand);
    border-bottom-color: var(--sap-brand);
    font-weight: 600;
  }
  .sap-tab .bi { font-size: .9rem; }
  .sap-tab:focus-visible { outline: 2px solid var(--sap-brand); outline-offset: -2px; }

  /* SAP Panel / form wrapper */
  .sap-panel {
    background: var(--sap-tile);
    border-radius: 0 0 .75rem .75rem;
    box-shadow: var(--sap-shadow);
  }
  .sap-panel-section { padding: 1.25rem 1.5rem; border-bottom: 1px solid var(--sap-border-soft); }
  .sap-panel-section:last-child { border-bottom: 0; }

  /* SAP form group */
  .sap-form-label {
    font-size: .75rem; text-transform: uppercase; letter-spacing: .04em;
    color: var(--sap-text-muted); font-weight: 600;
    margin-bottom: .3rem;
  }
  .sap-form-hint {
    font-size: .72rem; color: var(--sap-text-muted); margin-top: .25rem;
    line-height: 1.4;
  }
  .sap-form-group { margin-bottom: 1.15rem; }
  .sap-form-group:last-child { margin-bottom: 0; }

  .sap-panel input.form-control,
  .sap-panel select.form-select {
    font-size: .875rem;
    padding: .5rem .75rem;
    border-radius: .5rem;
    border: 1px solid var(--sap-border);
    background: #fff;
    color: var(--sap-text);
  }
  .sap-panel input.form-control:focus,
  .sap-panel select.form-select:focus {
    border-color: var(--sap-brand);
    box-shadow: 0 0 0 2px rgba(0,112,242,.15);
  }
  .sap-panel .form-control[readonly] {
    background: #f5f6f7; color: var(--sap-text-muted); cursor: not-allowed;
  }

  /* SAP Switch (toggle) */
  .sap-switch {
    display: inline-flex; align-items: center; gap: .6rem;
    cursor: pointer;
    user-select: none;
  }
  .sap-switch input { position: absolute; opacity: 0; pointer-events: none; }
  .sap-switch-track {
    width: 40px; height: 22px; border-radius: 11px;
    background: #c8cdd3;
    position: relative;
    transition: background .2s;
    flex-shrink: 0;
  }
  .sap-switch-track::after {
    content: '';
    position: absolute; top: 2px; left: 2px;
    width: 18px; height: 18px;
    background: #fff;
    border-radius: 50%;
    box-shadow: 0 1px 2px rgba(0,0,0,.2);
    transition: transform .2s;
  }
  .sap-switch input:checked + .sap-switch-track { background: var(--sap-brand); }
  .sap-switch input:checked + .sap-switch-track::after { transform: translateX(18px); }
  .sap-switch input:focus-visible + .sap-switch-track {
    outline: 2px solid var(--sap-brand); outline-offset: 2px;
  }
  .sap-switch-label {
    font-size: .8125rem; color: var(--sap-text);
  }

  /* SAP Button */
  .sap-btn {
    display: inline-flex; align-items: center; gap: .35rem;
    font-size: .8125rem; font-weight: 500;
    border-radius: .5rem;
    padding: .45rem .9rem;
    border: 1px solid transparent;
    background: transparent;
    color: var(--sap-brand);
    transition: background .15s, box-shadow .15s, color .15s;
    cursor: pointer;
    line-height: 1;
    text-decoration: none;
    white-space: nowrap;
  }
  .sap-btn:hover { background: #eaf4ff; color: var(--sap-brand-dark); }
  .sap-btn:focus-visible { outline: 2px solid var(--sap-brand); outline-offset: 2px; }
  .sap-btn.sap-btn-emphasized {
    background: var(--sap-brand); color: #fff;
    box-shadow: 0 1px 2px rgba(34,53,72,.15);
  }
  .sap-btn.sap-btn-emphasized:hover { background: var(--sap-brand-dark); color: #fff; }

  /* SAP MessageStrip (info banner) */
  .sap-message {
    display: flex; align-items: flex-start; gap: .6rem;
    padding: .75rem 1rem;
    border-radius: .5rem;
    background: #eaf4ff; border-left: 3px solid var(--sap-brand);
    font-size: .8125rem; color: var(--sap-text);
    margin-bottom: 1rem;
  }
  .sap-message .bi { color: var(--sap-brand); margin-top: .1rem; flex-shrink: 0; }

  /* Status pill */
  .sap-status {
    display: inline-flex; align-items: center; gap: .25rem;
    font-size: .7rem; font-weight: 600;
    padding: .1rem .5rem;
    border-radius: .75rem;
    background: #eaf4ff; color: var(--sap-brand);
    border: 1px solid #cfe2f8;
    white-space: nowrap;
  }

  /* Sticky save bar */
  .sap-save-bar {
    display: flex; align-items: center; justify-content: space-between;
    background: var(--sap-tile);
    border-radius: .75rem;
    box-shadow: var(--sap-shadow);
    padding: .75rem 1.25rem;
    margin-top: 1rem;
    position: sticky; bottom: 1rem;
    flex-wrap: wrap; gap: .5rem;
  }
  .sap-save-bar .info {
    font-size: .8125rem; color: var(--sap-text-muted);
  }

  @media (prefers-reduced-motion: reduce) {
    .sap-tab, .sap-switch-track, .sap-switch-track::after { transition: none !important; }
  }
</style>

<!-- ================= Page header ================= -->
<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb">
      <i class="bi bi-house-door"></i> Home / Administration / <strong>System Settings</strong>
    </div>
    <h1 class="sap-page-title">System Settings</h1>
  </div>
  <div class="d-flex align-items-center gap-2 flex-wrap">
    <span class="sap-status"><i class="bi bi-gear"></i> Configuration</span>
  </div>
</div>

<?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>

<form method="post" id="settingsForm">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">

<!-- ================= Tab strip ================= -->
<div class="sap-tabs" role="tablist">
  <button type="button" class="sap-tab active" data-tab="org">
    <i class="bi bi-building"></i> Organization
  </button>
  <button type="button" class="sap-tab" data-tab="ticketing">
    <i class="bi bi-ticket-detailed"></i> Ticketing
  </button>
  <button type="button" class="sap-tab" data-tab="hours">
    <i class="bi bi-clock-history"></i> Working Hours
  </button>
  <button type="button" class="sap-tab" data-tab="uploads">
    <i class="bi bi-cloud-upload"></i> Uploads
  </button>
  <button type="button" class="sap-tab" data-tab="kpi">
    <i class="bi bi-graph-up"></i> KPI
  </button>
</div>

<!-- ================= Panel ================= -->
<div class="sap-panel">

  <!-- ---------- Organization ---------- -->
  <section class="sap-panel-section tab-panel" data-panel="org">
    <div class="sap-message">
      <i class="bi bi-info-circle"></i>
      <div>These details appear at the top of every report and on the login page.</div>
    </div>
    <div class="row g-3">
      <div class="col-md-6">
        <div class="sap-form-group">
          <label class="sap-form-label">Organization Name</label>
          <input name="org_name" class="form-control" maxlength="200"
                 value="<?= e($get('org_name')) ?>">
          <div class="sap-form-hint">Full legal name of the organization.</div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="sap-form-group">
          <label class="sap-form-label">Branch Name</label>
          <input name="branch_name" class="form-control" maxlength="100"
                 value="<?= e($get('branch_name')) ?>">
          <div class="sap-form-hint">Shown alongside the organization name.</div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="sap-form-group">
          <label class="sap-form-label">System Name</label>
          <input name="system_name" class="form-control" maxlength="150"
                 value="<?= e($get('system_name')) ?>">
          <div class="sap-form-hint">Used in page titles and email subjects.</div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="sap-form-group">
          <label class="sap-form-label">Timezone</label>
          <select name="timezone" class="form-select">
            <?php foreach ($tzList as $tz => $label): ?>
              <option value="<?= e($tz) ?>" <?= $get('timezone') === $tz ? 'selected' : '' ?>>
                <?= e($label) ?>
              </option>
            <?php endforeach; ?>
          </select>
          <div class="sap-form-hint">Used for all timestamps.</div>
        </div>
      </div>
    </div>
  </section>

  <!-- ---------- Ticketing ---------- -->
  <section class="sap-panel-section tab-panel" data-panel="ticketing" style="display:none">
    <div class="sap-message">
      <i class="bi bi-info-circle"></i>
      <div>Controls how ticket numbers are generated. Changing these only affects newly created tickets.</div>
    </div>
    <div class="row g-3">
      <div class="col-md-6">
        <div class="sap-form-group">
          <label class="sap-form-label">Ticket Prefix</label>
          <input name="ticket_prefix" class="form-control" maxlength="30"
                 value="<?= e($get('ticket_prefix', 'EPSS-ICT')) ?>">
          <div class="sap-form-hint">Leading text on every ticket number, e.g. <code>EPSS-ICT</code>.</div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="sap-form-group">
          <label class="sap-form-label">Ticket Year</label>
          <input name="ticket_year" class="form-control" type="number" min="2000" max="2100"
                 value="<?= e($get('ticket_year', date('Y'))) ?>">
          <div class="sap-form-hint">Current numbering year. Format: <code>PREFIX-YEAR-NNNNNN</code>.</div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="sap-form-group">
          <label class="sap-form-label">KPI Default Target (%)</label>
          <input name="kpi_default_target" class="form-control" type="number"
                 step="0.01" min="0" max="100"
                 value="<?= e($get('kpi_default_target', '100')) ?>">
          <div class="sap-form-hint">Fallback target used when a KPI has no specific target set.</div>
        </div>
      </div>
    </div>
  </section>

  <!-- ---------- Working Hours ---------- -->
  <section class="sap-panel-section tab-panel" data-panel="hours" style="display:none">
    <div class="sap-message">
      <i class="bi bi-info-circle"></i>
      <div>Days use ISO numbering: 1 = Monday, 7 = Sunday.</div>
    </div>
    <div class="row g-3">
      <div class="col-md-4">
        <div class="sap-form-group">
          <label class="sap-form-label">Start Time</label>
          <input name="work_start" class="form-control" type="time"
                 value="<?= e($get('work_start', '08:30')) ?>">
        </div>
      </div>
      <div class="col-md-4">
        <div class="sap-form-group">
          <label class="sap-form-label">End Time</label>
          <input name="work_end" class="form-control" type="time"
                 value="<?= e($get('work_end', '17:30')) ?>">
        </div>
      </div>
      <div class="col-md-4">
        <div class="sap-form-group">
          <label class="sap-form-label">Working Days</label>
          <input name="work_days" class="form-control"
                 value="<?= e($get('work_days', '1,2,3,4,5')) ?>"
                 placeholder="1,2,3,4,5">
          <div class="sap-form-hint">Comma-separated ISO day numbers. Mon–Fri = <code>1,2,3,4,5</code>.</div>
        </div>
      </div>
    </div>
  </section>

  <!-- ---------- Uploads ---------- -->
  <section class="sap-panel-section tab-panel" data-panel="uploads" style="display:none">
    <div class="sap-message">
      <i class="bi bi-info-circle"></i>
      <div>Maximum file size and allowed extensions apply to every ticket attachment and evidence upload.</div>
    </div>
    <div class="row g-3">
      <div class="col-md-6">
        <div class="sap-form-group">
          <label class="sap-form-label">Max Upload Size (bytes)</label>
          <input name="max_upload_size" class="form-control" type="number"
                 min="1024" max="104857600"
                 value="<?= e($get('max_upload_size', '10485760')) ?>">
          <div class="sap-form-hint">
            Current: <strong><?= number_format(((int)$get('max_upload_size', 10485760)) / 1024 / 1024, 1) ?> MB</strong>
            · Common values: 5 MB = 5242880, 10 MB = 10485760, 20 MB = 20971520.
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="sap-form-group">
          <label class="sap-form-label">Allowed Extensions</label>
          <input name="allowed_ext" class="form-control"
                 value="<?= e($get('allowed_ext', 'jpg,jpeg,png,gif,pdf,doc,docx,xls,xlsx,txt,zip')) ?>">
          <div class="sap-form-hint">Comma-separated list, no dots.</div>
        </div>
      </div>
    </div>
  </section>

  <!-- ---------- KPI ---------- -->
  <section class="sap-panel-section tab-panel" data-panel="kpi" style="display:none">
    <div class="sap-message">
      <i class="bi bi-info-circle"></i>
      <div>
        The <strong>default target percentage</strong> is used when a KPI has no
        specific target set. Manage per‑category KPI targets from the KPI Management page.
      </div>
    </div>
    <div class="row g-3">
      <div class="col-md-6">
        <div class="sap-form-group">
          <label class="sap-form-label">Default KPI Target (%)</label>
          <input name="kpi_default_target" class="form-control" type="number"
                 step="0.01" min="0" max="100"
                 value="<?= e($get('kpi_default_target', '100')) ?>">
          <div class="sap-form-hint">Common value: <strong>100</strong>.</div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="sap-form-group">
          <label class="sap-form-label">Manage KPIs</label>
          <div>
            <a href="<?= BASE_URL ?>/admin/kpis.php" class="sap-btn sap-btn-emphasized">
              <i class="bi bi-graph-up"></i> Open KPI Management
            </a>
          </div>
          <div class="sap-form-hint">Create KPIs, adjust per‑category targets, and activate or deactivate definitions.</div>
        </div>
      </div>
    </div>
  </section>

</div>

<!-- ================= Sticky Save Bar ================= -->
<div class="sap-save-bar">
  <div class="info">
    <i class="bi bi-info-circle"></i>
    Changes take effect immediately after saving.
  </div>
  <div class="d-flex gap-2">
    <a href="<?= BASE_URL ?>/admin/dashboard.php" class="sap-btn">
      <i class="bi bi-x-circle"></i> Cancel
    </a>
    <button type="submit" class="sap-btn sap-btn-emphasized">
      <i class="bi bi-check2"></i> Save Settings
    </button>
  </div>
</div>

</form>

<script>
/* ---------- Tab switching ---------- */
document.querySelectorAll('.sap-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    const target = tab.dataset.tab;

    document.querySelectorAll('.sap-tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');

    document.querySelectorAll('.tab-panel').forEach(p => {
      p.style.display = (p.dataset.panel === target) ? '' : 'none';
    });
  });
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>