<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('ADMIN');
$pageTitle = 'Record KPI Measurements';
$pdo = db(); $ok = ''; $error = '';

$filterKpi = (int)($_GET['kpi_id'] ?? 0);

/* All active KPIs */
$kpis = $pdo->query("SELECT * FROM kpis WHERE status='ACTIVE' ORDER BY kpi_code, kpi_name")->fetchAll();

/* Handle submission */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf($_POST['csrf'] ?? null)) {
    try {
        $kpiId  = (int)$_POST['kpi_id'];
        $period = trim($_POST['period_label']);

        /* Look up the KPI's type to know which fields are needed */
        $stmt = $pdo->prepare("SELECT * FROM kpis WHERE id=?");
        $stmt->execute([$kpiId]);
        $kpi = $stmt->fetch();
        if (!$kpi) throw new RuntimeException('KPI not found.');

        $numerator   = $_POST['numerator']   !== '' ? (float)$_POST['numerator']   : null;
        $denominator = $_POST['denominator'] !== '' ? (float)$_POST['denominator'] : null;
        $actual      = $_POST['actual_value'] !== '' ? (float)$_POST['actual_value'] : null;

        /* Auto-compute for the known formulas */
        if ($actual === null && $numerator !== null && $denominator !== null && $denominator > 0) {
            if ($kpi['kpi_code'] === 'ICT-1') {
                $actual = round($numerator / $denominator * 100, 2);            // %
            } elseif ($kpi['kpi_code'] === 'ICT-2') {
                $actual = round($numerator / $denominator, 2);                   // ETB per order
            } elseif ($kpi['kpi_code'] === 'ICT-3') {
                $actual = round($numerator / $denominator, 2);                   // days
            }
        }

        /* Parse period label like 2026-Q1 or 2026-03 */
        $year = (int)substr($period, 0, 4);
        $q = null; $m = null;
        if (preg_match('/^(\d{4})-Q([1-4])$/', $period, $mm)) {
            $year = (int)$mm[1]; $q = (int)$mm[2];
        } elseif (preg_match('/^(\d{4})-(\d{2})$/', $period, $mm)) {
            $year = (int)$mm[1]; $m = (int)$mm[2];
        }

        $pdo->prepare("
            INSERT INTO kpi_measurements
                (kpi_id, period_label, period_year, period_quarter, period_month,
                 numerator, denominator, actual_value, notes, recorded_by)
            VALUES (?,?,?,?,?,?,?,?,?,?)
            ON DUPLICATE KEY UPDATE
                numerator   = VALUES(numerator),
                denominator = VALUES(denominator),
                actual_value = VALUES(actual_value),
                notes       = VALUES(notes),
                recorded_by = VALUES(recorded_by),
                recorded_at = NOW()
        ")->execute([
            $kpiId, $period, $year, $q, $m,
            $numerator, $denominator, $actual,
            trim($_POST['notes'] ?? '') ?: null,
            $u['id'],
        ]);

        audit('RecordKPIMeasurement','kpi_measurements',$kpiId,"Recorded $period");
        $ok = 'Measurement saved.';
    } catch (Throwable $e) {
        $error = app_exception_message($e);
    }
}

/* Load measurements */
$where = $filterKpi ? "WHERE m.kpi_id = " . (int)$filterKpi : "";
$rows = $pdo->query("
    SELECT m.*, k.kpi_code, k.kpi_name, k.kpi_type, k.target_value, k.target_unit,
           k.target_percentage, u.full_name AS recorder
    FROM kpi_measurements m
    JOIN kpis k ON k.id = m.kpi_id
    LEFT JOIN users u ON u.id = m.recorded_by
    $where
    ORDER BY m.period_year DESC, m.period_quarter DESC, m.period_month DESC, k.kpi_code
    LIMIT 200
")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:#0070f2; --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500;
    --sap-negative:#aa0808; --sap-neutral:#5b738b;
    --sap-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
  }
  body, .main-content { background:var(--sap-bg) !important;
    font-family:"72","72full",Arial,Helvetica,sans-serif !important; color:var(--sap-text); }
  .sap-page-header { display:flex; justify-content:space-between; align-items:flex-start;
    margin-bottom:1rem; flex-wrap:wrap; gap:.75rem; }
  .sap-page-title { font-size:1.625rem; font-weight:400; margin:0; }
  .sap-breadcrumb { font-size:.8125rem; color:var(--sap-text-muted); margin-bottom:.25rem; }
  .sap-card { background:var(--sap-tile); border-radius:.75rem;
    box-shadow:var(--sap-shadow); overflow:hidden; margin-bottom:1rem; }
  .sap-card-header { padding:.75rem 1.15rem; border-bottom:1px solid var(--sap-border-soft);
    font-size:.875rem; font-weight:600; }
  .sap-card-body { padding:1rem 1.15rem; }
  .sap-btn { display:inline-flex; align-items:center; gap:.35rem;
    font-size:.8125rem; font-weight:500; border-radius:.5rem;
    padding:.45rem .8rem; border:1px solid transparent; background:transparent;
    color:var(--sap-brand); cursor:pointer; text-decoration:none; }
  .sap-btn:hover { background:#eaf4ff; }
  .sap-btn.sap-btn-emphasized { background:var(--sap-brand); color:#fff; }
  .sap-btn.sap-btn-outline { border-color:var(--sap-border); background:#fff; }
  .sap-form-label { display:block; font-size:.72rem; text-transform:uppercase;
    letter-spacing:.04em; color:var(--sap-text-muted); font-weight:600; margin-bottom:.3rem; }
  .sap-form-control { width:100%; font-size:.875rem; font-family:inherit;
    color:var(--sap-text); background:#fff; border:1px solid var(--sap-border);
    border-radius:.5rem; padding:.55rem .75rem; outline:none; }
  .sap-form-control:focus { border-color:var(--sap-brand);
    box-shadow:0 0 0 3px rgba(0,112,242,.15); }

  table.sap-table { width:100%; border-collapse:separate; border-spacing:0; font-size:.8125rem; }
  table.sap-table thead th { background:#f5f6f7; border-bottom:1px solid var(--sap-border);
    font-weight:600; color:var(--sap-text-muted); text-align:left;
    padding:.55rem .7rem; text-transform:uppercase; font-size:.68rem; letter-spacing:.04em; }
  table.sap-table tbody td { padding:.6rem .7rem;
    border-bottom:1px solid var(--sap-border-soft); }
  table.sap-table tbody tr:last-child td { border-bottom:0; }
  .sap-num { text-align:right; font-variant-numeric:tabular-nums; }
  .sap-code { font-family:"72Mono","Courier New",monospace; font-size:.72rem; font-weight:700;
    background:#eaf4ff; color:var(--sap-brand); padding:.1rem .5rem; border-radius:.35rem; }
  .sap-status { display:inline-flex; align-items:center; gap:.2rem;
    font-size:.7rem; font-weight:600; padding:.1rem .5rem; border-radius:.75rem; }
  .sap-status.is-good { background:#f1fdf6; color:var(--sap-positive); border:1px solid #d6f0e0; }
  .sap-status.is-bad  { background:#fef4f4; color:var(--sap-negative); border:1px solid #f7d2d2; }
</style>

<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb"><i class="bi bi-house-door"></i> Home / Configuration / KPI / <strong>Measurements</strong></div>
    <h1 class="sap-page-title">Record KPI Measurements</h1>
  </div>
  <a href="kpis.php" class="sap-btn sap-btn-outline">
    <i class="bi bi-arrow-left"></i> Back to KPI List
  </a>
</div>

<?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>

<!-- ============ Entry form ============ -->
<div class="sap-card">
  <div class="sap-card-header"><i class="bi bi-pencil-square"></i> Enter a Measurement</div>
  <div class="sap-card-body">
    <form method="post" class="row g-3">
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">

      <div class="col-md-4">
        <label class="sap-form-label">KPI *</label>
        <select name="kpi_id" class="sap-form-control" required>
          <option value="">-- Select KPI --</option>
          <?php foreach ($kpis as $k): ?>
            <option value="<?= (int)$k['id'] ?>" <?= $filterKpi==$k['id']?'selected':'' ?>>
              <?= e($k['kpi_code'] ?? '—') ?> — <?= e($k['kpi_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-3">
        <label class="sap-form-label">Period Label *</label>
        <input name="period_label" class="sap-form-control"
               placeholder="2026-Q1 or 2026-03" required
               value="<?= e(date('Y') . '-Q' . (int)ceil(date('n')/3)) ?>">
        <div style="font-size:.7rem;color:var(--sap-text-muted);margin-top:.25rem">
          Format: <code>YYYY-QN</code> for quarterly, <code>YYYY-MM</code> for monthly.
        </div>
      </div>

      <div class="col-md-2">
        <label class="sap-form-label">Numerator</label>
        <input type="number" step="0.01" name="numerator" class="sap-form-control"
               placeholder="e.g. 18">
      </div>

      <div class="col-md-2">
        <label class="sap-form-label">Denominator</label>
        <input type="number" step="0.01" name="denominator" class="sap-form-control"
               placeholder="e.g. 20">
      </div>

      <div class="col-md-2">
        <label class="sap-form-label">Actual (auto)</label>
        <input type="number" step="0.01" name="actual_value" class="sap-form-control"
               placeholder="Leave blank to auto-compute">
      </div>

      <div class="col-md-12">
        <label class="sap-form-label">Notes</label>
        <textarea name="notes" class="sap-form-control" rows="2"
                  placeholder="Optional context, e.g. 'Three systems under upgrade this quarter'"></textarea>
      </div>

      <div class="col-md-12">
        <div class="alert alert-info small mb-0">
          <strong>Auto-compute rules:</strong>
          <code>ICT-1</code> → numerator / denominator × 100 &nbsp;·&nbsp;
          <code>ICT-2</code> → numerator / denominator (ETB per order) &nbsp;·&nbsp;
          <code>ICT-3</code> → numerator / denominator (days)
        </div>
      </div>

      <div class="col-md-12">
        <button class="sap-btn sap-btn-emphasized">
          <i class="bi bi-save"></i> Save Measurement
        </button>
        <?php if ($filterKpi): ?>
          <a href="kpi_measurements.php" class="sap-btn sap-btn-outline">Clear filter</a>
        <?php endif; ?>
      </div>
    </form>
  </div>
</div>

<!-- ============ History ============ -->
<div class="sap-card">
  <div class="sap-card-header"><i class="bi bi-clock-history"></i> Measurement History</div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="sap-table">
        <thead>
          <tr>
            <th>Code</th>
            <th>KPI</th>
            <th>Period</th>
            <th class="sap-num">Numerator</th>
            <th class="sap-num">Denominator</th>
            <th class="sap-num">Actual</th>
            <th class="sap-num">Target</th>
            <th class="sap-num">Variance</th>
            <th>Notes</th>
            <th>Recorded By</th>
          </tr>
        </thead>
        <tbody>
        <?php if (!$rows): ?>
          <tr><td colspan="10" class="text-center text-muted" style="padding:2rem">
            No measurements recorded yet.
          </td></tr>
        <?php else: foreach ($rows as $r):
            $target = $r['target_value'] !== null ? (float)$r['target_value'] : (float)$r['target_percentage'];
            $actual = $r['actual_value'] !== null ? (float)$r['actual_value'] : 0;
            $variance = round($actual - $target, 2);
            $isGood = $variance >= 0;
            /* For MTTR lower is better — invert comparison */
            if ($r['kpi_code'] === 'ICT-3') { $isGood = $variance <= 0; }
        ?>
          <tr>
            <td><span class="sap-code"><?= e($r['kpi_code'] ?? '—') ?></span></td>
            <td><?= e($r['kpi_name']) ?></td>
            <td><strong><?= e($r['period_label']) ?></strong></td>
            <td class="sap-num"><?= $r['numerator'] !== null ? number_format((float)$r['numerator'], 2) : '—' ?></td>
            <td class="sap-num"><?= $r['denominator'] !== null ? number_format((float)$r['denominator'], 2) : '—' ?></td>
            <td class="sap-num"><strong><?= number_format($actual, 2) ?></strong></td>
            <td class="sap-num">
              <?= number_format($target, 2) ?>
              <span style="font-size:.7rem;color:var(--sap-text-muted)"><?= e($r['target_unit'] ?? '%') ?></span>
            </td>
            <td class="sap-num">
              <span class="sap-status <?= $isGood ? 'is-good' : 'is-bad' ?>">
                <?= $variance >= 0 ? '+' : '' ?><?= number_format($variance, 2) ?>
              </span>
            </td>
            <td style="font-size:.75rem;color:var(--sap-text-muted)">
              <?= e(mb_strimwidth($r['notes'] ?? '', 0, 60, '…')) ?>
            </td>
            <td><small><?= e($r['recorder'] ?? '—') ?></small></td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>