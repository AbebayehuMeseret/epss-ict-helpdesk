<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('ADMIN');
$pageTitle = 'KPI Management';
$pdo = db(); $ok = ''; $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf($_POST['csrf'] ?? null)) {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'create') {
            $pdo->prepare("INSERT INTO kpis
                (kpi_code, kpi_name, kpi_type, category_id, description, kpi_formula,
                 target_percentage, target_value, target_unit, measurement_period,
                 strategic_objective, responsible_unit)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)")
                ->execute([
                    trim($_POST['code'] ?? '') ?: null,
                    trim($_POST['name']),
                    $_POST['type'] ?? 'PROCESS',
                    $_POST['category_id'] ?: null,
                    $_POST['description'] ?: null,
                    $_POST['formula'] ?: null,
                    (float)($_POST['target'] ?? 100),
                    $_POST['target_value'] !== '' ? (float)$_POST['target_value'] : null,
                    $_POST['target_unit'] ?: null,
                    $_POST['period'] ?? 'MONTHLY',
                    $_POST['strategic_objective'] ?: null,
                    $_POST['responsible_unit'] ?: null,
                ]);
            audit('CreateKPI','kpis',(int)$pdo->lastInsertId(),'Created KPI ' . $_POST['name']);
            $ok = 'KPI created.';

        } elseif ($action === 'update') {
            $id = (int)$_POST['id'];
            $pdo->prepare("UPDATE kpis SET
                kpi_code=?, kpi_name=?, kpi_type=?, category_id=?, description=?, kpi_formula=?,
                target_percentage=?, target_value=?, target_unit=?, measurement_period=?,
                strategic_objective=?, responsible_unit=?
                WHERE id=?")
                ->execute([
                    trim($_POST['code'] ?? '') ?: null,
                    trim($_POST['name']),
                    $_POST['type'] ?? 'PROCESS',
                    $_POST['category_id'] ?: null,
                    $_POST['description'] ?: null,
                    $_POST['formula'] ?: null,
                    (float)($_POST['target'] ?? 100),
                    $_POST['target_value'] !== '' ? (float)$_POST['target_value'] : null,
                    $_POST['target_unit'] ?: null,
                    $_POST['period'] ?? 'MONTHLY',
                    $_POST['strategic_objective'] ?: null,
                    $_POST['responsible_unit'] ?: null,
                    $id,
                ]);
            audit('UpdateKPI','kpis',$id,'Updated KPI ' . $_POST['name']);
            $ok = 'KPI updated.';

        } elseif ($action === 'toggle') {
            $pdo->prepare("UPDATE kpis SET status=IF(status='ACTIVE','INACTIVE','ACTIVE') WHERE id=?")
                ->execute([(int)$_POST['id']]);
            $ok = 'Status updated.';

        } elseif ($action === 'delete') {
            $id = (int)$_POST['id'];
            $s = $pdo->prepare("SELECT kpi_name FROM kpis WHERE id=?");
            $s->execute([$id]);
            $name = $s->fetchColumn() ?: ('#' . $id);
            $pdo->prepare("DELETE FROM kpis WHERE id=?")->execute([$id]);
            audit('DeleteKPI','kpis',$id,'Deleted KPI ' . $name);
            $ok = 'KPI deleted.';
        }
    } catch (Throwable $e) {
        $error = app_exception_message($e);
    }
}

$cats = $pdo->query("SELECT * FROM categories WHERE status='ACTIVE' ORDER BY category_name")->fetchAll();
$kpis = $pdo->query("
    SELECT k.*, c.category_name,
        (SELECT COUNT(*) FROM kpi_measurements m WHERE m.kpi_id = k.id) AS measurements
    FROM kpis k
    LEFT JOIN categories c ON c.id=k.category_id
    ORDER BY
        CASE WHEN k.kpi_code IS NULL THEN 1 ELSE 0 END,
        k.kpi_code,
        k.kpi_name
")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:#0070f2; --sap-brand-dark:#0057d2;
    --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500;
    --sap-negative:#aa0808; --sap-neutral:#5b738b;
    --sap-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
  }
  body, .main-content { background:var(--sap-bg) !important;
    font-family:"72","72full",Arial,Helvetica,sans-serif !important; color:var(--sap-text); }
  .sap-page-header { display:flex; justify-content:space-between; align-items:flex-start;
    margin-bottom:1rem; flex-wrap:wrap; gap:.75rem; }
  .sap-page-title { font-size:1.625rem; font-weight:400; margin:0; }
  .sap-breadcrumb { font-size:.8125rem; color:var(--sap-text-muted); margin-bottom:.25rem; }
  .sap-card { background:var(--sap-tile); border-radius:.75rem;
    box-shadow:var(--sap-shadow); overflow:hidden; }
  .sap-card-header { padding:.75rem 1.15rem; border-bottom:1px solid var(--sap-border-soft);
    display:flex; justify-content:space-between; align-items:center; gap:.5rem; flex-wrap:wrap; }
  .sap-card-body { padding:1rem 1.15rem; }
  .sap-btn { display:inline-flex; align-items:center; gap:.35rem;
    font-size:.8125rem; font-weight:500; border-radius:.5rem;
    padding:.45rem .8rem; border:1px solid transparent; background:transparent;
    color:var(--sap-brand); cursor:pointer; line-height:1; text-decoration:none;
    white-space:nowrap; font-family:inherit; }
  .sap-btn:hover { background:#eaf4ff; color:var(--sap-brand-dark); }
  .sap-btn.sap-btn-emphasized { background:var(--sap-brand); color:#fff; }
  .sap-btn.sap-btn-emphasized:hover { background:var(--sap-brand-dark); color:#fff; }
  .sap-btn.sap-btn-icon { padding:.35rem .5rem; }
  .sap-btn.sap-btn-danger { color:var(--sap-negative); }

  table.sap-table { width:100%; border-collapse:separate; border-spacing:0; font-size:.8125rem; }
  table.sap-table thead th { background:#f5f6f7; border-bottom:1px solid var(--sap-border);
    font-weight:600; color:var(--sap-text-muted); text-align:left;
    padding:.6rem .7rem; text-transform:uppercase; font-size:.68rem; letter-spacing:.04em; white-space:nowrap; }
  table.sap-table tbody td { padding:.65rem .7rem;
    border-bottom:1px solid var(--sap-border-soft); vertical-align:middle; }
  table.sap-table tbody tr:last-child td { border-bottom:0; }
  table.sap-table tbody tr:hover { background:#f8fbff; }

  .sap-code { font-family:"72Mono","Courier New",monospace; font-size:.72rem; font-weight:700;
    background:#eaf4ff; color:var(--sap-brand); padding:.1rem .5rem; border-radius:.35rem; }
  .sap-kpi-name { font-weight:600; }
  .sap-kpi-desc { font-size:.72rem; color:var(--sap-text-muted); margin-top:.15rem; }
  .sap-status { display:inline-flex; align-items:center;
    font-size:.68rem; font-weight:600; padding:.12rem .5rem;
    border-radius:.75rem; white-space:nowrap; }
  .sap-status.is-good { background:#f1fdf6; color:var(--sap-positive); border:1px solid #d6f0e0; }
  .sap-status.is-off  { background:#f4f5f7; color:var(--sap-neutral); border:1px solid #e4e7eb; }
  .sap-type-chip {
    display:inline-block; font-size:.65rem; font-weight:700;
    padding:.1rem .5rem; border-radius:.75rem; text-transform:uppercase;
    letter-spacing:.03em;
  }
  .sap-type-chip.SLA      { background:#eaf4ff; color:var(--sap-brand); }
  .sap-type-chip.PROCESS  { background:#f0e6ff; color:#5b21b6; }
  .sap-type-chip.OUTPUT   { background:#f1fdf6; color:var(--sap-positive); }
  .sap-type-chip.CUSTOM   { background:#f4f5f7; color:var(--sap-neutral); }

  .sap-target { font-family:"72Mono","Courier New",monospace; font-size:.9rem; font-weight:600; }
  .sap-unit   { font-size:.72rem; color:var(--sap-text-muted); font-weight:500; }
</style>

<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb"><i class="bi bi-house-door"></i> Home / Configuration / <strong>KPI Management</strong></div>
    <h1 class="sap-page-title">KPI Management</h1>
  </div>
  <div class="d-flex gap-2">
    <a href="kpi_measurements.php" class="sap-btn" style="border:1px solid var(--sap-border);background:#fff">
      <i class="bi bi-pencil-square"></i> Record Measurements
    </a>
    <button class="sap-btn sap-btn-emphasized" data-bs-toggle="modal" data-bs-target="#newK">
      <i class="bi bi-plus-lg"></i> Add KPI
    </button>
  </div>
</div>

<?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>

<div class="sap-card">
  <div class="sap-card-body p-0">
    <div class="table-responsive">
      <table class="sap-table">
        <thead>
          <tr>
            <th style="width:70px">Code</th>
            <th>KPI</th>
            <th>Type</th>
            <th>Scope</th>
            <th>Target</th>
            <th>Period</th>
            <th>Strategic Objective</th>
            <th class="text-center">Meas.</th>
            <th>Status</th>
            <th style="text-align:right">Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($kpis as $k):
            $type = $k['kpi_type'] ?? 'PROCESS';
        ?>
          <tr>
            <td>
              <?php if (!empty($k['kpi_code'])): ?>
                <span class="sap-code"><?= e($k['kpi_code']) ?></span>
              <?php else: ?>
                <span class="text-muted small">—</span>
              <?php endif; ?>
            </td>
            <td>
              <div class="sap-kpi-name"><?= e($k['kpi_name']) ?></div>
              <?php if (!empty($k['description'])): ?>
                <div class="sap-kpi-desc"><?= e($k['description']) ?></div>
              <?php endif; ?>
              <?php if (!empty($k['kpi_formula'])): ?>
                <div class="sap-kpi-desc" style="font-family:'72Mono',monospace;font-size:.7rem">
                  = <?= e($k['kpi_formula']) ?>
                </div>
              <?php endif; ?>
            </td>
            <td><span class="sap-type-chip <?= e($type) ?>"><?= e($type) ?></span></td>
            <td><?= e($k['category_name'] ?? 'Branch-wide') ?></td>
            <td>
              <?php if ($k['target_value'] !== null): ?>
                <span class="sap-target"><?= number_format((float)$k['target_value'], 2) ?></span>
                <span class="sap-unit"><?= e($k['target_unit'] ?? '') ?></span>
              <?php else: ?>
                <span class="sap-target"><?= number_format((float)$k['target_percentage'], 2) ?>%</span>
              <?php endif; ?>
            </td>
            <td><?= e($k['measurement_period']) ?></td>
            <td style="font-size:.72rem;color:var(--sap-text-muted)">
              <?= e(mb_strimwidth($k['strategic_objective'] ?? '—', 0, 55, '…')) ?>
            </td>
            <td class="text-center">
              <span class="sap-status <?= $k['measurements'] > 0 ? 'is-good' : 'is-off' ?>">
                <?= (int)$k['measurements'] ?>
              </span>
            </td>
            <td>
              <span class="sap-status <?= $k['status']==='ACTIVE' ? 'is-good' : 'is-off' ?>">
                <?= e($k['status']) ?>
              </span>
            </td>
            <td style="text-align:right">
              <div class="d-inline-flex gap-1">
                <a class="sap-btn sap-btn-icon"
                   href="kpi_measurements.php?kpi_id=<?= (int)$k['id'] ?>"
                   title="Record measurements">
                  <i class="bi bi-pencil-square"></i>
                </a>
                <button class="sap-btn sap-btn-icon"
                        data-bs-toggle="modal" data-bs-target="#editK"
                        data-id="<?= (int)$k['id'] ?>"
                        data-code="<?= e($k['kpi_code'] ?? '') ?>"
                        data-name="<?= e($k['kpi_name']) ?>"
                        data-type="<?= e($type) ?>"
                        data-category="<?= (int)($k['category_id'] ?? 0) ?>"
                        data-description="<?= e($k['description'] ?? '') ?>"
                        data-formula="<?= e($k['kpi_formula'] ?? '') ?>"
                        data-target="<?= (float)$k['target_percentage'] ?>"
                        data-target-value="<?= $k['target_value'] !== null ? (float)$k['target_value'] : '' ?>"
                        data-target-unit="<?= e($k['target_unit'] ?? '') ?>"
                        data-period="<?= e($k['measurement_period']) ?>"
                        data-objective="<?= e($k['strategic_objective'] ?? '') ?>"
                        data-unit-resp="<?= e($k['responsible_unit'] ?? '') ?>">
                  <i class="bi bi-pencil"></i>
                </button>
                <form method="post" class="d-inline">
                  <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                  <input type="hidden" name="action" value="toggle">
                  <input type="hidden" name="id" value="<?= (int)$k['id'] ?>">
                  <button class="sap-btn sap-btn-icon" title="Activate / Deactivate">
                    <i class="bi bi-power"></i>
                  </button>
                </form>
                <button class="sap-btn sap-btn-icon sap-btn-danger"
                        data-bs-toggle="modal" data-bs-target="#deleteK"
                        data-id="<?= (int)$k['id'] ?>"
                        data-name="<?= e($k['kpi_name']) ?>">
                  <i class="bi bi-trash"></i>
                </button>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- ================= Add KPI Modal ================= -->
<div class="modal fade" id="newK"><div class="modal-dialog modal-lg"><div class="modal-content">
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="create">
<div class="modal-header"><h5 class="modal-title">Add KPI</h5>
  <button class="btn-close" data-bs-dismiss="modal" type="button"></button></div>
<div class="modal-body row g-3">
  <div class="col-md-3"><label class="form-label">Code</label>
    <input name="code" class="form-control" placeholder="ICT-1" maxlength="30"></div>
  <div class="col-md-6"><label class="form-label">KPI Name *</label>
    <input name="name" class="form-control" required maxlength="200"></div>
  <div class="col-md-3"><label class="form-label">Type *</label>
    <select name="type" class="form-select" required>
      <option value="PROCESS">Process</option>
      <option value="OUTPUT">Output</option>
      <option value="CUSTOM">Custom</option>
    </select></div>

  <div class="col-md-6"><label class="form-label">Category</label>
    <select name="category_id" class="form-select"><option value="">Branch-wide</option>
      <?php foreach ($cats as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['category_name']) ?></option><?php endforeach; ?>
    </select></div>
  <div class="col-md-3"><label class="form-label">Target Value</label>
    <input type="number" step="0.01" name="target_value" class="form-control"
           placeholder="e.g. 5.00"></div>
  <div class="col-md-3"><label class="form-label">Target Unit</label>
    <input name="target_unit" class="form-control" placeholder="e.g. %, days, ETB" maxlength="30"></div>

  <div class="col-md-6"><label class="form-label">Target %</label>
    <input type="number" step="0.01" name="target" value="100" class="form-control"></div>
  <div class="col-md-6"><label class="form-label">Period *</label>
    <select name="period" class="form-select">
      <option value="MONTHLY">Monthly</option>
      <option value="QUARTERLY">Quarterly</option>
      <option value="YEARLY">Yearly</option>
    </select></div>

  <div class="col-md-12"><label class="form-label">Description</label>
    <textarea name="description" class="form-control" rows="2"></textarea></div>
  <div class="col-md-12"><label class="form-label">Formula</label>
    <textarea name="formula" class="form-control" rows="2"
              placeholder="(Number of functional systems) / (Total systems) * 100%"></textarea></div>

  <div class="col-md-6"><label class="form-label">Strategic Objective</label>
    <input name="strategic_objective" class="form-control"
           placeholder="SO-5: Transform Supply Chain Technologies and Information System"
           maxlength="100"></div>
  <div class="col-md-6"><label class="form-label">Responsible Unit</label>
    <input name="responsible_unit" class="form-control" placeholder="ICT" maxlength="50"></div>
</div>
<div class="modal-footer">
  <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Cancel</button>
  <button class="sap-btn sap-btn-emphasized">Create KPI</button>
</div>
</form></div></div></div>

<!-- ================= Edit KPI Modal ================= -->
<div class="modal fade" id="editK"><div class="modal-dialog modal-lg"><div class="modal-content">
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="update">
<input type="hidden" name="id" id="ek-id">
<div class="modal-header"><h5 class="modal-title">Edit KPI</h5>
  <button class="btn-close" data-bs-dismiss="modal" type="button"></button></div>
<div class="modal-body row g-3">
  <div class="col-md-3"><label class="form-label">Code</label>
    <input name="code" id="ek-code" class="form-control" maxlength="30"></div>
  <div class="col-md-6"><label class="form-label">KPI Name *</label>
    <input name="name" id="ek-name" class="form-control" required maxlength="200"></div>
  <div class="col-md-3"><label class="form-label">Type *</label>
    <select name="type" id="ek-type" class="form-select" required>
      <option value="PROCESS">Process</option>
      <option value="OUTPUT">Output</option>
      <option value="CUSTOM">Custom</option>
    </select></div>

  <div class="col-md-6"><label class="form-label">Category</label>
    <select name="category_id" id="ek-category" class="form-select"><option value="">Branch-wide</option>
      <?php foreach ($cats as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['category_name']) ?></option><?php endforeach; ?>
    </select></div>
  <div class="col-md-3"><label class="form-label">Target Value</label>
    <input type="number" step="0.01" name="target_value" id="ek-target-value" class="form-control"></div>
  <div class="col-md-3"><label class="form-label">Target Unit</label>
    <input name="target_unit" id="ek-target-unit" class="form-control" maxlength="30"></div>

  <div class="col-md-6"><label class="form-label">Target %</label>
    <input type="number" step="0.01" name="target" id="ek-target" class="form-control"></div>
  <div class="col-md-6"><label class="form-label">Period *</label>
    <select name="period" id="ek-period" class="form-select">
      <option value="MONTHLY">Monthly</option>
      <option value="QUARTERLY">Quarterly</option>
      <option value="YEARLY">Yearly</option>
    </select></div>

  <div class="col-md-12"><label class="form-label">Description</label>
    <textarea name="description" id="ek-description" class="form-control" rows="2"></textarea></div>
  <div class="col-md-12"><label class="form-label">Formula</label>
    <textarea name="formula" id="ek-formula" class="form-control" rows="2"></textarea></div>

  <div class="col-md-6"><label class="form-label">Strategic Objective</label>
    <input name="strategic_objective" id="ek-objective" class="form-control" maxlength="100"></div>
  <div class="col-md-6"><label class="form-label">Responsible Unit</label>
    <input name="responsible_unit" id="ek-unit-resp" class="form-control" maxlength="50"></div>
</div>
<div class="modal-footer">
  <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Cancel</button>
  <button class="sap-btn sap-btn-emphasized">Save Changes</button>
</div>
</form></div></div></div>

<!-- ================= Delete KPI Modal ================= -->
<div class="modal fade" id="deleteK"><div class="modal-dialog"><div class="modal-content">
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="delete">
<input type="hidden" name="id" id="dk-id">
<div class="modal-header" style="background:#fef4f4"><h5 class="modal-title">Delete KPI</h5>
  <button class="btn-close" data-bs-dismiss="modal" type="button"></button></div>
<div class="modal-body">
  <p>Delete <strong id="dk-name"></strong>?</p>
  <div class="alert alert-info small mb-0">
    All measurement records for this KPI will also be deleted. Consider deactivating instead.
  </div>
</div>
<div class="modal-footer">
  <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Cancel</button>
  <button class="btn btn-danger">Delete</button>
</div>
</form></div></div></div>

<script>
document.getElementById('editK').addEventListener('show.bs.modal', e => {
  const b = e.relatedTarget;
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.value = v ?? ''; };
  set('ek-id', b.dataset.id);
  set('ek-code', b.dataset.code);
  set('ek-name', b.dataset.name);
  set('ek-type', b.dataset.type);
  set('ek-category', b.dataset.category || '');
  set('ek-description', b.dataset.description);
  set('ek-formula', b.dataset.formula);
  set('ek-target', b.dataset.target);
  set('ek-target-value', b.dataset.targetValue);
  set('ek-target-unit', b.dataset.targetUnit);
  set('ek-period', b.dataset.period);
  set('ek-objective', b.dataset.objective);
  set('ek-unit-resp', b.dataset.unitResp);
});

document.getElementById('deleteK').addEventListener('show.bs.modal', e => {
  const b = e.relatedTarget;
  document.getElementById('dk-id').value = b.dataset.id;
  document.getElementById('dk-name').textContent = b.dataset.name;
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>