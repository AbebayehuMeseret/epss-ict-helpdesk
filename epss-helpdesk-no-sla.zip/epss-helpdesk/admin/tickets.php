<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('ADMIN');
$pageTitle = 'All Tickets';

$pdo = db();

/* ---------- Filters ---------- */
$q       = trim($_GET['q']       ?? '');
$status  = $_GET['status']       ?? '';
$prioId  = (int)($_GET['priority_id']  ?? 0);
$catId   = (int)($_GET['category_id']  ?? 0);
$deptId  = (int)($_GET['department_id']?? 0);

$sql = "SELECT t.*,
               c.category_name,
               p.name AS priority_name, p.color AS priority_color, p.level AS priority_level,
               req.full_name AS requester_name,
               d.department_name,
               tl.full_name  AS tl_name,
               tech.full_name AS tech_name
        FROM tickets t
        JOIN categories c ON c.id = t.category_id
        JOIN priorities p ON p.id = t.priority_id
        JOIN users req    ON req.id = t.requester_id
        LEFT JOIN departments d ON d.id = t.department_id
        LEFT JOIN users tl   ON tl.id = t.team_leader_id
        LEFT JOIN users tech ON tech.id = t.assigned_technician_id
        WHERE 1=1";

$params = [];
if ($q !== '') {
    $sql .= " AND (t.ticket_number LIKE ? OR t.subject LIKE ? OR req.full_name LIKE ?)";
    array_push($params, "%$q%", "%$q%", "%$q%");
}
if ($status !== '') { $sql .= " AND t.status = ?";         $params[] = $status; }
if ($prioId)        { $sql .= " AND t.priority_id = ?";    $params[] = $prioId; }
if ($catId)         { $sql .= " AND t.category_id = ?";    $params[] = $catId; }
if ($deptId)        { $sql .= " AND t.department_id = ?";  $params[] = $deptId; }

$sql .= " ORDER BY t.created_at DESC LIMIT 500";
$stmt = $pdo->prepare($sql); $stmt->execute($params);
$tickets = $stmt->fetchAll();

/* Filter dropdown data */
$cats     = $pdo->query("SELECT id, category_name FROM categories WHERE status='ACTIVE' ORDER BY category_name")->fetchAll();
$pris     = $pdo->query("SELECT id, name FROM priorities WHERE status='ACTIVE' ORDER BY level")->fetchAll();
$depts    = $pdo->query("SELECT id, department_name FROM departments WHERE status='ACTIVE' ORDER BY department_name")->fetchAll();

/* Priority colour → SAP hex */
function prio_hex(string $color): string {
    return match ($color) {
        'danger'    => '#aa0808',
        'warning'   => '#e76500',
        'info'      => '#0070f2',
        'primary'   => '#0057d2',
        'success'   => '#256f3a',
        'secondary' => '#5b738b',
        'dark'      => '#354a5f',
        default     => '#5b738b',
    };
}

/* Status → SAP Horizon status token */
function status_meta(string $status): array {
    return match ($status) {
        'PENDING_TEAM_LEADER_APPROVAL'              => ['Pending Approval','critical','hourglass-split'],
        'RETURNED_TO_EMPLOYEE'                      => ['Returned to Employee','info','arrow-return-left'],
        'APPROVED_FOR_ICT'                          => ['Approved for ICT','info','check2-circle'],
        'ASSIGNED_TO_ICT'                           => ['Assigned to ICT','info','person-check'],
        'IN_PROGRESS'                               => ['In Progress','info','tools'],
        'WAITING_FOR_INFORMATION'                   => ['Waiting for Info','neutral','pause-circle'],
        'WAITING_FOR_PARTS'                         => ['Waiting for Parts','neutral','pause-circle'],
        'WORK_COMPLETED'                            => ['Work Completed','good','check2'],
        'RESOLVED_PENDING_REQUESTER_CONFIRMATION'   => ['Awaiting Requester','critical','patch-check'],
        'RESOLVED_PENDING_TEAM_LEADER_VERIFICATION' => ['Awaiting Requester','critical','patch-check'],
        'RETURNED_TO_ICT'                           => ['Returned to ICT','critical','arrow-return-right'],
        'REJECTED'                                  => ['Rejected','bad','x-circle'],
        'CLOSED'                                    => ['Closed','good','check2-all'],
        'CANCELLED'                                 => ['Cancelled','neutral','slash-circle'],
        default                                     => [str_replace('_',' ',$status),'neutral','circle'],
    };
}

/* Counts for the summary pills */
$counts = [
    'total'    => count($tickets),
    'open'     => count(array_filter($tickets, fn($t) => !in_array($t['status'], ['CLOSED','REJECTED','CANCELLED'], true))),
];

include __DIR__ . '/../includes/header.php';
?>

<!-- ================= SAP Fiori Horizon theme ================= -->
<style>
  :root {
    --sap-brand:        #0070f2;
    --sap-brand-dark:   #0057d2;
    --sap-bg:           #f5f6f7;
    --sap-tile:         #ffffff;
    --sap-text:         #1d2d3e;
    --sap-text-muted:   #556b82;
    --sap-border:       #d9d9d9;
    --sap-border-soft:  #eaecf0;
    --sap-positive:     #256f3a;
    --sap-critical:     #e76500;
    --sap-negative:     #aa0808;
    --sap-neutral:      #5b738b;
    --sap-shadow:       0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
    --sap-shadow-hover: 0 0 0 1px rgba(34,53,72,.15), 0 8px 24px 0 rgba(34,53,72,.12);
  }

  body, .main-content {
    background: var(--sap-bg) !important;
    font-family: "72", "72full", Arial, Helvetica, sans-serif !important;
    color: var(--sap-text);
  }

  .sap-page-header {
    display: flex; align-items: flex-start; justify-content: space-between;
    margin-bottom: 1rem;
  }
  .sap-page-title { font-size: 1.625rem; font-weight: 400; margin: 0; }
  .sap-breadcrumb { font-size: .8125rem; color: var(--sap-text-muted); margin-bottom: .25rem; }

  /* SAP Filter bar (above toolbar) */
  .sap-filterbar {
    background: var(--sap-tile);
    border-radius: .75rem .75rem 0 0;
    box-shadow: var(--sap-shadow);
    padding: .75rem 1rem;
    border-bottom: 1px solid var(--sap-border-soft);
  }
  .sap-filterbar-row {
    display: flex; gap: .5rem; flex-wrap: wrap; align-items: center;
  }
  .sap-filterbar input.form-control,
  .sap-filterbar select.form-select {
    font-size: .8125rem;
    padding: .4rem .65rem;
    border-radius: .5rem;
    border: 1px solid var(--sap-border);
    background: #fff;
    min-width: 150px;
  }
  .sap-filterbar input.form-control:focus,
  .sap-filterbar select.form-select:focus {
    border-color: var(--sap-brand);
    box-shadow: 0 0 0 2px rgba(0,112,242,.15);
  }
  .sap-search-wrap { position: relative; flex: 1 1 320px; min-width: 220px; }
  .sap-search-wrap i {
    position: absolute; left: .6rem; top: 50%; transform: translateY(-50%);
    color: var(--sap-text-muted); font-size: .85rem;
  }
  .sap-search-wrap input { padding-left: 2rem !important; }

  /* SAP Toolbar */
  .sap-toolbar {
    display: flex; align-items: center; justify-content: space-between;
    background: var(--sap-tile);
    padding: .45rem 1rem;
    border-bottom: 1px solid var(--sap-border-soft);
    flex-wrap: wrap; gap: .5rem;
  }
  .sap-toolbar-title {
    font-size: .875rem; font-weight: 600;
    display: flex; align-items: center; gap: .4rem;
  }
  .sap-toolbar-title .bi { color: var(--sap-brand); }
  .sap-toolbar-info {
    font-size: .8125rem; color: var(--sap-text-muted);
  }
  .sap-toolbar-actions { display: flex; gap: .25rem; align-items: center; flex-wrap: wrap; }

  /* SAP flat button */
  .sap-btn {
    display: inline-flex; align-items: center; gap: .35rem;
    font-size: .8125rem; font-weight: 500;
    border-radius: .5rem;
    padding: .35rem .7rem;
    border: 1px solid transparent;
    background: transparent;
    color: var(--sap-brand);
    transition: background .15s, box-shadow .15s, color .15s;
    cursor: pointer;
    line-height: 1;
    text-decoration: none;
  }
  .sap-btn:hover { background: #eaf4ff; color: var(--sap-brand-dark); }
  .sap-btn:focus-visible { outline: 2px solid var(--sap-brand); outline-offset: 2px; }
  .sap-btn.sap-btn-emphasized {
    background: var(--sap-brand); color: #fff;
    box-shadow: 0 1px 2px rgba(34,53,72,.15);
  }
  .sap-btn.sap-btn-emphasized:hover { background: var(--sap-brand-dark); color: #fff; }
  .sap-btn.sap-btn-icon { padding: .35rem .5rem; }

  /* SAP Table */
  .sap-table-wrap {
    background: var(--sap-tile);
    border-radius: 0 0 .75rem .75rem;
    box-shadow: var(--sap-shadow);
    overflow: hidden;
  }
  table.sap-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    font-size: .8125rem;
    margin: 0;
  }
  table.sap-table thead th {
    background: #f5f6f7;
    border-bottom: 1px solid var(--sap-border);
    font-weight: 600;
    color: var(--sap-text-muted);
    text-align: left;
    padding: .6rem .75rem;
    white-space: nowrap;
    text-transform: uppercase;
    font-size: .7rem;
    letter-spacing: .04em;
  }
  table.sap-table tbody td {
    padding: .6rem .75rem;
    border-bottom: 1px solid var(--sap-border-soft);
    vertical-align: middle;
    color: var(--sap-text);
  }
  table.sap-table tbody tr:last-child td { border-bottom: 0; }
  table.sap-table tbody tr { transition: background .12s; cursor: pointer; }
  table.sap-table tbody tr:hover { background: #f8fbff; }

  /* Ticket number link */
  .sap-ticket-num {
    font-family: "72Mono", "Courier New", monospace;
    font-weight: 600;
    color: var(--sap-brand);
    text-decoration: none;
    white-space: nowrap;
  }
  .sap-ticket-num:hover { color: var(--sap-brand-dark); text-decoration: underline; }

  /* Ticket subject cell (two-line) */
  .sap-subj { font-weight: 600; color: var(--sap-text); line-height: 1.2; }
  .sap-subj-desc {
    font-size: .72rem; color: var(--sap-text-muted); margin-top: .15rem;
    max-width: 380px;
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  }

  /* User cell */
  .sap-user {
    display: flex; align-items: center; gap: .5rem;
  }
  .sap-avatar {
    width: 28px; height: 28px; border-radius: 50%;
    background: var(--sap-brand); color: #fff;
    display: inline-flex; align-items: center; justify-content: center;
    font-weight: 600; font-size: .75rem;
    flex-shrink: 0;
  }

  /* Priority chip */
  .sap-prio {
    display: inline-flex; align-items: center; gap: .3rem;
    font-size: .7rem; font-weight: 600;
    padding: .15rem .55rem;
    border-radius: .75rem;
    color: #fff;
    white-space: nowrap;
  }

  /* Category chip */
  .sap-cat {
    display: inline-flex; align-items: center; gap: .3rem;
    font-size: .72rem; font-weight: 500;
    padding: .15rem .55rem;
    border-radius: .75rem;
    background: #f4f5f7; color: var(--sap-text);
    border: 1px solid #e4e7eb;
    white-space: nowrap;
  }
  .sap-cat .bi { font-size: .65rem; color: var(--sap-text-muted); }

  /* ObjectStatus pill */
  .sap-status {
    display: inline-flex; align-items: center; gap: .25rem;
    font-size: .7rem; font-weight: 600;
    padding: .1rem .5rem;
    border-radius: .75rem;
    white-space: nowrap;
    border: 1px solid transparent;
  }
  .sap-status.is-good     { background: #f1fdf6; color: var(--sap-positive); border-color: #d6f0e0; }
  .sap-status.is-critical { background: #fff8f1; color: var(--sap-critical); border-color: #fbe0c8; }
  .sap-status.is-bad      { background: #fef4f4; color: var(--sap-negative); border-color: #f7d2d2; }
  .sap-status.is-info     { background: #eaf4ff; color: var(--sap-brand);    border-color: #cfe2f8; }
  .sap-status.is-neutral  { background: #f4f5f7; color: var(--sap-neutral);  border-color: #e4e7eb; }

  /* Overdue badge */
  .sap-overdue {
    display: inline-flex; align-items: center; gap: .2rem;
    font-size: .65rem; font-weight: 700;
    padding: .05rem .4rem;
    border-radius: .75rem;
    background: #fef4f4; color: var(--sap-negative);
    border: 1px solid #f7d2d2;
    margin-left: .35rem;
  }

  /* Empty state */
  .sap-empty {
    text-align: center; padding: 2.5rem 1rem; color: var(--sap-text-muted);
  }
  .sap-empty .bi { font-size: 2rem; opacity: .4; }

  /* Hide DataTables default chrome — we're using SAP filters */
  .dataTables_wrapper .dataTables_length,
  .dataTables_wrapper .dataTables_filter { display: none; }
  .dataTables_wrapper .dataTables_info,
  .dataTables_wrapper .dataTables_paginate { padding: .6rem 1rem; }
  .dataTables_wrapper .dataTables_paginate .paginate_button {
    border-radius: .35rem !important;
  }
  .dataTables_wrapper .dataTables_paginate .paginate_button.current {
    background: var(--sap-brand) !important;
    color: #fff !important;
    border-color: var(--sap-brand) !important;
  }

  @media (prefers-reduced-motion: reduce) {
    table.sap-table tbody tr { transition: none !important; }
  }
</style>

<!-- ================= Page header ================= -->
<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb">
      <i class="bi bi-house-door"></i> Home / Tickets / <strong>All Tickets</strong>
    </div>
    <h1 class="sap-page-title">All Tickets</h1>
  </div>
  <div class="d-flex align-items-center gap-2 flex-wrap">
    <span class="sap-status is-info">
      <i class="bi bi-ticket-detailed"></i> <?= number_format($counts['total']) ?> total
    </span>
    <span class="sap-status is-critical">
      <i class="bi bi-hourglass"></i> <?= number_format($counts['open']) ?> open
    </span>
  </div>
</div>

<!-- ================= Filter bar ================= -->
<div class="sap-filterbar">
  <form method="get" class="sap-filterbar-row">
    <div class="sap-search-wrap">
      <i class="bi bi-search"></i>
      <input name="q" class="form-control"
             placeholder="Search ticket #, subject, or requester…"
             value="<?= e($q) ?>">
    </div>

    <select name="status" class="form-select">
      <option value="">All Statuses</option>
      <?php foreach ([
        'PENDING_TEAM_LEADER_APPROVAL',
        'APPROVED_FOR_ICT','ASSIGNED_TO_ICT','IN_PROGRESS',
        'WAITING_FOR_INFORMATION','WAITING_FOR_PARTS',
        'RESOLVED_PENDING_REQUESTER_CONFIRMATION','RETURNED_TO_ICT',
        'CLOSED','REJECTED','CANCELLED',
      ] as $s): ?>
        <option value="<?= $s ?>" <?= $status === $s ? 'selected' : '' ?>>
          <?= e(str_replace('_',' ', $s)) ?>
        </option>
      <?php endforeach; ?>
    </select>

    <select name="priority_id" class="form-select">
      <option value="">All Priorities</option>
      <?php foreach ($pris as $p): ?>
        <option value="<?= (int)$p['id'] ?>" <?= $prioId == $p['id'] ? 'selected' : '' ?>>
          <?= e($p['name']) ?>
        </option>
      <?php endforeach; ?>
    </select>

    <select name="category_id" class="form-select">
      <option value="">All Categories</option>
      <?php foreach ($cats as $c): ?>
        <option value="<?= (int)$c['id'] ?>" <?= $catId == $c['id'] ? 'selected' : '' ?>>
          <?= e($c['category_name']) ?>
        </option>
      <?php endforeach; ?>
    </select>

    <select name="department_id" class="form-select">
      <option value="">All Departments</option>
      <?php foreach ($depts as $d): ?>
        <option value="<?= (int)$d['id'] ?>" <?= $deptId == $d['id'] ? 'selected' : '' ?>>
          <?= e($d['department_name']) ?>
        </option>
      <?php endforeach; ?>
    </select>

    <button class="sap-btn sap-btn-emphasized">
      <i class="bi bi-funnel"></i> Apply
    </button>
    <?php if ($q || $status || $prioId || $catId || $deptId): ?>
      <a class="sap-btn" href="<?= BASE_URL ?>/admin/tickets.php">
        <i class="bi bi-x-circle"></i> Clear
      </a>
    <?php endif; ?>
  </form>
</div>

<!-- ================= Toolbar ================= -->
<div class="sap-toolbar">
  <div class="sap-toolbar-title">
    <i class="bi bi-ticket-detailed"></i> Ticket List
    <span class="sap-toolbar-info">
      · <?= count($tickets) ?> row<?= count($tickets) === 1 ? '' : 's' ?>
      <?= count($tickets) >= 500 ? ' (showing first 500)' : '' ?>
    </span>
  </div>
  <div class="sap-toolbar-actions">
    <a class="sap-btn" href="<?= BASE_URL ?>/admin/reports.php">
      <i class="bi bi-file-earmark-bar-graph"></i> Reports
    </a>
  </div>
</div>

<!-- ================= Table ================= -->
<div class="sap-table-wrap">
  <?php if (!$tickets): ?>
    <div class="sap-empty">
      <i class="bi bi-inbox"></i>
      <div class="mt-2">
        <?= ($q || $status || $prioId || $catId || $deptId)
            ? 'No tickets match the current filters.'
            : 'No tickets yet.' ?>
      </div>
    </div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="sap-table" id="allTickets">
        <thead>
          <tr>
            <th>Ticket #</th>
            <th>Subject</th>
            <th>Requester</th>
            <th>Department</th>
            <th>Category</th>
            <th>Priority</th>
            <th>Status</th>
            <th>Created</th>
            <th style="text-align:right;"></th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($tickets as $t):
            [$label, $tone, $icon] = status_meta($t['status']);
            $hexPrio = prio_hex($t['priority_color']);
        ?>
          <tr onclick="if(!event.target.closest('a')) location.href='<?= BASE_URL ?>/admin/ticket_view.php?id=<?= (int)$t['id'] ?>';">
            <td>
              <a class="sap-ticket-num"
                 href="<?= BASE_URL ?>/admin/ticket_view.php?id=<?= (int)$t['id'] ?>">
                <?= e($t['ticket_number']) ?>
              </a>
            </td>
            <td>
              <div class="sap-subj"><?= e($t['subject']) ?></div>
              <?php if (!empty($t['description'])): ?>
                <div class="sap-subj-desc" title="<?= e($t['description']) ?>">
                  <?= e($t['description']) ?>
                </div>
              <?php endif; ?>
            </td>
            <td>
              <div class="sap-user">
                <div class="sap-avatar"><?= e(strtoupper(mb_substr($t['requester_name'], 0, 1))) ?></div>
                <div><?= e($t['requester_name']) ?></div>
              </div>
            </td>
            <td><?= e($t['department_name'] ?? '—') ?></td>
            <td>
              <span class="sap-cat">
                <i class="bi bi-tag"></i> <?= e($t['category_name']) ?>
              </span>
            </td>
            <td>
              <span class="sap-prio" style="background:<?= $hexPrio ?>">
                <?= e($t['priority_name']) ?>
              </span>
            </td>
            <td>
              <span class="sap-status is-<?= e($tone) ?>">
                <i class="bi bi-<?= e($icon) ?>"></i> <?= e($label) ?>
              </span>
            </td>
            <td>
              <small class="text-muted"><?= e(date('Y-m-d H:i', strtotime($t['created_at']))) ?></small>
            </td>
            <td style="text-align:right;">
              <a class="sap-btn sap-btn-icon"
                 title="Open ticket"
                 href="<?= BASE_URL ?>/admin/ticket_view.php?id=<?= (int)$t['id'] ?>">
                <i class="bi bi-chevron-right"></i>
              </a>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<script>
/* DataTables — sorting + pagination only; search & filters are handled server-side */
document.addEventListener('DOMContentLoaded', function () {
  if (window.jQuery && $.fn.dataTable && document.getElementById('allTickets')) {
    const $t = jQuery('#allTickets');
    if (!$.fn.dataTable.isDataTable($t)) {
      $t.DataTable({
        paging: true,
        pageLength: 25,
        lengthChange: false,
        searching: false,
        info: true,
        order: [],
        columnDefs: [
          { orderable: false, targets: [0, 1, 2, 7, 8] }   // disable sort on #, subject, requester, created, actions
        ],
        language: {
          info: 'Showing _START_ to _END_ of _TOTAL_ tickets',
          infoEmpty: 'No tickets to show',
          infoFiltered: '',
          zeroRecords: 'No matching tickets',
          paginate: { previous: '‹', next: '›' },
          emptyTable: 'No tickets yet'
        }
      });
    }
  }
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
