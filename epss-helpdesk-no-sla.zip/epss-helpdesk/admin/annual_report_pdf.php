<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/annual_report.php';

$u = require_role('ADMIN');

$ecYear = (int)($_GET['year'] ?? annual_ec_current_year());
if ($ecYear < 2010 || $ecYear > 2100) {
    $ecYear = annual_ec_current_year();
}

/* ---------- Load Dompdf (Composer or manual) ---------- */
$dompdfLoaded = false;
if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require_once __DIR__ . '/../vendor/autoload.php';
    $dompdfLoaded = class_exists('Dompdf\Dompdf');
} elseif (file_exists(__DIR__ . '/../vendor/dompdf/autoload.inc.php')) {
    require_once __DIR__ . '/../vendor/dompdf/autoload.inc.php';
    $dompdfLoaded = class_exists('Dompdf\Dompdf');
}

if (!$dompdfLoaded) {
    app_fail('E-RPT-501');
}

$narr   = annual_report_values($ecYear);
$report = annual_report_data($ecYear, $narr);
$slides = annual_report_slide_html($report);

/* Mark the final slide so Dompdf does not append a blank page after it. */
$lastPos = strrpos($slides, '<section class="slide"');
if ($lastPos !== false) {
    $slides = substr_replace(
        $slides,
        '<section class="slide slide-last"',
        $lastPos,
        strlen('<section class="slide"')
    );
}

$content = '<!DOCTYPE html>
<html><head><meta charset="UTF-8">
<style>
  /* =================================================================
   * Page geometry
   * A4 landscape = 297mm × 210mm.
   * Dompdf width/height exclude padding, so each slide sets:
   *   width  = 297mm - (20mm + 20mm) = 257mm
   *   height = 210mm - (14mm + 18mm) = 178mm
   * ================================================================= */
  @page { size: A4 landscape; margin: 0; }
  html, body { margin: 0; padding: 0; }
  body {
    font-family: "DejaVu Sans", sans-serif;
    font-size: 10.5pt;
    color: #1d2d3e;
    background: #ffffff;
  }

  .slide {
    position: relative;
    width: 257mm;
    height: 178mm;
    padding: 14mm 20mm 18mm;
    background: #ffffff;
    page-break-after: always;
    overflow: hidden;
    border-top: 1.6mm solid #0070f2;
  }
  .slide-last { page-break-after: avoid; }

  /* Decorative left accent bar on content slides */
  .slide::before {
    content: '';
    position: absolute;
    top: 0; left: 0;
    width: 1.6mm;
    height: 100%;
    background: #0070f2;
  }

  /* ---------- COVER ---------- */
  .slide-cover {
    background: #0a2a5e;
    background-image: linear-gradient(135deg, #0a2a5e 0%, #123a77 60%, #1a4a90 100%);
    color: #ffffff;
    width: 249mm;
    height: 167mm;
    padding: 24mm 24mm 22mm;
    border-top: 0;
  }
  .slide-cover::before { display: none; }

  /* Diagonal accent ribbon at the top of the cover */
  .slide-cover::after {
    content: '';
    position: absolute;
    top: 0; right: 0;
    width: 60mm;
    height: 60mm;
    background: linear-gradient(135deg, transparent 50%, #ffd166 50%);
    opacity: .15;
  }

  .cover-kicker {
    font-size: 9pt;
    letter-spacing: 3pt;
    text-transform: uppercase;
    color: #9fc3ff;
    font-weight: bold;
  }
  .cover-title {
    font-size: 44pt;
    font-weight: bold;
    line-height: 1.02;
    margin: 10mm 0 0;
    color: #ffffff;
    letter-spacing: -0.5pt;
  }
  .cover-year {
    font-size: 30pt;
    font-weight: bold;
    color: #ffd166;
    margin-top: 4mm;
    letter-spacing: 0.5pt;
  }
  .cover-branch {
    font-size: 13pt;
    color: #dbe7f7;
    margin-top: 3mm;
    letter-spacing: .5pt;
  }
  .cover-divider {
    width: 40mm;
    height: 1mm;
    background: #ffd166;
    margin: 12mm 0 0;
  }
  .cover-meta {
    position: absolute;
    left: 24mm;
    right: 24mm;
    bottom: 18mm;
    width: 249mm;
    border-collapse: collapse;
    border-top: 1px solid #3c5f92;
  }
  .cover-meta td {
    width: 50%;
    vertical-align: top;
    padding-top: 5mm;
  }
  .cover-meta span {
    display: block;
    font-size: 7pt;
    letter-spacing: 1.8pt;
    text-transform: uppercase;
    color: #9fc3ff;
    margin-bottom: 1.8mm;
  }
  .cover-meta strong {
    font-size: 11.5pt;
    font-weight: normal;
    color: #ffffff;
  }

  /* ---------- CONTENT SLIDES ---------- */
  .slide-eyebrow {
    font-size: 8pt;
    letter-spacing: 2pt;
    text-transform: uppercase;
    color: #0070f2;
    font-weight: bold;
  }
  h2 {
    font-size: 22pt;
    font-weight: bold;
    color: #0a2a5e;
    margin: 2.5mm 0 9mm;
    padding-left: 4.5mm;
    border-left: 1.6mm solid #0070f2;
    line-height: 1.15;
    letter-spacing: -0.2pt;
  }

  .slide-list {
    margin: 0;
    padding-left: 6mm;
  }
  .slide-list li {
    font-size: 10.5pt;
    line-height: 1.62;
    margin-bottom: 2.8mm;
  }
  .slide-list li::marker {
    color: #0070f2;
    font-weight: bold;
  }

  .slide-caption {
    font-size: 9pt;
    color: #556b82;
    margin-top: 6mm;
    line-height: 1.45;
  }

  .slide-foot {
    position: absolute;
    left: 20mm;
    right: 20mm;
    bottom: 8mm;
    border-top: 1px solid #eaecf0;
    padding-top: 2.5mm;
    font-size: 7.5pt;
    color: #7a8ba0;
    letter-spacing: .3pt;
  }

  /* ---------- DEPARTMENTS GRID ---------- */
  .dept-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 2mm;
  }
  .dept-table td {
    width: 50%;
    padding: 3.6mm 4.5mm;
    font-size: 10.5pt;
    border-bottom: 1px solid #eaecf0;
    color: #1d2d3e;
  }
  .dept-table tr:nth-child(odd) td {
    background: #f8fafc;
  }

  /* ---------- KPI CARDS ---------- */
  .kpi-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 4mm;
    margin-top: 1mm;
  }
  .kpi-card {
    width: 50%;
    background: #f5f8fc;
    border-left: 1.4mm solid #0070f2;
    padding: 5.5mm 6.5mm;
    vertical-align: top;
    border-radius: 1mm;
  }
  .kpi-value {
    font-size: 26pt;
    font-weight: bold;
    color: #0057d2;
    line-height: 1;
    letter-spacing: -0.5pt;
  }
  .kpi-label {
    font-size: 9.5pt;
    font-weight: bold;
    margin-top: 2.5mm;
    line-height: 1.35;
    color: #0a2a5e;
  }
  .kpi-note {
    font-size: 8pt;
    color: #556b82;
    margin-top: 2mm;
    line-height: 1.45;
  }
  .kpi-badge-met {
    display: inline-block;
    margin-top: 1.5mm;
    font-size: 7pt;
    font-weight: bold;
    letter-spacing: 1pt;
    color: #1d5d2e;
    background: #eafaf1;
    border: 1px solid #b8e6c9;
    padding: .8mm 2.2mm;
    border-radius: 1.5mm;
  }
  .kpi-badge-miss {
    display: inline-block;
    margin-top: 1.5mm;
    font-size: 7pt;
    font-weight: bold;
    letter-spacing: 1pt;
    color: #8a0606;
    background: #fdecec;
    border: 1px solid #f4bcbc;
    padding: .8mm 2.2mm;
    border-radius: 1.5mm;
  }

  /* ---------- STAT STRIP ---------- */
  .stat-strip {
    width: 100%;
    border-collapse: separate;
    border-spacing: 3mm 0;
    margin-bottom: 8mm;
  }
  .stat-strip td {
    width: 25%;
    background: #eaf4ff;
    text-align: center;
    padding: 4mm 2mm;
    border-radius: 1mm;
    border-bottom: 1mm solid #0070f2;
  }
  .stat-strip strong {
    display: block;
    font-size: 17pt;
    color: #0057d2;
    line-height: 1;
    letter-spacing: -0.3pt;
  }
  .stat-strip span {
    display: block;
    font-size: 7pt;
    color: #556b82;
    margin-top: 1.8mm;
    text-transform: uppercase;
    letter-spacing: 1pt;
    font-weight: bold;
  }

  /* ---------- CLOSING ---------- */
  .closing-line {
    margin-top: 7mm;
    padding-top: 3mm;
    font-size: 9.5pt;
    color: #0a2a5e;
    border-top: 1px solid #eaecf0;
    letter-spacing: .2pt;
  }
</style>
</head><body>'
    . $slides
    . '</body></html>';

$options = new \Dompdf\Options();
$options->set('isRemoteEnabled', false);
$options->set('isHtml5ParserEnabled', true);
$options->set('defaultFont', 'DejaVu Sans');
$options->set('chroot', __DIR__ . '/..');

$dompdf = new \Dompdf\Dompdf($options);
$dompdf->loadHtml($content, 'UTF-8');
$dompdf->setPaper('A4', 'landscape');

try {
    $dompdf->render();
} catch (\Throwable $ex) {
    while (ob_get_level() > 0) { ob_end_clean(); }
    app_fail('E-RPT-500', '', $ex);      // logged with a reference; no raw message shown
}

$filename = 'EPSS_ICT_Annual_Report_' . $ecYear . '_EC.pdf';
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . $filename . '"');
$dompdf->stream($filename, ['Attachment' => true]);
exit;