<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('ADMIN');
$pageTitle = 'Error Codes';

/* ---------- Data ---------- */
$areas    = app_error_areas();
$registry = app_error_registry();
$q        = trim((string)($_GET['q'] ?? ''));
$area     = (string)($_GET['area'] ?? '');

$log = app_error_log_tail(300);
if ($q !== '') {
    $log = array_values(array_filter($log, static function (array $r) use ($q): bool {
        foreach (['ref', 'code', 'url', 'detail', 'msg', 'exc'] as $k) {
            if (isset($r[$k]) && stripos((string)$r[$k], $q) !== false) { return true; }
        }
        return false;
    }));
}

$logCount   = count($log);
$todayCount = 0;
foreach ($log as $r) {
    if (substr((string)($r['t'] ?? ''), 0, 10) === date('Y-m-d')) { $todayCount++; }
}

/* Registry grouped by area, optionally filtered */
$grouped = [];
foreach ($registry as $code => [$http, $title, $message, $hint]) {
    $a = explode('-', $code)[1] ?? 'SYS';
    if ($area !== '' && $a !== $area) { continue; }
    /* typing a code (E-TKT-409) narrows the reference list; a reference or URL search leaves it alone */
    if (stripos($q, 'E-') === 0 && stripos($code, $q) === false) { continue; }
    $grouped[$a][] = [$code, $http, $title, $message, $hint];
}

include __DIR__ . '/../includes/header.php';
?>
<style>
  :root {
    --sap-brand:#0070f2; --sap-brand-dark:#0057d2; --sap-bg:#f5f6f7; --sap-tile:#fff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82; --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500; --sap-negative:#aa0808; --sap-neutral:#5b738b;
    --sap-shadow:0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
  }
  body, .main-content { background:var(--sap-bg) !important; font-family:"72","72full",Arial,Helvetica,sans-serif !important; color:var(--sap-text); }
  .sap-page-title { font-size:1.625rem; font-weight:400; margin:0; }
  .sap-breadcrumb { font-size:.8125rem; color:var(--sap-text-muted); margin-bottom:.25rem; }
  .sap-card { background:var(--sap-tile); border-radius:.75rem; box-shadow:var(--sap-shadow); overflow:hidden; margin-bottom:1rem; }
  .sap-card-header { padding:.75rem 1.15rem; border-bottom:1px solid var(--sap-border-soft); font-size:.875rem; font-weight:600;
    display:flex; justify-content:space-between; align-items:center; gap:.5rem; flex-wrap:wrap; }
  .sap-tile { background:var(--sap-tile); border-radius:.75rem; box-shadow:var(--sap-shadow); padding:1rem 1.15rem; height:100%; }
  .sap-tile-head { font-size:.72rem; text-transform:uppercase; letter-spacing:.04em; color:var(--sap-text-muted); font-weight:600; }
  .sap-tile-value { font-family:"72Mono","Courier New",monospace; font-size:1.9rem; font-weight:600; line-height:1.1; }
  .sap-filter { display:flex; gap:.5rem; flex-wrap:wrap; align-items:center; background:var(--sap-tile); border-radius:.75rem;
    box-shadow:var(--sap-shadow); padding:.85rem 1rem; margin-bottom:1rem; }
  .sap-filter input, .sap-filter select { font-size:.8125rem; padding:.5rem .7rem; border-radius:.5rem; border:1px solid var(--sap-border); font-family:inherit; }
  .sap-filter input { flex:1 1 260px; }
  .sap-btn { display:inline-flex; align-items:center; gap:.35rem; font-size:.8125rem; font-weight:500; border-radius:.5rem; padding:.5rem .9rem;
    border:1px solid var(--sap-brand); background:var(--sap-brand); color:#fff; cursor:pointer; text-decoration:none; }
  .sap-btn.is-plain { background:#fff; color:var(--sap-brand); }
  table.sap-table { width:100%; border-collapse:separate; border-spacing:0; font-size:.8125rem; }
  table.sap-table thead th { background:#f5f6f7; border-bottom:1px solid var(--sap-border); font-weight:600; color:var(--sap-text-muted);
    text-align:left; padding:.6rem .75rem; text-transform:uppercase; font-size:.68rem; letter-spacing:.04em; white-space:nowrap; }
  table.sap-table tbody td { padding:.6rem .75rem; border-bottom:1px solid var(--sap-border-soft); vertical-align:top; }
  table.sap-table tbody tr:last-child td { border-bottom:0; }
  .ec-code { font-family:"72Mono","Courier New",monospace; font-weight:600; font-size:.78rem; padding:.15rem .55rem; border-radius:.6rem;
    white-space:nowrap; display:inline-block; }
  .ec-4 { background:#fff8f1; color:#e76500; border:1px solid #fbe0c8; }
  .ec-5 { background:#fef4f4; color:#aa0808; border:1px solid #f7d2d2; }
  .ec-muted { color:var(--sap-text-muted); font-size:.75rem; }
  .ec-mono { font-family:"72Mono","Courier New",monospace; font-size:.74rem; word-break:break-all; }
  .sap-empty { text-align:center; padding:2rem 1rem; color:var(--sap-text-muted); }
  .scroll-x { overflow-x:auto; }
</style>

<div class="mb-3">
  <div class="sap-breadcrumb"><i class="bi bi-house-door"></i> Home / Administration / <strong>Error Codes</strong></div>
  <h1 class="sap-page-title">Error Codes</h1>
  <div class="ec-muted mt-1">
    Every error the helpdesk shows carries a code <code>E-AREA-NNN</code>. Users quote the code (and the reference, for system faults);
    this page tells you what it means and where the details are logged.
  </div>
</div>

<div class="row g-3 mb-3">
  <div class="col-6 col-md-3"><div class="sap-tile"><div class="sap-tile-head">Registered codes</div><div class="sap-tile-value"><?= count($registry) ?></div></div></div>
  <div class="col-6 col-md-3"><div class="sap-tile"><div class="sap-tile-head">Logged errors<?= $q !== '' ? ' (filtered)' : '' ?></div><div class="sap-tile-value"><?= (int)$logCount ?></div></div></div>
  <div class="col-6 col-md-3"><div class="sap-tile"><div class="sap-tile-head">Logged today</div><div class="sap-tile-value"><?= (int)$todayCount ?></div></div></div>
  <div class="col-6 col-md-3"><div class="sap-tile"><div class="sap-tile-head">Log file</div>
    <div class="ec-mono" style="margin-top:.4rem">logs/app_errors.log</div>
    <div class="ec-muted"><?= is_file(app_error_log_file()) ? e(number_format((int)@filesize(app_error_log_file()) / 1024, 1)) . ' KB' : 'not created yet' ?></div>
  </div></div>
</div>

<form method="get" class="sap-filter">
  <input type="text" name="q" value="<?= e($q) ?>" placeholder="Search a reference (R261110-143502-A3F9), a code, a URL or text…">
  <select name="area">
    <option value="">All areas</option>
    <?php foreach ($areas as $key => $label): ?>
      <option value="<?= e($key) ?>" <?= $area === $key ? 'selected' : '' ?>><?= e($key . ' - ' . $label) ?></option>
    <?php endforeach; ?>
  </select>
  <button class="sap-btn"><i class="bi bi-search"></i> Search</button>
  <?php if ($q !== '' || $area !== ''): ?><a class="sap-btn is-plain" href="error_codes.php">Reset</a><?php endif; ?>
</form>

<!-- ================= Recent logged errors ================= -->
<div class="sap-card">
  <div class="sap-card-header"><span><i class="bi bi-bug"></i> Recent logged errors</span><span class="ec-muted">newest first, last 300</span></div>
  <?php if (!$log): ?>
    <div class="sap-empty"><i class="bi bi-check-circle" style="font-size:1.8rem;opacity:.4;display:block"></i>
      <?= $q !== '' ? 'No logged error matches your search.' : 'No system errors have been logged. Only faults on the server side (database, files, unexpected exceptions) are written here.' ?></div>
  <?php else: ?>
    <div class="scroll-x">
      <table class="sap-table">
        <thead><tr><th>When</th><th>Reference</th><th>Code</th><th>User</th><th>Page</th><th>Detail</th></tr></thead>
        <tbody>
        <?php foreach ($log as $r):
            $code = (string)($r['code'] ?? '');
            $def  = app_error_def($code);
        ?>
          <tr>
            <td class="ec-muted" style="white-space:nowrap"><?= e($r['t'] ?? '') ?></td>
            <td class="ec-mono"><?= e($r['ref'] ?? '') ?></td>
            <td><span class="ec-code <?= $def['http'] >= 500 ? 'ec-5' : 'ec-4' ?>" title="<?= e($def['title']) ?>"><?= e($code) ?></span></td>
            <td class="ec-muted"><?= !empty($r['user']) ? '#' . (int)$r['user'] . ' ' . e($r['role'] ?? '') : '-' ?></td>
            <td class="ec-mono"><?= e($r['url'] ?? '') ?></td>
            <td>
              <?php if (!empty($r['detail'])): ?><div><?= e($r['detail']) ?></div><?php endif; ?>
              <?php if (!empty($r['msg'])): ?><div class="ec-mono ec-muted"><?= e(($r['exc'] ?? '') . ': ' . $r['msg']) ?></div><?php endif; ?>
              <?php if (!empty($r['where'])): ?><div class="ec-muted">at <?= e($r['where']) ?></div><?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<!-- ================= Registry ================= -->
<?php foreach ($grouped as $a => $rows): ?>
  <div class="sap-card">
    <div class="sap-card-header"><span><i class="bi bi-tag"></i> <?= e($a) ?> &mdash; <?= e($areas[$a] ?? $a) ?></span><span class="ec-muted"><?= count($rows) ?> code(s)</span></div>
    <div class="scroll-x">
      <table class="sap-table">
        <thead><tr><th>Code</th><th>HTTP</th><th>Meaning</th><th>Shown to the user</th><th>What to do</th></tr></thead>
        <tbody>
        <?php foreach ($rows as [$code, $http, $title, $message, $hint]): ?>
          <tr>
            <td><span class="ec-code <?= $http >= 500 ? 'ec-5' : 'ec-4' ?>"><?= e($code) ?></span></td>
            <td class="ec-mono"><?= (int)$http ?></td>
            <td><strong><?= e($title) ?></strong><?= $http >= 500 ? '<div class="ec-muted">logged with a reference</div>' : '' ?></td>
            <td><?= e($message) ?></td>
            <td class="ec-muted"><?= e($hint) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php endforeach; ?>
<?php if (!$grouped): ?>
  <div class="sap-card"><div class="sap-empty">No code matches that area.</div></div>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
