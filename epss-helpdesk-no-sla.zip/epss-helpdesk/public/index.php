<?php
require_once __DIR__ . '/../includes/auth.php';
$u = require_login();

$routes = [
    'ADMIN'          => BASE_URL . '/admin/dashboard.php',
    'BRANCH_MANAGER' => BASE_URL . '/teamleader/dashboard.php',  // same as TL
    'TEAM_LEADER'    => BASE_URL . '/teamleader/dashboard.php',
    'ICT_STAFF'      => BASE_URL . '/ict/dashboard.php',
    'EMPLOYEE'       => BASE_URL . '/employee/dashboard.php',
];

header('Location: ' . ($routes[$u['role']] ?? BASE_URL . '/public/login.php'));
exit;
