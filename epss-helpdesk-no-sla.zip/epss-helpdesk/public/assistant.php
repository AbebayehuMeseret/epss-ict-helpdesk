<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_login();
$pageTitle = 'ICT Assistant';
include __DIR__ . '/../includes/header.php';
?>

<style>
  .ai-shell {
    display: flex; flex-direction: column;
    height: calc(100vh - 200px); min-height: 520px;
    background: #fff; border-radius: .75rem; overflow: hidden;
    box-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
  }
  .ai-head {
    padding: 1rem 1.25rem; border-bottom: 1px solid #eaecf0;
    display: flex; align-items: center; gap: .75rem;
  }
  .ai-head .ai-avatar {
    width: 42px; height: 42px; border-radius: 50%;
    background: linear-gradient(135deg,#0070f2,#0057d2);
    color: #fff; display: inline-flex; align-items: center; justify-content: center;
    font-size: 1.2rem;
  }
  .ai-head-title { font-weight: 600; font-size: 1rem; color: #1d2d3e; }
  .ai-head-sub   { font-size: .78rem; color: #556b82; }
  .ai-head-pill  { margin-left: auto; font-size: .72rem; font-weight: 600;
    padding: .25rem .65rem; border-radius: 1rem;
    background: #f1fdf6; color: #256f3a; border: 1px solid #d6f0e0; }

  .ai-body {
    flex: 1; overflow-y: auto; padding: 1.25rem;
    background: #f5f6f7;
    display: flex; flex-direction: column; gap: .85rem;
  }
  .ai-msg { max-width: 78%; }
  .ai-msg.in  { align-self: flex-start; }
  .ai-msg.out { align-self: flex-end; }
  .ai-bubble {
    padding: .7rem 1rem; border-radius: 1rem; font-size: .875rem; line-height: 1.55;
    white-space: pre-wrap; word-wrap: break-word;
  }
  .ai-msg.in  .ai-bubble { background: #fff; color: #1d2d3e;
    box-shadow: 0 1px 3px rgba(0,0,0,.06); border-bottom-left-radius: .25rem; }
  .ai-msg.out .ai-bubble { background: #0070f2; color: #fff;
    border-bottom-right-radius: .25rem; }
  .ai-meta { font-size: .68rem; color: #8899aa; margin-top: .25rem; }
  .ai-msg.in  .ai-meta { text-align: left; }
  .ai-msg.out .ai-meta { text-align: right; }

  .ai-source {
    display: inline-block; margin-top: .35rem;
    font-size: .68rem; font-weight: 600;
    padding: .1rem .5rem; border-radius: .5rem;
    background: #eaf4ff; color: #0070f2; border: 1px solid #cfe2f8;
  }
  .ai-source.is-llm { background: #f0e6ff; color: #5b21b6; border-color: #ddd0f5; }

  .ai-feedback { display: flex; gap: .4rem; margin-top: .4rem; }
  .ai-feedback button {
    border: 1px solid #cfe2f8; background: #fff; color: #0070f2;
    padding: .2rem .55rem; border-radius: .35rem; font-size: .72rem; cursor: pointer;
  }
  .ai-feedback button:hover { background: #eaf4ff; }

  .ai-suggestions {
    display: flex; gap: .4rem; flex-wrap: wrap;
    padding: 0 1.25rem 1rem;
    background: #f5f6f7;
  }
  .ai-suggestions button {
    border: 1px solid #cfe2f8; background: #fff; color: #0070f2;
    padding: .35rem .75rem; border-radius: 1rem; font-size: .78rem; cursor: pointer;
  }
  .ai-suggestions button:hover { background: #eaf4ff; }

  .ai-foot {
    border-top: 1px solid #eaecf0; padding: .75rem; display: flex; gap: .5rem; background: #fff;
  }
  .ai-foot textarea {
    resize: none; height: 44px; flex: 1; border: 1px solid #d9d9d9;
    border-radius: .5rem; padding: .55rem .75rem; font-size: .875rem; outline: none;
    font-family: inherit;
  }
  .ai-foot textarea:focus { border-color: #0070f2; box-shadow: 0 0 0 3px rgba(0,112,242,.15); }
  .ai-foot button {
    background: #0070f2; color: #fff; border: 0; padding: 0 1.1rem;
    border-radius: .5rem; font-weight: 600; cursor: pointer;
  }
  .ai-foot button:hover { background: #0057d2; }
  .ai-foot button:disabled { opacity: .5; cursor: not-allowed; }

  .ai-typing { color: #8899aa; font-style: italic; font-size: .8rem; }
</style>

<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <div style="font-size:.8125rem;color:#556b82;margin-bottom:.25rem">
      <i class="bi bi-house-door"></i> Home / <strong>ICT Assistant</strong>
    </div>
    <h4 class="mb-0">ICT Assistant</h4>
  </div>
</div>

<div class="ai-shell">
  <div class="ai-head">
    <div class="ai-avatar"><i class="bi bi-robot"></i></div>
    <div>
      <div class="ai-head-title">EPSS ICT Assistant</div>
      <div class="ai-head-sub">Ask about hardware, software, network, or system issues</div>
    </div>
    <span class="ai-head-pill"><i class="bi bi-circle-fill" style="font-size:.5rem"></i> Online</span>
  </div>

  <div class="ai-body" id="aiBody">
    <div class="ai-msg in">
      <div class="ai-bubble">👋 Hello! I'm the EPSS ICT Assistant.

Describe your ICT problem in plain words — for example:
• "My printer is not printing"
• "Wi-Fi keeps dropping"
• "Outlook not sending email"
• "SAP login failing"

If I can't solve it, you can create a ticket right after.</div>
      <div class="ai-meta">Assistant · now</div>
    </div>
  </div>

  <div class="ai-suggestions" id="aiSuggestions">
    <button data-q="Printer not printing">Printer not printing</button>
    <button data-q="No internet connection">No internet</button>
    <button data-q="Wi-Fi keeps dropping">Wi-Fi dropping</button>
    <button data-q="Outlook not sending email">Outlook email</button>
    <button data-q="Computer very slow">Computer slow</button>
    <button data-q="SAP login failing">SAP login</button>
    <button data-q="Keyboard not working">Keyboard issue</button>
    <button data-q="Cannot access shared drive">Shared drive</button>
  </div>

  <form class="ai-foot" id="aiForm" autocomplete="off">
    <textarea id="aiInput" placeholder="Type your ICT problem… (Enter to send, Shift+Enter for newline)" required></textarea>
    <button type="submit" id="aiSend"><i class="bi bi-send"></i></button>
  </form>
</div>

<script>
const AI_CSRF = <?= json_encode(csrf_token()) ?>;
const AI_BASE = <?= json_encode(BASE_URL) ?>;
let lastConversationId = null;

function scrollBottom() {
  const b = document.getElementById('aiBody');
  b.scrollTop = b.scrollHeight;
}

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c =>
    ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function addUser(text) {
  const body = document.getElementById('aiBody');
  const div = document.createElement('div');
  div.className = 'ai-msg out';
  div.innerHTML = `<div class="ai-bubble">${esc(text)}</div>
                   <div class="ai-meta">You · ${new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</div>`;
  body.appendChild(div);
  scrollBottom();
}

function addAssistant(text, confidence, convId, source) {
  const body = document.getElementById('aiBody');
  const div = document.createElement('div');
  div.className = 'ai-msg in';

  const metaParts = [];
  metaParts.push('Assistant');
  if (confidence) metaParts.push(`confidence ${confidence}%`);
  metaParts.push(new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}));

  const sourceBadge = source === 'llm'
    ? '<span class="ai-source is-llm"><i class="bi bi-cpu"></i> AI</span>'
    : (source === 'knowledge_base' ? '<span class="ai-source"><i class="bi bi-journal-text"></i> Knowledge Base</span>' : '');

  const fb = convId ? `<div class="ai-feedback">
      <button data-cid="${convId}" data-helpful="1"><i class="bi bi-hand-thumbs-up"></i> Helpful</button>
      <button data-cid="${convId}" data-helpful="0"><i class="bi bi-hand-thumbs-down"></i> Not helpful</button>
    </div>` : '';

  div.innerHTML = `
    <div class="ai-bubble">${esc(text)}</div>
    <div class="ai-meta">${metaParts.join(' · ')} ${sourceBadge}</div>
    ${fb}`;
  body.appendChild(div);
  scrollBottom();
}

function addTyping() {
  const body = document.getElementById('aiBody');
  const div = document.createElement('div');
  div.className = 'ai-msg in';
  div.id = 'aiTyping';
  div.innerHTML = '<div class="ai-bubble ai-typing">Assistant is typing…</div>';
  body.appendChild(div);
  scrollBottom();
  return div;
}

async function ask(question) {
  addUser(question);
  const typing = addTyping();
  const sendBtn = document.getElementById('aiSend');
  sendBtn.disabled = true;

  const fd = new FormData();
  fd.append('csrf', AI_CSRF);
  fd.append('question', question);

  try {
    const r = await fetch(AI_BASE + '/api/ai.php?action=ask', {
      method: 'POST',
      body: fd,
      credentials: 'same-origin'
    });
    const d = await r.json();
    typing.remove();
    sendBtn.disabled = false;

    if (!d.ok) {
      addAssistant(d.error || 'Something went wrong.');
      return;
    }
    lastConversationId = d.conversation_id;
    addAssistant(d.answer, d.confidence, d.conversation_id, d.source);
  } catch (e) {
    typing.remove();
    sendBtn.disabled = false;
    addAssistant('Network error. Please try again.');
  }
}

document.getElementById('aiForm').addEventListener('submit', e => {
  e.preventDefault();
  const input = document.getElementById('aiInput');
  const q = input.value.trim();
  if (!q) return;
  input.value = '';
  input.style.height = '44px';
  ask(q);
});

document.getElementById('aiInput').addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    document.getElementById('aiForm').dispatchEvent(new Event('submit'));
  }
});

/* Auto-grow the textarea */
document.getElementById('aiInput').addEventListener('input', function () {
  this.style.height = '44px';
  this.style.height = Math.min(this.scrollHeight, 120) + 'px';
});

document.querySelectorAll('#aiSuggestions button').forEach(b => {
  b.addEventListener('click', () => ask(b.dataset.q));
});

document.getElementById('aiBody').addEventListener('click', async e => {
  const btn = e.target.closest('.ai-feedback button');
  if (!btn) return;
  const cid = btn.dataset.cid;
  const helpful = btn.dataset.helpful;
  const fd = new FormData();
  fd.append('csrf', AI_CSRF);
  fd.append('conversation_id', cid);
  fd.append('helpful', helpful);
  await fetch(AI_BASE + '/api/ai.php?action=feedback', {
    method: 'POST', body: fd, credentials: 'same-origin'
  });
  btn.parentElement.innerHTML = '<span style="color:#256f3a;font-size:.75rem">Thanks for your feedback ✔</span>';
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
