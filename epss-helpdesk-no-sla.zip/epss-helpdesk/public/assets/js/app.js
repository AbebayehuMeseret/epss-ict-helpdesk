document.addEventListener('DOMContentLoaded', () => {

  /* ---------- Mobile sidebar toggle ---------- */
  const toggle  = document.getElementById('sidebarToggle');
  const sidebar = document.getElementById('sidebar');
  if (toggle && sidebar) {
    toggle.addEventListener('click', () => sidebar.classList.toggle('show'));
  }

  /* ---------- DataTables ---------- */
  if (window.jQuery && $.fn.dataTable) {
    $('.dt, #usersTable, #auditTable, #allTickets, #myTickets, #teamTickets, #ictTickets, #reportTable')
      .each(function () {
        if (!$.fn.dataTable.isDataTable(this)) {
          $(this).DataTable({
            pageLength: 25,
            order: [],
            language: { search: 'Search:', lengthMenu: 'Show _MENU_ entries' }
          });
        }
      });
  }

  /* ---------- Auto-dismiss alerts ---------- */
  document.querySelectorAll('.alert-success, .alert-info').forEach(a => {
    setTimeout(() => a.classList.add('fade'), 4000);
    setTimeout(() => a.remove(), 4600);
  });

  /* ---------- Chart.js defaults ---------- */
  if (window.Chart) {
    Chart.defaults.font.family = "'Segoe UI', Tahoma, sans-serif";
    Chart.defaults.color = '#555';
  }

  /* ---------- Live chat unread badge polling (every 15s) ---------- */
  const BASE_URL = window.BASE_URL || '';
  if (BASE_URL) {
    const pollChatUnread = async () => {
      try {
        const r = await fetch(BASE_URL + '/api/chat.php?action=unread', { credentials: 'same-origin' });
        const d = await r.json();
        if (!d || !d.ok) return;
        const badge = document.getElementById('sidebarChatBadge');
        if (!badge) return;
        if (d.unread > 0) {
          badge.textContent = d.unread;
          badge.classList.remove('d-none');
        } else {
          badge.classList.add('d-none');
        }
      } catch (e) { /* silent */ }
    };
    pollChatUnread();
    setInterval(pollChatUnread, 15000);
  }
});
