<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_login();
$pageTitle = 'My Profile';
$pdo = db();

$id = (int)$u['id'];
$ok = ''; $error = '';

// ---- Telegram connect / disconnect ----
$tgLink = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tg_action']) && verify_csrf($_POST['csrf'] ?? null)) {
    try {
        require_once __DIR__ . '/../includes/telegram.php';
        if ($_POST['tg_action'] === 'connect') {
            $token = bin2hex(random_bytes(16));
            $pdo->prepare("UPDATE users SET telegram_link_token=? WHERE id=?")->execute([$token, $id]);
            $tgLink = 'https://t.me/' . rawurlencode(tg_setting('tg_bot_username')) . '?start=' . $token;
        } elseif ($_POST['tg_action'] === 'disconnect') {
            $pdo->prepare("UPDATE users SET telegram_chat_id=NULL, telegram_link_token=NULL WHERE id=?")->execute([$id]);
            $ok = 'Telegram disconnected.';
        }
    } catch (Throwable $e) { $error = app_exception_message($e); }
}

// ---- Handle profile update ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['tg_action']) && verify_csrf($_POST['csrf'] ?? null)) {
    try {
        $fullName = trim($_POST['full_name'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $phone    = trim($_POST['phone'] ?? '');
        $position = trim($_POST['position'] ?? '');

        if ($fullName === '') {
            throw new RuntimeException('Full name is required.');
        }
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException('Invalid email address.');
        }

        // Users may only edit their own contact fields — role, department,
        // team_leader_id, username, status are managed by an Admin.
        $pdo->prepare("UPDATE users SET full_name=?, email=?, phone=?, position=? WHERE id=?")
            ->execute([$fullName, $email ?: null, $phone ?: null, $position ?: null, $id]);

        audit('UpdateProfile', 'users', $id, 'User updated own profile');
        $ok = 'Profile updated successfully.';

        // Refresh the local $u so the page reflects the new values
        $u = current_user(); // current_user() has a static cache; see note below

    } catch (Throwable $e) {
        $error = app_exception_message($e);
    }
}

// ---- Load fresh row (bypasses the static cache in current_user()) ----
$stmt = $pdo->prepare("
    SELECT u.*, d.department_name, tl.full_name AS team_leader_name
    FROM users u
    LEFT JOIN departments d  ON d.id = u.department_id
    LEFT JOIN users tl       ON tl.id = u.team_leader_id
    WHERE u.id = ?
");
$stmt->execute([$id]);
$profile = $stmt->fetch();
if (!$profile) { app_fail('E-USR-404'); }

// ---- Stats (only meaningful for some roles, but harmless for all) ----
$stats = [
    'tickets_created'   => 0,
    'tickets_assigned'  => 0,
    'tickets_resolved'  => 0,
    'tickets_closed'    => 0,
];
if ($profile['role'] === 'EMPLOYEE') {
    $s = $pdo->prepare("SELECT COUNT(*) FROM tickets WHERE requester_id=?");
    $s->execute([$id]); $stats['tickets_created'] = (int)$s->fetchColumn();

    $s = $pdo->prepare("SELECT COUNT(*) FROM tickets WHERE requester_id=? AND status='CLOSED'");
    $s->execute([$id]); $stats['tickets_closed'] = (int)$s->fetchColumn();
} elseif ($profile['role'] === 'ICT_STAFF') {
    $s = $pdo->prepare("SELECT COUNT(*) FROM tickets WHERE assigned_technician_id=?");
    $s->execute([$id]); $stats['tickets_assigned'] = (int)$s->fetchColumn();

    $s = $pdo->prepare("SELECT COUNT(*) FROM tickets WHERE assigned_technician_id=? AND status='CLOSED'");
    $s->execute([$id]); $stats['tickets_resolved'] = (int)$s->fetchColumn();
} elseif ($profile['role'] === 'TEAM_LEADER') {
    $s = $pdo->prepare("SELECT COUNT(*) FROM tickets WHERE team_leader_id=?");
    $s->execute([$id]); $stats['tickets_created'] = (int)$s->fetchColumn();

    $s = $pdo->prepare("SELECT COUNT(*) FROM tickets WHERE team_leader_id=? AND status='CLOSED'");
    $s->execute([$id]); $stats['tickets_closed'] = (int)$s->fetchColumn();
}

include __DIR__ . '/../includes/header.php';
?>
<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb">
      <i class="bi bi-house-door"></i> Home / <strong>My Profile</strong>
    </div>
    <h1 class="sap-page-title">My Profile</h1>
  </div>
</div>

<?php if ($error): ?>
  <div class="alert alert-danger"><?= e($error) ?></div>
<?php endif; ?>
<?php if ($ok): ?>
  <div class="alert alert-success"><?= e($ok) ?></div>
<?php endif; ?>

<div class="row g-3">

  <!-- LEFT: identity card + stats -->
  <div class="col-lg-4">
    <div class="card mb-3">
      <div class="card-body text-center">
        <div class="avatar-circle mx-auto mb-3"
             style="width:88px;height:88px;font-size:2.2rem;">
          <?= e(strtoupper(mb_substr($profile['full_name'], 0, 1))) ?>
        </div>
        <h5 class="mb-1"><?= e($profile['full_name']) ?></h5>
        <div class="text-muted small mb-2">
          <?= e($profile['position'] ?: ucwords(strtolower(str_replace('_',' ', $profile['role'])))) ?>
        </div>
        <span class="badge bg-primary">
          <?= e(str_replace('_',' ', $profile['role'])) ?>
        </span>
        <?php if ($profile['status'] !== 'ACTIVE'): ?>
          <span class="badge bg-secondary ms-1"><?= e($profile['status']) ?></span>
        <?php endif; ?>

        <hr>

        <div class="text-start small">
          <div class="d-flex justify-content-between mb-1">
            <span class="text-muted">Username</span>
            <strong><?= e($profile['username']) ?></strong>
          </div>
          <div class="d-flex justify-content-between mb-1">
            <span class="text-muted">Employee ID</span>
            <strong><?= e($profile['employee_id'] ?? '—') ?></strong>
          </div>
          <div class="d-flex justify-content-between mb-1">
            <span class="text-muted">Department</span>
            <strong><?= e($profile['department_name'] ?? '—') ?></strong>
          </div>
          <?php if ($profile['role'] === 'EMPLOYEE'): ?>
            <div class="d-flex justify-content-between mb-1">
              <span class="text-muted">Team Leader</span>
              <strong><?= e($profile['team_leader_name'] ?? '—') ?></strong>
            </div>
          <?php endif; ?>
          <div class="d-flex justify-content-between mb-1">
            <span class="text-muted">Last Login</span>
            <strong><?= $profile['last_login'] ? e(date('Y-m-d H:i', strtotime($profile['last_login']))) : '—' ?></strong>
          </div>
          <div class="d-flex justify-content-between">
            <span class="text-muted">Member Since</span>
            <strong><?= e(date('Y-m-d', strtotime($profile['created_at']))) ?></strong>
          </div>
        </div>

        <hr>
        <a href="<?= BASE_URL ?>/public/change_password.php" class="btn btn-outline-primary btn-sm w-100">
          <i class="bi bi-key"></i> Change Password
        </a>
      </div>
    </div>

    <?php if (in_array($profile['role'], ['TEAM_LEADER','ICT_STAFF'], true)): ?>
      <div class="card mb-3">
        <div class="card-header"><i class="bi bi-telegram"></i> Telegram Notifications</div>
        <div class="card-body">
          <?php if (!empty($profile['telegram_chat_id'])): ?>
            <p class="text-success mb-2"><i class="bi bi-check-circle"></i> Connected</p>
            <form method="post">
              <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tg_action" value="disconnect">
              <button class="btn btn-sm btn-outline-danger">Disconnect</button>
            </form>
          <?php elseif ($tgLink): ?>
            <p class="mb-2">Open this link in Telegram, then press <strong>Start</strong>:</p>
            <a class="btn btn-sm btn-primary" href="<?= e($tgLink) ?>" target="_blank" rel="noopener">
              <i class="bi bi-telegram"></i> Open Telegram
            </a>
            <p class="text-muted small mt-2 mb-0">Refresh this page afterwards to confirm.</p>
          <?php else: ?>
            <p class="text-muted small">
              <?= $profile['role'] === 'TEAM_LEADER'
                    ? 'Get a message when someone in your team submits a ticket.'
                    : 'Get a message when a Team Leader approves a ticket for ICT.' ?>
            </p>
            <form method="post">
              <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="tg_action" value="connect">
              <button class="btn btn-sm btn-primary"><i class="bi bi-telegram"></i> Connect Telegram</button>
            </form>
          <?php endif; ?>
        </div>
      </div>
    <?php endif; ?>

    <?php if (array_sum($stats) > 0): ?>
      <div class="card">
        <div class="card-header"><i class="bi bi-bar-chart"></i> Activity</div>
        <div class="card-body">
          <?php if ($profile['role'] === 'EMPLOYEE'): ?>
            <div class="d-flex justify-content-between mb-2">
              <span class="text-muted">Tickets Created</span>
              <strong><?= number_format($stats['tickets_created']) ?></strong>
            </div>
            <div class="d-flex justify-content-between">
              <span class="text-muted">Tickets Closed</span>
              <strong><?= number_format($stats['tickets_closed']) ?></strong>
            </div>
          <?php elseif ($profile['role'] === 'ICT_STAFF'): ?>
            <div class="d-flex justify-content-between mb-2">
              <span class="text-muted">Tickets Assigned</span>
              <strong><?= number_format($stats['tickets_assigned']) ?></strong>
            </div>
            <div class="d-flex justify-content-between">
              <span class="text-muted">Tickets Resolved</span>
              <strong><?= number_format($stats['tickets_resolved']) ?></strong>
            </div>
          <?php elseif ($profile['role'] === 'TEAM_LEADER'): ?>
            <div class="d-flex justify-content-between mb-2">
              <span class="text-muted">Team Tickets</span>
              <strong><?= number_format($stats['tickets_created']) ?></strong>
            </div>
            <div class="d-flex justify-content-between">
              <span class="text-muted">Closed</span>
              <strong><?= number_format($stats['tickets_closed']) ?></strong>
            </div>
          <?php endif; ?>
        </div>
      </div>
    <?php endif; ?>
  </div>

  <!-- RIGHT: edit form -->
  <div class="col-lg-8">
    <div class="card">
      <div class="card-header">
        <i class="bi bi-pencil-square"></i> Edit Profile
      </div>
      <div class="card-body">
        <form method="post" autocomplete="off">
          <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">

          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Full Name *</label>
              <input type="text" name="full_name" class="form-control" required
                     value="<?= e($profile['full_name']) ?>">
            </div>

            <div class="col-md-6">
              <label class="form-label">Position</label>
              <input type="text" name="position" class="form-control"
                     value="<?= e($profile['position'] ?? '') ?>">
            </div>

            <div class="col-md-6">
              <label class="form-label">Email</label>
              <input type="email" name="email" class="form-control"
                     value="<?= e($profile['email'] ?? '') ?>">
              <small class="text-muted">Used for password resets and notifications.</small>
            </div>

            <div class="col-md-6">
              <label class="form-label">Phone</label>
              <input type="text" name="phone" class="form-control"
                     value="<?= e($profile['phone'] ?? '') ?>">
            </div>

            <div class="col-md-6">
              <label class="form-label">Username</label>
              <input type="text" class="form-control" value="<?= e($profile['username']) ?>" disabled>
              <small class="text-muted">Managed by the administrator.</small>
            </div>

            <div class="col-md-6">
              <label class="form-label">Role</label>
              <input type="text" class="form-control"
                     value="<?= e(str_replace('_',' ', $profile['role'])) ?>" disabled>
              <small class="text-muted">Managed by the administrator.</small>
            </div>

            <div class="col-md-6">
              <label class="form-label">Department</label>
              <input type="text" class="form-control"
                     value="<?= e($profile['department_name'] ?? '—') ?>" disabled>
            </div>

            <?php if ($profile['role'] === 'EMPLOYEE'): ?>
              <div class="col-md-6">
                <label class="form-label">Team Leader</label>
                <input type="text" class="form-control"
                       value="<?= e($profile['team_leader_name'] ?? '—') ?>" disabled>
              </div>
            <?php endif; ?>
          </div>

          <div class="mt-4 d-flex gap-2">
            <button class="btn btn-primary">
              <i class="bi bi-check2"></i> Save Changes
            </button>
            <a href="<?= BASE_URL ?>/public/index.php" class="btn btn-secondary">
              Cancel
            </a>
          </div>
        </form>
      </div>
    </div>

    <div class="card mt-3">
      <div class="card-header"><i class="bi bi-shield-lock"></i> Security</div>
      <div class="card-body">
        <p class="mb-2 small text-muted">
          To change your password, use the
          <a href="<?= BASE_URL ?>/public/change_password.php">Change Password</a> page.
          Passwords must be at least 8 characters.
        </p>
        <p class="mb-0 small text-muted">
          If you believe your account has been compromised, contact the
          System Administrator immediately.
        </p>
      </div>
    </div>
  </div>

</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
