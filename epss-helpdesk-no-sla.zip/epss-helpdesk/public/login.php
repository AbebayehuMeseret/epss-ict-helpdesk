<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';

if (!empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/public/index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf'] ?? null)) {
        $error = 'Invalid session. Please try again.';
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        if ($username === '' || $password === '') {
            $error = 'Enter username and password.';
        } else {
            $stmt = db()->prepare("SELECT * FROM users WHERE username=? LIMIT 1");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user && $user['locked_until'] && strtotime($user['locked_until']) > time()) {
                $error = 'Account temporarily locked. Try again later.';
            } elseif ($user && $user['status'] !== 'ACTIVE') {
                $error = 'Account is not active. Contact the administrator.';
            } elseif ($user && password_verify($password, $user['password_hash'])) {
                session_regenerate_id(true);
                $_SESSION['user_id']       = (int)$user['id'];
                $_SESSION['role']          = $user['role'];
                $_SESSION['last_activity'] = time();
                db()->prepare("UPDATE users SET failed_login_attempts=0, locked_until=NULL, last_login=NOW() WHERE id=?")
                    ->execute([$user['id']]);
                audit('Login','auth',(int)$user['id'],'User logged in');
                header('Location: ' . BASE_URL . '/public/index.php');
                exit;
            } else {
                if ($user) {
                    $attempts = (int)$user['failed_login_attempts'] + 1;
                    $lock = $attempts >= MAX_LOGIN_ATTEMPTS
                        ? date('Y-m-d H:i:s', time() + LOCKOUT_MINUTES * 60) : null;
                    db()->prepare("UPDATE users SET failed_login_attempts=?, locked_until=? WHERE id=?")
                        ->execute([$attempts, $lock, $user['id']]);
                }
                $error = 'Invalid username or password.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign In – <?= e(APP_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
  /* ============================================================
     SAP Fiori Horizon — Sign-In page with ICT person watermark
     ============================================================ */
  :root {
    --sap-brand:        #0070f2;
    --sap-brand-dark:   #0057d2;
    --sap-brand-hover:  #0064d9;
    --sap-bg:           #f5f6f7;
    --sap-tile:         #ffffff;
    --sap-text:         #1d2d3e;
    --sap-text-muted:   #556b82;
    --sap-border:       #d9d9d9;
    --sap-border-soft:  #eaecf0;
    --sap-negative:     #aa0808;
    --sap-critical:     #e76500;
    --sap-positive:     #256f3a;
    --sap-shadow:       0 2px 12px rgba(34,53,72,.10), 0 0 0 1px rgba(34,53,72,.05);
    --sap-shadow-hover: 0 8px 32px rgba(34,53,72,.14), 0 0 0 1px rgba(34,53,72,.06);
  }

  * { box-sizing: border-box; }

  html, body {
    height: 100%;
    margin: 0;
  }

  body {
    font-family: "72", "72full", Arial, Helvetica, sans-serif;
    background: var(--sap-bg);
    color: var(--sap-text);
    -webkit-font-smoothing: antialiased;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    padding: 1.5rem;
    position: relative;
    overflow-x: hidden;
  }

  /* ============================================================
     Watermark layer
     ============================================================ */
  .login-watermark {
    position: fixed;
    inset: 0;
    z-index: 0;
    pointer-events: none;
    overflow: hidden;
  }

  /* Floating equipment icons */
  .login-watermark .wm-icon {
    position: absolute;
    color: #0070f2;
    opacity: 0.07;
    line-height: 1;
    user-select: none;
  }

  /* ICT person — large, centered, faded silhouette */
  .login-watermark .wm-person {
    position: absolute;
    top: 50%;
    left: 50%;
    width: min(720px, 80vw);
    height: auto;
    transform: translate(-50%, -50%);
    opacity: 0.06;
    color: #0a1f44;
    filter: blur(0.2px);
    user-select: none;
  }

  @keyframes wmFloat {
    0%, 100% { transform: translateY(0) rotate(var(--rot, 0deg)); }
    50%      { transform: translateY(-10px) rotate(var(--rot, 0deg)); }
  }
  .login-watermark .wm-icon.animate {
    animation: wmFloat 8s ease-in-out infinite;
  }

  @keyframes wmPersonPulse {
    0%, 100% { opacity: 0.06; }
    50%      { opacity: 0.09; }
  }
  .login-watermark .wm-person { animation: wmPersonPulse 10s ease-in-out infinite; }

  /* ============================================================
     Decorative SAP Horizon gradients
     ============================================================ */
  body::before,
  body::after {
    content: "";
    position: fixed;
    border-radius: 50%;
    pointer-events: none;
    z-index: 0;
  }
  body::before {
    top: -260px; left: -260px;
    width: 620px; height: 620px;
    background: radial-gradient(circle, rgba(0,112,242,.16) 0%, transparent 70%);
  }
  body::after {
    bottom: -320px; right: -320px;
    width: 680px; height: 680px;
    background: radial-gradient(circle, rgba(0,87,210,.12) 0%, transparent 70%);
  }

  /* Container */
  .login-wrap {
    position: relative;
    z-index: 2;
    width: 100%;
    max-width: 420px;
  }

  /* SAP card */
  .login-card {
    background: var(--sap-tile);
    border: 1px solid var(--sap-border-soft);
    border-radius: 1rem;
    box-shadow: var(--sap-shadow);
    padding: 2.25rem 2rem 1.75rem;
    transition: box-shadow .25s;
    position: relative;
    z-index: 2;
  }
  .login-card:hover { box-shadow: var(--sap-shadow-hover); }

  /* Brand block */
  .brand-block { text-align: center; margin-bottom: 1.75rem; }
  .brand-logo {
    display: block;
    height: 96px;
    width: auto;
    margin: 0 auto 1rem;
    filter: drop-shadow(0 2px 6px rgba(34,53,72,.08));
  }
  .brand-title {
    font-size: 1.125rem;
    font-weight: 600;
    color: var(--sap-text);
    margin: 0 0 .2rem;
    letter-spacing: -.01em;
  }
  .brand-subtitle {
    font-size: .8125rem;
    color: var(--sap-text-muted);
    margin: 0;
  }

  /* Divider */
  .brand-divider {
    height: 1px;
    background: var(--sap-border-soft);
    margin: 0 -2rem 1.5rem;
  }

  /* Message strip */
  .sap-message {
    display: flex;
    align-items: flex-start;
    gap: .55rem;
    padding: .7rem .85rem;
    font-size: .8125rem;
    border-radius: .5rem;
    margin-bottom: 1rem;
    line-height: 1.4;
    border-left: 3px solid;
  }
  .sap-message .bi { flex-shrink: 0; font-size: .95rem; margin-top: .05rem; }
  .sap-message.is-error   { background: #fef4f4; color: var(--sap-negative); border-left-color: var(--sap-negative); }
  .sap-message.is-warning { background: #fff8f1; color: var(--sap-critical); border-left-color: var(--sap-critical); }

  /* Input fields */
  .sap-field { margin-bottom: 1.1rem; }
  .sap-field:last-of-type { margin-bottom: 1.35rem; }
  .sap-label {
    display: block;
    font-size: .75rem;
    text-transform: uppercase;
    letter-spacing: .04em;
    color: var(--sap-text-muted);
    font-weight: 600;
    margin-bottom: .35rem;
  }
  .sap-input-wrap {
    display: flex;
    align-items: stretch;
    border: 1px solid var(--sap-border);
    border-radius: .55rem;
    background: #fff;
    transition: border-color .15s, box-shadow .15s;
    overflow: hidden;
  }
  .sap-input-wrap:focus-within {
    border-color: var(--sap-brand);
    box-shadow: 0 0 0 3px rgba(0,112,242,.15);
  }
  .sap-input-icon {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0 .85rem;
    background: transparent;
    color: var(--sap-text-muted);
    font-size: .95rem;
    border-right: 1px solid var(--sap-border-soft);
  }
  .sap-input-wrap:focus-within .sap-input-icon { color: var(--sap-brand); }

  .sap-input {
    flex: 1;
    border: 0;
    outline: none;
    padding: .65rem .8rem;
    font-size: .9rem;
    font-family: inherit;
    color: var(--sap-text);
    background: transparent;
  }
  .sap-input::placeholder { color: #98a9bb; }

  .sap-eye {
    border: 0;
    background: transparent;
    padding: 0 .85rem;
    color: var(--sap-text-muted);
    cursor: pointer;
    font-size: .95rem;
    transition: color .15s, background .15s;
    border-left: 1px solid var(--sap-border-soft);
  }
  .sap-eye:hover { color: var(--sap-brand); background: #f5f8fb; }
  .sap-eye:focus-visible { outline: 2px solid var(--sap-brand); outline-offset: -3px; }

  /* SAP primary button */
  .sap-btn-primary {
    width: 100%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: .5rem;
    padding: .7rem 1rem;
    font-size: .875rem;
    font-weight: 600;
    font-family: inherit;
    color: #fff;
    background: var(--sap-brand);
    border: 1px solid var(--sap-brand);
    border-radius: .55rem;
    cursor: pointer;
    transition: background .15s, box-shadow .15s, transform .05s;
    box-shadow: 0 1px 2px rgba(34,53,72,.10);
  }
  .sap-btn-primary:hover   { background: var(--sap-brand-hover); border-color: var(--sap-brand-hover); }
  .sap-btn-primary:active  { transform: translateY(1px); box-shadow: 0 0 0 rgba(0,0,0,0); }
  .sap-btn-primary:focus-visible {
    outline: 2px solid var(--sap-brand);
    outline-offset: 2px;
    box-shadow: 0 0 0 4px rgba(0,112,242,.20);
  }

  /* Footer text */
  .login-footer {
    text-align: center;
    margin-top: 1.5rem;
    padding-top: 1.15rem;
    border-top: 1px solid var(--sap-border-soft);
    font-size: .72rem;
    color: var(--sap-text-muted);
    line-height: 1.55;
  }
  .login-footer strong { color: var(--sap-text); font-weight: 600; }

  /* Sub-brand under card (outside) */
  .page-footer {
    text-align: center;
    margin-top: 1.25rem;
    font-size: .72rem;
    color: var(--sap-text-muted);
    letter-spacing: .02em;
    position: relative;
    z-index: 2;
  }
  .page-footer .dot { color: var(--sap-border); margin: 0 .4rem; }

  /* Mobile */
  @media (max-width: 480px) {
    body { padding: 1rem; }
    .login-card { padding: 1.75rem 1.35rem 1.35rem; border-radius: .85rem; }
    .brand-logo { height: 78px; }
    .brand-divider { margin: 0 -1.35rem 1.15rem; }
    .login-watermark .wm-icon.wm-hide-sm { display: none; }
    .login-watermark .wm-person { width: 100vw; opacity: 0.05; }
  }

  /* Reduced motion */
  @media (prefers-reduced-motion: reduce) {
    .login-card, .sap-btn-primary, .sap-eye, .sap-input-wrap { transition: none !important; }
    .login-watermark .wm-icon.animate,
    .login-watermark .wm-person { animation: none !important; }
  }
</style>
</head>
<body>

<!-- ============================================================
     ICT watermark — person at laptop + equipment icons
     ============================================================ -->
<div class="login-watermark" aria-hidden="true">

  <!-- =========================================================
       CENTERPIECE: person sitting at a laptop, wearing a suit
       (inline SVG so no external asset is needed)
       ========================================================= -->
  <svg class="wm-person" viewBox="0 0 800 600" xmlns="http://www.w3.org/2000/svg"
       fill="none" stroke="currentColor" stroke-width="6"
       stroke-linecap="round" stroke-linejoin="round">

    <!-- Desk -->
    <line x1="120" y1="500" x2="680" y2="500" />
    <line x1="200" y1="500" x2="200" y2="560" />
    <line x1="600" y1="500" x2="600" y2="560" />

    <!-- Laptop base -->
    <rect x="330" y="475" width="140" height="10" rx="2" />

    <!-- Laptop screen (angled slightly back) -->
    <rect x="340" y="360" width="120" height="115" rx="4" />

    <!-- Laptop screen content (cursor bar) -->
    <line x1="360" y1="390" x2="440" y2="390" stroke-width="4" />
    <line x1="360" y1="410" x2="420" y2="410" stroke-width="4" />
    <line x1="360" y1="430" x2="430" y2="430" stroke-width="4" />

    <!-- Chair back -->
    <path d="M 200 350 Q 200 300 260 300 L 260 400" />
    <line x1="200" y1="460" x2="260" y2="460" />

    <!-- Person body — suit jacket (shoulders + torso) -->
    <path d="M 240 320 Q 240 300 260 300 L 300 300 Q 320 300 320 320 L 320 460 L 240 460 Z" />

    <!-- Lapels (suit V-neck) -->
    <path d="M 270 300 L 280 340 L 290 300" />

    <!-- Tie -->
    <path d="M 280 340 L 275 400 L 280 420 L 285 400 Z" />

    <!-- Shirt collar -->
    <path d="M 265 300 L 280 320 L 295 300" stroke-width="4" />

    <!-- Head -->
    <circle cx="280" cy="260" r="35" />

    <!-- Hair -->
    <path d="M 245 250 Q 280 220 315 250 Q 315 235 280 225 Q 245 235 245 250" />

    <!-- Neck -->
    <line x1="270" y1="292" x2="270" y2="305" />
    <line x1="290" y1="292" x2="290" y2="305" />

    <!-- Left arm reaching to laptop -->
    <path d="M 250 340 Q 280 380 340 440" stroke-width="7" />
    <path d="M 340 440 L 355 455" stroke-width="7" />

    <!-- Right arm resting on chair -->
    <path d="M 310 340 Q 330 380 330 420" stroke-width="7" />

    <!-- Legs (seated) -->
    <path d="M 260 460 L 260 500" />
    <path d="M 300 460 L 300 500" />

    <!-- Suit detail — button -->
    <circle cx="280" cy="380" r="3" fill="currentColor" />

    <!-- Chair wheels -->
    <circle cx="210" cy="560" r="8" />
    <circle cx="250" cy="560" r="8" />
  </svg>

  <!-- =========================================================
       Scattered ICT equipment icons around the person
       ========================================================= -->

  <!-- Top-left cluster -->
  <i class="bi bi-pc-display       wm-icon animate"
     style="top: 6%;   left: 5%;    font-size: 6rem;  --rot: -8deg;  animation-delay: 0s;"></i>
  <i class="bi bi-printer          wm-icon animate wm-hide-sm"
     style="top: 22%;  left: 14%;   font-size: 4.5rem; --rot: 6deg;   animation-delay: 1.5s;"></i>
  <i class="bi bi-router           wm-icon animate"
     style="top: 40%;  left: 4%;    font-size: 3.5rem; --rot: -4deg;  animation-delay: 2.2s;"></i>

  <!-- Top-right cluster -->
  <i class="bi bi-laptop           wm-icon animate"
     style="top: 8%;   right: 6%;   font-size: 5.5rem; --rot: 10deg;  animation-delay: 0.6s;"></i>
  <i class="bi bi-hdd-network      wm-icon animate wm-hide-sm"
     style="top: 24%;  right: 18%;  font-size: 4rem;   --rot: -6deg;  animation-delay: 1.8s;"></i>
  <i class="bi bi-ethernet         wm-icon animate"
     style="top: 42%;  right: 4%;   font-size: 3rem;   --rot: 4deg;   animation-delay: 3.0s;"></i>

  <!-- Middle-left -->
  <i class="bi bi-hdd-stack        wm-icon animate wm-hide-sm"
     style="top: 60%;  left: 3%;    font-size: 4rem;   --rot: 4deg;   animation-delay: 0.9s;"></i>
  <i class="bi bi-cpu              wm-icon animate"
     style="top: 76%;  left: 12%;   font-size: 3.5rem; --rot: -10deg; animation-delay: 2.5s;"></i>

  <!-- Middle-right -->
  <i class="bi bi-display          wm-icon animate wm-hide-sm"
     style="top: 62%;  right: 4%;   font-size: 4.5rem; --rot: -5deg;  animation-delay: 1.2s;"></i>
  <i class="bi bi-keyboard         wm-icon animate"
     style="top: 78%;  right: 12%;  font-size: 3.5rem; --rot: 6deg;   animation-delay: 2.8s;"></i>

  <!-- Bottom-left -->
  <i class="bi bi-mouse            wm-icon animate wm-hide-sm"
     style="bottom: 4%; left: 24%;  font-size: 2.8rem; --rot: -12deg; animation-delay: 1.6s;"></i>

  <!-- Bottom-right -->
  <i class="bi bi-hdd               wm-icon animate"
     style="bottom: 4%;  right: 26%;font-size: 3.5rem; --rot: 10deg;  animation-delay: 0.3s;"></i>
  <i class="bi bi-wifi              wm-icon animate wm-hide-sm"
     style="bottom: 12%; right: 8%; font-size: 3rem;   --rot: -6deg;  animation-delay: 2.0s;"></i>

</div>

<!-- ============================================================
     Login card
     ============================================================ -->
<div class="login-wrap">

  <div class="login-card">

    <!-- Brand -->
    <div class="brand-block">
      <img src="<?= BASE_URL ?>/public/assets/img/epss-logo.png"
           alt="EPSS – Ethiopian Pharmaceuticals Supply Service"
           class="brand-logo">
      <h1 class="brand-title">EPSS Adama Branch</h1>
      <p class="brand-subtitle">ICT Helpdesk</p>
    </div>
    <div class="brand-divider"></div>

    <!-- Messages -->
    <?php if (isset($_GET['timeout'])): ?>
      <div class="sap-message is-warning">
        <i class="bi bi-clock-history"></i>
        <span>Your session expired. Please sign in again.</span>
      </div>
    <?php endif; ?>
    <?php if ($error): ?>
      <div class="sap-message is-error">
        <i class="bi bi-exclamation-circle"></i>
        <span><?= e($error) ?></span>
      </div>
    <?php endif; ?>

    <!-- Form -->
    <form method="post" autocomplete="off" novalidate>
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">

      <div class="sap-field">
        <label class="sap-label" for="username">Username</label>
        <div class="sap-input-wrap">
          <span class="sap-input-icon"><i class="bi bi-person"></i></span>
          <input type="text"
                 id="username"
                 name="username"
                 class="sap-input"
                 placeholder="Enter your username"
                 autocomplete="username"
                 spellcheck="false"
                 required
                 autofocus
                 value="<?= e($_POST['username'] ?? '') ?>">
        </div>
      </div>

      <div class="sap-field">
        <label class="sap-label" for="password">Password</label>
        <div class="sap-input-wrap">
          <span class="sap-input-icon"><i class="bi bi-lock"></i></span>
          <input type="password"
                 id="password"
                 name="password"
                 class="sap-input"
                 placeholder="Enter your password"
                 autocomplete="current-password"
                 required>
          <button type="button"
                  class="sap-eye"
                  id="togglePassword"
                  aria-label="Show or hide password"
                  title="Show / hide password">
            <i class="bi bi-eye" id="togglePasswordIcon"></i>
          </button>
        </div>
      </div>

      <button type="submit" class="sap-btn-primary">
        <i class="bi bi-box-arrow-in-right"></i>
        <span>Sign In</span>
      </button>
    </form>

    <!-- Footer inside card -->
    <div class="login-footer">
      <strong>Ethiopian Pharmaceuticals Supply Service</strong><br>
      Adama Branch · ICT Helpdesk
    </div>

  </div>

  <div class="page-footer">
    <i class="bi bi-shield-check"></i>
    Secured access
    <span class="dot">·</span>
    v1.0
  </div>

</div>

<script>
/* Password show / hide toggle */
(function () {
  const btn   = document.getElementById('togglePassword');
  const input = document.getElementById('password');
  const icon  = document.getElementById('togglePasswordIcon');
  if (!btn || !input || !icon) return;

  btn.addEventListener('click', () => {
    const showing = input.type === 'text';
    input.type = showing ? 'password' : 'text';
    icon.classList.toggle('bi-eye',      showing);
    icon.classList.toggle('bi-eye-slash', !showing);
    input.focus();
  });
})();

/* Auto-focus username if empty */
(function () {
  const u = document.getElementById('username');
  if (u && !u.value) setTimeout(() => u.focus(), 50);
})();

/* Parallax: watermark drifts subtly as the mouse moves */
(function () {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  if (window.matchMedia('(hover: none)').matches) return;

  const wm = document.querySelector('.login-watermark');
  if (!wm) return;

  let rafId = null;
  let targetX = 0, targetY = 0;
  let currentX = 0, currentY = 0;

  document.addEventListener('mousemove', (e) => {
    const w = window.innerWidth;
    const h = window.innerHeight;
    targetX = (e.clientX / w - 0.5) * 20;
    targetY = (e.clientY / h - 0.5) * 20;

    if (rafId === null) rafId = requestAnimationFrame(tick);
  });

  function tick() {
    currentX += (targetX - currentX) * 0.08;
    currentY += (targetY - currentY) * 0.08;
    wm.style.transform = `translate3d(${currentX}px, ${currentY}px, 0)`;

    if (Math.abs(targetX - currentX) > 0.1 || Math.abs(targetY - currentY) > 0.1) {
      rafId = requestAnimationFrame(tick);
    } else {
      rafId = null;
    }
  }
})();
</script>

</body>
</html>
