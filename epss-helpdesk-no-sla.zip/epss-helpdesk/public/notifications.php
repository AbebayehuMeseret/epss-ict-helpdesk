<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_login();
$pageTitle = 'Notifications';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf($_POST['csrf'] ?? null)) {
    if (($_POST['action'] ?? '') === 'mark_all') {
        db()->prepare("UPDATE notifications SET is_read=1 WHERE user_id=?")->execute([$u['id']]);
    }
}
$notifs = db()->prepare("SELECT n.*, t.ticket_number FROM notifications n
    LEFT JOIN tickets t ON t.id = n.ticket_id
    WHERE n.user_id=? ORDER BY n.created_at DESC LIMIT 100");
$notifs->execute([$u['id']]);
$notifs = $notifs->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h4 class="mb-0">Notifications</h4>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="action" value="mark_all">
    <button class="btn btn-outline-primary btn-sm"><i class="bi bi-check2-all"></i> Mark all as read</button>
  </form>
</div>
<div class="card"><div class="list-group list-group-flush">
<?php if (!$notifs): ?>
  <div class="list-group-item text-center text-muted py-4">No notifications.</div>
<?php else: foreach ($notifs as $n): ?>
  <div class="list-group-item <?= $n['is_read'] ? '' : 'bg-light' ?>">
    <div class="d-flex justify-content-between">
      <div>
        <strong><?= e($n['title']) ?></strong>
        <?php if ($n['ticket_number']): ?>
          <span class="badge bg-secondary ms-2"><?= e($n['ticket_number']) ?></span>
        <?php endif; ?>
        <div class="small text-muted"><?= e($n['message']) ?></div>
      </div>
      <small class="text-muted"><?= e(date('M d, Y H:i', strtotime($n['created_at']))) ?></small>
    </div>
  </div>
<?php endforeach; endif; ?>
</div></div>
<?php include __DIR__ . '/../includes/footer.php'; ?>