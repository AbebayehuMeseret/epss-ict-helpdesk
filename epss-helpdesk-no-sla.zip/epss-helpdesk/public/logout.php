<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
if (!empty($_SESSION['user_id'])) audit('Logout','auth',(int)$_SESSION['user_id'],'User logged out');
session_unset(); session_destroy();
header('Location: ' . BASE_URL . '/public/login.php');
exit;