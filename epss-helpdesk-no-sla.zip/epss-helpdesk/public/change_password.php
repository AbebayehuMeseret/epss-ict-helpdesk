<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = current_user();
if (!$u) { header('Location: ' . BASE_URL . '/public/login.php'); exit; }
$error = $ok = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf'] ?? null)) {
        $error = 'Invalid session.';
    } else {
        $cur = $_POST['current'] ?? '';
        $new = $_POST['new'] ?? '';
        $conf = $_POST['confirm'] ?? '';
        if (!password_verify($cur, $u['password_hash'])) {
            $error = 'Current password is incorrect.';
        } elseif (strlen($new) < 8) {
            $error = 'New password must be at least 8 characters.';
        } elseif ($new !== $conf) {
            $error = 'Passwords do not match.';
        } else {
            $hash = password_hash($new, PASSWORD_DEFAULT);
            db()->prepare("UPDATE users SET password_hash=?, must_change_password=0 WHERE id=?")
                ->execute([$hash, $u['id']]);
            audit('PasswordChanged','users',(int)$u['id'],'Password changed');
            $ok = 'Password changed successfully.';
        }
    }
}
$pageTitle = 'Change Password';
include __DIR__ . '/../includes/header.php';
?>
<h4 class="mb-4">Change Password</h4>
<?php if ($u['must_change_password']): ?>
  <div class="alert alert-warning">You must change your password before continuing.</div>
<?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<div class="card" style="max-width:520px">
  <div class="card-body">
    <form method="post">
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
      <div class="mb-3"><label class="form-label">Current Password</label>
        <input type="password" name="current" class="form-control" required></div>
      <div class="mb-3"><label class="form-label">New Password</label>
        <input type="password" name="new" class="form-control" required minlength="8"></div>
      <div class="mb-3"><label class="form-label">Confirm New Password</label>
        <input type="password" name="confirm" class="form-control" required></div>
      <button class="btn btn-primary">Change Password</button>
      <?php if (!$u['must_change_password']): ?>
        <a href="<?= BASE_URL ?>/public/index.php" class="btn btn-secondary">Cancel</a>
      <?php endif; ?>
    </form>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>