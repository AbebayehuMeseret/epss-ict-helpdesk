<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_login();
$pageTitle = 'Help & Support';
include __DIR__ . '/../includes/header.php';

/* Role label */
$roleLabel = [
    'ADMIN'       => 'Administrator',
    'TEAM_LEADER' => 'Team Leader',
    'ICT_STAFF'   => 'ICT Staff',
    'EMPLOYEE'    => 'Employee',
][$u['role']] ?? $u['role'];
?>

<style>
  :root {
    --sap-brand:        #0070f2;
    --sap-brand-dark:   #0057d2;
    --sap-bg:           #f5f6f7;
    --sap-tile:         #ffffff;
    --sap-text:         #1d2d3e;
    --sap-text-muted:   #556b82;
    --sap-border:       #d9d9d9;
    --sap-border-soft:  #eaecf0;
    --sap-positive:     #256f3a;
    --sap-critical:     #e76500;
    --sap-negative:     #aa0808;
    --sap-neutral:      #5b738b;
    --sap-shadow:       0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
    --sap-shadow-hover: 0 0 0 1px rgba(34,53,72,.15), 0 8px 24px 0 rgba(34,53,72,.12);
  }

  body, .main-content {
    background: var(--sap-bg) !important;
    font-family: "72", "72full", Arial, Helvetica, sans-serif !important;
    color: var(--sap-text);
  }

  .sap-page-header {
    display: flex; align-items: flex-start; justify-content: space-between;
    margin-bottom: 1rem;
  }
  .sap-page-title { font-size: 1.625rem; font-weight: 400; margin: 0; }
  .sap-breadcrumb { font-size: .8125rem; color: var(--sap-text-muted); margin-bottom: .25rem; }

  .sap-status {
    display: inline-flex; align-items: center; gap: .25rem;
    font-size: .7rem; font-weight: 600;
    padding: .1rem .5rem;
    border-radius: .75rem;
    background: #eaf4ff; color: var(--sap-brand);
    border: 1px solid #cfe2f8;
    white-space: nowrap;
  }

  /* SAP card */
  .sap-card {
    background: var(--sap-tile);
    border-radius: .75rem;
    box-shadow: var(--sap-shadow);
    overflow: hidden;
    margin-bottom: 1rem;
    transition: box-shadow .2s, transform .2s;
    height: 100%;
  }
  .sap-card:hover { box-shadow: var(--sap-shadow-hover); transform: translateY(-1px); }
  .sap-card-header {
    padding: .85rem 1.1rem;
    border-bottom: 1px solid var(--sap-border-soft);
    font-size: .9rem; font-weight: 600; color: var(--sap-text);
    display: flex; align-items: center; gap: .5rem;
  }
  .sap-card-header .bi { color: var(--sap-brand); font-size: 1rem; }
  .sap-card-body { padding: 1rem 1.1rem; font-size: .855rem; line-height: 1.55; color: var(--sap-text); }

  /* Workflow steps */
  .sap-flow {
    display: flex; flex-wrap: wrap; gap: .4rem; align-items: center;
    margin: 0;
    padding: 0;
    list-style: none;
  }
  .sap-flow-step {
    display: inline-flex; align-items: center; gap: .35rem;
    padding: .35rem .7rem;
    background: #f5f6f7;
    border: 1px solid var(--sap-border-soft);
    border-radius: .5rem;
    font-size: .78rem; font-weight: 500; color: var(--sap-text);
  }
  .sap-flow-step.is-active {
    background: #eaf4ff; color: var(--sap-brand);
    border-color: #cfe2f8;
    font-weight: 600;
  }
  .sap-flow-arrow { color: var(--sap-text-muted); font-size: .8rem; }

  /* FAQ */
  .sap-faq { border-radius: .75rem; box-shadow: var(--sap-shadow); background: var(--sap-tile); overflow: hidden; }
  .sap-faq-item { border-bottom: 1px solid var(--sap-border-soft); }
  .sap-faq-item:last-child { border-bottom: 0; }
  .sap-faq-q {
    width: 100%;
    background: transparent; border: 0;
    padding: .85rem 1rem;
    display: flex; align-items: center; justify-content: space-between; gap: .75rem;
    font-size: .875rem; font-weight: 600; color: var(--sap-text);
    text-align: left;
    cursor: pointer;
    transition: background .12s;
    font-family: inherit;
  }
  .sap-faq-q:hover { background: #f8fbff; }
  .sap-faq-q .bi {
    color: var(--sap-brand); font-size: .9rem;
    transition: transform .2s;
    flex-shrink: 0;
  }
  .sap-faq-item.open .sap-faq-q .bi { transform: rotate(180deg); }
  .sap-faq-a {
    display: none;
    padding: 0 1rem 1rem;
    font-size: .84rem; line-height: 1.6; color: var(--sap-text-muted);
    background: #fafbfc;
    border-top: 1px dashed var(--sap-border-soft);
    padding-top: .75rem;
  }
  .sap-faq-item.open .sap-faq-a { display: block; }

  /* Buttons */
  .sap-btn {
    display: inline-flex; align-items: center; gap: .35rem;
    font-size: .8125rem; font-weight: 500;
    border-radius: .5rem;
    padding: .45rem .85rem;
    border: 1px solid transparent;
    background: transparent;
    color: var(--sap-brand);
    cursor: pointer;
    line-height: 1;
    text-decoration: none;
    white-space: nowrap;
    transition: background .15s, color .15s, box-shadow .15s;
  }
  .sap-btn:hover { background: #eaf4ff; color: var(--sap-brand-dark); }
  .sap-btn:focus-visible { outline: 2px solid var(--sap-brand); outline-offset: 2px; }
  .sap-btn.sap-btn-emphasized {
    background: var(--sap-brand); color: #fff;
    box-shadow: 0 1px 2px rgba(34,53,72,.15);
  }
  .sap-btn.sap-btn-emphasized:hover { background: var(--sap-brand-dark); color: #fff; }

  /* Contact tiles */
  .sap-contact {
    display: flex; align-items: center; gap: .85rem;
    padding: .85rem 1rem;
    background: var(--sap-tile);
    border-radius: .75rem;
    box-shadow: var(--sap-shadow);
    text-decoration: none;
    color: var(--sap-text);
    transition: transform .15s, box-shadow .15s;
    height: 100%;
  }
  .sap-contact:hover {
    transform: translateY(-2px);
    box-shadow: var(--sap-shadow-hover);
    color: var(--sap-text);
  }
  .sap-contact-icon {
    width: 42px; height: 42px;
    border-radius: .6rem;
    display: inline-flex; align-items: center; justify-content: center;
    font-size: 1.15rem;
    flex-shrink: 0;
    background: #eaf4ff; color: var(--sap-brand);
  }
  .sap-contact-icon.is-green   { background: #f1fdf6; color: var(--sap-positive); }
  .sap-contact-icon.is-orange  { background: #fff8f1; color: var(--sap-critical); }
  .sap-contact-icon.is-red     { background: #fef4f4; color: var(--sap-negative); }
  .sap-contact-title { font-weight: 600; font-size: .875rem; color: var(--sap-text); line-height: 1.2; }
  .sap-contact-sub   { font-size: .72rem; color: var(--sap-text-muted); margin-top: .15rem; }

  @media (prefers-reduced-motion: reduce) {
    .sap-card, .sap-contact, .sap-faq-q .bi { transition: none !important; }
  }
</style>

<!-- ================= Page header ================= -->
<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb">
      <i class="bi bi-house-door"></i> Home / <strong>Help &amp; Support</strong>
    </div>
    <h1 class="sap-page-title">Help &amp; Support</h1>
  </div>
  <div class="d-flex align-items-center gap-2 flex-wrap">
    <span class="sap-status"><i class="bi bi-person-badge"></i> <?= e($roleLabel) ?></span>
    <span class="sap-status"><i class="bi bi-headset"></i> EPSS Adama Branch</span>
  </div>
</div>

<!-- ================= Quick actions ================= -->
<div class="row g-3 mb-3">
  <div class="col-md-6 col-lg-4">
    <a href="<?= BASE_URL ?>/public/chat.php" class="sap-contact">
      <div class="sap-contact-icon"><i class="bi bi-chat-dots"></i></div>
      <div>
        <div class="sap-contact-title">Start a Live Chat</div>
        <div class="sap-contact-sub">Talk to ICT staff in real time</div>
      </div>
    </a>
  </div>
  <?php if ($u['role'] === 'EMPLOYEE'): ?>
    <div class="col-md-6 col-lg-4">
      <a href="<?= BASE_URL ?>/employee/create_ticket.php" class="sap-contact">
        <div class="sap-contact-icon is-green"><i class="bi bi-plus-circle"></i></div>
        <div>
          <div class="sap-contact-title">Create a New Ticket</div>
          <div class="sap-contact-sub">Report an ICT issue</div>
        </div>
      </a>
    </div>
  <?php endif; ?>
  <?php if (in_array($u['role'], ['ADMIN','ICT_STAFF','TEAM_LEADER'], true)): ?>
    <div class="col-md-6 col-lg-4">
      <a href="<?= BASE_URL ?>/public/notifications.php" class="sap-contact">
        <div class="sap-contact-icon is-orange"><i class="bi bi-bell"></i></div>
        <div>
          <div class="sap-contact-title">View Notifications</div>
          <div class="sap-contact-sub">Recent alerts and updates</div>
        </div>
      </a>
    </div>
  <?php endif; ?>
</div>

<!-- ================= Workflow explainer ================= -->
<div class="sap-card">
  <div class="sap-card-header">
    <i class="bi bi-diagram-3"></i> How the Ticket Workflow Works
  </div>
  <div class="sap-card-body">
    <p class="mb-3 text-muted" style="font-size:.82rem">
      Every ticket moves through a controlled workflow to ensure accountability and quality of service.
    </p>
    <ul class="sap-flow mb-3">
      <li class="sap-flow-step <?= $u['role'] === 'EMPLOYEE'    ? 'is-active' : '' ?>"><i class="bi bi-person"></i> Employee creates ticket</li>
      <li class="sap-flow-arrow"><i class="bi bi-arrow-right"></i></li>
      <li class="sap-flow-step <?= $u['role'] === 'TEAM_LEADER' ? 'is-active' : '' ?>"><i class="bi bi-person-check"></i> Team Leader approves</li>
      <li class="sap-flow-arrow"><i class="bi bi-arrow-right"></i></li>
      <li class="sap-flow-step <?= $u['role'] === 'ICT_STAFF'   ? 'is-active' : '' ?>"><i class="bi bi-tools"></i> ICT accepts &amp; resolves</li>
      <li class="sap-flow-arrow"><i class="bi bi-arrow-right"></i></li>
      <li class="sap-flow-step <?= $u['role'] === 'EMPLOYEE'    ? 'is-active' : '' ?>"><i class="bi bi-patch-check"></i> Requester confirms</li>
      <li class="sap-flow-arrow"><i class="bi bi-arrow-right"></i></li>
      <li class="sap-flow-step <?= $u['role'] === 'ADMIN'       ? 'is-active' : '' ?>"><i class="bi bi-check2-all"></i> Closed</li>
    </ul>
    <p class="mb-0 text-muted" style="font-size:.82rem">
      <i class="bi bi-info-circle"></i>
      Your role is highlighted above. Use the sidebar to reach the pages you need.
    </p>
  </div>
</div>

<!-- ================= Role-specific tips + FAQ ================= -->
<div class="row g-3">

  <!-- Role tips -->
  <div class="col-lg-5">
    <div class="sap-card h-100">
      <div class="sap-card-header">
        <i class="bi bi-lightbulb"></i> Tips for <?= e($roleLabel) ?>s
      </div>
      <div class="sap-card-body">
        <?php if ($u['role'] === 'EMPLOYEE'): ?>
          <ul class="mb-0 ps-3" style="line-height:1.7">
            <li>Describe the problem clearly — include what changed and when it stopped working.</li>
            <li>Attach a photo or screenshot if the issue is visual.</li>
            <li>Choose the right <strong>priority</strong>. Marking everything Critical slows down real emergencies.</li>
            <li>Respond quickly when your Team Leader asks for clarification.</li>
            <li>When ICT resolves your ticket, confirm the fix on the ticket page so it can be closed. If it is still broken, send it back to ICT.</li>
            <li>Please answer within <strong>30 minutes</strong> — if you forget, the ticket closes automatically as confirmed. The ticket page shows the time you have left.</li>
          </ul>
        <?php elseif ($u['role'] === 'TEAM_LEADER'): ?>
          <ul class="mb-0 ps-3" style="line-height:1.7">
            <li>Approve, reject, or return tickets promptly — ICT is blocked until you do.</li>
            <li>Rejections and clarification requests <strong>require a reason</strong> — be specific.</li>
            <li>You approve (or return/reject) tickets — ICT cannot start work until you do.</li>
            <li>If you don't respond within 15 minutes the ticket is forwarded to ICT automatically and you are told it was bypassed.</li>
            <li>After ICT resolves a ticket, the requester confirms the fix and the ticket closes — automatically after 30 minutes if they do not answer.</li>
            <li>For tickets <strong>you create yourself</strong>, you are the requester: when ICT resolves one, open it and choose <strong>Confirm &amp; Close Ticket</strong> (or <em>Not Resolved</em> to send it back to ICT) within 30 minutes.</li>
            <li>When the requester sends a ticket back as <em>Not Resolved</em>, the technician is notified again (in-app and on Telegram) with the reason.</li>
            <li>Your <strong>Team Reports</strong> page summarises your team's tickets by category.</li>
          </ul>
        <?php elseif ($u['role'] === 'ICT_STAFF'): ?>
          <ul class="mb-0 ps-3" style="line-height:1.7">
            <li>Accept tickets from the queue, or assign them to a specific technician.</li>
            <li>Record <strong>diagnosis</strong>, <strong>root cause</strong>, and <strong>resolution</strong> for every ticket.</li>
            <li>Use <em>Waiting for Info/Parts</em> instead of leaving tickets idle.</li>
            <li>Mark tickets as <strong>Resolved</strong> when work is complete — the requester then confirms and the ticket closes.</li>
            <li>Attach evidence (screenshots, photos) so the requester can see what was done.</li>
          </ul>
        <?php else: ?>
          <ul class="mb-0 ps-3" style="line-height:1.7">
            <li>Configure <strong>users</strong> and <strong>departments</strong> before creating tickets.</li>
            <li>Every employee must have a Team Leader — the system enforces this.</li>
            <li>Set the <strong>priorities</strong> your branch uses for tickets.</li>
            <li>Review <strong>Audit Logs</strong> regularly to track configuration changes.</li>
            <li>Use the <strong>Reports</strong> page (with PDF export) for monthly KPI reviews.</li>
          </ul>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- FAQ -->
  <div class="col-lg-7">
    <div class="sap-card h-100">
      <div class="sap-card-header">
        <i class="bi bi-question-circle"></i> Frequently Asked Questions
      </div>
      <div class="sap-faq">
        <?php
        $faqs = [
            [
                'How do I reset my password?',
                'Open your profile menu in the top-right corner and choose <strong>Change Password</strong>. You will need your current password. If you forgot it, ask the System Administrator to reset it for you.',
            ],
            [
                'Why can’t I approve a ticket?',
                'Only the Team Leader assigned to an employee can approve their tickets. If the ticket belongs to another team, contact the Administrator to reassign it.',
            ],
            [
                'I can’t upload a file. What types are allowed?',
                'Attachments are limited by the size and file‑type rules configured in System Settings. Typical allowed formats include JPG, PNG, PDF, DOC(X), XLS(X), TXT, and ZIP. Ask your Administrator to review the limits if you need a different type.',
            ],
            [
                'My ticket was resolved but it is not closed yet.',
                'When ICT marks work complete, the ticket waits for the requester to confirm. Open the ticket and choose <strong>Confirm &amp; Close Ticket</strong>. If the problem is not fixed, choose <strong>Not Resolved</strong> to send it back to ICT. You have <strong>30 minutes</strong> — after that the ticket closes automatically as confirmed.',
            ],
            [
                'How do I export a report?',
                'Open <strong>Reports</strong> from the sidebar and click the format you need: <strong>Print</strong>, <strong>CSV</strong>, <strong>Excel</strong>, or <strong>PDF</strong>. The PDF includes the KPI summary and charts.',
            ],
            [
                'What is the Live Chat for?',
                'Live Chat is a real-time messaging channel between staff. Use it for quick questions without creating a full ticket. For formal IT issues that need tracking, create a ticket instead.',
            ],
            [
                'Who can see my tickets?',
                'You, your Team Leader, the assigned ICT technician, and the System Administrator. Nobody else can access your tickets.',
            ],
        ];
        foreach ($faqs as $i => [$q, $a]): ?>
          <div class="sap-faq-item" data-faq="<?= $i ?>">
            <button type="button" class="sap-faq-q">
              <span><?= $q ?></span>
              <i class="bi bi-chevron-down"></i>
            </button>
            <div class="sap-faq-a"><?= $a ?></div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<!-- ================= Contact support ================= -->
<div class="sap-card mt-3">
  <div class="sap-card-header">
    <i class="bi bi-telephone"></i> Contact Support
  </div>
  <div class="sap-card-body">
    <p class="text-muted mb-3" style="font-size:.85rem">
      If the answers above don’t resolve your issue, reach out through one of the channels below.
    </p>
    <div class="row g-3">
      <div class="col-md-4">
        <a href="<?= BASE_URL ?>/public/chat.php" class="sap-contact">
          <div class="sap-contact-icon"><i class="bi bi-chat-dots"></i></div>
          <div>
            <div class="sap-contact-title">Live Chat</div>
            <div class="sap-contact-sub">Fastest response during working hours</div>
          </div>
        </a>
      </div>
      <div class="col-md-4">
        <a href="mailto:ict-helpdesk@epss-adama.gov.et" class="sap-contact">
          <div class="sap-contact-icon is-green"><i class="bi bi-envelope"></i></div>
          <div>
            <div class="sap-contact-title">Email ICT Helpdesk</div>
            <div class="sap-contact-sub">messiabex@gmail.com</div>
          </div>
        </a>
      </div>
      <div class="col-md-4">
        <div class="sap-contact">
          <div class="sap-contact-icon is-orange"><i class="bi bi-telephone"></i></div>
          <div>
            <div class="sap-contact-title">Internal Extension</div>
            <div class="sap-contact-sub">Dial <strong>ICT</strong> 0913925920/0920396329</div>
          </div>
        </div>
      </div>
    </div>
    <hr class="my-3">
    <div class="d-flex align-items-center gap-2 small text-muted">
      <i class="bi bi-clock-history"></i>
      <span>Working hours: <strong>Monday – Friday, 08:30 – 17:30</strong> (East Africa Time).</span>
    </div>
  </div>
</div>

<script>
/* FAQ accordion */
document.querySelectorAll('.sap-faq-q').forEach(btn => {
  btn.addEventListener('click', () => {
    const item = btn.closest('.sap-faq-item');
    item.classList.toggle('open');
  });
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
