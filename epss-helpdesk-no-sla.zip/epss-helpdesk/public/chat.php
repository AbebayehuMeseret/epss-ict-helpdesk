<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_login();
$pageTitle = 'Live Chat';
include __DIR__ . '/../includes/header.php';
?>

<style>
.chat-shell {
  display: flex; height: calc(100vh - 180px); min-height: 500px;
  background: #fff; border-radius: .75rem; overflow: hidden;
  box-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
}
.chat-side {
  width: 320px; border-right: 1px solid #e5e5e5; display: flex; flex-direction: column;
  background: #fafafa;
}
.chat-side-head {
  padding: .75rem 1rem; border-bottom: 1px solid #e5e5e5;
  display: flex; align-items: center; justify-content: space-between; background: #fff;
}
.chat-conv-list { flex: 1; overflow-y: auto; }
.chat-conv-item {
  padding: .75rem 1rem; border-bottom: 1px solid #f0f0f0; cursor: pointer;
  transition: background .12s;
}
.chat-conv-item:hover { background: #f0f6ff; }
.chat-conv-item.active { background: #e8f1ff; border-left: 3px solid #0070f2; }
.chat-conv-title { font-size: .85rem; font-weight: 600; color: #1d2d3e; }
.chat-conv-sub   { font-size: .75rem; color: #556b82; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.chat-conv-meta  { font-size: .7rem; color: #8899aa; display: flex; justify-content: space-between; }
.chat-unread { background: #0070f2; color: #fff; border-radius: 1rem; font-size: .65rem; padding: .1rem .45rem; }

.chat-main { flex: 1; display: flex; flex-direction: column; background: #fff; }
.chat-main-head {
  padding: .75rem 1rem; border-bottom: 1px solid #e5e5e5;
  display: flex; align-items: center; justify-content: space-between;
}
.chat-body {
  flex: 1; overflow-y: auto; padding: 1rem; background: #f5f6f7;
  display: flex; flex-direction: column; gap: .5rem;
}
.chat-msg { max-width: 70%; display: flex; flex-direction: column; }
.chat-msg.out { align-self: flex-end; align-items: flex-end; }
.chat-msg.in  { align-self: flex-start; }
.chat-bubble {
  padding: .55rem .8rem; border-radius: .9rem; font-size: .85rem; line-height: 1.35;
  background: #fff; color: #1d2d3e; box-shadow: 0 1px 2px rgba(0,0,0,.06);
  word-wrap: break-word; white-space: pre-wrap;
}
.chat-msg.out .chat-bubble { background: #0070f2; color: #fff; }
.chat-meta { font-size: .68rem; color: #8899aa; margin-top: .15rem; }
.chat-foot { border-top: 1px solid #e5e5e5; padding: .5rem; display: flex; gap: .5rem; background: #fff; }
.chat-foot textarea { resize: none; height: 42px; }

@media (max-width: 768px) {
  .chat-shell { flex-direction: column; height: auto; }
  .chat-side { width: 100%; max-height: 240px; }
}
</style>

<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb"><i class="bi bi-house-door"></i> Home / <strong>Live Chat</strong></div>
    <h1 class="sap-page-title">Live Chat</h1>
  </div>
  <div class="d-flex gap-2">
    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#newConv">
      <i class="bi bi-plus-circle"></i> New Conversation
    </button>
  </div>
</div>

<div class="chat-shell">
  <!-- LEFT: conversation list -->
  <aside class="chat-side">
    <div class="chat-side-head">
      <strong style="font-size:.85rem">Conversations</strong>
      <span class="badge bg-primary" id="totalUnread">0</span>
    </div>
    <div class="chat-conv-list" id="convList">
      <div class="text-center text-muted small p-3">Loading…</div>
    </div>
  </aside>

  <!-- RIGHT: message pane -->
  <section class="chat-main">
    <div class="chat-main-head" id="chatHead">
      <div>
        <strong id="chatTitle">Select a conversation</strong>
        <div class="small text-muted" id="chatSubtitle">—</div>
      </div>
      <button class="btn btn-sm btn-outline-secondary d-none" id="btnRefresh">
        <i class="bi bi-arrow-clockwise"></i>
      </button>
    </div>
    <div class="chat-body" id="chatBody">
      <div class="text-center text-muted small m-auto">No conversation selected.</div>
    </div>
    <form class="chat-foot" id="sendForm" autocomplete="off">
      <input type="hidden" id="activeConvId" value="">
      <textarea class="form-control" id="msgInput" placeholder="Type a message… (Enter to send, Shift+Enter for newline)" disabled></textarea>
      <button class="btn btn-primary" id="sendBtn" type="submit" disabled>
        <i class="bi bi-send"></i>
      </button>
    </form>
  </section>
</div>

<!-- New Conversation Modal -->
<div class="modal fade" id="newConv"><div class="modal-dialog"><div class="modal-content">
<form id="newConvForm">
<div class="modal-header"><h5 class="modal-title">Start New Conversation</h5>
  <button class="btn-close" data-bs-dismiss="modal" type="button"></button></div>
<div class="modal-body">
  <div class="mb-3"><label class="form-label">Subject *</label>
    <input name="subject" id="ncSubject" class="form-control" required maxlength="200"></div>
  <div class="mb-3"><label class="form-label">Invite a colleague (optional)</label>
    <select id="ncInvitee" class="form-select"><option value="">-- none --</option></select></div>
  <div class="mb-3"><label class="form-label">Link to ticket # (optional)</label>
    <input id="ncTicket" class="form-control" placeholder="e.g. 5 (numeric id)"></div>
  <div class="small text-muted">If you link a ticket, its requester, Team Leader, and assigned technician are invited automatically.</div>
</div>
<div class="modal-footer">
  <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Cancel</button>
  <button class="btn btn-primary">Create</button>
</div>
</form>
</div></div></div>

<script>
const CSRF = <?= json_encode(csrf_token()) ?>;
let activeConv = 0;
let lastMsgId = 0;
let pollTimer = null;

const fmtTime = ts => new Date(ts.replace(' ', 'T')).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});

async function api(action, opts = {}) {
  const qs = opts.query ? '?' + new URLSearchParams(opts.query).toString() : '';
  const url = '<?= BASE_URL ?>/api/chat.php' + qs + (qs ? '&' : '?') + 'action=' + action;
  const init = { method: opts.method || 'GET' };
  if (opts.body) {
    const fd = new FormData();
    fd.append('csrf', CSRF);
    for (const k in opts.body) fd.append(k, opts.body[k]);
    init.method = 'POST';
    init.body = fd;
  }
  const r = await fetch(url, init);
  return r.json();
}

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

async function loadConversations() {
  const data = await api('conversations');
  if (!data.ok) return;
  const list = document.getElementById('convList');
  if (!data.conversations.length) {
    list.innerHTML = '<div class="text-center text-muted small p-3">No conversations yet.<br>Click <strong>New Conversation</strong> to start one.</div>';
    document.getElementById('totalUnread').textContent = '0';
    return;
  }
  let totalUnread = 0;
  list.innerHTML = data.conversations.map(c => {
    totalUnread += Number(c.unread);
    return `<div class="chat-conv-item ${Number(c.id)===activeConv?'active':''}" data-id="${c.id}" data-subject="${esc(c.subject)}" data-ticket="${esc(c.ticket_number||'')}">
      <div class="d-flex justify-content-between">
        <div class="chat-conv-title">${esc(c.subject)}</div>
        ${Number(c.unread)>0 ? `<span class="chat-unread">${c.unread}</span>` : ''}
      </div>
      <div class="chat-conv-sub">${c.last_sender ? esc(c.last_sender)+': ' : ''}${esc(c.last_body||'')}</div>
      <div class="chat-conv-meta">
        <span>${c.ticket_number ? '#'+esc(c.ticket_number) : (c.status==='CLOSED'?'closed':'')}</span>
        <span>${fmtTime(c.last_message_at)}</span>
      </div>
    </div>`;
  }).join('');
  document.getElementById('totalUnread').textContent = totalUnread;

  list.querySelectorAll('.chat-conv-item').forEach(el => {
    el.addEventListener('click', () => openConversation(
      Number(el.dataset.id),
      el.dataset.subject,
      el.dataset.ticket
    ));
  });
}

async function openConversation(id, subject, ticketNumber) {
  activeConv = id;
  lastMsgId = 0;
  document.getElementById('activeConvId').value = id;
  document.getElementById('chatTitle').textContent = subject || 'Conversation';
  document.getElementById('chatSubtitle').textContent = ticketNumber ? ('Ticket #' + ticketNumber) : '';
  document.getElementById('msgInput').disabled = false;
  document.getElementById('sendBtn').disabled = false;
  document.getElementById('btnRefresh').classList.remove('d-none');
  document.getElementById('chatBody').innerHTML = '<div class="text-center text-muted small m-auto">Loading…</div>';

  document.querySelectorAll('.chat-conv-item').forEach(e => e.classList.remove('active'));
  const cur = document.querySelector(`.chat-conv-item[data-id="${id}"]`);
  if (cur) cur.classList.add('active');

  await fetchMessages();
  startPolling();
}

async function fetchMessages() {
  if (!activeConv) return;
  const data = await api('messages', { query: { conversation_id: activeConv, since_id: lastMsgId } });
  if (!data.ok) return;
  const body = document.getElementById('chatBody');
  if (lastMsgId === 0) body.innerHTML = '';

  data.messages.forEach(m => {
    lastMsgId = Math.max(lastMsgId, Number(m.id));
    const mine = Number(m.sender_id) === <?= (int)$u['id'] ?>;
    const div = document.createElement('div');
    div.className = 'chat-msg ' + (mine ? 'out' : 'in');
    div.innerHTML = `
      <div class="chat-bubble">${esc(m.body)}</div>
      <div class="chat-meta">${mine ? 'You' : esc(m.sender_name)} · ${fmtTime(m.created_at)}</div>`;
    body.appendChild(div);
  });
  body.scrollTop = body.scrollHeight;

  // Refresh unread badge (mark-as-read happened server-side)
  loadConversations();
}

function startPolling() {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = setInterval(fetchMessages, 3000);
}

document.getElementById('sendForm').addEventListener('submit', async e => {
  e.preventDefault();
  const input = document.getElementById('msgInput');
  const body = input.value.trim();
  if (!body || !activeConv) return;
  input.value = '';
  const r = await api('send', { body: { conversation_id: activeConv, body } });
  if (r.ok) {
    lastMsgId = r.id - 1;   // force refetch from just before this new one
    await fetchMessages();
  } else {
    alert('Could not send: ' + (r.error || 'unknown'));
  }
});

document.getElementById('msgInput').addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    document.getElementById('sendForm').dispatchEvent(new Event('submit'));
  }
});

document.getElementById('btnRefresh').addEventListener('click', fetchMessages);

// New conversation
(async () => {
  const p = await api('people');
  if (p.ok) {
    const sel = document.getElementById('ncInvitee');
    p.people.filter(x => x.id !== <?= (int)$u['id'] ?>).forEach(x => {
      const o = document.createElement('option');
      o.value = x.id;
      o.textContent = x.full_name + ' (' + x.role.replace('_',' ') + ')';
      sel.appendChild(o);
    });
  }
})();

document.getElementById('newConvForm').addEventListener('submit', async e => {
  e.preventDefault();
  const r = await api('start', {
    body: {
      subject:    document.getElementById('ncSubject').value,
      invitee_id: document.getElementById('ncInvitee').value,
      ticket_id:  document.getElementById('ncTicket').value
    }
  });
  if (r.ok) {
    bootstrap.Modal.getInstance(document.getElementById('newConv')).hide();
    document.getElementById('newConvForm').reset();
    await loadConversations();
    openConversation(r.conversation_id, 'Conversation', '');
  } else {
    alert('Error: ' + r.error);
  }
});

// Initial
loadConversations();
setInterval(loadConversations, 8000);
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
