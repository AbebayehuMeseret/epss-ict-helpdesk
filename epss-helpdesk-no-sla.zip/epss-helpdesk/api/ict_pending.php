<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');
header('Cache-Control: no-store');

$u = require_login();

if ($u['role'] !== 'ICT_STAFF') {
    app_fail('E-AUTH-403');
}

$pdo = db();

$stmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM tickets
    WHERE status = 'APPROVED_FOR_ICT'
      AND (assigned_technician_id IS NULL OR assigned_technician_id = ?)
");
$stmt->execute([$u['id']]);
$pending = (int)$stmt->fetchColumn();

$row = $pdo->query("
    SELECT ticket_number, subject, created_at
    FROM tickets
    WHERE status = 'APPROVED_FOR_ICT'
    ORDER BY created_at DESC
    LIMIT 1
")->fetch();

echo json_encode([
    'ok'      => true,
    'pending' => $pending,
    'latest'  => $row ?: null,
    'ts'      => time(),
]);