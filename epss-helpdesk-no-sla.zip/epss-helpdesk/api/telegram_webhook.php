<?php
declare(strict_types=1);
/** Only used when the server has a public HTTPS address (webhook mode). Local servers use polling instead. */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/telegram.php';

http_response_code(200);
$secret = tg_setting('tg_webhook_secret');
$hdr    = $_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ?? '';
if ($secret === '' || !hash_equals($secret, $hdr)) { http_response_code(403); exit; }

$update = json_decode((string)file_get_contents('php://input'), true);
if (is_array($update)) tg_handle_update($update);
