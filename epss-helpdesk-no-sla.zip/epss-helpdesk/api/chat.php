<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');
$u = require_login();
$pdo = db();
$action = $_GET['action'] ?? $_POST['action'] ?? '';

function json_out($data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

try {
    switch ($action) {

        // ---------- List conversations visible to current user ----------
        case 'conversations':
            $rows = $pdo->prepare("
                SELECT c.id, c.ticket_id, c.subject, c.status, c.last_message_at,
                       t.ticket_number,
                       (SELECT body FROM chat_messages WHERE conversation_id=c.id ORDER BY id DESC LIMIT 1) AS last_body,
                       (SELECT full_name FROM users u2
                            JOIN chat_messages m ON m.sender_id=u2.id
                            WHERE m.conversation_id=c.id ORDER BY m.id DESC LIMIT 1) AS last_sender,
                       (SELECT COUNT(*) FROM chat_messages m
                            WHERE m.conversation_id=c.id
                              AND m.id > COALESCE(
                                    (SELECT last_read_at FROM chat_participants
                                     WHERE conversation_id=c.id AND user_id=?), 0)
                       ) AS unread
                FROM chat_conversations c
                JOIN chat_participants cp ON cp.conversation_id=c.id AND cp.user_id=?
                LEFT JOIN tickets t ON t.id=c.ticket_id
                ORDER BY c.last_message_at DESC
                LIMIT 100
            ");
            $rows->execute([$u['id'], $u['id']]);
            json_out(['ok' => true, 'conversations' => $rows->fetchAll()]);

        // ---------- Fetch messages in a conversation ----------
        case 'messages':
            $convId = (int)($_GET['conversation_id'] ?? 0);
            $since  = (int)($_GET['since_id'] ?? 0);
            if (!$convId) json_out(['ok'=>false,'error'=>'conversation_id required'], 400);

            // Authorization: must be a participant
            $chk = $pdo->prepare("SELECT 1 FROM chat_participants WHERE conversation_id=? AND user_id=?");
            $chk->execute([$convId, $u['id']]);
            if (!$chk->fetchColumn()) json_out(['ok'=>false,'error'=>'forbidden'], 403);

            $sql = "SELECT m.id, m.sender_id, m.body, m.attachment_id, m.created_at,
                           u.full_name AS sender_name, u.role AS sender_role
                    FROM chat_messages m JOIN users u ON u.id=m.sender_id
                    WHERE m.conversation_id=?";
            $params = [$convId];
            if ($since > 0) { $sql .= " AND m.id > ?"; $params[] = $since; }
            $sql .= " ORDER BY m.id ASC LIMIT 500";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);

            // Update last_read_at
            $pdo->prepare("UPDATE chat_participants SET last_read_at=UNIX_TIMESTAMP() WHERE conversation_id=? AND user_id=?")
                ->execute([$convId, $u['id']]);

            json_out(['ok' => true, 'messages' => $stmt->fetchAll()]);

        // ---------- Send a message ----------
        case 'send':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf($_POST['csrf'] ?? null))
                json_out(['ok'=>false,'error'=>'bad csrf'], 400);

            $convId = (int)($_POST['conversation_id'] ?? 0);
            $body   = trim($_POST['body'] ?? '');
            if (!$convId || $body === '') json_out(['ok'=>false,'error'=>'empty'], 400);
            if (mb_strlen($body) > 4000)   json_out(['ok'=>false,'error'=>'too long'], 400);

            $chk = $pdo->prepare("SELECT 1 FROM chat_participants WHERE conversation_id=? AND user_id=?");
            $chk->execute([$convId, $u['id']]);
            if (!$chk->fetchColumn()) json_out(['ok'=>false,'error'=>'forbidden'], 403);

            $pdo->beginTransaction();
            try {
                $pdo->prepare("INSERT INTO chat_messages (conversation_id,sender_id,body) VALUES (?,?,?)")
                    ->execute([$convId, $u['id'], $body]);
                $msgId = (int)$pdo->lastInsertId();
                $pdo->prepare("UPDATE chat_conversations SET last_message_at=NOW() WHERE id=?")
                    ->execute([$convId]);

                // Notify other participants
                $parts = $pdo->prepare("SELECT user_id FROM chat_participants WHERE conversation_id=? AND user_id<>?");
                $parts->execute([$convId, $u['id']]);
                foreach ($parts->fetchAll() as $p) {
                    notify((int)$p['user_id'], null, 'New Chat Message',
                        $u['full_name'] . ': ' . mb_substr($body, 0, 80), 'chat');
                }
                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }
            json_out(['ok'=>true, 'id'=>$msgId]);

        // ---------- Start a new conversation ----------
        case 'start':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf($_POST['csrf'] ?? null))
                json_out(['ok'=>false,'error'=>'bad csrf'], 400);

            $ticketId = (int)($_POST['ticket_id'] ?? 0);
            $subject  = trim($_POST['subject'] ?? '');
            $invitee  = (int)($_POST['invitee_id'] ?? 0);

            if (!$subject) $subject = $ticketId ? ('Chat on ticket') : 'New conversation';

            // Determine participants
            $participants = [$u['id']];
            if ($invitee && $invitee !== $u['id']) $participants[] = $invitee;

            // If tied to a ticket, auto-invite requester, TL, and assigned tech
            if ($ticketId) {
                $q = $pdo->prepare("SELECT requester_id, team_leader_id, assigned_technician_id FROM tickets WHERE id=?");
                $q->execute([$ticketId]);
                if ($row = $q->fetch()) {
                    foreach (['requester_id','team_leader_id','assigned_technician_id'] as $f) {
                        if (!empty($row[$f]) && !in_array((int)$row[$f], $participants, true)) {
                            $participants[] = (int)$row[$f];
                        }
                    }
                }
            }

            $pdo->beginTransaction();
            try {
                $pdo->prepare("INSERT INTO chat_conversations (ticket_id,subject,created_by) VALUES (?,?,?)")
                    ->execute([$ticketId ?: null, $subject, $u['id']]);
                $convId = (int)$pdo->lastInsertId();

                $ins = $pdo->prepare("INSERT INTO chat_participants (conversation_id,user_id) VALUES (?,?)");
                foreach ($participants as $pid) $ins->execute([$convId, $pid]);

                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }
            json_out(['ok'=>true, 'conversation_id'=>$convId]);

        // ---------- Unread count (for header badge) ----------
        case 'unread':
            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM chat_messages m
                JOIN chat_participants cp ON cp.conversation_id=m.conversation_id AND cp.user_id=?
                WHERE m.sender_id <> ?
                  AND m.id > COALESCE(cp.last_read_at, 0)
            ");
            $stmt->execute([$u['id'], $u['id']]);
            json_out(['ok'=>true, 'unread'=>(int)$stmt->fetchColumn()]);

        // ---------- List all users you can chat with ----------
        case 'people':
            $rows = $pdo->query("SELECT id, full_name, role FROM users WHERE status='ACTIVE' ORDER BY full_name")->fetchAll();
            json_out(['ok'=>true, 'people'=>$rows]);

        default:
            json_out(['ok'=>false,'error'=>app_error_text('E-REQ-400', 'Unknown action.'), 'code'=>'E-REQ-400'], 400);
    }
} catch (Throwable $e) {
    $info = app_exception_info($e);          // coded, user-safe; SQL text is logged, not sent
    json_out(['ok'=>false, 'error'=>'[' . $info['code'] . '] ' . $info['message'], 'code'=>$info['code'], 'ref'=>$info['ref']], $info['http']);
}
