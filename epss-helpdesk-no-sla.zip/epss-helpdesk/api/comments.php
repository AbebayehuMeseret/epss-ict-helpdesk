<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    app_fail('E-REQ-400');
}
if (!verify_csrf($_POST['csrf'] ?? null)) {
    app_fail('E-REQ-419');
}
$ticketId = (int)($_POST['ticket_id'] ?? 0);
$comment = trim($_POST['comment'] ?? '');
if (!$ticketId || $comment === '') { app_fail('E-REQ-422', 'Ticket and comment are required.'); }

// authorization: user must be able to access ticket
$ok = false;
if ($u['role'] === 'ADMIN') $ok = true;
elseif ($u['role'] === 'EMPLOYEE') {
    $s = db()->prepare("SELECT 1 FROM tickets WHERE id=? AND requester_id=?");
    $s->execute([$ticketId, $u['id']]); $ok = (bool)$s->fetchColumn();
} elseif ($u['role'] === 'TEAM_LEADER') {
    $s = db()->prepare("SELECT 1 FROM tickets WHERE id=? AND team_leader_id=?");
    $s->execute([$ticketId, $u['id']]); $ok = (bool)$s->fetchColumn();
} elseif ($u['role'] === 'ICT_STAFF') {
    $s = db()->prepare("SELECT 1 FROM tickets WHERE id=?");
    $s->execute([$ticketId]); $ok = (bool)$s->fetchColumn();
}
if (!$ok) { app_fail('E-AUTH-403'); }

db()->prepare("INSERT INTO ticket_comments (ticket_id,user_id,comment) VALUES (?,?,?)")
    ->execute([$ticketId, $u['id'], $comment]);

record_history($ticketId,(int)$u['id'],null,null,'Comment Added',$comment);
header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? BASE_URL . '/public/index.php'));