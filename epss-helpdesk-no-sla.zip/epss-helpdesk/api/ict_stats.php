<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');
header('Cache-Control: no-store');

$u = require_login();

if ($u['role'] !== 'ICT_STAFF') {
    app_fail('E-AUTH-403');
}

$pdo  = db();
$myId = (int)$u['id'];

/* Same definitions as the ICT dashboard scorecards, so the 10-second refresh
   never contradicts the numbers rendered on first paint. */
$received = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status='APPROVED_FOR_ICT'")->fetchColumn();

$approved = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE team_leader_approved_at IS NOT NULL")->fetchColumn();

$inProgress = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status IN ('ASSIGNED_TO_ICT','IN_PROGRESS')")->fetchColumn();

$waiting = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status IN ('WAITING_FOR_INFORMATION','WAITING_FOR_PARTS')")->fetchColumn();

$pendingVerify = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status='RESOLVED_PENDING_REQUESTER_CONFIRMATION'")->fetchColumn();

$solved = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status IN ('RESOLVED_PENDING_REQUESTER_CONFIRMATION','CLOSED') OR resolved_at IS NOT NULL")->fetchColumn();

$closed = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status='CLOSED'")->fetchColumn();

$myAssigned = (int)$pdo->query("
    SELECT COUNT(*) FROM tickets
    WHERE assigned_technician_id = $myId
      AND status NOT IN ('CLOSED','REJECTED','CANCELLED')
")->fetchColumn();

$myToday = (int)$pdo->query("
    SELECT COUNT(*) FROM tickets
    WHERE assigned_technician_id = $myId
      AND resolved_at IS NOT NULL AND DATE(resolved_at) = CURDATE()
")->fetchColumn();

$latest = $pdo->query("
    SELECT id, ticket_number, subject, created_at
    FROM tickets
    WHERE status = 'APPROVED_FOR_ICT'
    ORDER BY created_at DESC
    LIMIT 1
")->fetch() ?: null;

echo json_encode([
    'ok'             => true,
    'received'       => $received,
    'approved'       => $approved,
    'in_progress'    => $inProgress,
    'waiting'        => $waiting,
    'pending_verify' => $pendingVerify,
    'total_solved'   => $solved,
    'closed'         => $closed,
    'my_assigned'    => $myAssigned,
    'my_today'       => $myToday,
    'latest'         => $latest,
    'ts'             => time(),
]);
