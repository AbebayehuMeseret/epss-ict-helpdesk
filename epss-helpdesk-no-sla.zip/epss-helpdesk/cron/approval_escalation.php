<?php
/**
 * Cron: forward tickets whose Team Leader did not respond within the allowed
 * time (15 minutes by default) to ICT. Safe to run every minute.
 *
 * Windows (XAMPP):
 *   schtasks /create /tn "EPSS TL bypass" /tr "C:\xampp\php\php.exe C:\xampp\htdocs\epss-helpdesk\cron\approval_escalation.php" /sc minute /mo 1
 * Linux:
 *   * * * * * php /path/to/epss-helpdesk/cron/approval_escalation.php
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/escalation.php';

$forwarded = escalate_stale_approvals(true);
echo date('Y-m-d H:i:s') . " — forwarded {$forwarded} ticket(s)\n";
