<?php
/**
 * Cron: close tickets whose requester never confirmed the ICT resolution
 * (30 minutes by default). Safe to run every minute.
 *
 * Windows (XAMPP):
 *   schtasks /create /tn "EPSS confirm auto-close" /tr "C:\xampp\php\php.exe C:\xampp\htdocs\epss-helpdesk\cron\confirmation_escalation.php" /sc minute /mo 1
 * Linux:
 *   * * * * * php /path/to/epss-helpdesk/cron/confirmation_escalation.php
 *
 * Not required if the Telegram worker or any helpdesk page is running: both run
 * the same sweep, self-throttled to once a minute.
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/escalation.php';

$closed = escalate_stale_confirmations(true);
echo date('Y-m-d H:i:s') . " — auto-closed {$closed} ticket(s) without requester confirmation\n";
