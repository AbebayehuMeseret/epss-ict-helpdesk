<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/pm.php';

$result = pm_send_quarterly_reminders();
echo date('Y-m-d H:i:s') . " — " . json_encode($result) . "\n";