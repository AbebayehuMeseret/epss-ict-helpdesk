<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('EMPLOYEE');
$pageTitle = 'My Dashboard';

$pdo = db();
$uid = (int)$u['id'];

/* ===================== KPI counts ===================== */
$stats = [
    'total'    => (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE requester_id=$uid")->fetchColumn(),
    'pending'  => (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE requester_id=$uid AND status='PENDING_TEAM_LEADER_APPROVAL'")->fetchColumn(),
    'progress' => (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE requester_id=$uid AND status IN ('APPROVED_FOR_ICT','ASSIGNED_TO_ICT','IN_PROGRESS')")->fetchColumn(),
    'resolved' => (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE requester_id=$uid AND status='RESOLVED_PENDING_REQUESTER_CONFIRMATION'")->fetchColumn(),
    'closed'   => (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE requester_id=$uid AND status='CLOSED'")->fetchColumn(),
];

/* ===================== Recent tickets ===================== */
$recent = $pdo->query("
    SELECT t.*, c.category_name, p.name AS priority_name, p.color AS priority_color
    FROM tickets t
    JOIN categories c ON c.id = t.category_id
    JOIN priorities p ON p.id = t.priority_id
    WHERE t.requester_id = $uid
    ORDER BY t.created_at DESC
    LIMIT 5
")->fetchAll();

/* ===================== Chart data (last 6 months) ===================== */
$chartRows = $pdo->query("
    SELECT DATE_FORMAT(created_at,'%Y-%m') ym, COUNT(*) cnt
    FROM tickets
    WHERE requester_id = $uid
      AND created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY ym ORDER BY ym
")->fetchAll();

$chartMap = [];
foreach ($chartRows as $r) $chartMap[$r['ym']] = (int)$r['cnt'];

/* Build the 6-month window ending this month */
$chartLabels = [];
$chartData   = [];
for ($i = 5; $i >= 0; $i--) {
    $ym = date('Y-m', strtotime("-$i months"));
    $chartLabels[] = $ym;
    $chartData[]   = $chartMap[$ym] ?? 0;
}

/* Priority colour → SAP hex */
function prio_hex(string $color): string {
    return match ($color) {
        'danger'    => '#aa0808',
        'warning'   => '#e76500',
        'info'      => '#0070f2',
        'primary'   => '#0057d2',
        'success'   => '#256f3a',
        'secondary' => '#5b738b',
        'dark'      => '#354a5f',
        default     => '#5b738b',
    };
}

/* Status → SAP Horizon status tone + icon */
function status_meta(string $status): array {
    return match ($status) {
        'PENDING_TEAM_LEADER_APPROVAL'              => ['Pending Approval','critical','hourglass-split'],
        'RETURNED_TO_EMPLOYEE'                      => ['Returned to You','info','arrow-return-left'],
        'APPROVED_FOR_ICT'                          => ['Approved for ICT','info','check2-circle'],
        'ASSIGNED_TO_ICT'                           => ['Assigned to ICT','info','person-check'],
        'IN_PROGRESS'                               => ['In Progress','info','tools'],
        'WAITING_FOR_INFORMATION'                   => ['Waiting for Info','neutral','pause-circle'],
        'WAITING_FOR_PARTS'                         => ['Waiting for Parts','neutral','pause-circle'],
        'WORK_COMPLETED'                            => ['Work Completed','good','check2'],
        'RESOLVED_PENDING_REQUESTER_CONFIRMATION'   => ['Confirm Resolution','critical','patch-check'],
        'RESOLVED_PENDING_TEAM_LEADER_VERIFICATION' => ['Confirm Resolution','critical','patch-check'],
        'RETURNED_TO_ICT'                           => ['Returned to ICT','critical','arrow-return-right'],
        'REJECTED'                                  => ['Rejected','bad','x-circle'],
        'CLOSED'                                    => ['Closed','good','check2-all'],
        'CANCELLED'                                 => ['Cancelled','neutral','slash-circle'],
        default                                     => [str_replace('_',' ',$status),'neutral','circle'],
    };
}

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:        #0070f2;
    --sap-brand-dark:   #0057d2;
    --sap-bg:           #f5f6f7;
    --sap-tile:         #ffffff;
    --sap-text:         #1d2d3e;
    --sap-text-muted:   #556b82;
    --sap-border:       #d9d9d9;
    --sap-border-soft:  #eaecf0;
    --sap-positive:     #256f3a;
    --sap-critical:     #e76500;
    --sap-negative:     #aa0808;
    --sap-neutral:      #5b738b;
    --sap-shadow:       0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
    --sap-shadow-hover: 0 0 0 1px rgba(34,53,72,.15), 0 8px 24px 0 rgba(34,53,72,.12);
  }

  body, .main-content {
    background: var(--sap-bg) !important;
    font-family: "72", "72full", Arial, Helvetica, sans-serif !important;
    color: var(--sap-text);
  }

  .sap-page-header {
    display: flex; align-items: flex-start; justify-content: space-between;
    margin-bottom: 1rem;
  }
  .sap-page-title { font-size: 1.625rem; font-weight: 400; margin: 0; }
  .sap-breadcrumb { font-size: .8125rem; color: var(--sap-text-muted); margin-bottom: .25rem; }

  /* SAP button */
  .sap-btn {
    display: inline-flex; align-items: center; gap: .4rem;
    font-size: .8125rem; font-weight: 500;
    border-radius: .5rem;
    padding: .5rem .9rem;
    border: 1px solid transparent;
    background: transparent;
    color: var(--sap-brand);
    cursor: pointer;
    line-height: 1;
    text-decoration: none;
    white-space: nowrap;
    transition: background .15s, box-shadow .15s, color .15s;
  }
  .sap-btn:hover { background: #eaf4ff; color: var(--sap-brand-dark); }
  .sap-btn.sap-btn-emphasized {
    background: var(--sap-brand); color: #fff;
    box-shadow: 0 1px 2px rgba(34,53,72,.15);
  }
  .sap-btn.sap-btn-emphasized:hover { background: var(--sap-brand-dark); color: #fff; }
  .sap-btn:focus-visible { outline: 2px solid var(--sap-brand); outline-offset: 2px; }

  /* SAP KPI tile */
  .sap-tile {
    background: var(--sap-tile);
    border-radius: .75rem;
    box-shadow: var(--sap-shadow);
    padding: 1rem 1.15rem;
    position: relative;
    overflow: hidden;
    height: 100%;
    transition: box-shadow .2s, transform .2s;
    opacity: 0; transform: translateY(10px);
    animation: sapFadeUp .5s cubic-bezier(.2,.8,.2,1) forwards;
  }
  .sap-tile:hover { box-shadow: var(--sap-shadow-hover); transform: translateY(-2px); }

  .sap-tile::before {
    content: ""; position: absolute; top: 0; left: 0; right: 0; height: 3px;
    background: var(--sap-brand);
  }
  .sap-tile.is-good::before     { background: var(--sap-positive); }
  .sap-tile.is-critical::before { background: var(--sap-critical); }
  .sap-tile.is-bad::before      { background: var(--sap-negative); }
  .sap-tile.is-neutral::before  { background: var(--sap-neutral); }
  .sap-tile.is-info::before     { background: var(--sap-brand); }

  .sap-tile-head {
    display: flex; align-items: center; gap: .45rem;
    font-size: .72rem; text-transform: uppercase; letter-spacing: .04em;
    color: var(--sap-text-muted); font-weight: 600;
    margin-bottom: .35rem;
  }
  .sap-tile-head .bi { font-size: .85rem; }
  .sap-tile-value {
    font-family: "72Mono", "Courier New", monospace;
    font-size: 2rem; font-weight: 600;
    line-height: 1.05; letter-spacing: -.02em;
    color: var(--sap-text);
    font-variant-numeric: tabular-nums;
  }
  .sap-tile-foot {
    font-size: .72rem; color: var(--sap-text-muted);
    margin-top: .35rem;
  }

  @keyframes sapFadeUp {
    to { opacity: 1; transform: translateY(0); }
  }
  .sap-tile:nth-child(1) { animation-delay: .00s; }
  .sap-tile:nth-child(2) { animation-delay: .06s; }
  .sap-tile:nth-child(3) { animation-delay: .12s; }
  .sap-tile:nth-child(4) { animation-delay: .18s; }
  .sap-tile:nth-child(5) { animation-delay: .24s; }

  /* SAP card */
  .sap-card {
    background: var(--sap-tile);
    border-radius: .75rem;
    box-shadow: var(--sap-shadow);
    overflow: hidden;
    height: 100%;
  }
  .sap-card-header {
    padding: .85rem 1.15rem;
    border-bottom: 1px solid var(--sap-border-soft);
    font-size: .875rem; font-weight: 600;
    display: flex; align-items: center; justify-content: space-between;
    gap: .5rem;
  }
  .sap-card-header .bi { color: var(--sap-brand); margin-right: .35rem; }
  .sap-card-body { padding: 1rem 1.15rem; }

  /* SAP table */
  table.sap-table {
    width: 100%; border-collapse: separate; border-spacing: 0;
    font-size: .8125rem; margin: 0;
  }
  table.sap-table thead th {
    background: #f5f6f7;
    border-bottom: 1px solid var(--sap-border);
    font-weight: 600; color: var(--sap-text-muted);
    text-align: left; padding: .55rem .7rem;
    white-space: nowrap;
    text-transform: uppercase;
    font-size: .68rem; letter-spacing: .04em;
  }
  table.sap-table tbody td {
    padding: .55rem .7rem;
    border-bottom: 1px solid var(--sap-border-soft);
    vertical-align: middle;
    color: var(--sap-text);
  }
  table.sap-table tbody tr:last-child td { border-bottom: 0; }
  table.sap-table tbody tr { transition: background .12s; cursor: pointer; }
  table.sap-table tbody tr:hover { background: #f8fbff; }

  /* Ticket number */
  .sap-ticket-num {
    font-family: "72Mono", "Courier New", monospace;
    font-weight: 600;
    color: var(--sap-brand);
    text-decoration: none;
    white-space: nowrap;
  }
  .sap-ticket-num:hover { color: var(--sap-brand-dark); text-decoration: underline; }

  /* Priority chip */
  .sap-prio {
    display: inline-flex; align-items: center;
    font-size: .7rem; font-weight: 600;
    padding: .15rem .55rem;
    border-radius: .75rem;
    color: #fff;
    white-space: nowrap;
  }

  /* ObjectStatus pill */
  .sap-status {
    display: inline-flex; align-items: center; gap: .25rem;
    font-size: .7rem; font-weight: 600;
    padding: .1rem .5rem;
    border-radius: .75rem;
    white-space: nowrap;
    border: 1px solid transparent;
  }
  .sap-status.is-good     { background: #f1fdf6; color: var(--sap-positive); border-color: #d6f0e0; }
  .sap-status.is-critical { background: #fff8f1; color: var(--sap-critical); border-color: #fbe0c8; }
  .sap-status.is-bad      { background: #fef4f4; color: var(--sap-negative); border-color: #f7d2d2; }
  .sap-status.is-info     { background: #eaf4ff; color: var(--sap-brand);    border-color: #cfe2f8; }
  .sap-status.is-neutral  { background: #f4f5f7; color: var(--sap-neutral);  border-color: #e4e7eb; }

  /* Empty state */
  .sap-empty {
    text-align: center; padding: 2.5rem 1rem; color: var(--sap-text-muted);
  }
  .sap-empty .bi { font-size: 2.2rem; opacity: .4; }
  .sap-empty-title { font-size: .95rem; font-weight: 600; color: var(--sap-text); margin-top: .5rem; }
  .sap-empty-hint  { font-size: .82rem; margin-top: .2rem; }

  /* Chart container */
  .sap-chart-wrap { position: relative; height: 220px; }

  @media (prefers-reduced-motion: reduce) {
    .sap-tile { animation: none !important; opacity: 1 !important; transform: none !important; }
  }
</style>

<!-- ================= Page header ================= -->
<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb">
      <i class="bi bi-house-door"></i> Home / <strong>My Dashboard</strong>
    </div>
    <h1 class="sap-page-title">Welcome, <?= e($u['full_name']) ?></h1>
  </div>
  <div class="d-flex gap-2">
    <a href="tickets.php" class="sap-btn">
      <i class="bi bi-list-ul"></i> My Tickets
    </a>
    <a href="create_ticket.php" class="sap-btn sap-btn-emphasized">
      <i class="bi bi-plus-lg"></i> New Ticket
    </a>
  </div>
</div>

<!-- ================= KPI tiles ================= -->
<div class="row g-3 mb-3">
  <?php
  $tiles = [
    ['Total Tickets',    $stats['total'],    'info',     'ticket-detailed',  'All time'],
    ['Pending Approval', $stats['pending'],  'critical', 'hourglass-split',  'Awaiting Team Leader'],
    ['In Progress',      $stats['progress'], 'info',     'tools',            'Being handled by ICT'],
    ['Resolved',         $stats['resolved'], 'critical', 'patch-check',      'Awaiting your confirmation'],
    ['Closed',           $stats['closed'],   'good',     'check2-all',       'Confirmed & closed'],
  ];
  foreach ($tiles as [$label, $val, $tone, $icon, $foot]): ?>
    <div class="col-6 col-md-4 col-lg">
      <div class="sap-tile is-<?= $tone ?>">
        <div class="sap-tile-head">
          <i class="bi bi-<?= $icon ?>"></i> <?= e($label) ?>
        </div>
        <div class="sap-tile-value" data-count="<?= (int)$val ?>">0</div>
        <div class="sap-tile-foot"><?= e($foot) ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- ================= Chart + Recent tickets ================= -->
<div class="row g-3">

  <!-- Monthly trend chart -->
  <div class="col-lg-5">
    <div class="sap-card">
      <div class="sap-card-header">
        <span><i class="bi bi-graph-up-arrow"></i> My Tickets — Last 6 Months</span>
      </div>
      <div class="sap-card-body">
        <div class="sap-chart-wrap">
          <canvas id="chartMonthly"></canvas>
        </div>
      </div>
    </div>
  </div>

  <!-- Recent tickets -->
  <div class="col-lg-7">
    <div class="sap-card">
      <div class="sap-card-header">
        <span><i class="bi bi-clock-history"></i> Recent Tickets</span>
        <a href="tickets.php" class="sap-btn" style="font-size:.75rem;padding:.3rem .55rem">
          View all <i class="bi bi-arrow-right"></i>
        </a>
      </div>

      <?php if (!$recent): ?>
        <div class="sap-empty">
          <i class="bi bi-inbox"></i>
          <div class="sap-empty-title">No tickets yet</div>
          <div class="sap-empty-hint">
            <a href="create_ticket.php" class="sap-ticket-num">Create your first ticket</a>
            to get started.
          </div>
        </div>
      <?php else: ?>
        <div class="table-responsive">
          <table class="sap-table">
            <thead>
              <tr>
                <th>Ticket #</th>
                <th>Subject</th>
                <th>Category</th>
                <th>Priority</th>
                <th>Status</th>
                <th>Created</th>
              </tr>
            </thead>
            <tbody>
            <?php foreach ($recent as $t):
                [$statusLabel, $statusTone, $statusIcon] = status_meta($t['status']);
                $hex = prio_hex($t['priority_color']);
            ?>
              <tr onclick="location.href='ticket_view.php?id=<?= (int)$t['id'] ?>';">
                <td>
                  <a class="sap-ticket-num"
                     href="ticket_view.php?id=<?= (int)$t['id'] ?>"
                     onclick="event.stopPropagation()">
                    <?= e($t['ticket_number']) ?>
                  </a>
                </td>
                <td><?= e($t['subject']) ?></td>
                <td><?= e($t['category_name']) ?></td>
                <td>
                  <span class="sap-prio" style="background:<?= $hex ?>">
                    <?= e($t['priority_name']) ?>
                  </span>
                </td>
                <td>
                  <span class="sap-status is-<?= e($statusTone) ?>">
                    <i class="bi bi-<?= e($statusIcon) ?>"></i> <?= e($statusLabel) ?>
                  </span>
                </td>
                <td>
                  <small class="text-muted">
                    <?= e(date('Y-m-d', strtotime($t['created_at']))) ?>
                  </small>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>

</div>

<script>
/* ---------- Data from PHP ---------- */
const chartLabels = <?= json_encode($chartLabels) ?>;
const chartData   = <?= json_encode($chartData) ?>;

/* ---------- SAP Horizon palette ---------- */
const SAP = {
  brand:     '#0070f2',
  brandDark: '#0057d2',
  grid:      '#e5e5e5',
  text:      '#556b82'
};

/* ---------- Count-up animation for KPI tiles ---------- */
function animateCount(el) {
  const target   = parseFloat(el.dataset.count || '0');
  const duration = 900;
  let done = false;

  const finalise = () => {
    if (done) return;
    done = true;
    clearTimeout(fallback);
    el.textContent = Math.round(target).toLocaleString();
  };

  /* The tile markup ships a literal "0". Guarantee the real count replaces it
     even when requestAnimationFrame is throttled away (hidden/background tab,
     reduced motion, print) — otherwise the dashboard shows 0 for everything. */
  const fallback = setTimeout(finalise, 1200);

  if (document.visibilityState !== 'visible' ||
      window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    finalise();
    return;
  }

  const start = performance.now();
  const tick = (now) => {
    if (done) return;
    const t = Math.min(1, (now - start) / duration);
    el.textContent = Math.round(target * (1 - Math.pow(1 - t, 3))).toLocaleString();
    if (t < 1) requestAnimationFrame(tick); else finalise();
  };
  requestAnimationFrame(tick);
}

/* ---------- Init ---------- */
document.addEventListener('DOMContentLoaded', () => {
  /* 1) Count-up numbers */
  document.querySelectorAll('.sap-tile-value[data-count]').forEach(animateCount);

  /* 2) Monthly line chart */
  if (window.Chart && document.getElementById('chartMonthly')) {
    Chart.defaults.font.family = "'72', Arial, Helvetica, sans-serif";
    Chart.defaults.font.size = 12;
    Chart.defaults.color = SAP.text;

    new Chart(document.getElementById('chartMonthly'), {
      type: 'line',
      data: {
        labels: chartLabels,
        datasets: [{
          label: 'Tickets created',
          data: chartData,
          borderColor: SAP.brand,
          backgroundColor: 'rgba(0,112,242,.12)',
          fill: true,
          tension: 0.35,
          pointRadius: 4,
          pointBackgroundColor: SAP.brand,
          pointBorderColor: '#fff',
          pointBorderWidth: 2,
          pointHoverRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: { duration: 1100, easing: 'easeOutQuart' },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: '#1d2d3e',
            titleColor: '#fff',
            bodyColor: '#fff',
            padding: 8,
            displayColors: false,
            callbacks: {
              label: ctx => ctx.parsed.y + ' ticket' + (ctx.parsed.y === 1 ? '' : 's')
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            grid: { color: SAP.grid },
            ticks: { precision: 0 }
          },
          x: {
            grid: { display: false }
          }
        }
      }
    });
  }
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
