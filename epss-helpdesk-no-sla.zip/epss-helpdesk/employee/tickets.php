<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('EMPLOYEE');
$pageTitle = 'My Tickets';

$pdo = db();
$uid = (int)$u['id'];

/* ===================== Filters ===================== */
$q       = trim($_GET['q']       ?? '');
$status  = $_GET['status']       ?? '';
$prioId  = (int)($_GET['priority_id'] ?? 0);
$catId   = (int)($_GET['category_id'] ?? 0);

/* ===================== Query ===================== */
$sql = "SELECT t.*, c.category_name,
               p.name AS priority_name, p.color AS priority_color
        FROM tickets t
        JOIN categories c ON c.id = t.category_id
        JOIN priorities p ON p.id = t.priority_id
        WHERE t.requester_id = ?";
$params = [$uid];

if ($q !== '') {
    $sql .= " AND (t.ticket_number LIKE ? OR t.subject LIKE ?)";
    array_push($params, "%$q%", "%$q%");
}
if ($status !== '') { $sql .= " AND t.status = ?";       $params[] = $status; }
if ($prioId)        { $sql .= " AND t.priority_id = ?";  $params[] = $prioId; }
if ($catId)         { $sql .= " AND t.category_id = ?";  $params[] = $catId; }

$sql .= " ORDER BY t.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$tickets = $stmt->fetchAll();

/* ===================== Filter dropdown data ===================== */
$cats = $pdo->query("SELECT id, category_name FROM categories WHERE status='ACTIVE' ORDER BY category_name")->fetchAll();
$pris = $pdo->query("SELECT id, name FROM priorities  WHERE status='ACTIVE' ORDER BY level")->fetchAll();

/* ===================== Summary pills ===================== */
$openCount     = 0;
$closedCount   = 0;
$pendingCount  = 0;

foreach ($tickets as $t) {
    if ($t['status'] === 'CLOSED') $closedCount++;
    elseif (!in_array($t['status'], ['REJECTED','CANCELLED'], true)) $openCount++;

    if ($t['status'] === 'PENDING_TEAM_LEADER_APPROVAL') $pendingCount++;

}

/* ===================== Helpers ===================== */
function status_meta(string $status): array {
    return match ($status) {
        'PENDING_TEAM_LEADER_APPROVAL'              => ['Pending Approval','critical','hourglass-split'],
        'RETURNED_TO_EMPLOYEE'                      => ['Returned to You','critical','arrow-return-left'],
        'APPROVED_FOR_ICT'                          => ['Approved for ICT','info','check2-circle'],
        'ASSIGNED_TO_ICT'                           => ['Assigned to ICT','info','person-check'],
        'IN_PROGRESS'                               => ['In Progress','info','tools'],
        'WAITING_FOR_INFORMATION'                   => ['Waiting for Info','neutral','pause-circle'],
        'WAITING_FOR_PARTS'                         => ['Waiting for Parts','neutral','pause-circle'],
        'WORK_COMPLETED'                            => ['Work Completed','good','check2'],
        'RESOLVED_PENDING_REQUESTER_CONFIRMATION'   => ['Awaiting Your Confirmation','critical','patch-check'],
        'RESOLVED_PENDING_TEAM_LEADER_VERIFICATION' => ['Awaiting Your Confirmation','critical','patch-check'],
        'RETURNED_TO_ICT'                           => ['Returned to ICT','critical','arrow-return-right'],
        'REJECTED'                                  => ['Rejected','bad','x-circle'],
        'CLOSED'                                    => ['Closed','good','check2-all'],
        'CANCELLED'                                 => ['Cancelled','neutral','slash-circle'],
        default                                     => [str_replace('_',' ',$status),'neutral','circle'],
    };
}
function prio_hex(string $c): string {
    return match ($c) {
        'danger'=>'#aa0808','warning'=>'#e76500','info'=>'#0070f2',
        'primary'=>'#0057d2','success'=>'#256f3a','secondary'=>'#5b738b',
        'dark'=>'#354a5f', default=>'#5b738b',
    };
}

include __DIR__ . '/../includes/header.php';
?>

<!-- ================= SAP Fiori Horizon theme ================= -->
<style>
  :root {
    --sap-brand:        #0070f2;
    --sap-brand-dark:   #0057d2;
    --sap-bg:           #f5f6f7;
    --sap-tile:         #ffffff;
    --sap-text:         #1d2d3e;
    --sap-text-muted:   #556b82;
    --sap-border:       #d9d9d9;
    --sap-border-soft:  #eaecf0;
    --sap-positive:     #256f3a;
    --sap-critical:     #e76500;
    --sap-negative:     #aa0808;
    --sap-neutral:      #5b738b;
    --sap-shadow:       0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
    --sap-shadow-hover: 0 0 0 1px rgba(34,53,72,.15), 0 8px 24px 0 rgba(34,53,72,.12);
  }

  body, .main-content {
    background: var(--sap-bg) !important;
    font-family: "72", "72full", Arial, Helvetica, sans-serif !important;
    color: var(--sap-text);
  }

  /* ---------- Page header ---------- */
  .sap-page-header {
    display: flex; align-items: flex-start; justify-content: space-between;
    margin-bottom: 1rem;
    flex-wrap: wrap; gap: .75rem;
  }
  .sap-page-title { font-size: 1.625rem; font-weight: 400; margin: 0; }
  .sap-breadcrumb { font-size: .8125rem; color: var(--sap-text-muted); margin-bottom: .25rem; }

  /* ---------- Status pills ---------- */
  .sap-status {
    display: inline-flex; align-items: center; gap: .3rem;
    font-size: .72rem; font-weight: 600;
    padding: .25rem .65rem;
    border-radius: .75rem;
    white-space: nowrap;
    border: 1px solid transparent;
  }
  .sap-status.is-good     { background: #f1fdf6; color: var(--sap-positive); border-color: #d6f0e0; }
  .sap-status.is-critical { background: #fff8f1; color: var(--sap-critical); border-color: #fbe0c8; }
  .sap-status.is-bad      { background: #fef4f4; color: var(--sap-negative); border-color: #f7d2d2; }
  .sap-status.is-info     { background: #eaf4ff; color: var(--sap-brand);    border-color: #cfe2f8; }
  .sap-status.is-neutral  { background: #f4f5f7; color: var(--sap-neutral);  border-color: #e4e7eb; }
  .sap-status .bi { font-size: .75rem; }

  /* ---------- Filter bar ---------- */
  .sap-filterbar {
    background: var(--sap-tile);
    border-radius: .75rem .75rem 0 0;
    box-shadow: var(--sap-shadow);
    padding: .85rem 1rem;
    border-bottom: 1px solid var(--sap-border-soft);
  }
  .sap-filterbar-row {
    display: flex; gap: .5rem; flex-wrap: wrap; align-items: flex-end;
  }
  .sap-filterbar .sap-form-label {
    font-size: .7rem; text-transform: uppercase; letter-spacing: .04em;
    color: var(--sap-text-muted); font-weight: 600; margin-bottom: .2rem;
  }
  .sap-filterbar input,
  .sap-filterbar select {
    font-size: .8125rem;
    padding: .45rem .65rem;
    border-radius: .5rem;
    border: 1px solid var(--sap-border);
    background: #fff;
    min-width: 150px;
    color: var(--sap-text);
    font-family: inherit;
  }
  .sap-filterbar select {
    appearance: none;
    background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'><path fill='%23556b82' d='M3 5l3 3 3-3z'/></svg>");
    background-repeat: no-repeat;
    background-position: right .6rem center;
    padding-right: 2rem;
  }
  .sap-filterbar input:focus,
  .sap-filterbar select:focus {
    outline: none;
    border-color: var(--sap-brand);
    box-shadow: 0 0 0 3px rgba(0,112,242,.15);
  }

  .sap-search-wrap { position: relative; flex: 1 1 260px; min-width: 220px; }
  .sap-search-wrap i {
    position: absolute; left: .7rem; top: 50%; transform: translateY(-50%);
    color: var(--sap-text-muted); font-size: .85rem; pointer-events: none;
  }
  .sap-search-wrap input { padding-left: 2.1rem !important; width: 100%; }

  /* ---------- Toolbar ---------- */
  .sap-toolbar {
    display: flex; align-items: center; justify-content: space-between;
    background: var(--sap-tile);
    padding: .5rem 1rem;
    border-bottom: 1px solid var(--sap-border-soft);
    flex-wrap: wrap; gap: .5rem;
  }
  .sap-toolbar-title {
    font-size: .875rem; font-weight: 600;
    display: flex; align-items: center; gap: .4rem;
  }
  .sap-toolbar-title .bi { color: var(--sap-brand); }
  .sap-toolbar-info { font-size: .8125rem; color: var(--sap-text-muted); }

  /* ---------- Buttons ---------- */
  .sap-btn {
    display: inline-flex; align-items: center; gap: .35rem;
    font-size: .8125rem; font-weight: 500;
    border-radius: .5rem;
    padding: .45rem .8rem;
    border: 1px solid transparent;
    background: transparent;
    color: var(--sap-brand);
    cursor: pointer;
    line-height: 1;
    text-decoration: none;
    white-space: nowrap;
    transition: background .15s, color .15s, box-shadow .15s;
    font-family: inherit;
  }
  .sap-btn:hover { background: #eaf4ff; color: var(--sap-brand-dark); }
  .sap-btn:focus-visible { outline: 2px solid var(--sap-brand); outline-offset: 2px; }
  .sap-btn.sap-btn-emphasized {
    background: var(--sap-brand); color: #fff;
    box-shadow: 0 1px 2px rgba(34,53,72,.15);
  }
  .sap-btn.sap-btn-emphasized:hover { background: var(--sap-brand-dark); color: #fff; }
  .sap-btn.sap-btn-icon { padding: .4rem .5rem; }

  /* ---------- Table wrapper ---------- */
  .sap-table-wrap {
    background: var(--sap-tile);
    border-radius: 0 0 .75rem .75rem;
    box-shadow: var(--sap-shadow);
    overflow: hidden;
  }

  /* ---------- SAP table ---------- */
  table.sap-table {
    width: 100%; border-collapse: separate; border-spacing: 0;
    font-size: .8125rem; margin: 0;
  }
  table.sap-table thead th {
    background: #f5f6f7;
    border-bottom: 1px solid var(--sap-border);
    font-weight: 600; color: var(--sap-text-muted);
    text-align: left; padding: .6rem .75rem;
    white-space: nowrap;
    text-transform: uppercase;
    font-size: .68rem; letter-spacing: .04em;
  }
  table.sap-table tbody td {
    padding: .65rem .75rem;
    border-bottom: 1px solid var(--sap-border-soft);
    vertical-align: middle;
    color: var(--sap-text);
  }
  table.sap-table tbody tr:last-child td { border-bottom: 0; }
  table.sap-table tbody tr { transition: background .12s; cursor: pointer; }
  table.sap-table tbody tr:hover { background: #f8fbff; }

  /* Ticket number */
  .sap-ticket-num {
    font-family: "72Mono", "Courier New", monospace;
    font-weight: 600;
    color: var(--sap-brand);
    text-decoration: none;
    white-space: nowrap;
  }
  .sap-ticket-num:hover { color: var(--sap-brand-dark); text-decoration: underline; }

  /* Subject cell */
  .sap-subj { font-weight: 600; color: var(--sap-text); line-height: 1.2; }
  .sap-subj-desc {
    font-size: .72rem; color: var(--sap-text-muted); margin-top: .15rem;
    max-width: 380px;
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  }

  /* Priority chip */
  .sap-prio {
    display: inline-flex; align-items: center; gap: .3rem;
    font-size: .7rem; font-weight: 600;
    padding: .15rem .55rem;
    border-radius: .75rem;
    color: #fff;
    white-space: nowrap;
  }
  .sap-prio .swatch {
    width: 6px; height: 6px; border-radius: 50%;
    background: rgba(255,255,255,.75);
  }

  /* Category chip */
  .sap-cat {
    display: inline-flex; align-items: center; gap: .3rem;
    font-size: .72rem; font-weight: 500;
    padding: .15rem .55rem;
    border-radius: .75rem;
    background: #f4f5f7; color: var(--sap-text);
    border: 1px solid #e4e7eb;
    white-space: nowrap;
  }
  .sap-cat .bi { font-size: .65rem; color: var(--sap-text-muted); }

  /* Overdue chip */
  .sap-overdue {
    display: inline-flex; align-items: center; gap: .2rem;
    font-size: .65rem; font-weight: 700;
    padding: .08rem .4rem;
    border-radius: .75rem;
    background: #fef4f4; color: var(--sap-negative);
    border: 1px solid #f7d2d2;
    margin-left: .35rem;
    white-space: nowrap;
  }

  /* ---------- Empty state ---------- */
  .sap-empty {
    text-align: center; padding: 2.75rem 1rem; color: var(--sap-text-muted);
  }
  .sap-empty .bi { font-size: 2.2rem; opacity: .4; }
  .sap-empty-title { font-size: .95rem; font-weight: 600; color: var(--sap-text); margin-top: .55rem; }
  .sap-empty-hint  { font-size: .82rem; margin-top: .25rem; }

  /* Hide DataTables default chrome — the SAP filter bar is used instead */
  .dataTables_wrapper .dataTables_length,
  .dataTables_wrapper .dataTables_filter { display: none; }
  .dataTables_wrapper .dataTables_info,
  .dataTables_wrapper .dataTables_paginate { padding: .65rem 1rem; font-size: .78rem; }
  .dataTables_wrapper .dataTables_paginate .paginate_button {
    border-radius: .35rem !important;
  }
  .dataTables_wrapper .dataTables_paginate .paginate_button.current {
    background: var(--sap-brand) !important;
    color: #fff !important;
    border-color: var(--sap-brand) !important;
  }

  @media (prefers-reduced-motion: reduce) {
    table.sap-table tbody tr, .sap-btn { transition: none !important; }
  }
</style>

<!-- ================= Page header ================= -->
<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb">
      <i class="bi bi-house-door"></i> Home / <strong>My Tickets</strong>
    </div>
    <h1 class="sap-page-title">My Tickets</h1>
  </div>
  <div class="d-flex align-items-center gap-2 flex-wrap">
    <span class="sap-status is-info">
      <i class="bi bi-ticket-detailed"></i> <?= count($tickets) ?> total
    </span>
    <span class="sap-status is-info">
      <i class="bi bi-hourglass"></i> <?= (int)$openCount ?> open
    </span>
    <span class="sap-status is-critical">
      <i class="bi bi-clock-history"></i> <?= (int)$pendingCount ?> pending
    </span>
    <span class="sap-status is-good">
      <i class="bi bi-check2-all"></i> <?= (int)$closedCount ?> closed
    </span>
  </div>
</div>

<!-- ================= Filter bar ================= -->
<div class="sap-filterbar">
  <form class="sap-filterbar-row" method="get">
    <div class="sap-search-wrap">
      <i class="bi bi-search"></i>
      <input name="q" class="form-control"
             placeholder="Search ticket # or subject…"
             value="<?= e($q) ?>">
    </div>

    <div>
      <label class="sap-form-label d-block">Status</label>
      <select name="status">
        <option value="">All statuses</option>
        <?php foreach ([
          'PENDING_TEAM_LEADER_APPROVAL',
          'RETURNED_TO_EMPLOYEE',
          'APPROVED_FOR_ICT',
          'IN_PROGRESS',
          'WAITING_FOR_INFORMATION',
          'WAITING_FOR_PARTS',
          'RESOLVED_PENDING_REQUESTER_CONFIRMATION',
          'CLOSED',
          'REJECTED',
        ] as $s): ?>
          <option value="<?= $s ?>" <?= $status === $s ? 'selected' : '' ?>>
            <?= e(str_replace('_',' ', $s)) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div>
      <label class="sap-form-label d-block">Priority</label>
      <select name="priority_id">
        <option value="">All priorities</option>
        <?php foreach ($pris as $p): ?>
          <option value="<?= (int)$p['id'] ?>" <?= $prioId == $p['id'] ? 'selected' : '' ?>>
            <?= e($p['name']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div>
      <label class="sap-form-label d-block">Category</label>
      <select name="category_id">
        <option value="">All categories</option>
        <?php foreach ($cats as $c): ?>
          <option value="<?= (int)$c['id'] ?>" <?= $catId == $c['id'] ? 'selected' : '' ?>>
            <?= e($c['category_name']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="d-flex gap-1">
      <button class="sap-btn sap-btn-emphasized">
        <i class="bi bi-funnel"></i> Apply
      </button>
      <?php if ($q || $status || $prioId || $catId): ?>
        <a class="sap-btn" href="tickets.php">
          <i class="bi bi-x-circle"></i> Clear
        </a>
      <?php endif; ?>
    </div>
  </form>
</div>

<!-- ================= Toolbar ================= -->
<div class="sap-toolbar">
  <div class="sap-toolbar-title">
    <i class="bi bi-list-ul"></i> Ticket List
    <span class="sap-toolbar-info">
      · <?= count($tickets) ?> row<?= count($tickets) === 1 ? '' : 's' ?>
      <?= ($q || $status || $prioId || $catId) ? ' (filtered)' : '' ?>
    </span>
  </div>
  <a href="create_ticket.php" class="sap-btn sap-btn-emphasized">
    <i class="bi bi-plus-lg"></i> New Ticket
  </a>
</div>

<!-- ================= Table ================= -->
<div class="sap-table-wrap">
  <?php if (!$tickets): ?>
    <div class="sap-empty">
      <i class="bi bi-inbox"></i>
      <div class="sap-empty-title">
        <?= ($q || $status || $prioId || $catId)
            ? 'No tickets match the current filters'
            : 'No tickets yet' ?>
      </div>
      <div class="sap-empty-hint">
        <?php if ($q || $status || $prioId || $catId): ?>
          <a class="sap-ticket-num" href="tickets.php">Clear filters</a>
          to see all your tickets.
        <?php else: ?>
          <a class="sap-ticket-num" href="create_ticket.php">Create your first ticket</a>
          to get started.
        <?php endif; ?>
      </div>
    </div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="sap-table" id="myTickets">
        <thead>
          <tr>
            <th>Ticket #</th>
            <th>Subject</th>
            <th>Category</th>
            <th>Priority</th>
            <th>Status</th>
            <th>Created</th>
            <th style="text-align:right;"></th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($tickets as $t):
            [$label, $tone, $icon] = status_meta($t['status']);
            $hex    = prio_hex($t['priority_color']);
        ?>
          <tr onclick="if(!event.target.closest('a')) location.href='ticket_view.php?id=<?= (int)$t['id'] ?>';">
            <td>
              <a class="sap-ticket-num"
                 href="ticket_view.php?id=<?= (int)$t['id'] ?>"
                 onclick="event.stopPropagation()">
                <?= e($t['ticket_number']) ?>
              </a>
            </td>
            <td>
              <div class="sap-subj"><?= e($t['subject']) ?></div>
              <?php if (!empty($t['description'])): ?>
                <div class="sap-subj-desc" title="<?= e($t['description']) ?>">
                  <?= e($t['description']) ?>
                </div>
              <?php endif; ?>
            </td>
            <td>
              <span class="sap-cat">
                <i class="bi bi-tag"></i> <?= e($t['category_name']) ?>
              </span>
            </td>
            <td>
              <span class="sap-prio" style="background:<?= e($hex) ?>">
                <span class="swatch"></span> <?= e($t['priority_name']) ?>
              </span>
            </td>
            <td>
              <span class="sap-status is-<?= e($tone) ?>">
                <i class="bi bi-<?= e($icon) ?>"></i> <?= e($label) ?>
              </span>
            </td>
            <td>
              <small class="text-muted">
                <?= e(date('Y-m-d H:i', strtotime($t['created_at']))) ?>
              </small>
            </td>
            <td style="text-align:right;">
              <a class="sap-btn sap-btn-icon"
                 title="Open ticket"
                 href="ticket_view.php?id=<?= (int)$t['id'] ?>"
                 onclick="event.stopPropagation()">
                <i class="bi bi-chevron-right"></i>
              </a>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<script>
/* DataTables — sorting + pagination only.
   Searching and filtering are handled server-side via the SAP filter bar. */
document.addEventListener('DOMContentLoaded', function () {
  if (window.jQuery && $.fn.dataTable && document.getElementById('myTickets')) {
    const $t = jQuery('#myTickets');
    if (!$.fn.dataTable.isDataTable($t)) {
      $t.DataTable({
        paging: true,
        pageLength: 25,
        lengthChange: false,
        searching: false,
        info: true,
        order: [],
        columnDefs: [
          { orderable: false, targets: [0, 1, 5, 6] }
        ],
        language: {
          info: 'Showing _START_ to _END_ of _TOTAL_ tickets',
          infoEmpty: 'No tickets to show',
          infoFiltered: '',
          zeroRecords: 'No matching tickets',
          paginate: { previous: '‹', next: '›' },
          emptyTable: 'No tickets yet'
        }
      });
    }
  }
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
