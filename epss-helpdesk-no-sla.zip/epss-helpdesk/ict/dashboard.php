<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('ICT_STAFF');
$pageTitle = 'ICT Dashboard';
$pdo = db();
$myId = (int)$u['id'];

/* =========================================================
   1. WORKFLOW SCORECARDS
   ========================================================= */
$received      = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status='APPROVED_FOR_ICT'")->fetchColumn();
$approved      = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE team_leader_approved_at IS NOT NULL")->fetchColumn();
$inProgress    = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status IN ('ASSIGNED_TO_ICT','IN_PROGRESS')")->fetchColumn();
$totalWaiting  = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status IN ('WAITING_FOR_INFORMATION','WAITING_FOR_PARTS')")->fetchColumn();
$pendingConfirm = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status='RESOLVED_PENDING_REQUESTER_CONFIRMATION'")->fetchColumn();
$totalSolved   = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status IN ('RESOLVED_PENDING_REQUESTER_CONFIRMATION','CLOSED') OR resolved_at IS NOT NULL")->fetchColumn();
$closed        = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status='CLOSED'")->fetchColumn();

$myAssigned = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE assigned_technician_id=$myId AND status NOT IN ('CLOSED','REJECTED','CANCELLED')")->fetchColumn();
$myToday    = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE assigned_technician_id=$myId AND resolved_at IS NOT NULL AND DATE(resolved_at)=CURDATE()")->fetchColumn();

/* =========================================================
   2. AVERAGE RESOLUTION TIME
   ========================================================= */
$avg = $pdo->query("SELECT AVG(TIMESTAMPDIFF(MINUTE, ict_started_at, closed_at)) FROM tickets WHERE closed_at IS NOT NULL AND ict_started_at IS NOT NULL")->fetchColumn();
$avgHrs = $avg ? round($avg / 60, 1) : 0;

/* =========================================================
   3. CHART DATA
   ========================================================= */
$byStatus = $pdo->query("
    SELECT status, COUNT(*) cnt
    FROM tickets
    WHERE status IN (
        'APPROVED_FOR_ICT','ASSIGNED_TO_ICT','IN_PROGRESS',
        'WAITING_FOR_INFORMATION','WAITING_FOR_PARTS',
        'RESOLVED_PENDING_REQUESTER_CONFIRMATION',
        'RETURNED_TO_ICT','CLOSED'
    )
    GROUP BY status ORDER BY cnt DESC
")->fetchAll();

$byCat = $pdo->query("
    SELECT c.category_name, COUNT(t.id) cnt
    FROM categories c
    LEFT JOIN tickets t ON t.category_id = c.id
      AND t.status NOT IN ('PENDING_TEAM_LEADER_APPROVAL','RETURNED_TO_EMPLOYEE','REJECTED','CANCELLED')
    GROUP BY c.id HAVING cnt > 0 ORDER BY cnt DESC
")->fetchAll();

$byPriority = $pdo->query("
    SELECT p.name, p.color, COUNT(t.id) cnt
    FROM priorities p
    LEFT JOIN tickets t ON t.priority_id = p.id
      AND t.status NOT IN ('PENDING_TEAM_LEADER_APPROVAL','RETURNED_TO_EMPLOYEE','REJECTED','CANCELLED')
    GROUP BY p.id HAVING cnt > 0 ORDER BY p.level
")->fetchAll();

$createdRows = $pdo->query("
    SELECT DATE_FORMAT(team_leader_approved_at,'%Y-%m') ym, COUNT(*) cnt
    FROM tickets
    WHERE team_leader_approved_at IS NOT NULL
      AND team_leader_approved_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
    GROUP BY ym ORDER BY ym
")->fetchAll();
$closedRows = $pdo->query("
    SELECT DATE_FORMAT(closed_at,'%Y-%m') ym, COUNT(*) cnt
    FROM tickets
    WHERE closed_at IS NOT NULL
      AND closed_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
    GROUP BY ym ORDER BY ym
")->fetchAll();

$createdMap = []; foreach ($createdRows as $r) $createdMap[$r['ym']] = (int)$r['cnt'];
$closedMap  = []; foreach ($closedRows  as $r) $closedMap[$r['ym']]  = (int)$r['cnt'];

$allMonths = array_values(array_unique(array_merge(array_keys($createdMap), array_keys($closedMap))));
sort($allMonths);
$createdSeries = array_map(fn($m) => $createdMap[$m] ?? 0, $allMonths);
$closedSeries  = array_map(fn($m) => $closedMap[$m]  ?? 0, $allMonths);

$topTechs = $pdo->query("
    SELECT u.full_name, COUNT(t.id) cnt
    FROM users u
    JOIN tickets t ON t.assigned_technician_id = u.id
    WHERE t.status IN ('RESOLVED_PENDING_REQUESTER_CONFIRMATION','CLOSED')
       OR t.resolved_at IS NOT NULL
    GROUP BY u.id ORDER BY cnt DESC LIMIT 5
")->fetchAll();

$avgByCat = $pdo->query("
    SELECT c.category_name,
           AVG(TIMESTAMPDIFF(MINUTE, t.ict_started_at, t.closed_at)) AS avg_min
    FROM categories c
    JOIN tickets t ON t.category_id = c.id
    WHERE t.closed_at IS NOT NULL AND t.ict_started_at IS NOT NULL
    GROUP BY c.id ORDER BY c.category_name
")->fetchAll();
$radarLabels = array_map(fn($r) => $r['category_name'], $avgByCat);
$radarData   = array_map(fn($r) => round(((float)$r['avg_min']) / 60, 2), $avgByCat);

/* =========================================================
   4. LIST DATA
   ========================================================= */
$unassigned = $pdo->query("
    SELECT t.*, c.category_name, p.name AS priority_name, p.color AS priority_color,
           req.full_name AS requester_name
    FROM tickets t
    JOIN categories c ON c.id = t.category_id
    JOIN priorities p ON p.id = t.priority_id
    JOIN users req    ON req.id = t.requester_id
    WHERE t.status = 'APPROVED_FOR_ICT'
    ORDER BY p.level DESC, t.created_at
    LIMIT 6
")->fetchAll();

$myActive = $pdo->query("
    SELECT t.*, c.category_name, p.name AS priority_name, p.color AS priority_color,
           req.full_name AS requester_name
    FROM tickets t
    JOIN categories c ON c.id = t.category_id
    JOIN priorities p ON p.id = t.priority_id
    JOIN users req    ON req.id = t.requester_id
    WHERE t.assigned_technician_id = $myId
      AND t.status NOT IN ('CLOSED','REJECTED','CANCELLED')
    ORDER BY FIELD(t.status, 'IN_PROGRESS','ASSIGNED_TO_ICT','WAITING_FOR_INFORMATION','WAITING_FOR_PARTS','RETURNED_TO_ICT','RESOLVED_PENDING_REQUESTER_CONFIRMATION'),
             p.level DESC, t.created_at
    LIMIT 8
")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:#0070f2; --sap-brand-dark:#0057d2;
    --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500;
    --sap-negative:#aa0808; --sap-neutral:#5b738b;
    --sap-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
    --sap-shadow-hover: 0 0 0 1px rgba(34,53,72,.15), 0 8px 24px 0 rgba(34,53,72,.12);
  }
  body, .main-content { background: var(--sap-bg) !important;
    font-family: "72","72full",Arial,Helvetica,sans-serif !important; color: var(--sap-text); }

  .sap-page-header { display:flex; justify-content:space-between; align-items:flex-start;
    margin-bottom:1rem; flex-wrap:wrap; gap:.75rem; }
  .sap-page-title { font-size:1.625rem; font-weight:400; margin:0; }
  .sap-breadcrumb { font-size:.8125rem; color:var(--sap-text-muted); margin-bottom:.25rem; }

  .sap-status { display:inline-flex; align-items:center; gap:.3rem;
    font-size:.72rem; font-weight:600; padding:.25rem .65rem;
    border-radius:.75rem; white-space:nowrap; border:1px solid transparent; }
  .sap-status.is-info     { background:#eaf4ff; color:var(--sap-brand);    border-color:#cfe2f8; }
  .sap-status.is-critical { background:#fff8f1; color:var(--sap-critical); border-color:#fbe0c8; }
  .sap-status.is-good     { background:#f1fdf6; color:var(--sap-positive); border-color:#d6f0e0; }
  .sap-status.is-bad      { background:#fef4f4; color:var(--sap-negative); border-color:#f7d2d2; }
  .sap-status.is-neutral  { background:#f4f5f7; color:var(--sap-neutral);  border-color:#e4e7eb; }

  .sap-tile {
    background:var(--sap-tile); border-radius:.75rem; box-shadow:var(--sap-shadow);
    padding:1rem 1.15rem; position:relative; overflow:hidden; height:100%;
    transition: box-shadow .2s, transform .2s;
    text-decoration:none; color:var(--sap-text); display:block;
    opacity:0; transform: translateY(10px);
    animation: sapFadeUp .5s cubic-bezier(.2,.8,.2,1) forwards;
  }
  .sap-tile:hover { box-shadow: var(--sap-shadow-hover); transform: translateY(-2px); color:var(--sap-text); }
  .sap-tile::before { content:""; position:absolute; top:0; left:0; right:0; height:3px; background:var(--sap-brand); }
  .sap-tile.is-critical::before { background: var(--sap-critical); }
  .sap-tile.is-good::before     { background: var(--sap-positive); }
  .sap-tile.is-bad::before      { background: var(--sap-negative); }
  .sap-tile.is-neutral::before  { background: var(--sap-neutral); }
  .sap-tile-head { display:flex; align-items:center; gap:.45rem; font-size:.72rem;
    text-transform:uppercase; letter-spacing:.04em; color:var(--sap-text-muted);
    font-weight:600; margin-bottom:.35rem; }
  .sap-tile-value { font-family:"72Mono","Courier New",monospace; font-size:2rem;
    font-weight:600; line-height:1.05; font-variant-numeric: tabular-nums;
    transition: color .3s; }
  .sap-tile-foot { font-size:.72rem; color:var(--sap-text-muted); margin-top:.35rem; }

  /* Green flash when a scorecard value increases */
  @keyframes scorecardFlash {
    0%   { color: #256f3a; transform: scale(1); }
    50%  { color: #256f3a; transform: scale(1.15); }
    100% { color: inherit; transform: scale(1); }
  }
  .sap-tile-value.flash { animation: scorecardFlash 1.2s ease-out; }

  @keyframes sapFadeUp { to { opacity:1; transform: translateY(0); } }
  .sap-tile:nth-child(1) { animation-delay: .00s; }
  .sap-tile:nth-child(2) { animation-delay: .04s; }
  .sap-tile:nth-child(3) { animation-delay: .08s; }
  .sap-tile:nth-child(4) { animation-delay: .12s; }
  .sap-tile:nth-child(5) { animation-delay: .16s; }
  .sap-tile:nth-child(6) { animation-delay: .20s; }
  .sap-tile:nth-child(7) { animation-delay: .24s; }
  .sap-tile:nth-child(8) { animation-delay: .28s; }

  .sap-card { background:var(--sap-tile); border-radius:.75rem;
    box-shadow:var(--sap-shadow); overflow:hidden; height:100%; margin-bottom:1rem; }
  .sap-card-header { padding:.85rem 1.15rem; border-bottom:1px solid var(--sap-border-soft);
    font-size:.875rem; font-weight:600; display:flex; align-items:center; justify-content:space-between; gap:.5rem; }
  .sap-card-header .bi { color: var(--sap-brand); margin-right: .4rem; }
  .sap-card-body { padding:1rem 1.15rem; }
  .sap-chart-wrap { position: relative; height: 260px; }

  .sap-section-label {
    font-size:.75rem; text-transform:uppercase; letter-spacing:.06em;
    color: var(--sap-brand); font-weight:700;
    margin: 1rem 0 .5rem;
    display:flex; align-items:center; gap:.4rem;
  }
  .sap-section-label::before { content:""; display:inline-block; width:3px; height:12px;
    background: var(--sap-brand); border-radius:2px; }

  table.sap-table { width:100%; border-collapse:separate; border-spacing:0;
    font-size:.8125rem; margin:0; }
  table.sap-table thead th { background:#f5f6f7; border-bottom:1px solid var(--sap-border);
    font-weight:600; color:var(--sap-text-muted); text-align:left;
    padding:.55rem .7rem; text-transform:uppercase; font-size:.68rem; letter-spacing:.04em; }
  table.sap-table tbody td { padding:.6rem .7rem;
    border-bottom:1px solid var(--sap-border-soft); vertical-align:middle; }
  table.sap-table tbody tr:last-child td { border-bottom:0; }
  table.sap-table tbody tr:hover { background:#f8fbff; }
  table.sap-table tbody tr { cursor: pointer; }
  .sap-ticket-num { font-family:"72Mono","Courier New",monospace; font-weight:600;
    color: var(--sap-brand); text-decoration:none; }
  .sap-ticket-num:hover { color: var(--sap-brand-dark); text-decoration:underline; }
  .sap-prio { display:inline-flex; align-items:center;
    font-size:.7rem; font-weight:600; padding:.15rem .55rem;
    border-radius:.75rem; color:#fff; white-space:nowrap; }
  .sap-empty { text-align:center; padding:1.5rem 1rem; color: var(--sap-text-muted); font-size:.82rem; }

  .sap-status-pill { display:inline-flex; align-items:center; gap:.25rem;
    font-size:.7rem; font-weight:600; padding:.1rem .5rem;
    border-radius:.75rem; white-space:nowrap; border:1px solid transparent; }
  .sap-status-pill.is-good     { background:#f1fdf6; color:var(--sap-positive); border-color:#d6f0e0; }
  .sap-status-pill.is-critical { background:#fff8f1; color:var(--sap-critical); border-color:#fbe0c8; }
  .sap-status-pill.is-bad      { background:#fef4f4; color:var(--sap-negative); border-color:#f7d2d2; }
  .sap-status-pill.is-info     { background:#eaf4ff; color:var(--sap-brand);    border-color:#cfe2f8; }
  .sap-status-pill.is-neutral  { background:#f4f5f7; color:var(--sap-neutral);  border-color:#e4e7eb; }

  .sap-progress { height:6px; border-radius:3px; background:#e5e5e5; overflow:hidden; margin-top:.5rem; }
  .sap-progress > span { display:block; height:100%; width:0;
    transition: width 1.2s cubic-bezier(.2,.8,.2,1); }

  @media (prefers-reduced-motion: reduce) {
    .sap-tile { animation: none !important; opacity: 1 !important; transform: none !important; }
    .sap-progress > span { transition: none !important; }
    .sap-tile-value.flash { animation: none !important; }
  }

  /* ---------- ICT new-ticket toast ---------- */
  @keyframes ictToastIn {
    from { opacity: 0; transform: translateX(20px); }
    to   { opacity: 1; transform: translateX(0); }
  }
</style>

<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb"><i class="bi bi-house-door"></i> Home / <strong>ICT Dashboard</strong></div>
    <h1 class="sap-page-title">ICT Dashboard</h1>
  </div>
  <div class="d-flex gap-2 flex-wrap">
    <span class="sap-status is-info"><i class="bi bi-tools"></i> <?= e($u['full_name']) ?></span>
    <span class="sap-status is-good" id="liveIndicator">
      <i class="bi bi-circle-fill" style="font-size:.5rem"></i> Live · refreshes every 10s
    </span>
  </div>
</div>

<!-- ================= PIPELINE SCORECARDS ================= -->
<div class="sap-section-label">Ticket Workflow Pipeline</div>
<div class="row g-3 mb-3">
  <div class="col-6 col-md-4 col-lg">
    <a href="tickets.php" class="sap-tile is-critical">
      <div class="sap-tile-head"><i class="bi bi-inbox-fill"></i> Received</div>
      <div class="sap-tile-value" id="kpi-received" data-count="<?= (int)$received ?>">0</div>
      <div class="sap-tile-foot">In queue, awaiting ICT</div>
    </a>
  </div>
  <div class="col-6 col-md-4 col-lg">
    <a href="tickets.php" class="sap-tile is-info">
      <div class="sap-tile-head"><i class="bi bi-check2-circle"></i> Approved</div>
      <div class="sap-tile-value" id="kpi-approved" data-count="<?= (int)$approved ?>">0</div>
      <div class="sap-tile-foot">Approved by TL</div>
    </a>
  </div>
  <div class="col-6 col-md-4 col-lg">
    <a href="tickets.php" class="sap-tile is-info">
      <div class="sap-tile-head"><i class="bi bi-tools"></i> In Progress</div>
      <div class="sap-tile-value" id="kpi-inprogress" data-count="<?= (int)$inProgress ?>">0</div>
      <div class="sap-tile-foot">Being worked on</div>
    </a>
  </div>
  <div class="col-6 col-md-4 col-lg">
    <a href="tickets.php" class="sap-tile is-neutral">
      <div class="sap-tile-head"><i class="bi bi-pause-circle"></i> Waiting</div>
      <div class="sap-tile-value" id="kpi-waiting" data-count="<?= (int)$totalWaiting ?>">0</div>
      <div class="sap-tile-foot">Blocked on info/parts</div>
    </a>
  </div>
  <div class="col-6 col-md-4 col-lg">
    <a href="tickets.php" class="sap-tile is-critical">
      <div class="sap-tile-head"><i class="bi bi-patch-check"></i> Pending Confirm</div>
      <div class="sap-tile-value" id="kpi-pendingverify" data-count="<?= (int)$pendingConfirm ?>">0</div>
      <div class="sap-tile-foot">Awaiting requester confirmation</div>
    </a>
  </div>
</div>

<div class="row g-3 mb-3">
  <div class="col-6 col-md-3">
    <a href="resolution.php" class="sap-tile is-good">
      <div class="sap-tile-head"><i class="bi bi-check2-all"></i> Total Solved</div>
      <div class="sap-tile-value" id="kpi-solved" data-count="<?= (int)$totalSolved ?>">0</div>
      <div class="sap-tile-foot">Resolved or closed by ICT</div>
    </a>
  </div>
  <div class="col-6 col-md-3">
    <a href="resolution.php" class="sap-tile is-good">
      <div class="sap-tile-head"><i class="bi bi-check-circle-fill"></i> Closed</div>
      <div class="sap-tile-value" id="kpi-closed" data-count="<?= (int)$closed ?>">0</div>
      <div class="sap-tile-foot">Confirmed by requester &amp; closed</div>
    </a>
  </div>
  <div class="col-6 col-md-3">
    <a href="assigned.php" class="sap-tile is-info">
      <div class="sap-tile-head"><i class="bi bi-person-check"></i> Assigned to Me</div>
      <div class="sap-tile-value" id="kpi-myassigned" data-count="<?= (int)$myAssigned ?>">0</div>
      <div class="sap-tile-foot">
        My open tickets ·
        <span id="myTodayCount"><?= (int)$myToday ?></span> solved today
      </div>
    </a>
  </div>
</div>

<!-- ================= AVG RESOLUTION ================= -->
<div class="sap-section-label">Resolution Time</div>
<div class="row g-3 mb-3">
  <div class="col-lg-6">
    <div class="sap-card h-100">
      <div class="sap-card-header">
        <span><i class="bi bi-clock-history"></i> Average Resolution Time</span>
        <span class="sap-status is-info"><i class="bi bi-stopwatch"></i> Hours</span>
      </div>
      <div class="sap-card-body">
        <div style="display:flex;align-items:baseline;gap:.5rem">
          <div style="font-family:'72Mono','Courier New',monospace;font-size:2rem;font-weight:600"
               data-count="<?= $avgHrs ?>" data-decimals="1">0</div>
          <div class="text-muted small">hrs</div>
        </div>
        <div class="small text-muted mt-1">
          Measured from ICT start to ticket closure.
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ================= UNASSIGNED QUEUE ================= -->
<div class="sap-section-label">Unassigned Queue — Ready to Accept</div>
<div class="row g-3 mb-3">
  <div class="col-12">
    <div class="sap-card">
      <div class="sap-card-header">
        <span><i class="bi bi-inbox-fill text-primary"></i> Received (<span id="queueCount"><?= count($unassigned) ?></span>)</span>
        <a href="tickets.php" class="sap-status is-info" style="text-decoration:none">
          <i class="bi bi-arrow-right"></i> Open full queue
        </a>
      </div>
      <div class="sap-card-body p-0" id="queueBody">
        <?php if (!$unassigned): ?>
          <div class="sap-empty">No tickets waiting in the unassigned queue.</div>
        <?php else: ?>
          <div class="table-responsive">
            <table class="sap-table">
              <thead>
                <tr><th>Ticket #</th><th>Subject</th><th>Requester</th><th>Category</th><th>Priority</th><th>Created</th><th></th></tr>
              </thead>
              <tbody>
              <?php foreach ($unassigned as $t):
                  $hex = match ($t['priority_color']) {
                      'danger'=>'#aa0808','warning'=>'#e76500','info'=>'#0070f2',
                      'primary'=>'#0057d2','success'=>'#256f3a','secondary'=>'#5b738b',
                      'dark'=>'#354a5f', default=>'#5b738b' };
              ?>
                <tr onclick="if(!event.target.closest('a')) location.href='ticket_view.php?id=<?= (int)$t['id'] ?>';">
                  <td><a class="sap-ticket-num" href="ticket_view.php?id=<?= (int)$t['id'] ?>" onclick="event.stopPropagation()"><?= e($t['ticket_number']) ?></a></td>
                  <td><?= e($t['subject']) ?></td>
                  <td><?= e($t['requester_name']) ?></td>
                  <td><?= e($t['category_name']) ?></td>
                  <td><span class="sap-prio" style="background:<?= e($hex) ?>"><?= e($t['priority_name']) ?></span></td>
                  <td><small class="text-muted"><?= e(date('Y-m-d H:i', strtotime($t['created_at']))) ?></small></td>
                  <td style="text-align:right;">
                    <a href="ticket_view.php?id=<?= (int)$t['id'] ?>" onclick="event.stopPropagation()"
                       style="color:var(--sap-brand);text-decoration:none;font-size:.8125rem;font-weight:500;padding:.35rem .7rem;border-radius:.5rem">
                      Open <i class="bi bi-chevron-right"></i>
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<!-- ================= MY ACTIVE TICKETS ================= -->
<div class="sap-section-label">My Active Tickets</div>
<div class="row g-3 mb-3">
  <div class="col-12">
    <div class="sap-card">
      <div class="sap-card-header">
        <span><i class="bi bi-person-check-fill"></i> Assigned to me (<span id="myActiveCount"><?= count($myActive) ?></span>)</span>
        <a href="assigned.php" class="sap-status is-info" style="text-decoration:none">
          <i class="bi bi-arrow-right"></i> View all
        </a>
      </div>
      <div class="sap-card-body p-0">
        <?php if (!$myActive): ?>
          <div class="sap-empty">You have no active tickets. Accept one from the queue above.</div>
        <?php else:
            $smeta = function(string $s): array {
                return match ($s) {
                    'PENDING_TEAM_LEADER_APPROVAL'              => ['Pending Approval','critical','hourglass-split'],
                    'APPROVED_FOR_ICT'                          => ['Approved for ICT','info','check2-circle'],
                    'ASSIGNED_TO_ICT'                           => ['Assigned to ICT','info','person-check'],
                    'IN_PROGRESS'                               => ['In Progress','info','tools'],
                    'WAITING_FOR_INFORMATION'                   => ['Waiting for Info','neutral','pause-circle'],
                    'WAITING_FOR_PARTS'                         => ['Waiting for Parts','neutral','pause-circle'],
                    'RESOLVED_PENDING_REQUESTER_CONFIRMATION'   => ['Pending Confirmation','critical','patch-check'],
                    'RESOLVED_PENDING_TEAM_LEADER_VERIFICATION' => ['Pending Confirmation','critical','patch-check'],
                    'RETURNED_TO_ICT'                           => ['Returned to ICT','critical','arrow-return-right'],
                    'CLOSED'                                    => ['Closed','good','check2-all'],
                    default                                     => [str_replace('_',' ',$s),'neutral','circle'],
                };
            };
        ?>
          <div class="table-responsive">
            <table class="sap-table">
              <thead>
                <tr><th>Ticket #</th><th>Subject</th><th>Requester</th><th>Priority</th><th>Status</th><th></th></tr>
              </thead>
              <tbody>
              <?php foreach ($myActive as $t):
                  [$label, $tone, $icon] = $smeta($t['status']);
                  $hex = match ($t['priority_color']) {
                      'danger'=>'#aa0808','warning'=>'#e76500','info'=>'#0070f2',
                      'primary'=>'#0057d2','success'=>'#256f3a','secondary'=>'#5b738b',
                      'dark'=>'#354a5f', default=>'#5b738b' };
              ?>
                <tr onclick="if(!event.target.closest('a')) location.href='ticket_view.php?id=<?= (int)$t['id'] ?>';">
                  <td><a class="sap-ticket-num" href="ticket_view.php?id=<?= (int)$t['id'] ?>" onclick="event.stopPropagation()"><?= e($t['ticket_number']) ?></a></td>
                  <td><?= e($t['subject']) ?></td>
                  <td><?= e($t['requester_name']) ?></td>
                  <td><span class="sap-prio" style="background:<?= e($hex) ?>"><?= e($t['priority_name']) ?></span></td>
                  <td>
                    <span class="sap-status-pill is-<?= e($tone) ?>">
                      <i class="bi bi-<?= e($icon) ?>"></i> <?= e($label) ?>
                    </span>
                  </td>
                  <td style="text-align:right;">
                    <a href="ticket_view.php?id=<?= (int)$t['id'] ?>" onclick="event.stopPropagation()"
                       style="color:var(--sap-brand);text-decoration:none;font-size:.8125rem;font-weight:500;padding:.35rem .7rem;border-radius:.5rem">
                      Open <i class="bi bi-chevron-right"></i>
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<!-- ================= CHARTS ================= -->
<div class="sap-section-label">Analytics — Overview</div>
<div class="row g-3">
  <div class="col-lg-6">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-diagram-3"></i> Tickets by Status</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartStatus"></canvas></div></div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-tags"></i> Tickets by Category</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartCategory"></canvas></div></div>
    </div>
  </div>
</div>

<div class="sap-section-label">Analytics — Distributions</div>
<div class="row g-3">
  <div class="col-lg-4">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-flag"></i> Tickets by Priority</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartPriority"></canvas></div></div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-person-check"></i> Top Technicians</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartTopTech"></canvas></div></div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-pie-chart"></i> Status Share</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartStatusShare"></canvas></div></div>
    </div>
  </div>
</div>

<div class="sap-section-label">Analytics — Trends &amp; Performance</div>
<div class="row g-3">
  <div class="col-lg-8">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-graph-up"></i> Monthly Approved vs Closed</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartCreatedVsClosed"></canvas></div></div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-bullseye"></i> Avg Resolution by Category</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartRadar"></canvas></div></div>
    </div>
  </div>
</div>

<script>
/* ========== Data from PHP (initial render) ========== */
const statusLabels  = <?= json_encode(array_map(fn($r)=>str_replace('_',' ', $r['status']), $byStatus)) ?>;
const statusData    = <?= json_encode(array_map('intval', array_column($byStatus,'cnt'))) ?>;

const catLabels     = <?= json_encode(array_column($byCat,'category_name')) ?>;
const catData       = <?= json_encode(array_map('intval', array_column($byCat,'cnt'))) ?>;

const priorityLabels = <?= json_encode(array_column($byPriority,'name')) ?>;
const priorityData   = <?= json_encode(array_map('intval', array_column($byPriority,'cnt'))) ?>;
const priorityColors = <?= json_encode(array_map(fn($r)=>'#'.ltrim(match($r['color']){
    'danger'=>'bb0000','warning'=>'e76500','info'=>'0070f2','primary'=>'0057d2',
    'success'=>'256f3a','secondary'=>'5b738b','dark'=>'354a5f',
    default=>'5b738b'}, '#'), $byPriority)) ?>;

const topTechLabels = <?= json_encode(array_column($topTechs,'full_name')) ?>;
const topTechData   = <?= json_encode(array_map('intval', array_column($topTechs,'cnt'))) ?>;

const cvMonths  = <?= json_encode($allMonths) ?>;
const cvCreated = <?= json_encode($createdSeries) ?>;
const cvClosed  = <?= json_encode($closedSeries) ?>;

const radarLabels = <?= json_encode($radarLabels) ?>;
const radarData   = <?= json_encode($radarData) ?>;

/* ========== Colors ========== */
const SAP = {
  brand:      '#0070f2',
  brandMid:   '#34495e',
  positive:   '#256f3a',
  critical:   '#e76500',
  negative:   '#aa0808',
  neutral:    '#5b738b',
  palette:    ['#0070f2','#0057d2','#256f3a','#e76500','#aa0808','#5b738b','#7858a0','#0097b2'],
  grid:       '#e5e5e5',
  text:       '#556b82'
};

/* ========== Count-up animation ========== */
function animateCount(el) {
  const target   = parseFloat(el.dataset.count || '0');
  const decimals = parseInt(el.dataset.decimals || '0', 10);
  const duration = 900;
  let done = false;

  const render = (v) => {
    el.textContent = decimals ? v.toFixed(decimals) : Math.round(v).toLocaleString();
  };

  const finalise = () => {
    if (done) return;
    done = true;
    clearTimeout(fallback);
    render(target);
    el.dataset.value = String(target);
  };

  /* The tile markup ships a literal "0". Guarantee the real count replaces it
     even when requestAnimationFrame is throttled away (hidden/background tab,
     reduced motion, print) — otherwise the dashboard shows 0 for everything. */
  const fallback = setTimeout(finalise, 1200);

  if (document.visibilityState !== 'visible' ||
      window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    finalise();
    return;
  }

  const start = performance.now();
  const tick = (now) => {
    if (done) return;
    const t = Math.min(1, (now - start) / duration);
    render(target * (1 - Math.pow(1 - t, 3)));
    if (t < 1) requestAnimationFrame(tick); else finalise();
  };
  requestAnimationFrame(tick);
}

/* ========== Chart defaults ==========
   Applied from the init handler below: this script is emitted before
   includes/footer.php loads Chart.js, so `Chart` is still undefined here. */

/* ============================================================
   CHIME — Web Audio (shared context, unlocked on interaction)
   ============================================================ */
let audioCtx = null;
let soundUnlocked = false;

function getCtx() {
  if (!audioCtx) {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return null;
    audioCtx = new Ctx();
  }
  return audioCtx;
}

async function resumeCtx() {
  const ctx = getCtx();
  if (!ctx) return false;
  try {
    if (ctx.state === 'suspended') await ctx.resume();
    soundUnlocked = (ctx.state === 'running');
    return soundUnlocked;
  } catch (e) { return false; }
}

async function playChime() {
  const ok = await resumeCtx();
  if (!ok) { console.warn('[ICT] AudioContext blocked'); return false; }
  const ctx = audioCtx;
  function tone(freq, start, duration, gainVal) {
    const osc  = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.value = freq;
    const t0 = ctx.currentTime + start;
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.linearRampToValueAtTime(gainVal, t0 + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);
    osc.connect(gain).connect(ctx.destination);
    osc.start(t0);
    osc.stop(t0 + duration + 0.05);
  }
  tone(880,     0.00, 0.18, 0.30); // A5
  tone(1174.66, 0.16, 0.30, 0.28); // D6
  return true;
}

/* ============================================================
   TOAST
   ============================================================ */
function showToast(ticket) {
  const existing = document.getElementById('ictNewTicketToast');
  if (existing) existing.remove();

  const t = document.createElement('div');
  t.id = 'ictNewTicketToast';
  t.innerHTML = `
    <div style="display:flex;align-items:flex-start;gap:.6rem;">
      <div style="flex-shrink:0;width:32px;height:32px;border-radius:8px;
                  background:#eaf4ff;color:#0070f2;display:flex;align-items:center;
                  justify-content:center;font-size:1.1rem;">
        <i class="bi bi-bell-fill"></i>
      </div>
      <div style="flex:1;min-width:0;">
        <div style="font-weight:600;font-size:.875rem;color:#1d2d3e;">
          New ticket reached ICT
        </div>
        <div style="font-size:.78rem;color:#556b82;margin-top:.15rem;
                    overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"
             title="${ticket.subject}">
          <code style="background:#f4f5f7;padding:.05rem .3rem;
                       border-radius:.25rem;font-size:.72rem;">${ticket.ticket_number}</code>
          ${ticket.subject}
        </div>
        <div style="margin-top:.55rem;display:flex;gap:.4rem;">
          <a href="ticket_view.php?id=${ticket.id}"
             style="font-size:.75rem;font-weight:500;color:#0070f2;
                    text-decoration:none;padding:.25rem .55rem;
                    border:1px solid #cfe2f8;border-radius:.35rem;">
            Open Ticket
          </a>
          <button onclick="document.getElementById('ictNewTicketToast').remove()"
                  style="font-size:.75rem;font-weight:500;color:#556b82;
                         background:transparent;border:0;cursor:pointer;
                         padding:.25rem .55rem;">
            Dismiss
          </button>
        </div>
      </div>
    </div>`;

  Object.assign(t.style, {
    position: 'fixed',
    bottom: '1.25rem',
    right: '1.25rem',
    zIndex: '9999',
    background: '#ffffff',
    border: '1px solid #eaecf0',
    borderLeft: '4px solid #0070f2',
    borderRadius: '.6rem',
    boxShadow: '0 8px 24px rgba(34,53,72,.18)',
    padding: '.85rem 1rem',
    maxWidth: '360px',
    fontFamily: '"72", "72full", Arial, Helvetica, sans-serif',
    animation: 'ictToastIn .28s cubic-bezier(.2,.8,.2,1)',
    transition: 'opacity .25s, transform .25s',
  });

  document.body.appendChild(t);
  setTimeout(() => {
    if (!t.parentNode) return;
    t.style.opacity = '0';
    t.style.transform = 'translateX(20px)';
    setTimeout(() => t.remove(), 260);
  }, 8000);
}

/* ============================================================
   SCORECARD LIVE REFRESH — every 10 seconds
   ============================================================ */
const KPI_MAP = {
  'kpi-received'     : 'received',
  'kpi-approved'     : 'approved',
  'kpi-inprogress'   : 'in_progress',
  'kpi-waiting'      : 'waiting',
  'kpi-pendingverify': 'pending_verify',
  'kpi-solved'       : 'total_solved',
  'kpi-closed'       : 'closed',
  'kpi-myassigned'   : 'my_assigned',
};

let lastStats   = null;
let firstPoll   = true;

function setKpiValue(el, newValue) {
  if (!el) return;
  const prev = parseInt((el.dataset.value ?? el.textContent).replace(/\D/g, ''), 10) || 0;
  if (newValue !== prev) {
    el.textContent = Number(newValue).toLocaleString();
    el.dataset.value = String(newValue);
    if (newValue > prev) {
      el.classList.remove('flash');
      void el.offsetWidth;      // restart animation
      el.classList.add('flash');
    }
  }
}

async function pollStats() {
  try {
    const r = await fetch(BASE_URL + '/api/ict_stats.php', {
      credentials: 'same-origin', cache: 'no-store'
    });
    const d = await r.json();
    if (!d || !d.ok) return;

    /* Update scorecards */
    for (const [elId, key] of Object.entries(KPI_MAP)) {
      setKpiValue(document.getElementById(elId), d[key]);
    }

    /* Update "solved today" text */
    const todayEl = document.getElementById('myTodayCount');
    if (todayEl) todayEl.textContent = d.my_today;

    /* Detect a new ticket arrival */
    if (!firstPoll && lastStats) {
      const wentUp = d.received > lastStats.received;

      if (wentUp) {
        playChime();
        if (d.latest) {
          showToast({
            id:            d.latest.id ?? '',
            ticket_number: d.latest.ticket_number,
            subject:       d.latest.subject,
          });
        }
        /* Also refresh the whole page's queue table after a short delay */
        setTimeout(() => {
          /* Reload the page to refresh the table rows too (keeps things simple) */
          window.location.reload();
        }, 2500);
      }
    }

    lastStats = d;
    firstPoll = false;

    /* Live indicator blip */
    const ind = document.getElementById('liveIndicator');
    if (ind) {
      ind.style.transition = 'opacity .2s';
      ind.style.opacity = '.5';
      setTimeout(() => { ind.style.opacity = '1'; }, 200);
    }
  } catch (e) { /* silent */ }
}

/* ============================================================
   INIT
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {

  /* Count-up all initial values */
  document.querySelectorAll('[data-count]').forEach(animateCount);

  /* Save initial values for flash comparison */
  document.querySelectorAll('.sap-tile-value').forEach(el => {
    el.dataset.value = (el.textContent || '0').replace(/\D/g, '');
  });

  /* Animate progress bars */
  document.querySelectorAll('[data-width]').forEach((el, i) => {
    setTimeout(() => { el.style.width = el.dataset.width + '%'; }, 300 + i * 120);
  });

  /* Chart.js defaults (only when the CDN script actually loaded) */
  if (typeof Chart !== 'undefined') {
    Chart.defaults.font.family = "'72', Arial, Helvetica, sans-serif";
    Chart.defaults.font.size = 12;
    Chart.defaults.color = SAP.text;
    Chart.defaults.animation.duration = 1200;
    Chart.defaults.animation.easing = 'easeOutQuart';
  }

  /* Skip chart construction cleanly when Chart.js could not be loaded */
  const stagger = (fn, delay) => setTimeout(() => { if (typeof Chart !== 'undefined') fn(); }, delay);

  /* ---------- Charts ---------- */
  stagger(() => new Chart(document.getElementById('chartStatus'), {
    type: 'doughnut',
    data: { labels: statusLabels, datasets: [{
      data: statusData, backgroundColor: SAP.palette,
      borderColor: '#fff', borderWidth: 2, hoverOffset: 8 }] },
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: { duration: 1400, animateRotate: true, animateScale: true, easing: 'easeOutQuart' },
      cutout: '62%',
      plugins: { legend: { position: 'right', labels: { boxWidth: 10, padding: 10, font: { size: 10 } } } }
    }
  }), 150);

  stagger(() => new Chart(document.getElementById('chartCategory'), {
    type: 'bar',
    data: { labels: catLabels, datasets: [{
      label: 'Tickets', data: catData,
      backgroundColor: SAP.brand, hoverBackgroundColor: SAP.brandMid,
      borderRadius: 4, barThickness: 18 }] },
    options: {
      indexAxis: 'y', responsive: true, maintainAspectRatio: false,
      animation: { duration: 1400, easing: 'easeOutQuart' },
      plugins: { legend: { display: false } },
      scales: {
        x: { beginAtZero: true, grid: { color: SAP.grid }, ticks: { precision: 0 } },
        y: { grid: { display: false } }
      }
    }
  }), 300);

  stagger(() => new Chart(document.getElementById('chartPriority'), {
    type: 'pie',
    data: { labels: priorityLabels, datasets: [{
      data: priorityData, backgroundColor: priorityColors,
      borderColor: '#fff', borderWidth: 2, hoverOffset: 8 }] },
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: { duration: 1400, animateRotate: true, animateScale: true, easing: 'easeOutQuart' },
      plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, padding: 10, font: { size: 11 } } } }
    }
  }), 450);

  stagger(() => new Chart(document.getElementById('chartTopTech'), {
    type: 'bar',
    data: { labels: topTechLabels, datasets: [{
      label: 'Resolved', data: topTechData,
      backgroundColor: SAP.positive,
      borderRadius: 4, barThickness: 18 }] },
    options: {
      indexAxis: 'y', responsive: true, maintainAspectRatio: false,
      animation: { duration: 1400, easing: 'easeOutQuart' },
      plugins: { legend: { display: false } },
      scales: {
        x: { beginAtZero: true, grid: { color: SAP.grid }, ticks: { precision: 0 } },
        y: { grid: { display: false } }
      }
    }
  }), 600);

  stagger(() => new Chart(document.getElementById('chartStatusShare'), {
    type: 'polarArea',
    data: { labels: statusLabels, datasets: [{
      data: statusData, backgroundColor: SAP.palette,
      borderColor: '#fff', borderWidth: 2 }] },
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: { duration: 1400, animateRotate: true, animateScale: true, easing: 'easeOutQuart' },
      plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, padding: 8, font: { size: 10 } } } },
      scales: { r: { beginAtZero: true, grid: { color: SAP.grid }, ticks: { backdropColor: 'transparent' } } }
    }
  }), 750);

  stagger(() => new Chart(document.getElementById('chartCreatedVsClosed'), {
    type: 'line',
    data: {
      labels: cvMonths,
      datasets: [
        { label: 'Approved', data: cvCreated,
          borderColor: SAP.brand, backgroundColor: 'rgba(0,112,242,.12)',
          fill: true, tension: .35,
          pointRadius: 3, pointBackgroundColor: SAP.brand,
          pointBorderColor: '#fff', pointBorderWidth: 2 },
        { label: 'Closed', data: cvClosed,
          borderColor: SAP.positive, backgroundColor: 'rgba(37,111,58,.12)',
          fill: true, tension: .35,
          pointRadius: 3, pointBackgroundColor: SAP.positive,
          pointBorderColor: '#fff', pointBorderWidth: 2 }
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: { duration: 1600, easing: 'easeOutQuart' },
      plugins: { legend: { position: 'bottom' } },
      scales: {
        y: { beginAtZero: true, grid: { color: SAP.grid }, ticks: { precision: 0 } },
        x: { grid: { display: false } }
      }
    }
  }), 900);

  stagger(() => new Chart(document.getElementById('chartRadar'), {
    type: 'radar',
    data: { labels: radarLabels, datasets: [{
      label: 'Avg hrs', data: radarData,
      borderColor: SAP.brand,
      backgroundColor: 'rgba(0,112,242,.20)',
      pointBackgroundColor: SAP.brand,
      pointBorderColor: '#fff',
      pointRadius: 4 }] },
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: { duration: 1400, easing: 'easeOutQuart' },
      plugins: { legend: { display: false } },
      scales: { r: { beginAtZero: true, grid: { color: SAP.grid },
                    angleLines: { color: SAP.grid }, ticks: { backdropColor: 'transparent' } } }
    }
  }), 1050);

  /* ---------- Unlock audio on any user interaction ---------- */
  ['click','keydown','touchstart','pointerdown'].forEach(evt => {
    document.addEventListener(evt, () => { resumeCtx(); }, { passive: true });
  });

  /* Try to resume now (often succeeds after navigation from a click) */
  resumeCtx();

  /* ---------- Show "Enable sound" button if blocked after 3 s ---------- */
  setTimeout(() => {
    if (soundUnlocked) return;

    const btn = document.createElement('button');
    btn.id = 'ictEnableSoundBtn';
    btn.type = 'button';
    btn.innerHTML = '<i class="bi bi-volume-up-fill"></i> Enable notification sound';
    Object.assign(btn.style, {
      position: 'fixed', bottom: '1.25rem', right: '1.25rem', zIndex: '9999',
      background: '#0070f2', color: '#fff', border: '0', borderRadius: '.5rem',
      padding: '.55rem .9rem', fontSize: '.8125rem', fontWeight: '600',
      fontFamily: '"72", "72full", Arial, Helvetica, sans-serif',
      boxShadow: '0 6px 20px rgba(0,112,242,.35)', cursor: 'pointer',
      display: 'inline-flex', alignItems: 'center', gap: '.4rem',
      animation: 'ictToastIn .3s ease-out',
    });
    btn.addEventListener('click', async () => {
      const ok = await playChime();
      if (ok) btn.remove();
      else {
        btn.innerHTML = '<i class="bi bi-x-circle-fill"></i> Sound blocked by browser';
        btn.style.background = '#aa0808';
      }
    });
    document.body.appendChild(btn);
  }, 3000);

  /* ---------- Start polling ---------- */
  setTimeout(pollStats, 2000);   // first poll after 2 s
  setInterval(pollStats, 10000); // then every 10 s
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>