<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

$u = require_role('ICT_STAFF');
$pageTitle = 'Assigned to Me';

/* ---------- Local fallback: status_badge() ----------
 * functions.php defines it now, so this block is skipped at runtime.
 * Kept here only so this page never crashes if someone removes it
 * from functions.php by accident. */
if (!function_exists('status_badge')) {
    function status_badge(string $status, string $size = ''): string
    {
        $raw = trim($status);
        $key = strtoupper(preg_replace('/[^A-Z0-9]+/i', '_', $raw));
        $map = [
            'OPEN'                    => ['info',     'circle',                'Open'],
            'NEW'                     => ['info',     'star',                  'New'],
            'PENDING'                 => ['critical', 'hourglass-split',       'Pending'],
            'APPROVED'                => ['good',     'check2-circle',         'Approved'],
            'APPROVED_FOR_ICT'        => ['info',     'check2-circle',         'Approved for ICT'],
            'ASSIGNED'                => ['info',     'person-check',          'Assigned'],
            'ASSIGNED_TO_ICT'         => ['info',     'person-check',          'Assigned to ICT'],
            'IN_PROGRESS'             => ['info',     'arrow-repeat',          'In Progress'],
            'WAITING_FOR_PARTS'       => ['critical', 'pause-circle',          'Waiting for Parts'],
            'WAITING_FOR_INFORMATION' => ['critical', 'question-circle',       'Waiting for Info'],
            'RESOLVED'                => ['good',     'check2-circle',         'Resolved'],
            'RESOLVED_PENDING_REQUESTER_CONFIRMATION'
                                      => ['critical', 'hourglass-split',       'Awaiting Requester'],
            'RESOLVED_PENDING_TEAM_LEADER_VERIFICATION'
                                      => ['critical', 'hourglass-split',       'Awaiting Team Leader'],
            'RETURNED_TO_ICT'         => ['critical', 'arrow-counterclockwise','Returned to ICT'],
            'CLOSED'                  => ['good',     'check2-all',            'Closed'],
            'REJECTED'                => ['bad',      'x-circle',              'Rejected'],
            'CANCELLED'               => ['bad',      'slash-circle',          'Cancelled'],
        ];
        [$tone, $icon, $label] = $map[$key]
            ?? ['neutral', 'circle', $raw !== '' ? ucwords(strtolower(str_replace('_', ' ', $raw))) : '—'];
        $sizeClass = $size !== '' ? ' is-' . preg_replace('/[^a-z]/', '', strtolower($size)) : '';
        return sprintf(
            '<span class="sap-status is-%s%s"><i class="bi bi-%s"></i> %s</span>',
            htmlspecialchars($tone,      ENT_QUOTES, 'UTF-8'),
            htmlspecialchars($sizeClass, ENT_QUOTES, 'UTF-8'),
            htmlspecialchars($icon,      ENT_QUOTES, 'UTF-8'),
            htmlspecialchars($label,     ENT_QUOTES, 'UTF-8')
        );
    }
}

$stmt = db()->prepare("SELECT t.*, c.category_name, p.name AS priority_name, p.color AS priority_color,
    req.full_name AS requester_name
    FROM tickets t JOIN categories c ON c.id=t.category_id JOIN priorities p ON p.id=t.priority_id
    JOIN users req ON req.id=t.requester_id
    WHERE t.assigned_technician_id=? AND t.status NOT IN ('CLOSED','REJECTED','CANCELLED')
    ORDER BY p.level DESC, t.created_at");
$stmt->execute([$u['id']]);
$tickets = $stmt->fetchAll();

/* ---------- Small derived counters ---------- */
$total         = count($tickets);
$waitingCount  = 0;
foreach ($tickets as $row) {
    if (in_array($row['status'], ['WAITING_FOR_PARTS','WAITING_FOR_INFORMATION'], true)) {
        $waitingCount++;
    }
}

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:#0070f2; --sap-brand-dark:#0057d2;
    --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500;
    --sap-negative:#aa0808; --sap-neutral:#5b738b;
    --sap-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
  }
  body, .main-content { background: var(--sap-bg) !important;
    font-family: "72","72full",Arial,Helvetica,sans-serif !important; color: var(--sap-text); }

  .sap-page-header { display: flex; align-items: flex-start; justify-content: space-between;
    margin-bottom: 1rem; gap: .75rem; flex-wrap: wrap; }
  .sap-page-title { font-size: 1.625rem; font-weight: 400; margin: 0; }
  .sap-breadcrumb { font-size: .8125rem; color: var(--sap-text-muted); margin-bottom: .25rem; }

  .sap-pill { display: inline-flex; align-items: center; gap: .3rem;
    font-size: .72rem; font-weight: 600; padding: .25rem .65rem;
    border-radius: .75rem; white-space: nowrap; border: 1px solid transparent; }
  .sap-pill.is-info     { background:#eaf4ff; color:var(--sap-brand);    border-color:#cfe2f8; }
  .sap-pill.is-critical { background:#fff8f1; color:var(--sap-critical); border-color:#fbe0c8; }
  .sap-pill.is-bad      { background:#fef4f4; color:var(--sap-negative); border-color:#f7d2d2; }
  .sap-pill.is-good     { background:#f1fdf6; color:var(--sap-positive); border-color:#d6f0e0; }
  .sap-pill.is-neutral  { background:#f4f5f7; color:var(--sap-neutral);  border-color:#e4e7eb; }

  /* Shared status badge (also defined per-page elsewhere) */
  .sap-status { display: inline-flex; align-items: center; gap: .3rem;
    font-size: .72rem; font-weight: 600; padding: .2rem .6rem;
    border-radius: .75rem; white-space: nowrap; border: 1px solid transparent; }
  .sap-status.is-good     { background:#f1fdf6; color:var(--sap-positive); border-color:#d6f0e0; }
  .sap-status.is-critical { background:#fff8f1; color:var(--sap-critical); border-color:#fbe0c8; }
  .sap-status.is-bad      { background:#fef4f4; color:var(--sap-negative); border-color:#f7d2d2; }
  .sap-status.is-info     { background:#eaf4ff; color:var(--sap-brand);    border-color:#cfe2f8; }
  .sap-status.is-neutral  { background:#f4f5f7; color:var(--sap-neutral);  border-color:#e4e7eb; }

  .sap-card { background: var(--sap-tile); border-radius: .75rem;
    box-shadow: var(--sap-shadow); overflow: hidden; }
  .sap-card-header { padding: .8rem 1.15rem; border-bottom: 1px solid var(--sap-border-soft);
    display: flex; align-items: center; justify-content: space-between; gap: .5rem;
    font-size: .8125rem; font-weight: 700; text-transform: uppercase; letter-spacing: .05em;
    color: var(--sap-text-muted); }
  .sap-card-header .title-wrap { display: flex; align-items: center; gap: .45rem; }
  .sap-card-header .bi { color: var(--sap-brand); font-size: .95rem; }
  .sap-card-body { padding: 0; }

  table.sap-table { width: 100%; border-collapse: separate; border-spacing: 0;
    font-size: .85rem; margin: 0; }
  table.sap-table thead th { background:#f5f6f7; border-bottom:1px solid var(--sap-border);
    font-weight:600; color:var(--sap-text-muted); text-align:left;
    padding:.6rem .85rem; white-space:nowrap; text-transform:uppercase;
    font-size:.68rem; letter-spacing:.04em; }
  table.sap-table tbody td { padding:.7rem .85rem; border-bottom:1px solid var(--sap-border-soft);
    vertical-align: middle; }
  table.sap-table tbody tr:last-child td { border-bottom:0; }
  table.sap-table tbody tr { transition: background .12s; }
  table.sap-table tbody tr:hover { background:#f8fbff; }

  .sap-tnum { font-family:"72Mono","Courier New",monospace; font-size:.8rem;
    color:var(--sap-brand); background:#eaf4ff; border:1px solid #cfe2f8;
    padding:.1rem .5rem; border-radius:.35rem; text-decoration:none; }
  .sap-tnum:hover { background:#dcecfd; color:var(--sap-brand-dark); }

  .sap-prio { display: inline-flex; align-items: center; gap: .3rem;
    font-size:.72rem; font-weight:600; padding:.22rem .6rem; border-radius:.75rem;
    color:#fff; white-space:nowrap; }
  .sap-prio .swatch { width: 6px; height: 6px; border-radius: 50%; background: rgba(255,255,255,.75); }

  .sap-btn { display: inline-flex; align-items: center; gap: .35rem;
    font-size: .8125rem; font-weight: 500; border-radius: .5rem;
    padding: .4rem .8rem; border: 1px solid transparent; background: transparent;
    color: var(--sap-brand); cursor: pointer; line-height: 1; text-decoration: none;
    white-space: nowrap; transition: background .15s, color .15s; }
  .sap-btn:hover { background: #eaf4ff; color: var(--sap-brand-dark); }
  .sap-btn.sap-btn-emphasized { background: var(--sap-brand); color: #fff; }
  .sap-btn.sap-btn-emphasized:hover { background: var(--sap-brand-dark); color: #fff; }

  .sap-empty { text-align: center; padding: 3rem 1rem; color: var(--sap-text-muted); }
  .sap-empty .bi { font-size: 2.2rem; opacity: .35; display: block; margin-bottom: .5rem; }
  .sap-empty-title { font-size: .95rem; font-weight: 600; color: var(--sap-text); }
</style>

<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb">
      <i class="bi bi-house-door"></i> Home / <strong>Assigned to Me</strong>
    </div>
    <h1 class="sap-page-title">Assigned to Me</h1>
  </div>
  <div class="d-flex gap-2 flex-wrap">
    <span class="sap-pill is-info"><i class="bi bi-inbox"></i> <?= $total ?> open</span>
    <?php if ($waitingCount): ?>
      <span class="sap-pill is-critical"><i class="bi bi-pause-circle"></i> <?= $waitingCount ?> waiting</span>
    <?php endif; ?>
  </div>
</div>

<div class="sap-card">
  <div class="sap-card-header">
    <span class="title-wrap"><i class="bi bi-person-check"></i> Tickets Assigned to You</span>
    <span style="font-size:.7rem;font-weight:500;text-transform:none;letter-spacing:0;color:var(--sap-text-muted)">
      <?= $total ?> ticket<?= $total === 1 ? '' : 's' ?>
    </span>
  </div>

  <?php if (!$tickets): ?>
    <div class="sap-empty">
      <i class="bi bi-inbox"></i>
      <div class="sap-empty-title">No tickets assigned to you</div>
      <div style="font-size:.82rem;margin-top:.3rem">
        You'll see them here as soon as your Team Leader assigns one.
      </div>
    </div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="sap-table">
        <thead>
          <tr>
            <th style="width:150px">Ticket</th>
            <th>Subject</th>
            <th style="width:180px">Requester</th>
            <th style="width:130px">Priority</th>
            <th style="width:180px">Status</th>
            <th style="width:90px"></th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($tickets as $t):
            $pcolor = match ($t['priority_color']) {
                'danger'    => '#aa0808',
                'warning'   => '#e76500',
                'info'      => '#0070f2',
                'primary'   => '#0057d2',
                'success'   => '#256f3a',
                'secondary' => '#5b738b',
                'dark'      => '#354a5f',
                default     => '#5b738b',
            };
        ?>
          <tr>
            <td>
              <a class="sap-tnum" href="ticket_view.php?id=<?= (int)$t['id'] ?>">
                <?= e($t['ticket_number']) ?>
              </a>
            </td>
            <td>
              <div style="font-weight:600;color:var(--sap-text)"><?= e($t['subject']) ?></div>
              <div style="font-size:.72rem;color:var(--sap-text-muted);margin-top:.15rem">
                <?= e($t['category_name']) ?>
              </div>
            </td>
            <td><?= e($t['requester_name']) ?></td>
            <td>
              <span class="sap-prio" style="background:<?= e($pcolor) ?>">
                <span class="swatch"></span> <?= e($t['priority_name']) ?>
              </span>
            </td>
            <td><?= status_badge($t['status']) ?></td>
            <td class="text-end">
              <a href="ticket_view.php?id=<?= (int)$t['id'] ?>"
                 class="sap-btn sap-btn-emphasized">
                <i class="bi bi-box-arrow-up-right"></i> Open
              </a>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>