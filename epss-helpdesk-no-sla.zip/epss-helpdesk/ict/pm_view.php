<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/pm.php';
$u = require_role('BRANCH_MANAGER', 'ADMIN', 'ICT_STAFF');
$pageTitle = 'Preventive Maintenance Checklist';
$pdo = db();

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    redirect(BASE_URL . '/ict/pm_approvals.php');
}

/* =====================================================================
 * Schema detection — pm_checklists / pm_checklist_items vary between
 * installs. Detect available columns once, then adapt query + template.
 * ===================================================================== */

function pmv_cols(PDO $pdo, string $table): array {
    static $cache = [];
    if (isset($cache[$table])) return $cache[$table];
    try {
        $rows = $pdo->query("SHOW COLUMNS FROM `" . str_replace('`', '', $table) . "`")
                    ->fetchAll(PDO::FETCH_COLUMN);
        return $cache[$table] = array_map('strtolower', $rows ?: []);
    } catch (Throwable $e) {
        return $cache[$table] = [];
    }
}
function pmv_has(array $cols, string ...$cands): ?string {
    foreach ($cands as $c) if (in_array($c, $cols, true)) return $c;
    return null;
}

$pmCols  = pmv_cols($pdo, 'pm_checklists');
$itmCols = pmv_cols($pdo, 'pm_checklist_items');

$colStatus     = pmv_has($pmCols, 'status', 'approval_status', 'checklist_status', 'review_status', 'state');
$colApprovedBy = pmv_has($pmCols, 'approved_by');
$colApprovedAt = pmv_has($pmCols, 'approved_at', 'reviewed_at');
$colSubmitted  = pmv_has($pmCols, 'submitted_at', 'created_at');
$colNotes      = pmv_has($pmCols, 'notes', 'remarks', 'comment');
$colQuarter    = pmv_has($pmCols, 'quarter_label', 'quarter');
$colTechName   = pmv_has($pmCols, 'technician_name');
$colTechId     = pmv_has($pmCols, 'technician_id');
$colDeptId     = pmv_has($pmCols, 'department_id');
$colCheckDate  = pmv_has($pmCols, 'checklist_date', 'date', 'performed_date');
$colApprRemark = pmv_has($pmCols, 'approval_remarks', 'review_remarks');

// users table & relevant columns
$userCols = [];
try { $userCols = pmv_cols($pdo, 'users'); } catch (Throwable $e) {}
$hasUsers        = in_array('id', $userCols, true) && in_array('full_name', $userCols, true);
$hasUsernameCol  = in_array('username', $userCols, true);

// departments table
$hasDept = false;
try { $hasDept = (bool)$pdo->query("SHOW TABLES LIKE 'departments'")->fetchColumn(); } catch (Throwable $e) {}

/* ---------- Build the SELECT for this checklist ---------- */
$selects = ['c.*'];
$joins   = [];

if ($hasUsers && $colTechId !== null) {
    $selects[] = 't.full_name AS tech_full_name';
    if ($hasUsernameCol) $selects[] = 't.username AS tech_username';
    else                 $selects[] = 'NULL AS tech_username';
    $joins[]   = "INNER JOIN users t ON t.id = c.`$colTechId`";
} else {
    $selects[] = 'NULL AS tech_full_name';
    $selects[] = 'NULL AS tech_username';
}

if ($hasDept && $colDeptId !== null) {
    $selects[] = 'd.department_name';
    $joins[]   = "LEFT JOIN departments d ON d.id = c.`$colDeptId`";
} else {
    $selects[] = 'NULL AS department_name';
}

if ($hasUsers && $colApprovedBy !== null) {
    $selects[] = 'ap.full_name AS approver_name';
    $joins[]   = "LEFT JOIN users ap ON ap.id = c.`$colApprovedBy`";
} else {
    $selects[] = 'NULL AS approver_name';
}

// Stable aliases for template use
$selects[] = $colStatus     ? "c.`$colStatus`     AS status_value"     : "NULL AS status_value";
$selects[] = $colApprovedAt ? "c.`$colApprovedAt` AS approved_at"      : "NULL AS approved_at";
$selects[] = $colSubmitted  ? "c.`$colSubmitted`  AS submitted_at"     : "NULL AS submitted_at";
$selects[] = $colNotes      ? "c.`$colNotes`      AS notes"            : "NULL AS notes";
$selects[] = $colQuarter    ? "c.`$colQuarter`    AS quarter_label"    : "NULL AS quarter_label";
$selects[] = $colTechName   ? "c.`$colTechName`   AS technician_name"  : "NULL AS technician_name";
$selects[] = $colCheckDate  ? "c.`$colCheckDate`  AS checklist_date"   : "NULL AS checklist_date";
$selects[] = $colApprRemark ? "c.`$colApprRemark` AS approval_remarks" : "NULL AS approval_remarks";
$selects[] = $colTechId     ? "c.`$colTechId`     AS technician_id"    : "NULL AS technician_id";

$sql = "SELECT " . implode(",\n       ", $selects) . "
        FROM pm_checklists c
        " . implode("\n        ", $joins) . "
        WHERE c.id = ?";

$stmt = $pdo->prepare($sql);
$stmt->execute([$id]);
$c = $stmt->fetch();

if (!$c) {
    app_fail('E-PM-404');
}

/* Normalise status to a bucket */
$rawStatus = strtoupper((string)($c['status_value'] ?? ''));
if ($rawStatus === '') {
    $bucket = 'APPROVED'; // no status column → treat as decided
} elseif (str_contains($rawStatus, 'REJECT') || str_contains($rawStatus, 'DECLINE') || str_contains($rawStatus, 'RETURN')) {
    $bucket = 'REJECTED';
} elseif (str_contains($rawStatus, 'APPROV') || str_contains($rawStatus, 'ACCEPT') || $rawStatus === 'DONE' || $rawStatus === 'COMPLETED') {
    $bucket = 'APPROVED';
} else {
    $bucket = 'PENDING';
}

$isApprover = in_array($u['role'], ['ADMIN', 'BRANCH_MANAGER'], true);
$isOwner    = $c['technician_id'] !== null && (int)$c['technician_id'] === (int)$u['id'];

if (!$isApprover && !$isOwner) {
    app_fail('E-AUTH-403');
}

$error = '';
$ok = '';

/* ---------- Approve / reject ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action  = $_POST['action'] ?? '';
    $remarks = trim((string)($_POST['remarks'] ?? ''));

    if (!$isApprover) {
        $error = 'Only the Branch Manager can approve or reject a checklist.';
    } elseif (!verify_csrf($_POST['csrf'] ?? null)) {
        $error = 'Your session expired. Please try again.';
    } elseif (!in_array($action, ['approve', 'reject'], true)) {
        $error = 'Unknown action.';
    } elseif ($action === 'reject' && $remarks === '') {
        $error = 'Please explain why the checklist is being rejected.';
    } elseif ($isOwner) {
        $error = 'You cannot approve or reject your own checklist.';
    } elseif ($bucket !== 'PENDING') {
        $error = 'This checklist has already been decided.';
    } elseif ($colStatus === null || $colApprovedBy === null || $colApprovedAt === null) {
        $error = 'Approvals are not yet enabled: the database is missing the '
               . 'status / approved_by / approved_at columns on pm_checklists. '
               . 'Ask the administrator to run the migration.';
    } else {
        try {
            $pdo->beginTransaction();

            $lock = $pdo->prepare("SELECT `$colStatus` AS s, " . ($colTechId ? "`$colTechId`" : "NULL") . " AS tid
                                   FROM pm_checklists WHERE id = ? FOR UPDATE");
            $lock->execute([$id]);
            $fresh = $lock->fetch();

            if (!$fresh) {
                throw new RuntimeException('Checklist no longer exists.');
            }
            if (strtoupper((string)$fresh['s']) !== 'PENDING') {
                throw new RuntimeException('This checklist was already decided by someone else.');
            }
            if ($colTechId && (int)$fresh['tid'] === (int)$u['id']) {
                throw new RuntimeException('You cannot approve or reject your own checklist.');
            }

            $newStatus = $action === 'approve' ? 'APPROVED' : 'REJECTED';

            // Build UPDATE dynamically for optional approval_remarks column
            $setSql = "`$colStatus` = ?, `$colApprovedBy` = ?, `$colApprovedAt` = NOW()";
            $params = [$newStatus, (int)$u['id']];
            if ($colApprRemark !== null) {
                $setSql .= ", `$colApprRemark` = ?";
                $params[] = $remarks !== '' ? $remarks : null;
            }
            $params[] = $id;

            $pdo->prepare("UPDATE pm_checklists SET $setSql WHERE id = ?")
                ->execute($params);

            $quarterLabel = (string)($c['quarter_label'] ?? '');

            if (function_exists('audit')) {
                audit($action === 'approve' ? 'ApprovePMChecklist' : 'RejectPMChecklist',
                      'pm_checklists', $id,
                      trim($quarterLabel . ' ' . ($action === 'approve' ? 'approved' : 'rejected')
                        . ($remarks !== '' ? ": {$remarks}" : '')));
            }

            if (function_exists('notify') && $colTechId !== null) {
                $techId = (int)$fresh['tid'];
                $label  = $quarterLabel !== '' ? $quarterLabel : 'PM checklist';
                notify($techId, null,
                    'Preventive maintenance ' . strtolower($newStatus) . " ({$label})",
                    $action === 'approve'
                        ? "Your {$label} preventive maintenance checklist was approved by {$u['full_name']}."
                        : "Your {$label} preventive maintenance checklist was rejected by {$u['full_name']}. Remarks: {$remarks}",
                    $action === 'approve' ? 'pm' : 'warning');
            }

            $pdo->commit();
            redirect(BASE_URL . '/ict/pm_view.php?id=' . $id . '&done=1');
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = app_exception_message($e);
        }
    }
}

if (isset($_GET['done']) && $error === '') {
    $ok = 'Your decision has been saved and the technician has been notified.';
}

/* ---------- Items grouped per employee ---------- */
$itemsStmt = $pdo->prepare("SELECT * FROM pm_checklist_items
                            WHERE checklist_id = ?
                            ORDER BY employee_name, item_number");
$itemsStmt->execute([$id]);

$employees = [];
foreach ($itemsStmt->fetchAll() as $it) {
    $empName = (string)($it['employee_name'] ?? '—');
    $key = (isset($it['employee_id']) && $it['employee_id'] ? 'id:' . $it['employee_id'] : 'name:' . $empName)
         . '|' . $empName;
    if (!isset($employees[$key])) {
        $employees[$key] = ['name' => $empName, 'items' => [], 'notes' => []];
    }
    $num = (int)($it['item_number'] ?? 0);
    $employees[$key]['items'][$num] = (int)($it['done'] ?? 0);
    $note = trim((string)($it['note'] ?? ''));
    if ($note !== '') {
        $employees[$key]['notes'][$num] = $note;
    }
}

$totalItems = 0;
$doneItems  = 0;
foreach ($employees as $emp) {
    $totalItems += count($emp['items']);
    $doneItems  += array_sum($emp['items']);
}

// Status badge — works whether pm_status_badge exists and supports $bucket
$badgeHtml = function_exists('pm_status_badge')
    ? pm_status_badge($bucket)
    : '<span class="pm-status ' . ($bucket === 'APPROVED' ? 'is-good' : ($bucket === 'REJECTED' ? 'is-bad' : 'is-critical')) . '">' . e($bucket) . '</span>';

$backUrl = $isApprover
    ? BASE_URL . '/ict/pm_approvals.php'
    : BASE_URL . '/ict/preventive_maintenance.php';

$quarterText = !empty($c['quarter_label']) ? $c['quarter_label'] : 'Checklist';
$techText    = !empty($c['tech_full_name']) ? $c['tech_full_name'] : ($c['technician_name'] ?: '—');

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:#0070f2; --sap-brand-dark:#0057d2;
    --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500;
    --sap-negative:#aa0808;
    --sap-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
  }
  body, .main-content { background: var(--sap-bg) !important;
    font-family: "72","72full",Arial,Helvetica,sans-serif !important; color: var(--sap-text); }

  .sap-page-header { display:flex; align-items:flex-start; justify-content:space-between;
    margin-bottom:1rem; flex-wrap:wrap; gap:.75rem; }
  .sap-page-title { font-size:1.625rem; font-weight:400; margin:0; }
  .sap-breadcrumb { font-size:.8125rem; color:var(--sap-text-muted); margin-bottom:.25rem; }

  .sap-message { display:flex; align-items:flex-start; gap:.6rem; padding:.75rem 1rem;
    border-radius:.5rem; font-size:.8125rem; line-height:1.45; margin-bottom:1rem;
    border-left:3px solid; }
  .sap-message.is-success { background:#f1fdf6; color:var(--sap-positive); border-left-color:var(--sap-positive); }
  .sap-message.is-error   { background:#fef4f4; color:var(--sap-negative); border-left-color:var(--sap-negative); }
  .sap-message.is-info    { background:#eaf4ff; color:#0a4a9c; border-left-color:var(--sap-brand); }
  .sap-message.is-warning { background:#fff8f1; color:#8a3b00; border-left-color:var(--sap-critical); }

  .sap-card { background:var(--sap-tile); border-radius:.75rem; box-shadow:var(--sap-shadow);
    overflow:hidden; margin-bottom:1rem; }
  .sap-card-header { padding:.85rem 1.15rem; border-bottom:1px solid var(--sap-border-soft);
    font-size:.875rem; font-weight:600; display:flex; align-items:center; gap:.45rem; }
  .sap-card-header .bi { color:var(--sap-brand); }
  .sap-card-body { padding:1rem 1.15rem; }

  .pm-id { font-family:"72Mono","Courier New",monospace; font-size:.8rem;
    color:var(--sap-brand); background:#eaf4ff; border:1px solid #cfe2f8;
    padding:.12rem .5rem; border-radius:.35rem; margin-right:.5rem; }
  .pm-subject { font-size:1.05rem; font-weight:600; }

  .pm-info-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(170px,1fr));
    gap:.75rem 1.25rem; }
  .pm-info-label { font-size:.66rem; text-transform:uppercase; letter-spacing:.05em;
    font-weight:600; color:var(--sap-text-muted); margin-bottom:.12rem; }
  .pm-info-value { font-size:.855rem; }

  .pm-status { display:inline-flex; align-items:center; gap:.3rem; font-size:.72rem;
    font-weight:600; padding:.25rem .65rem; border-radius:.75rem;
    white-space:nowrap; border:1px solid transparent; }
  .pm-status.is-critical { background:#fff8f1; color:var(--sap-critical); border-color:#fbe0c8; }
  .pm-status.is-good     { background:#f1fdf6; color:var(--sap-positive); border-color:#d6f0e0; }
  .pm-status.is-bad      { background:#fef4f4; color:var(--sap-negative); border-color:#f7d2d2; }

  .pm-notes-box { background:#fafbfc; border:1px solid var(--sap-border-soft);
    border-radius:.5rem; padding:.75rem .9rem; font-size:.83rem; line-height:1.5;
    white-space:pre-wrap; }

  .pm-remarks-box { background:#fff8f1; border:1px solid #fbe0c8; color:#8a3b00;
    border-radius:.5rem; padding:.75rem .9rem; font-size:.83rem; line-height:1.5; }

  .pm-table-wrap { overflow-x:auto; }
  .pm-matrix { width:100%; border-collapse:separate; border-spacing:0; font-size:.74rem;
    background:#fff; border:1px solid var(--sap-border); border-radius:.5rem; overflow:hidden; }
  .pm-matrix thead th { background:#f5f6f7; font-size:.62rem; text-transform:uppercase;
    letter-spacing:.03em; color:var(--sap-text-muted); padding:.45rem .3rem;
    text-align:center; border-bottom:1px solid var(--sap-border);
    border-right:1px solid var(--sap-border-soft); }
  .pm-matrix thead th:first-child { text-align:left; min-width:170px; }
  .pm-matrix thead th .item-label { display:block; margin-top:.15rem; font-size:.55rem;
    text-transform:none; letter-spacing:0; line-height:1.15; font-weight:600; }
  .pm-matrix tbody td { padding:.4rem .3rem; border-bottom:1px solid var(--sap-border-soft);
    border-right:1px solid var(--sap-border-soft); text-align:center; vertical-align:middle; }
  .pm-matrix tbody td:first-child { text-align:left; }
  .pm-matrix tbody tr:last-child td { border-bottom:0; }
  .pm-matrix tbody tr:nth-child(even) { background:#fafbfc; }
  .pm-matrix th:last-child, .pm-matrix td:last-child { border-right:0; }
  .pm-matrix .emp-name { font-weight:600; font-size:.8rem; }
  .pm-done { color:var(--sap-positive); font-size:.95rem; }
  .pm-off  { color:#c5cdd6; font-size:.95rem; }
  .pm-note { font-size:.7rem; color:var(--sap-text); text-align:left; min-width:170px; }
  .pm-note-num { font-weight:700; color:var(--sap-brand); margin-right:.2rem; }

  .sap-btn { display:inline-flex; align-items:center; gap:.4rem; font-size:.8125rem;
    font-weight:500; border-radius:.5rem; padding:.5rem .9rem; border:1px solid transparent;
    background:transparent; color:var(--sap-brand); cursor:pointer; line-height:1;
    text-decoration:none; white-space:nowrap; font-family:inherit; }
  .sap-btn:hover { background:#eaf4ff; color:var(--sap-brand-dark); }
  .sap-btn.sap-btn-outline { border-color:var(--sap-border); background:#fff; }
  .sap-btn.sap-btn-success { background:var(--sap-positive); color:#fff; }
  .sap-btn.sap-btn-success:hover { background:#1d5d2e; color:#fff; }
  .sap-btn.sap-btn-danger { background:var(--sap-negative); color:#fff; }
  .sap-btn.sap-btn-danger:hover { background:#8a0606; color:#fff; }

  .pm-form-label { display:block; font-size:.7rem; text-transform:uppercase;
    letter-spacing:.04em; font-weight:600; color:var(--sap-text-muted); margin-bottom:.3rem; }
  .pm-form-control { width:100%; font-size:.86rem; font-family:inherit; color:var(--sap-text);
    background:#fff; border:1px solid var(--sap-border); border-radius:.5rem;
    padding:.5rem .7rem; outline:none; resize:vertical; }
  .pm-form-control:focus { border-color:var(--sap-brand); box-shadow:0 0 0 3px rgba(0,112,242,.15); }
  .pm-decision-actions { display:flex; gap:.6rem; flex-wrap:wrap; margin-top:.75rem; }
</style>

<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb">
      <i class="bi bi-house-door"></i> Home /
      <?php if ($isApprover): ?>
        <a href="<?= BASE_URL ?>/ict/pm_approvals.php" style="color:inherit;text-decoration:none">PM Approvals</a> /
      <?php endif; ?>
      <strong>PM-<?= str_pad((string)$c['id'], 4, '0', STR_PAD_LEFT) ?></strong>
    </div>
    <h1 class="sap-page-title">
      Preventive Maintenance — <?= e($quarterText) ?>
    </h1>
  </div>
  <?= $badgeHtml ?>
</div>

<?php if ($error): ?>
  <div class="sap-message is-error"><i class="bi bi-exclamation-circle"></i><span><?= e($error) ?></span></div>
<?php endif; ?>
<?php if ($ok): ?>
  <div class="sap-message is-success"><i class="bi bi-check-circle"></i><span><?= e($ok) ?></span></div>
<?php endif; ?>

<?php if ($bucket === 'PENDING' && !$isApprover): ?>
  <div class="sap-message is-info">
    <i class="bi bi-hourglass-split"></i>
    <span>This checklist is waiting for the Branch Manager to approve it. You will be notified when a decision is made.</span>
  </div>
<?php elseif ($bucket === 'REJECTED' && $isOwner): ?>
  <div class="sap-message is-warning">
    <i class="bi bi-exclamation-triangle"></i>
    <span>This checklist was rejected. Read the remarks below, then
      <a href="<?= BASE_URL ?>/ict/preventive_maintenance.php">submit a corrected checklist</a>.</span>
  </div>
<?php endif; ?>

<!-- ===================== Header ===================== -->
<div class="sap-card">
  <div class="sap-card-header"><i class="bi bi-clipboard-check"></i> Checklist Summary</div>
  <div class="sap-card-body">
    <div class="pm-info-grid">
      <div>
        <div class="pm-info-label">Technician</div>
        <div class="pm-info-value"><?= e($techText) ?></div>
      </div>
      <div>
        <div class="pm-info-label">Department</div>
        <div class="pm-info-value"><?= e($c['department_name'] ?? '—') ?></div>
      </div>
      <div>
        <div class="pm-info-label">Checklist date</div>
        <div class="pm-info-value">
          <?= !empty($c['checklist_date']) ? e(date('M j, Y', strtotime($c['checklist_date']))) : '—' ?>
        </div>
      </div>
      <div>
        <div class="pm-info-label">Submitted</div>
        <div class="pm-info-value">
          <?= !empty($c['submitted_at']) ? e(date('M j, Y H:i', strtotime($c['submitted_at']))) : '—' ?>
        </div>
      </div>
      <div>
        <div class="pm-info-label">Employees inspected</div>
        <div class="pm-info-value"><?= count($employees) ?></div>
      </div>
      <div>
        <div class="pm-info-label">Items completed</div>
        <div class="pm-info-value"><strong><?= $doneItems ?></strong> of <?= $totalItems ?></div>
      </div>
      <?php if (!empty($c['approver_name'])): ?>
        <div>
          <div class="pm-info-label">Reviewed by</div>
          <div class="pm-info-value"><?= e($c['approver_name']) ?></div>
        </div>
        <?php if (!empty($c['approved_at'])): ?>
        <div>
          <div class="pm-info-label">Decision date</div>
          <div class="pm-info-value"><?= e(date('M j, Y H:i', strtotime($c['approved_at']))) ?></div>
        </div>
        <?php endif; ?>
      <?php endif; ?>
    </div>

    <?php if (!empty($c['notes'])): ?>
      <div class="pm-info-label" style="margin-top:1rem">Technician notes</div>
      <div class="pm-notes-box"><?= e($c['notes']) ?></div>
    <?php endif; ?>

    <?php if (!empty($c['approval_remarks'])): ?>
      <div class="pm-info-label" style="margin-top:1rem">Approval remarks</div>
      <div class="<?= $bucket === 'REJECTED' ? 'pm-remarks-box' : 'pm-notes-box' ?>">
        <?= e($c['approval_remarks']) ?>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- ===================== Decision ===================== -->
<?php if ($isApprover && $bucket === 'PENDING'): ?>
<div class="sap-card">
  <div class="sap-card-header"><i class="bi bi-patch-check"></i> Branch Manager Decision</div>
  <div class="sap-card-body">
    <form method="post" id="decisionForm">
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
      <label class="pm-form-label" for="remarks">Remarks (required when rejecting)</label>
      <textarea id="remarks" name="remarks" class="pm-form-control" rows="3"
                placeholder="Optional note for approval; explain what must be corrected when rejecting"></textarea>
      <div class="pm-decision-actions">
        <button type="submit" name="action" value="approve" class="sap-btn sap-btn-success">
          <i class="bi bi-check2-circle"></i> Approve Checklist
        </button>
        <button type="submit" name="action" value="reject" class="sap-btn sap-btn-danger">
          <i class="bi bi-x-circle"></i> Reject with Remarks
        </button>
        <a href="<?= BASE_URL ?>/ict/pm_approvals.php" class="sap-btn sap-btn-outline">
          <i class="bi bi-arrow-left"></i> Back to Approvals
        </a>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<!-- ===================== Matrix ===================== -->
<div class="sap-card">
  <div class="sap-card-header"><i class="bi bi-list-check"></i> Completed Checklist Items</div>
  <div class="sap-card-body p-2">
    <?php if (!$employees): ?>
      <div style="text-align:center;padding:2rem;color:var(--sap-text-muted)">
        No checklist items were recorded for this submission.
      </div>
    <?php else: ?>
      <div class="pm-table-wrap">
        <table class="pm-matrix">
          <thead>
            <tr>
              <th>Employee</th>
              <?php foreach (PM_ITEMS as $num => $item): ?>
                <th title="<?= e($item['label']) ?>">
                  <?= $num ?>
                  <span class="item-label"><?= e($item['label']) ?></span>
                </th>
              <?php endforeach; ?>
              <th>Notes</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($employees as $emp): ?>
              <tr>
                <td>
                  <div class="emp-name"><?= e($emp['name'] ?: '—') ?></div>
                </td>
                <?php foreach (PM_ITEMS as $num => $item): ?>
                  <?php $done = !empty($emp['items'][$num]); ?>
                  <td title="<?= e($item['label']) ?>">
                    <?php if ($done): ?>
                      <i class="bi bi-check-circle-fill pm-done"></i>
                    <?php else: ?>
                      <i class="bi bi-dash-circle pm-off"></i>
                    <?php endif; ?>
                  </td>
                <?php endforeach; ?>
                <td class="pm-note">
                  <?php if ($emp['notes']): foreach ($emp['notes'] as $num => $note): ?>
                    <div>
                      <span class="pm-note-num"><?= (int)$num ?>.</span><?= e($note) ?>
                    </div>
                  <?php endforeach; else: ?>
                    —
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>

    <div class="pm-decision-actions">
      <a href="<?= $backUrl ?>" class="sap-btn sap-btn-outline">
        <i class="bi bi-arrow-left"></i>
        <?= $isApprover ? 'Back to Approvals' : 'Back to Preventive Maintenance' ?>
      </a>
    </div>
  </div>
</div>

<script>
document.getElementById('decisionForm')?.addEventListener('submit', e => {
  const remarks = document.getElementById('remarks');
  if (e.submitter && e.submitter.value === 'reject' && !remarks.value.trim()) {
    e.preventDefault();
    alert('Please write the reason for rejecting this checklist.');
    remarks.focus();
  } else if (e.submitter && e.submitter.value === 'approve'
             && !confirm('Approve this preventive maintenance checklist?')) {
    e.preventDefault();
  }
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>