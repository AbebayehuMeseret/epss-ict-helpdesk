<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/pm.php';
$u = require_role('BRANCH_MANAGER', 'ADMIN');
$pageTitle = 'PM Approvals';
$pdo = db();

/* =====================================================================
 * Schema detection — pm_checklists varies a lot between installs.
 * Detect which optional columns exist once, then build queries and
 * templates that only use what is actually available.
 * ===================================================================== */

function pma_cols(PDO $pdo, string $table): array {
    static $cache = [];
    if (isset($cache[$table])) return $cache[$table];
    try {
        $rows = $pdo->query("SHOW COLUMNS FROM `" . str_replace('`', '', $table) . "`")
                    ->fetchAll(PDO::FETCH_COLUMN);
        return $cache[$table] = array_map('strtolower', $rows ?: []);
    } catch (Throwable $e) {
        return $cache[$table] = [];
    }
}

function pma_has(array $cols, string ...$candidates): ?string {
    foreach ($candidates as $c) {
        if (in_array($c, $cols, true)) return $c;
    }
    return null;
}

$pmCols = pma_cols($pdo, 'pm_checklists');

// Status column
$statusCol = pma_has($pmCols, 'status', 'approval_status', 'checklist_status', 'review_status', 'state');

// Individual optional columns used by the template / joins
$colApprovedBy     = pma_has($pmCols, 'approved_by');
$colApprovedAt     = pma_has($pmCols, 'approved_at', 'reviewed_at');
$colSubmittedAt    = pma_has($pmCols, 'submitted_at', 'created_at');
$colNotes          = pma_has($pmCols, 'notes', 'remarks', 'comment');
$colQuarter        = pma_has($pmCols, 'quarter_label', 'quarter');
$colTechName       = pma_has($pmCols, 'technician_name');
$colTechId         = pma_has($pmCols, 'technician_id');
$colDepartmentId   = pma_has($pmCols, 'department_id');
$colChecklistDate  = pma_has($pmCols, 'checklist_date', 'date', 'performed_date');

/* ---------- Filter (unchanged interface) ---------- */
$status = strtoupper($_GET['status'] ?? 'PENDING');
if (!in_array($status, ['PENDING', 'APPROVED', 'REJECTED', 'ALL'], true)) {
    $status = 'PENDING';
}

/* ---------- Status helpers ---------- */
function pma_status_values(PDO $pdo, ?string $col): array {
    static $vals = null;
    if ($vals !== null) return $vals;
    if ($col === null) return $vals = [];
    try {
        $rows = $pdo->query("SELECT DISTINCT `$col` FROM pm_checklists")->fetchAll(PDO::FETCH_COLUMN);
        return $vals = array_values(array_filter($rows, static fn($v) => $v !== null && $v !== ''));
    } catch (Throwable $e) {
        return $vals = [];
    }
}

function pma_match_value(PDO $pdo, ?string $col, string $bucket): ?string {
    $aliases = [
        'PENDING'  => ['PENDING', 'SUBMITTED', 'AWAITING', 'IN_REVIEW', 'WAITING'],
        'APPROVED' => ['APPROVED', 'APPROVE', 'ACCEPTED', 'OK', 'DONE', 'COMPLETED'],
        'REJECTED' => ['REJECTED', 'REJECT', 'DECLINED', 'RETURNED', 'SENT_BACK'],
    ];
    $vals = pma_status_values($pdo, $col);
    if (!$vals) return null;
    foreach ($aliases[$bucket] ?? [$bucket] as $want) {
        foreach ($vals as $v) if (strtoupper((string)$v) === $want) return (string)$v;
    }
    foreach ($aliases[$bucket] ?? [$bucket] as $want) {
        foreach ($vals as $v) if (str_contains(strtoupper((string)$v), $want)) return (string)$v;
    }
    return null;
}

/* ---------- Counts ---------- */
$counts = ['PENDING' => 0, 'APPROVED' => 0, 'REJECTED' => 0];
if ($statusCol !== null) {
    try {
        $stmt = $pdo->query("SELECT `$statusCol` AS s, COUNT(*) c FROM pm_checklists GROUP BY `$statusCol`");
        foreach ($stmt as $r) {
            $val = strtoupper((string)$r['s']);
            if (isset($counts[$val])) $counts[$val] = (int)$r['c'];
        }
    } catch (Throwable $e) { /* leave zeros */ }
} else {
    try {
        $counts['APPROVED'] = (int)$pdo->query("SELECT COUNT(*) FROM pm_checklists")->fetchColumn();
    } catch (Throwable $e) { /* ignore */ }
}
$counts['ALL'] = array_sum($counts);

/* ---------- Build SELECT dynamically ---------- */
$selects = ['c.*'];

// Department name (optional join)
$hasDepartments = $colDepartmentId !== null
    && in_array('departments', array_map('strtolower', array_column(
        $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_NUM), 0)), true);

$joins = [];
if ($colDepartmentId !== null) {
    try {
        $deptExists = $pdo->query("SHOW TABLES LIKE 'departments'")->fetchColumn();
        if ($deptExists) {
            $selects[] = 'd.department_name';
            $joins[]   = "LEFT JOIN departments d ON d.id = c.`$colDepartmentId`";
        }
    } catch (Throwable $e) { /* ignore */ }
}

// Technician full name (optional join)
$hasUserTable = false;
try { $hasUserTable = (bool)$pdo->query("SHOW TABLES LIKE 'users'")->fetchColumn(); } catch (Throwable $e) {}
if ($hasUserTable && $colTechId !== null) {
    $selects[] = 'tu.full_name AS tech_full_name';
    $joins[]   = "LEFT JOIN users tu ON tu.id = c.`$colTechId`";
}
if ($hasUserTable && $colApprovedBy !== null) {
    $selects[] = 'ap.full_name AS approver_name';
    $joins[]   = "LEFT JOIN users ap ON ap.id = c.`$colApprovedBy`";
}

// Subselects for the items list — only if the child table exists
$hasItems = false;
try { $hasItems = (bool)$pdo->query("SHOW TABLES LIKE 'pm_checklist_items'")->fetchColumn(); } catch (Throwable $e) {}
if ($hasItems) {
    $selects[] = "(SELECT COUNT(*) FROM pm_checklist_items i WHERE i.checklist_id = c.id) AS items_total";
    $selects[] = "(SELECT COALESCE(SUM(i.done), 0) FROM pm_checklist_items i WHERE i.checklist_id = c.id) AS items_done";
    $selects[] = "(SELECT COUNT(DISTINCT i.employee_name) FROM pm_checklist_items i WHERE i.checklist_id = c.id) AS employees_total";
} else {
    $selects[] = "0 AS items_total";
    $selects[] = "0 AS items_done";
    $selects[] = "0 AS employees_total";
}

// Aliased helpers so the template can always reference stable names
$selects[] = $colApprovedAt  ? "c.`$colApprovedAt` AS approved_at"   : "NULL AS approved_at";
$selects[] = $colSubmittedAt ? "c.`$colSubmittedAt` AS submitted_at" : "NULL AS submitted_at";
$selects[] = $colNotes       ? "c.`$colNotes` AS notes"              : "NULL AS notes";
$selects[] = $colQuarter     ? "c.`$colQuarter` AS quarter_label"    : "NULL AS quarter_label";
$selects[] = $colTechName    ? "c.`$colTechName` AS technician_name" : "NULL AS technician_name";
$selects[] = $colChecklistDate
    ? "c.`$colChecklistDate` AS checklist_date"
    : "NULL AS checklist_date";
$selects[] = $statusCol ? "c.`$statusCol` AS status_value" : "NULL AS status_value";

$sql = "SELECT " . implode(",\n       ", $selects) . "
        FROM pm_checklists c
        " . implode("\n        ", $joins);

$params = [];
if ($status !== 'ALL' && $statusCol !== null) {
    $want = pma_match_value($pdo, $statusCol, $status);
    if ($want !== null) {
        $sql .= " WHERE c.`$statusCol` = ?";
        $params[] = $want;
    } else {
        $sql .= " WHERE 1=0";
    }
} elseif ($status !== 'ALL' && $statusCol === null) {
    if ($status !== 'APPROVED') $sql .= " WHERE 1=0";
}

$orderCol = $colSubmittedAt ?: 'id';
$sql .= " ORDER BY c.`$orderCol` DESC, c.id DESC LIMIT 200";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll();

/** Normalise a row's status to a UI bucket. */
$bucketOf = static function (array $row): string {
    $v = strtoupper((string)($row['status_value'] ?? ''));
    if ($v === '') return 'APPROVED'; // no status column → treat as done
    if (str_contains($v, 'REJECT') || str_contains($v, 'DECLINE') || str_contains($v, 'RETURN')) return 'REJECTED';
    if (str_contains($v, 'APPROV') || str_contains($v, 'ACCEPT') || $v === 'DONE' || $v === 'COMPLETED') return 'APPROVED';
    return 'PENDING';
};

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:#0070f2; --sap-brand-dark:#0057d2;
    --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500;
    --sap-negative:#aa0808;
    --sap-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
    --sap-shadow-hover: 0 0 0 1px rgba(34,53,72,.15), 0 8px 24px 0 rgba(34,53,72,.12);
  }
  body, .main-content { background: var(--sap-bg) !important;
    font-family: "72","72full",Arial,Helvetica,sans-serif !important; color: var(--sap-text); }

  .sap-page-header { display:flex; align-items:flex-start; justify-content:space-between;
    margin-bottom:1rem; flex-wrap:wrap; gap:.75rem; }
  .sap-page-title { font-size:1.625rem; font-weight:400; margin:0; }
  .sap-breadcrumb { font-size:.8125rem; color:var(--sap-text-muted); margin-bottom:.25rem; }

  .sap-message { display:flex; align-items:flex-start; gap:.6rem; padding:.75rem 1rem;
    border-radius:.5rem; font-size:.8125rem; line-height:1.4; margin-bottom:1rem;
    border-left:3px solid; }
  .sap-message.is-success { background:#f1fdf6; color:var(--sap-positive); border-left-color:var(--sap-positive); }
  .sap-message.is-info { background:#eaf4ff; color:#0a4a9c; border-left-color:var(--sap-brand); }

  .pm-tabs { display:flex; gap:.35rem; flex-wrap:wrap; margin-bottom:1rem; }
  .pm-tab { display:inline-flex; align-items:center; gap:.4rem; padding:.45rem .85rem;
    border-radius:.5rem; font-size:.8rem; color:var(--sap-text); text-decoration:none;
    background:#fff; box-shadow:var(--sap-shadow); transition:background .15s,color .15s; }
  .pm-tab:hover { background:#eaf4ff; color:var(--sap-brand-dark); }
  .pm-tab.active { background:var(--sap-brand); color:#fff; box-shadow:none; }
  .pm-tab .count { font-size:.7rem; font-weight:700; padding:.05rem .4rem;
    border-radius:.65rem; background:rgba(0,0,0,.07); }
  .pm-tab.active .count { background:rgba(255,255,255,.25); }

  .pm-card { background:var(--sap-tile); border-radius:.75rem; box-shadow:var(--sap-shadow);
    overflow:hidden; margin-bottom:1rem; transition:box-shadow .2s; }
  .pm-card:hover { box-shadow:var(--sap-shadow-hover); }
  .pm-card-head { padding:.9rem 1.15rem; display:flex; justify-content:space-between;
    align-items:flex-start; gap:.75rem; flex-wrap:wrap;
    border-bottom:1px solid var(--sap-border-soft); }
  .pm-id { font-family:"72Mono","Courier New",monospace; font-size:.78rem;
    color:var(--sap-brand); background:#eaf4ff; border:1px solid #cfe2f8;
    padding:.12rem .5rem; border-radius:.35rem; margin-right:.5rem; }
  .pm-tech { font-weight:600; font-size:.95rem; }
  .pm-sub { font-size:.75rem; color:var(--sap-text-muted); margin-top:.25rem; }
  .pm-card-body { padding:.95rem 1.15rem; }

  .pm-stats { display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr));
    gap:.75rem 1.25rem; margin-bottom:.85rem; }
  .pm-stat-label { font-size:.66rem; text-transform:uppercase; letter-spacing:.05em;
    font-weight:600; color:var(--sap-text-muted); }
  .pm-stat-value { font-size:.84rem; }

  .pm-progress { height:7px; background:#eaecf0; border-radius:999px; overflow:hidden; margin-bottom:.35rem; }
  .pm-progress > span { display:block; height:100%; border-radius:999px; background:var(--sap-brand); }
  .pm-progress.is-good > span { background:var(--sap-positive); }
  .pm-progress.is-bad > span { background:var(--sap-negative); }

  .pm-notes { background:#fafbfc; border:1px solid var(--sap-border-soft);
    border-radius:.5rem; padding:.65rem .8rem; font-size:.8rem; line-height:1.5;
    color:var(--sap-text); white-space:pre-wrap; margin:.75rem 0; }

  .pm-status { display:inline-flex; align-items:center; gap:.3rem; font-size:.7rem;
    font-weight:600; padding:.22rem .6rem; border-radius:.75rem;
    white-space:nowrap; border:1px solid transparent; }
  .pm-status.is-critical { background:#fff8f1; color:var(--sap-critical); border-color:#fbe0c8; }
  .pm-status.is-good     { background:#f1fdf6; color:var(--sap-positive); border-color:#d6f0e0; }
  .pm-status.is-bad      { background:#fef4f4; color:var(--sap-negative); border-color:#f7d2d2; }

  .sap-btn { display:inline-flex; align-items:center; gap:.4rem; font-size:.8125rem;
    font-weight:500; border-radius:.5rem; padding:.5rem .9rem; border:1px solid transparent;
    background:transparent; color:var(--sap-brand); cursor:pointer; line-height:1;
    text-decoration:none; white-space:nowrap; font-family:inherit; }
  .sap-btn:hover { background:#eaf4ff; color:var(--sap-brand-dark); }
  .sap-btn.sap-btn-emphasized { background:var(--sap-brand); color:#fff; }
  .sap-btn.sap-btn-emphasized:hover { background:var(--sap-brand-dark); color:#fff; }

  .pm-empty { text-align:center; padding:2.75rem 1rem; color:var(--sap-text-muted);
    background:#fff; border-radius:.75rem; box-shadow:var(--sap-shadow); }
  .pm-empty .bi { font-size:2.2rem; opacity:.4; }
  .pm-empty-title { font-size:.95rem; font-weight:600; color:var(--sap-text); margin-top:.55rem; }
</style>

<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb"><i class="bi bi-house-door"></i> Home / <strong>PM Approvals</strong></div>
    <h1 class="sap-page-title">Preventive Maintenance Approvals</h1>
  </div>
  <span class="pm-status is-critical" style="font-size:.78rem;padding:.35rem .8rem">
    <i class="bi bi-hourglass-split"></i> <?= (int)$counts['PENDING'] ?> awaiting approval
  </span>
</div>

<div class="sap-message is-info">
  <i class="bi bi-info-circle"></i>
  <span>ICT technicians submit their quarterly checklist here. Review the completed items, then
        <strong>approve</strong> or <strong>send it back with remarks</strong>. The technician is notified either way.</span>
</div>

<div class="pm-tabs">
  <?php foreach (['PENDING' => 'Pending', 'APPROVED' => 'Approved',
                  'REJECTED' => 'Rejected', 'ALL' => 'All'] as $key => $label): ?>
    <a class="pm-tab <?= $status === $key ? 'active' : '' ?>"
       href="?status=<?= $key ?>">
      <?= e($label) ?> <span class="count"><?= (int)$counts[$key] ?></span>
    </a>
  <?php endforeach; ?>
</div>

<?php if (!$items): ?>
  <div class="pm-empty">
    <i class="bi bi-clipboard-check"></i>
    <div class="pm-empty-title">
      <?= $status === 'PENDING' ? 'Nothing waiting for you' : 'No checklists in this view' ?>
    </div>
    <div style="font-size:.82rem;margin-top:.3rem">
      <?= $status === 'PENDING'
            ? 'Every preventive maintenance checklist has been reviewed.'
            : 'Try another filter.' ?>
    </div>
  </div>
<?php else: foreach ($items as $c):
    $bucket   = $bucketOf($c);
    $total    = (int)$c['items_total'];
    $done     = (int)$c['items_done'];
    $pct      = $total > 0 ? (int)round($done / $total * 100) : 0;
    $barClass = $bucket === 'APPROVED' ? 'is-good' : ($bucket === 'REJECTED' ? 'is-bad' : '');
    $notes    = trim((string)($c['notes'] ?? ''));
    $excerpt  = $notes === '' ? '' : (mb_strlen($notes) > 170 ? mb_substr($notes, 0, 170) . '…' : $notes);
    $techName = ($c['tech_full_name'] ?? null) ?: ($c['technician_name'] ?? '—');
    $deptName = $c['department_name'] ?? 'No department';
    $quarter  = $c['quarter_label'] ?? null;
    $submittedAt = $c['submitted_at'] ?? null;
    $approvedAt  = $c['approved_at']  ?? null;
    $checkDate   = $c['checklist_date'] ?? null;
?>
  <div class="pm-card">
    <div class="pm-card-head">
      <div>
        <div>
          <span class="pm-id">PM-<?= str_pad((string)$c['id'], 4, '0', STR_PAD_LEFT) ?></span>
          <span class="pm-tech"><?= e($techName) ?></span>
        </div>
        <div class="pm-sub">
          <?= e($deptName) ?>
          <?php if ($quarter): ?> · <strong><?= e($quarter) ?></strong><?php endif; ?>
          <?php if ($submittedAt): ?>
            · submitted <?= e(date('M j, Y H:i', strtotime($submittedAt))) ?>
          <?php endif; ?>
        </div>
      </div>
      <?php if (function_exists('pm_status_badge')): ?>
        <?= pm_status_badge($bucket) ?>
      <?php else: ?>
        <span class="pm-status <?= $bucket === 'APPROVED' ? 'is-good' : ($bucket === 'REJECTED' ? 'is-bad' : 'is-critical') ?>">
          <?= e($bucket) ?>
        </span>
      <?php endif; ?>
    </div>

    <div class="pm-card-body">
      <div class="pm-stats">
        <div>
          <div class="pm-stat-label">Checklist date</div>
          <div class="pm-stat-value">
            <?= $checkDate ? e(date('M j, Y', strtotime($checkDate))) : '—' ?>
          </div>
        </div>
        <div>
          <div class="pm-stat-label">Employees</div>
          <div class="pm-stat-value"><?= (int)$c['employees_total'] ?></div>
        </div>
        <div>
          <div class="pm-stat-label">Items completed</div>
          <div class="pm-stat-value"><strong><?= $done ?></strong> / <?= $total ?> (<?= $pct ?>%)</div>
        </div>
        <div>
          <div class="pm-stat-label">Reviewed by</div>
          <div class="pm-stat-value">
            <?= !empty($c['approver_name']) ? e($c['approver_name']) : '—' ?>
            <?php if ($approvedAt): ?>
              <span style="color:var(--sap-text-muted);font-size:.72rem">
                · <?= e(date('M j, Y H:i', strtotime($approvedAt))) ?>
              </span>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <div class="pm-progress <?= $barClass ?>">
        <span style="width:<?= $pct ?>%"></span>
      </div>
      <div style="font-size:.7rem;color:var(--sap-text-muted)"><?= $done ?> of <?= $total ?> checklist items completed</div>

      <?php if ($excerpt !== ''): ?>
        <div class="pm-notes"><?= e($excerpt) ?></div>
      <?php endif; ?>

      <a class="sap-btn sap-btn-emphasized"
         href="<?= BASE_URL ?>/ict/pm_view.php?id=<?= (int)$c['id'] ?>">
        <i class="bi bi-<?= $bucket === 'PENDING' ? 'clipboard-check' : 'eye' ?>"></i>
        <?= $bucket === 'PENDING' ? 'Review & Decide' : 'View Checklist' ?>
      </a>
    </div>
  </div>
<?php endforeach; endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>