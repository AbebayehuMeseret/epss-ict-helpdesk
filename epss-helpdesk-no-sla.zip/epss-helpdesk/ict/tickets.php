<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('ICT_STAFF');
$pageTitle = 'Approved Tickets';

$pdo = db();
$stmt = $pdo->query("SELECT t.*, c.category_name, p.name AS priority_name, p.color AS priority_color,
    req.full_name AS requester_name, d.department_name,
    (SELECT COUNT(*) FROM ticket_attachments WHERE ticket_id=t.id) attach_count
    FROM tickets t
    JOIN categories c ON c.id=t.category_id JOIN priorities p ON p.id=t.priority_id
    JOIN users req ON req.id=t.requester_id
    LEFT JOIN departments d ON d.id=t.department_id
    WHERE t.status IN ('APPROVED_FOR_ICT','ASSIGNED_TO_ICT','IN_PROGRESS',
                       'WAITING_FOR_INFORMATION','WAITING_FOR_PARTS','RETURNED_TO_ICT')
    ORDER BY p.level DESC, t.created_at");
$tickets = $stmt->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h4 class="mb-3">Approved Tickets</h4>
<div class="card"><div class="card-body">
<div class="table-responsive">
<table class="table table-hover" id="ictTickets">
<thead><tr>
  <th>#</th><th>Subject</th><th>Requester</th><th>Category</th>
  <th>Priority</th><th>Status</th><th>Assigned To</th><th>Created</th><th></th>
</tr></thead>
<tbody>
<?php
$techStmt = db()->prepare("SELECT full_name FROM users WHERE id=?");
foreach ($tickets as $t):
  $assigned = '-';
  if ($t['assigned_technician_id']) {
      $techStmt->execute([$t['assigned_technician_id']]);
      $assigned = $techStmt->fetchColumn() ?: '-';
  }
?>
<tr>
  <td><?= e($t['ticket_number']) ?></td>
  <td><?= e($t['subject']) ?></td>
  <td><?= e($t['requester_name']) ?></td>
  <td><?= e($t['category_name']) ?></td>
  <td><span class="badge bg-<?= e($t['priority_color']) ?>"><?= e($t['priority_name']) ?></span></td>
  <td><?= status_badge($t['status']) ?></td>
  <td><?= e($assigned) ?></td>
  <td><small><?= e(date('Y-m-d H:i', strtotime($t['created_at']))) ?></small></td>
  <td><a href="ticket_view.php?id=<?= (int)$t['id'] ?>" class="btn btn-sm btn-primary">Open</a></td>
</tr>
<?php endforeach; ?>
</tbody></table>
</div>
</div></div>
<?php include __DIR__ . '/../includes/footer.php'; ?>