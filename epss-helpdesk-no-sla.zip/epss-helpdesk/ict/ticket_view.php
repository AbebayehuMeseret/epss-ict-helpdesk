<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/escalation.php';
require_once __DIR__ . '/../includes/workflow.php';

$u   = require_role('ICT_STAFF');
$pdo = db();
$id  = (int)($_GET['id'] ?? 0);
if ($id <= 0) { app_fail('E-REQ-400', 'Invalid ticket id.'); }

/* One query, used on first load and again after a failed action so the page
   always shows the ticket's real, current state. */
$fetchTicket = static function () use ($pdo, $id) {
    $stmt = $pdo->prepare("SELECT t.*, c.category_name, sc.name AS subcat_name,
        p.name AS priority_name, p.color AS priority_color, req.full_name AS requester_name,
        d.department_name, tl.full_name AS tl_name, tech.full_name AS tech_name
        FROM tickets t JOIN categories c ON c.id=t.category_id
        LEFT JOIN subcategories sc ON sc.id=t.subcategory_id
        JOIN priorities p ON p.id=t.priority_id
        JOIN users req ON req.id=t.requester_id
        LEFT JOIN departments d ON d.id=t.department_id
        LEFT JOIN users tl ON tl.id=t.team_leader_id
        LEFT JOIN users tech ON tech.id=t.assigned_technician_id
        WHERE t.id=?");
    $stmt->execute([$id]);
    return $stmt->fetch();
};

$t = $fetchTicket();
if (!$t) { app_fail('E-TKT-404'); }

/* ---------- POST: every action goes through includes/workflow.php ---------- */
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        wf_check_csrf();                                   // E-REQ-419 instead of silently doing nothing
        $act = (string)($_POST['action'] ?? '');

        switch ($act) {
            case 'accept':
                ict_accept_ticket($id, $u);
                flash('success', 'You accepted this ticket. The requester has been told that ICT started working on it.');
                break;
            case 'resume':
                ict_resume_ticket($id, $u);
                flash('success', 'Work resumed. The ticket is In Progress again.');
                break;
            case 'assign':
                ict_assign_ticket($id, $u, (int)($_POST['technician_id'] ?? 0));
                flash('success', 'Ticket assigned. The technician must accept it before work starts.');
                break;
            case 'wait_info':
            case 'wait_parts':
                ict_wait_ticket($id, $u, $act === 'wait_info' ? 'info' : 'parts', (string)($_POST['reason'] ?? ''));
                flash('success', 'Ticket put on hold.');
                break;
            case 'resolve':
                ict_resolve_ticket($id, $u, (string)($_POST['action_taken'] ?? ''), $_FILES['evidence'] ?? null);
                flash('success', 'Marked as resolved. The requester has been asked to confirm the fix.');
                break;
            default:
                throw new AppError('E-REQ-400', 'Unknown action.');
        }

        header("Location: ticket_view.php?id={$id}");
        exit;
    } catch (Throwable $e) {
        $error = app_exception_message($e);                // coded, user-safe text (SQL never shown)
        $t = $fetchTicket() ?: $t;
    }
}
$flashOk = flash('success');

/* ---------- What may THIS technician do right now? (the server re-checks every one of these) ---------- */
$status      = (string)$t['status'];
$myId        = (int)$u['id'];
$assignedId  = (int)($t['assigned_technician_id'] ?? 0);
$isMine      = ($assignedId === $myId);
$isActive    = in_array($status, wf_ict_active_statuses(), true);
$onHold      = in_array($status, wf_waiting_statuses(), true);
$canAccept   = in_array($status, wf_acceptable_statuses(), true) && ($assignedId === 0 || $isMine);
$canWork     = ($status === 'IN_PROGRESS' || $onHold) && ($assignedId === 0 || $isMine);
$heldByOther = $isActive && $assignedId > 0 && !$isMine;

$history = $pdo->prepare("SELECT h.*, u.full_name FROM ticket_history h JOIN users u ON u.id=h.user_id WHERE h.ticket_id=? ORDER BY h.created_at");
$history->execute([$id]); $history = $history->fetchAll();
$attachments = $pdo->prepare("SELECT * FROM ticket_attachments WHERE ticket_id=? ORDER BY uploaded_at");
$attachments->execute([$id]); $attachments = $attachments->fetchAll();
$comments = $pdo->prepare("SELECT c.*, u.full_name FROM ticket_comments c JOIN users u ON u.id=c.user_id WHERE c.ticket_id=? ORDER BY c.created_at");
$comments->execute([$id]); $comments = $comments->fetchAll();
$work = $pdo->prepare("SELECT w.*, u.full_name FROM ticket_work_logs w JOIN users u ON u.id=w.technician_id WHERE w.ticket_id=? ORDER BY w.created_at DESC");
$work->execute([$id]); $work = $work->fetchAll();
$techs = $pdo->query("SELECT id, full_name FROM users WHERE role='ICT_STAFF' AND STATUS='ACTIVE' ORDER BY full_name")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:#0070f2; --sap-brand-dark:#0057d2;
    --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500;
    --sap-negative:#aa0808; --sap-neutral:#5b738b;
    --sap-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
  }
  body, .main-content { background: var(--sap-bg) !important;
    font-family: "72","72full",Arial,Helvetica,sans-serif !important; color: var(--sap-text); }

  .sap-obj-header { background: var(--sap-tile); border-radius: .75rem;
    box-shadow: var(--sap-shadow); padding: 1.1rem 1.4rem; margin-bottom: 1rem;
    border-left: 4px solid var(--sap-brand); }
  .sap-breadcrumb { font-size: .78rem; color: var(--sap-text-muted);
    margin-bottom: .35rem; display: flex; align-items: center; gap: .3rem; flex-wrap: wrap; }
  .sap-breadcrumb a { color: var(--sap-brand); text-decoration: none; }
  .sap-breadcrumb a:hover { text-decoration: underline; }
  .sap-obj-title { font-size: 1.375rem; font-weight: 600;
    margin: 0 0 .25rem; display: flex; align-items: center; gap: .6rem; flex-wrap: wrap; }
  .sap-obj-id { font-family: "72Mono","Courier New",monospace; font-size: 1rem;
    color: var(--sap-brand); background: #eaf4ff; border: 1px solid #cfe2f8;
    padding: .1rem .55rem; border-radius: .35rem; }
  .sap-obj-subject { font-size: .9rem; color: var(--sap-text-muted); margin: 0; }
  .sap-obj-pills { display: flex; gap: .4rem; flex-wrap: wrap; margin-top: .75rem; }

  .sap-status { display: inline-flex; align-items: center; gap: .3rem;
    font-size: .72rem; font-weight: 600; padding: .2rem .6rem;
    border-radius: .75rem; white-space: nowrap; border: 1px solid transparent; }
  .sap-status.is-good     { background:#f1fdf6; color: var(--sap-positive); border-color:#d6f0e0; }
  .sap-status.is-critical { background:#fff8f1; color: var(--sap-critical); border-color:#fbe0c8; }
  .sap-status.is-bad      { background:#fef4f4; color: var(--sap-negative); border-color:#f7d2d2; }
  .sap-status.is-info     { background:#eaf4ff; color: var(--sap-brand);    border-color:#cfe2f8; }
  .sap-status.is-neutral  { background:#f4f5f7; color: var(--sap-neutral);  border-color:#e4e7eb; }
  .sap-status .bi { font-size: .85em; }

  .sap-prio { display: inline-flex; align-items: center; gap: .35rem;
    font-size: .72rem; font-weight: 600; padding: .2rem .6rem;
    border-radius: .75rem; color: #fff; white-space: nowrap;
    box-shadow: 0 1px 2px rgba(0,0,0,.15); }
  .sap-prio .swatch { width: 7px; height: 7px; border-radius: 50%; background: rgba(255,255,255,.75); }

  .sap-card { background: var(--sap-tile); border-radius: .75rem;
    box-shadow: var(--sap-shadow); overflow: hidden; margin-bottom: 1rem; }
  .sap-card:last-child { margin-bottom: 0; }
  .sap-card-header { padding: .8rem 1.15rem; border-bottom: 1px solid var(--sap-border-soft);
    font-size: .8125rem; font-weight: 700; text-transform: uppercase; letter-spacing: .05em;
    color: var(--sap-text-muted); display: flex; align-items: center; justify-content: space-between; gap: .5rem; }
  .sap-card-header .title-wrap { display: flex; align-items: center; gap: .45rem; }
  .sap-card-header .bi { color: var(--sap-brand); font-size: .95rem; }
  .sap-card-body { padding: 1rem 1.15rem; }

  .sap-info-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: .85rem 1.25rem; }
  .sap-info-label { font-size: .68rem; text-transform: uppercase; letter-spacing: .05em;
    font-weight: 600; color: var(--sap-text-muted); margin-bottom: .15rem; }
  .sap-info-value { font-size: .875rem; color: var(--sap-text); word-break: break-word; }
  .sap-info-value.mono { font-family: "72Mono","Courier New",monospace; }

  .sap-desc { white-space: pre-wrap; font-size: .875rem; line-height: 1.65;
    background: #fafbfc; border: 1px solid var(--sap-border-soft);
    border-radius: .5rem; padding: .85rem 1rem; margin-top: .35rem; }

  .sap-message { display: flex; align-items: flex-start; gap: .6rem;
    padding: .75rem 1rem; border-radius: .5rem; font-size: .8125rem; line-height: 1.4;
    margin-bottom: .75rem; border-left: 3px solid; }
  .sap-message:last-child { margin-bottom: 0; }
  .sap-message .bi { flex-shrink: 0; font-size: .95rem; margin-top: .05rem; }
  .sap-message.is-error   { background: #fef4f4; color: var(--sap-negative); border-left-color: var(--sap-negative); }

  .sap-form-control { width: 100%; font-size: .875rem; font-family: inherit;
    color: var(--sap-text); background: #fff; border: 1px solid var(--sap-border);
    border-radius: .5rem; padding: .55rem .75rem;
    transition: border-color .15s, box-shadow .15s; outline: none; resize: vertical; }
  .sap-form-control:focus { border-color: var(--sap-brand);
    box-shadow: 0 0 0 3px rgba(0,112,242,.15); }

  .sap-btn { display: inline-flex; align-items: center; justify-content: center; gap: .4rem;
    font-size: .8125rem; font-weight: 500; border-radius: .5rem;
    padding: .55rem .9rem; border: 1px solid transparent; background: transparent;
    color: var(--sap-brand); cursor: pointer; line-height: 1; text-decoration: none;
    white-space: nowrap; transition: background .15s, color .15s, border-color .15s; font-family: inherit;
    min-height: 36px; }
  .sap-btn:hover { background: #eaf4ff; color: var(--sap-brand-dark); }
  .sap-btn:focus-visible { outline: 2px solid var(--sap-brand); outline-offset: 2px; }
  .sap-btn.sap-btn-emphasized { background: var(--sap-brand); color: #fff;
    box-shadow: 0 1px 2px rgba(34,53,72,.15); }
  .sap-btn.sap-btn-emphasized:hover { background: var(--sap-brand-dark); color: #fff; }
  .sap-btn.sap-btn-success { background: var(--sap-positive); color: #fff; }
  .sap-btn.sap-btn-success:hover { background: #1d5d2e; color: #fff; }
  .sap-btn.sap-btn-outline { border-color: var(--sap-border); background: #fff; }
  .sap-btn.sap-btn-outline:hover { border-color: var(--sap-brand); color: var(--sap-brand); background: #fff; }

  .sap-timeline { list-style: none; margin: 0; padding: .25rem 0 .25rem 1.5rem; position: relative; }
  .sap-timeline::before { content: ''; position: absolute; left: .35rem; top: .4rem; bottom: .4rem;
    width: 2px; background: linear-gradient(180deg, var(--sap-brand) 0%, var(--sap-border-soft) 100%);
    border-radius: 1px; }
  .sap-timeline li { position: relative; padding: 0 0 .95rem 0; font-size: .84rem; }
  .sap-timeline li:last-child { padding-bottom: 0; }
  .sap-timeline li::before { content: ''; position: absolute;
    left: -1.35rem; top: .28rem; width: 10px; height: 10px; border-radius: 50%;
    background: #fff; border: 2px solid var(--sap-brand);
    box-shadow: 0 0 0 3px rgba(0,112,242,.10); }
  .sap-timeline li.is-latest::before { background: var(--sap-brand);
    box-shadow: 0 0 0 4px rgba(0,112,242,.20); }
  .sap-tl-action { font-weight: 600; color: var(--sap-text); display: block; }
  .sap-tl-meta { font-size: .72rem; color: var(--sap-text-muted); margin-top: .1rem; }
  .sap-tl-note { font-size: .78rem; color: var(--sap-text-muted); margin-top: .35rem;
    background: #fafbfc; border-left: 2px solid var(--sap-border-soft);
    padding: .35rem .6rem; border-radius: .25rem; white-space: pre-wrap; }

  .sap-comment { padding: .75rem .9rem; border-radius: .5rem;
    background: #fafbfc; border: 1px solid var(--sap-border-soft);
    margin-bottom: .55rem; font-size: .82rem; }
  .sap-comment:last-child { margin-bottom: 0; }
  .sap-comment-head { display: flex; align-items: baseline; gap: .5rem;
    margin-bottom: .25rem; flex-wrap: wrap; }
  .sap-comment-author { font-weight: 600; color: var(--sap-text); }
  .sap-comment-time { font-size: .7rem; color: var(--sap-text-muted); }
  .sap-comment-body { white-space: pre-wrap; line-height: 1.55; }

  .sap-attach { display: flex; align-items: center; gap: .65rem;
    padding: .55rem .7rem; border-radius: .5rem; background: #fafbfc;
    border: 1px solid var(--sap-border-soft); text-decoration: none;
    color: var(--sap-text); font-size: .82rem;
    transition: background .12s, border-color .12s; margin-bottom: .45rem; }
  .sap-attach:last-child { margin-bottom: 0; }
  .sap-attach:hover { background: #f4f9ff; border-color: #cfe2f8; color: var(--sap-brand); }
  .sap-attach-icon { width: 30px; height: 30px; border-radius: .4rem;
    background: #eaf4ff; color: var(--sap-brand);
    display: inline-flex; align-items: center; justify-content: center; font-size: .95rem; flex-shrink: 0; }
  .sap-attach-info { flex: 1; min-width: 0; }
  .sap-attach-name { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .sap-attach-meta { font-size: .7rem; color: var(--sap-text-muted); }
  .sap-attach-dl { color: var(--sap-text-muted); font-size: .95rem; flex-shrink: 0; }

  .sap-empty { text-align: center; padding: 1.25rem .75rem; color: var(--sap-text-muted); font-size: .82rem; }
  .sap-empty .bi { font-size: 1.5rem; opacity: .4; display: block; margin-bottom: .3rem; }

  .sap-worklog { border: 1px solid var(--sap-border-soft); border-radius: .5rem;
    padding: .85rem 1rem; margin-bottom: .65rem; background: #fafbfc; font-size: .82rem; }
  .sap-worklog:last-child { margin-bottom: 0; }
  .sap-worklog-head { display: flex; align-items: baseline; gap: .5rem;
    margin-bottom: .5rem; font-size: .75rem; color: var(--sap-text-muted); flex-wrap: wrap; }
  .sap-worklog-head strong { color: var(--sap-text); }
  .sap-worklog-row { display: flex; gap: .5rem; margin-bottom: .35rem; }
  .sap-worklog-row:last-child { margin-bottom: 0; }
  .sap-worklog-lbl { font-weight: 600; color: var(--sap-text-muted);
    text-transform: uppercase; font-size: .68rem; letter-spacing: .04em;
    min-width: 90px; flex-shrink: 0; }
  .sap-worklog-val { color: var(--sap-text); white-space: pre-wrap; }

  /* Sticky actions column on large screens */
  @media (min-width: 992px) {
    .actions-col { position: sticky; top: 1rem; align-self: flex-start; }
  }
</style>

<div class="sap-obj-header">
  <div class="sap-breadcrumb">
    <a href="dashboard.php"><i class="bi bi-house-door"></i> Home</a>
    <i class="bi bi-chevron-right" style="font-size:.65rem"></i>
    <a href="tickets.php">Approved Tickets</a>
    <i class="bi bi-chevron-right" style="font-size:.65rem"></i>
    <strong style="color:var(--sap-text)"><?= e($t['ticket_number']) ?></strong>
  </div>

  <h1 class="sap-obj-title">
    <span class="sap-obj-id"><?= e($t['ticket_number']) ?></span>
    <span><?= e($t['subject']) ?></span>
  </h1>
  <p class="sap-obj-subject">
    Submitted by <strong><?= e($t['requester_name']) ?></strong>
    on <?= e(date('Y-m-d H:i', strtotime($t['created_at']))) ?>
  </p>

  <div class="sap-obj-pills">
    <?= status_badge($t['status']) ?>
    <span class="sap-prio" style="background:<?= e(match ($t['priority_color']) {
        'danger'=>'#aa0808','warning'=>'#e76500','info'=>'#0070f2',
        'primary'=>'#0057d2','success'=>'#256f3a','secondary'=>'#5b738b',
        'dark'=>'#354a5f', default=>'#5b738b' }) ?>">
      <span class="swatch"></span> <?= e($t['priority_name']) ?>
    </span>
    <?php if (function_exists('is_waiting_status') && is_waiting_status($t['status']) && function_exists('waiting_meta')): $wm = waiting_meta($t['status']); ?>
      <span class="sap-status <?= e($wm['class']) ?>"><i class="bi <?= e($wm['icon']) ?>"></i> <?= e($wm['label']) ?></span>
    <?php endif; ?>
  </div>
</div>

<?= wf_stepper($t, (string)($t['tech_name'] ?? '')) ?>

<?php if ($flashOk): ?>
  <div class="sap-message" style="background:#f1fdf6;color:#256f3a;border-left:3px solid #256f3a">
    <i class="bi bi-check-circle"></i>
    <span><?= e($flashOk) ?></span>
  </div>
<?php endif; ?>

<?php if ($error): ?>
  <div class="sap-message is-error">
    <i class="bi bi-exclamation-circle"></i>
    <span><?= e($error) ?></span>
  </div>
<?php endif; ?>

<div class="row g-3">
  <div class="col-lg-8">

    <!-- Ticket details -->
    <div class="sap-card">
      <div class="sap-card-header">
        <span class="title-wrap"><i class="bi bi-info-circle"></i> Ticket Details</span>
      </div>
      <div class="sap-card-body">
        <div class="sap-info-grid">
          <div><div class="sap-info-label">Requester</div><div class="sap-info-value"><?= e($t['requester_name']) ?></div></div>
          <div><div class="sap-info-label">Department</div><div class="sap-info-value"><?= e($t['department_name'] ?? '—') ?></div></div>
          <div><div class="sap-info-label">Team Leader</div><div class="sap-info-value"><?= e($t['tl_name'] ?? '—') ?></div></div>
          <div><div class="sap-info-label">Category</div><div class="sap-info-value"><?= e($t['category_name']) ?></div></div>
          <div><div class="sap-info-label">Subcategory</div><div class="sap-info-value"><?= e($t['subcat_name'] ?? '—') ?></div></div>
          <div><div class="sap-info-label">Location</div><div class="sap-info-value"><?= e($t['location'] ?? '—') ?></div></div>
          <div><div class="sap-info-label">Created</div><div class="sap-info-value mono"><?= e(date('Y-m-d H:i', strtotime($t['created_at']))) ?></div></div>
          <div><div class="sap-info-label">Technician</div><div class="sap-info-value"><?= e($t['tech_name'] ?? '—') ?></div></div>
        </div>
        <div style="margin-top:1.25rem">
          <div class="sap-info-label">Description</div>
          <div class="sap-desc"><?= e($t['description']) ?></div>
        </div>
      </div>
    </div>

    <!-- Work logs -->
    <?php if ($work): ?>
      <div class="sap-card">
        <div class="sap-card-header">
          <span class="title-wrap"><i class="bi bi-tools"></i> Work Logs</span>
          <span style="font-size:.7rem;color:var(--sap-text-muted);font-weight:500;text-transform:none;letter-spacing:0">
            <?= count($work) ?>
          </span>
        </div>
        <div class="sap-card-body">
          <?php foreach ($work as $w): ?>
            <div class="sap-worklog">
              <div class="sap-worklog-head">
                <strong><?= e($w['full_name']) ?></strong>
                · <?= e(date('Y-m-d H:i', strtotime($w['created_at']))) ?>
              </div>
              <div class="sap-worklog-row">
                <div class="sap-worklog-lbl">Action Taken</div>
                <div class="sap-worklog-val"><?= e($w['action_taken'] ?? '—') ?></div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    <?php endif; ?>

    <!-- Timeline -->
    <div class="sap-card">
      <div class="sap-card-header">
        <span class="title-wrap"><i class="bi bi-clock-history"></i> Timeline</span>
        <span style="font-size:.7rem;color:var(--sap-text-muted);font-weight:500;text-transform:none;letter-spacing:0">
          <?= count($history) ?> event<?= count($history) === 1 ? '' : 's' ?>
        </span>
      </div>
      <div class="sap-card-body">
        <?php if (!$history): ?>
          <div class="sap-empty"><i class="bi bi-clock-history"></i>No history yet.</div>
        <?php else: ?>
          <ul class="sap-timeline">
            <?php $lastIdx = count($history) - 1; foreach ($history as $i => $h): ?>
              <li class="<?= $i === $lastIdx ? 'is-latest' : '' ?>">
                <span class="sap-tl-action"><?= e($h['action']) ?></span>
                <div class="sap-tl-meta"><?= e($h['full_name']) ?> · <?= e(date('Y-m-d H:i', strtotime($h['created_at']))) ?></div>
                <?php if (!empty($h['comment'])): ?>
                  <div class="sap-tl-note"><?= e($h['comment']) ?></div>
                <?php endif; ?>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>
    </div>

  </div>

  <div class="col-lg-4 actions-col">

    <!-- Actions -->
    <div class="sap-card">
      <div class="sap-card-header">
        <span class="title-wrap"><i class="bi bi-lightning-charge"></i> Actions</span>
      </div>
      <div class="sap-card-body d-grid gap-2">

        <?php
          /* reason the requester gave when they sent the ticket back, if it was returned */
          $returnReason = '';
          if ($status === 'RETURNED_TO_ICT') {
              foreach (array_reverse($history) as $hrow) {
                  if (($hrow['new_status'] ?? '') === 'RETURNED_TO_ICT') { $returnReason = (string)($hrow['comment'] ?? ''); break; }
              }
          }
        ?>
        <?php if ($status === 'RETURNED_TO_ICT'): ?>
          <div class="sap-message is-error" style="margin:0">
            <i class="bi bi-arrow-counterclockwise"></i>
            <div><strong>The requester says it is NOT fixed.</strong>
              <?php if ($returnReason !== ''): ?><div style="font-size:.78rem;margin-top:.2rem"><?= e($returnReason) ?></div><?php endif; ?>
            </div>
          </div>
        <?php endif; ?>

        <?php if ($heldByOther): ?>
          <div class="sap-message" style="background:#fff8f1;color:#8a3b00;border-left:3px solid var(--sap-critical);margin:0">
            <i class="bi bi-person-lock"></i>
            <div>
              <strong>Held by <?= e($t['tech_name'] ?? 'another technician') ?>.</strong>
              <div style="font-size:.75rem;margin-top:.2rem">Only they can accept or resolve it. To take over, assign it to yourself below.</div>
            </div>
          </div>
        <?php endif; ?>

        <?php /* Step 1 - ICT ACCEPTS */ if ($canAccept): ?>
          <form method="post">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="accept">
            <button class="sap-btn sap-btn-emphasized w-100">
              <i class="bi bi-check2-circle"></i>
              <?= $status === 'RETURNED_TO_ICT' ? 'Accept Again' : 'Accept Ticket' ?>
            </button>
          </form>
          <div style="font-size:.75rem;color:var(--sap-text-muted)">
            Accept the ticket to start work. The requester is told right away, and you can then put it on hold or mark it as resolved.
          </div>
        <?php endif; ?>

        <?php /* Step 2 - ICT works */ if ($canWork): ?>
          <?php if ($onHold): ?>
            <form method="post">
              <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="action" value="resume">
              <button class="sap-btn sap-btn-emphasized w-100"><i class="bi bi-play-circle"></i> Resume Work</button>
            </form>
          <?php endif; ?>

          <button class="sap-btn sap-btn-outline w-100" data-bs-toggle="modal" data-bs-target="#waitInfoModal">
            <i class="bi bi-question-circle"></i> Waiting for Info
          </button>
          <button class="sap-btn sap-btn-outline w-100" data-bs-toggle="modal" data-bs-target="#waitPartsModal">
            <i class="bi bi-box-seam"></i> Waiting for Parts
          </button>

          <?php /* Step 3 - ICT marks it RESOLVED */ ?>
          <button class="sap-btn sap-btn-success w-100" data-bs-toggle="modal" data-bs-target="#resolveModal">
            <i class="bi bi-check2-circle"></i> Mark as Resolved
          </button>
        <?php endif; ?>

        <?php if ($isActive): ?>
          <div class="dropdown">
            <button class="sap-btn sap-btn-outline w-100" style="justify-content:space-between"
                    data-bs-toggle="dropdown">
              <span><i class="bi bi-person-check"></i> Assign to Technician</span>
              <i class="bi bi-chevron-down"></i>
            </button>
            <ul class="dropdown-menu w-100">
              <?php if (!$techs): ?>
                <li><span class="dropdown-item-text text-muted small">No active technicians.</span></li>
              <?php else: foreach ($techs as $tech): ?>
                <li>
                  <form method="post">
                    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="assign">
                    <input type="hidden" name="technician_id" value="<?= (int)$tech['id'] ?>">
                    <button class="dropdown-item"><?= e($tech['full_name']) ?><?= (int)$tech['id'] === $myId ? ' (me)' : '' ?></button>
                  </form>
                </li>
              <?php endforeach; endif; ?>
            </ul>
          </div>
        <?php endif; ?>

        <?php if ($status === 'RESOLVED_PENDING_REQUESTER_CONFIRMATION' || $status === 'RESOLVED_PENDING_TEAM_LEADER_VERIFICATION'): ?>
          <div class="sap-empty">
            <i class="bi bi-hourglass-split"></i>
            Resolved. Waiting for <strong><?= e($t['requester_name']) ?></strong> to confirm the fix.
            If they do not answer within <?= (int)requester_confirm_minutes() ?> minutes the ticket closes automatically.
          </div>
        <?php elseif ($status === 'CLOSED'): ?>
          <div class="sap-empty"><i class="bi bi-check2-all"></i> Confirmed and closed.</div>
        <?php elseif (!$isActive): ?>
          <div class="sap-empty"><i class="bi bi-info-circle"></i> This ticket is not in the ICT queue (<?= e(wf_status_label($status)) ?>).</div>
        <?php endif; ?>

        <?php if ($onHold): ?>
          <div class="sap-message" style="background:#fff8f1;color:#8a3b00;border-left:3px solid var(--sap-critical);margin-top:.5rem">
            <i class="bi bi-pause-circle-fill"></i>
            <div>
              <strong>Ticket is on hold.</strong>
              <?= $status === 'WAITING_FOR_PARTS' ? 'Waiting for spare parts.' : 'Waiting for the requester to supply information. The ticket resumes automatically when they reply.' ?>
              <div style="font-size:.75rem;margin-top:.25rem">The requester and Team Leader have been notified.</div>
            </div>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Attachments -->
    <div class="sap-card">
      <div class="sap-card-header">
        <span class="title-wrap"><i class="bi bi-paperclip"></i> Attachments</span>
        <?php if ($attachments): ?>
          <span style="font-size:.7rem;color:var(--sap-text-muted);font-weight:500;text-transform:none;letter-spacing:0">
            <?= count($attachments) ?>
          </span>
        <?php endif; ?>
      </div>
      <div class="sap-card-body">
        <?php if (!$attachments): ?>
          <div class="sap-empty"><i class="bi bi-paperclip"></i>No attachments.</div>
        <?php else: ?>
          <?php foreach ($attachments as $att): ?>
            <a class="sap-attach" href="../<?= e($att['file_path']) ?>" target="_blank" download>
              <span class="sap-attach-icon"><i class="bi bi-file-earmark"></i></span>
              <span class="sap-attach-info">
                <span class="sap-attach-name"><?= e($att['original_name'] ?? basename($att['file_path'])) ?></span>
                <span class="sap-attach-meta"><?= e(date('Y-m-d H:i', strtotime($att['uploaded_at']))) ?></span>
              </span>
              <i class="bi bi-download sap-attach-dl"></i>
            </a>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>

    <!-- Comments -->
    <?php if ($comments): ?>
      <div class="sap-card">
        <div class="sap-card-header">
          <span class="title-wrap"><i class="bi bi-chat-dots"></i> Comments</span>
        </div>
        <div class="sap-card-body">
          <?php foreach ($comments as $c): ?>
            <div class="sap-comment">
              <div class="sap-comment-head">
                <span class="sap-comment-author"><?= e($c['full_name']) ?></span>
                <span class="sap-comment-time"><?= e(date('Y-m-d H:i', strtotime($c['created_at']))) ?></span>
              </div>
              <div class="sap-comment-body"><?= e($c['comment']) ?></div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    <?php endif; ?>

  </div>
</div>

<!-- Modals -->
<div class="modal fade" id="waitInfoModal" tabindex="-1">
  <div class="modal-dialog">
    <form method="post" class="modal-content">
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
      <input type="hidden" name="action" value="wait_info">
      <div class="modal-header">
        <h5 class="modal-title">Waiting for Information</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <label class="sap-info-label">What information do you need from the requester? (required)</label>
        <textarea name="reason" class="sap-form-control" rows="3" placeholder="What information is needed?" required></textarea>
      </div>
      <div class="modal-footer">
        <button type="button" class="sap-btn" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="sap-btn sap-btn-emphasized">Confirm</button>
      </div>
    </form>
  </div>
</div>

<div class="modal fade" id="waitPartsModal" tabindex="-1">
  <div class="modal-dialog">
    <form method="post" class="modal-content">
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
      <input type="hidden" name="action" value="wait_parts">
      <div class="modal-header">
        <h5 class="modal-title">Waiting for Parts</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <label class="sap-info-label">Reason (optional)</label>
        <textarea name="reason" class="sap-form-control" rows="3" placeholder="Which parts are needed?"></textarea>
      </div>
      <div class="modal-footer">
        <button type="button" class="sap-btn" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="sap-btn sap-btn-emphasized">Confirm</button>
      </div>
    </form>
  </div>
</div>

<div class="modal fade" id="resolveModal" tabindex="-1">
  <div class="modal-dialog">
    <form method="post" enctype="multipart/form-data" class="modal-content">
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
      <input type="hidden" name="action" value="resolve">
      <div class="modal-header">
        <h5 class="modal-title">Mark as Resolved</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label class="sap-info-label">Action Taken</label>
          <textarea name="action_taken" class="sap-form-control" rows="4" placeholder="Describe the work performed..." required></textarea>
        </div>
        <div class="mb-3">
          <label class="sap-info-label">Evidence (optional)</label>
          <input type="file" name="evidence" class="sap-form-control">
        </div>
        <div class="alert alert-info py-2 mb-0" style="font-size:.82rem">
          <i class="bi bi-clock-history"></i>
          The requester is asked to confirm and has
          <strong><?= (int)requester_confirm_minutes() ?> minutes</strong>.
          If they answer <em>Not Resolved</em> the ticket comes back to you and you are notified again;
          if they stay silent the ticket closes automatically as confirmed.
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="sap-btn" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="sap-btn sap-btn-success">Confirm Resolution</button>
      </div>
    </form>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>