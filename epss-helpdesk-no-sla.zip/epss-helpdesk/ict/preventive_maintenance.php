<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/pm.php';
$u = require_role('ICT_STAFF');
$pageTitle = 'Preventive Maintenance Checklist';
$pdo = db();
$myId = (int)$u['id'];

/* =====================================================================
 * Schema detection — pm_checklists varies between installs.
 * ===================================================================== */

function pmc_cols(PDO $pdo, string $table): array {
    static $cache = [];
    if (isset($cache[$table])) return $cache[$table];
    try {
        $rows = $pdo->query("SHOW COLUMNS FROM `" . str_replace('`', '', $table) . "`")
                    ->fetchAll(PDO::FETCH_COLUMN);
        return $cache[$table] = array_map('strtolower', $rows ?: []);
    } catch (Throwable $e) {
        return $cache[$table] = [];
    }
}
function pmc_has(array $cols, string ...$cands): ?string {
    foreach ($cands as $c) if (in_array($c, $cols, true)) return $c;
    return null;
}

$pmCols = pmc_cols($pdo, 'pm_checklists');

$colStatus     = pmc_has($pmCols, 'status', 'approval_status', 'checklist_status', 'review_status', 'state');
$colApprovedBy = pmc_has($pmCols, 'approved_by');
$colSubmitted  = pmc_has($pmCols, 'submitted_at', 'created_at');
$colQuarter    = pmc_has($pmCols, 'quarter_label', 'quarter');
$colNotes      = pmc_has($pmCols, 'notes', 'remarks', 'comment');
$colTechName   = pmc_has($pmCols, 'technician_name');
$colTechId     = pmc_has($pmCols, 'technician_id');
$colDeptId     = pmc_has($pmCols, 'department_id');
$colCheckDate  = pmc_has($pmCols, 'checklist_date', 'date', 'performed_date');
$colApprRemark = pmc_has($pmCols, 'approval_remarks', 'review_remarks');
$colYear       = pmc_has($pmCols, 'year');
$colQuarterNum = pmc_has($pmCols, 'quarter');

/* Departments (for the header of the form) */
$deptCols = pmc_cols($pdo, 'departments');
$deptActiveSql = in_array('status', $deptCols, true)
    ? "WHERE status='ACTIVE'"
    : "";
try {
    $departments = $pdo->query(
        "SELECT id, department_name FROM departments $deptActiveSql ORDER BY department_name"
    )->fetchAll();
} catch (Throwable $e) {
    $departments = [];
}

/* Employees to inspect — all active employees, or just a selected department */
$deptFilter = (int)($_GET['dept'] ?? 0);
$empSql = "SELECT u.id, u.full_name, u.employee_id, u.department_id, d.department_name
           FROM users u
           LEFT JOIN departments d ON d.id = u.department_id
           WHERE u.status='ACTIVE' AND u.role IN ('EMPLOYEE','TEAM_LEADER','ICT_STAFF','BRANCH_MANAGER','ADMIN')";
$empParams = [];
if ($deptFilter) { $empSql .= " AND u.department_id=?"; $empParams[] = $deptFilter; }
$empSql .= " ORDER BY d.department_name, u.full_name";
$empStmt = $pdo->prepare($empSql);
$empStmt->execute($empParams);
$employees = $empStmt->fetchAll();

/* Check if this technician already has a submission this quarter */
$currentYear    = (int)date('Y');
$currentQuarter = pm_quarter_of(date('Y-m-d'));
$alreadySubmitted = function_exists('pm_has_submission')
    ? pm_has_submission($myId, $currentYear, $currentQuarter)
    : false;

$ok = ''; $error = '';

/* ---------- Handle submission ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf($_POST['csrf'] ?? null)) {
    try {
        $pdo->beginTransaction();

        $checklistDate = $_POST['checklist_date'] ?: date('Y-m-d');
        $year          = (int)date('Y', strtotime($checklistDate));
        $quarter       = pm_quarter_of($checklistDate);
        $deptId        = $_POST['department_id'] ?: null;
        $techName      = trim($_POST['technician_name'] ?: $u['full_name']);
        $notesVal      = trim($_POST['notes'] ?? '') ?: null;

        // Build INSERT dynamically from available columns.
        $insertCols = [];
        $insertVals = [];
        $insertParams = [];

        if ($colTechId !== null)   { $insertCols[] = "`$colTechId`";   $insertVals[] = '?'; $insertParams[] = $myId; }
        if ($colDeptId !== null)   { $insertCols[] = "`$colDeptId`";   $insertVals[] = '?'; $insertParams[] = $deptId; }
        if ($colTechName !== null) { $insertCols[] = "`$colTechName`"; $insertVals[] = '?'; $insertParams[] = $techName; }
        if ($colCheckDate !== null){ $insertCols[] = "`$colCheckDate`";$insertVals[] = '?'; $insertParams[] = $checklistDate; }
        if ($colQuarter !== null)  { $insertCols[] = "`$colQuarter`";  $insertVals[] = '?'; $insertParams[] = "{$year}-Q{$quarter}"; }
        if ($colYear !== null)     { $insertCols[] = "`$colYear`";     $insertVals[] = '?'; $insertParams[] = $year; }
        if ($colQuarterNum !== null){ $insertCols[] = "`$colQuarterNum`"; $insertVals[] = '?'; $insertParams[] = $quarter; }
        if ($colNotes !== null)    { $insertCols[] = "`$colNotes`";    $insertVals[] = '?'; $insertParams[] = $notesVal; }
        if ($colStatus !== null)   { $insertCols[] = "`$colStatus`";   $insertVals[] = '?'; $insertParams[] = 'PENDING'; }

        if (!$insertCols) {
            throw new RuntimeException('pm_checklists has no usable columns to insert into.');
        }

        $stmt = $pdo->prepare(
            "INSERT INTO pm_checklists (" . implode(', ', $insertCols) . ")
             VALUES (" . implode(', ', $insertVals) . ")"
        );
        $stmt->execute($insertParams);
        $checklistId = (int)$pdo->lastInsertId();

        /* Insert item rows */
        $itemStmt = $pdo->prepare("INSERT INTO pm_checklist_items
            (checklist_id, item_number, employee_id, employee_name, item_code, done, note)
            VALUES (?,?,?,?,?,?,?)");

        foreach ($_POST['employees'] ?? [] as $empId => $empData) {
            $empId = (int)$empId;
            if ($empId <= 0) continue;

            $empName = trim($empData['name'] ?? '');
            if ($empName === '') continue;

            $employeeRow = $pdo->prepare("SELECT id FROM users WHERE id=?");
            $employeeRow->execute([$empId]);
            $empValidId = $employeeRow->fetchColumn() ?: null;

            foreach (PM_ITEMS as $num => $meta) {
                $code = $meta['code'];
                $done = isset($empData['items'][$num]) ? 1 : 0;
                $note = trim($empData['notes'][$num] ?? '') ?: null;

                $itemStmt->execute([
                    $checklistId,
                    $num,
                    $empValidId,
                    $empName,
                    $code,
                    $done,
                    $note,
                ]);
            }
        }

        audit('CreatePMChecklist','pm_checklists',$checklistId,
              "Preventive maintenance for {$year}-Q{$quarter}");

        $pdo->commit();
        $ok = 'Checklist submitted. It is now waiting for Branch Manager approval.';
        $alreadySubmitted = true;

        try {
            pm_notify_approvers($checklistId, $techName, "{$year}-Q{$quarter}");
        } catch (Throwable $e) {
            error_log('PM approval notification: ' . $e->getMessage());
        }
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $error = app_exception_message($e);
    }
}

/* Past submissions by this technician — adapt to schema */
$hSelects = ['c.*'];
$hJoins   = [];
$hasUsers = false;
try { $hasUsers = (bool)$pdo->query("SHOW TABLES LIKE 'users'")->fetchColumn(); } catch (Throwable $e) {}

if ($hasUsers && $colApprovedBy !== null) {
    $hSelects[] = 'a.full_name AS approver_name';
    $hJoins[]   = "LEFT JOIN users a ON a.id = c.`$colApprovedBy`";
} else {
    $hSelects[] = 'NULL AS approver_name';
}

$hSelects[] = $colSubmitted  ? "c.`$colSubmitted` AS submitted_at"      : "NULL AS submitted_at";
$hSelects[] = $colQuarter    ? "c.`$colQuarter`   AS quarter_label"     : "NULL AS quarter_label";
$hSelects[] = $colCheckDate  ? "c.`$colCheckDate` AS checklist_date"    : "NULL AS checklist_date";
$hSelects[] = $colStatus     ? "c.`$colStatus`    AS status_value"      : "NULL AS status_value";
$hSelects[] = $colApprRemark ? "c.`$colApprRemark` AS approval_remarks" : "NULL AS approval_remarks";

$historySql = "SELECT " . implode(', ', $hSelects) . "
               FROM pm_checklists c
               " . implode(' ', $hJoins) . "
               " . ($colTechId !== null ? "WHERE c.`$colTechId` = ?" : "") . "
               ORDER BY " . ($colSubmitted ? "c.`$colSubmitted`" : "c.id") . " DESC
               LIMIT 20";

$history = [];
try {
    $history = $colTechId !== null
        ? $pdo->prepare($historySql)
        : $pdo->prepare($historySql);
    $history->execute($colTechId !== null ? [$myId] : []);
    $history = $history->fetchAll();
} catch (Throwable $e) {
    $history = [];
}

/* Normalise status helper */
$bucketOf = static function (array $row): string {
    $v = strtoupper((string)($row['status_value'] ?? ''));
    if ($v === '') return 'PENDING';
    if (str_contains($v, 'REJECT') || str_contains($v, 'DECLINE') || str_contains($v, 'RETURN')) return 'REJECTED';
    if (str_contains($v, 'APPROV') || str_contains($v, 'ACCEPT') || $v === 'DONE' || $v === 'COMPLETED') return 'APPROVED';
    return 'PENDING';
};

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:#0070f2; --sap-brand-dark:#0057d2;
    --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500;
    --sap-negative:#aa0808;
    --sap-shadow:0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
  }
  body, .main-content { background:var(--sap-bg) !important;
    font-family:"72","72full",Arial,Helvetica,sans-serif !important; color:var(--sap-text); }

  .sap-page-header { display:flex; justify-content:space-between; align-items:flex-start;
    margin-bottom:1rem; flex-wrap:wrap; gap:.75rem; }
  .sap-page-title { font-size:1.625rem; font-weight:400; margin:0; }
  .sap-breadcrumb { font-size:.8125rem; color:var(--sap-text-muted); margin-bottom:.25rem; }

  .sap-message { display:flex; gap:.6rem; padding:.85rem 1rem;
    border-radius:.5rem; font-size:.84rem; line-height:1.5;
    border-left:3px solid; margin-bottom:1rem; }
  .sap-message.is-info    { background:#eaf4ff; color:#0a4a9c; border-left-color:var(--sap-brand); }
  .sap-message.is-success { background:#f1fdf6; color:var(--sap-positive); border-left-color:var(--sap-positive); }
  .sap-message.is-warning { background:#fff8f1; color:#8a3b00; border-left-color:var(--sap-critical); }
  .sap-message.is-error   { background:#fef4f4; color:var(--sap-negative); border-left-color:var(--sap-negative); }

  .sap-card { background:var(--sap-tile); border-radius:.75rem;
    box-shadow:var(--sap-shadow); overflow:hidden; margin-bottom:1rem; }
  .sap-card-header { padding:.85rem 1.15rem; border-bottom:1px solid var(--sap-border-soft);
    font-size:.875rem; font-weight:600; display:flex; align-items:center; gap:.45rem; }
  .sap-card-header .bi { color:var(--sap-brand); }
  .sap-card-body { padding:1rem 1.15rem; }

  .sap-form-label { display:block; font-size:.72rem; text-transform:uppercase;
    letter-spacing:.04em; color:var(--sap-text-muted); font-weight:600; margin-bottom:.3rem; }
  .sap-form-control { width:100%; font-size:.875rem; font-family:inherit;
    color:var(--sap-text); background:#fff; border:1px solid var(--sap-border);
    border-radius:.5rem; padding:.5rem .7rem; outline:none; }
  .sap-form-control:focus { border-color:var(--sap-brand);
    box-shadow:0 0 0 3px rgba(0,112,242,.15); }

  .sap-btn { display:inline-flex; align-items:center; gap:.4rem;
    font-size:.8125rem; font-weight:500; border-radius:.5rem;
    padding:.5rem .9rem; border:1px solid transparent; background:transparent;
    color:var(--sap-brand); cursor:pointer; line-height:1;
    text-decoration:none; white-space:nowrap; font-family:inherit; }
  .sap-btn:hover { background:#eaf4ff; color:var(--sap-brand-dark); }
  .sap-btn.sap-btn-emphasized { background:var(--sap-brand); color:#fff;
    box-shadow:0 1px 2px rgba(34,53,72,.15); }
  .sap-btn.sap-btn-emphasized:hover { background:var(--sap-brand-dark); color:#fff; }
  .sap-btn.sap-btn-outline { border-color:var(--sap-border); background:#fff; }

  .pm-table { width:100%; border-collapse:separate; border-spacing:0;
    font-size:.78rem; background:#fff; border-radius:.5rem; overflow:hidden;
    border:1px solid var(--sap-border); }
  .pm-table thead th {
    background:#f5f6f7; font-weight:700; font-size:.68rem;
    text-transform:uppercase; letter-spacing:.03em; color:var(--sap-text-muted);
    padding:.5rem .35rem; text-align:center; border-bottom:1px solid var(--sap-border);
    border-right:1px solid var(--sap-border-soft); }
  .pm-table thead th:first-child,
  .pm-table thead th:nth-child(2) { text-align:left; }
  .pm-table tbody td {
    padding:.4rem .35rem; border-bottom:1px solid var(--sap-border-soft);
    border-right:1px solid var(--sap-border-soft); text-align:center;
    vertical-align:middle; }
  .pm-table tbody td:first-child,
  .pm-table tbody td:nth-child(2) { text-align:left; }
  .pm-table tbody tr:last-child td { border-bottom:0; }
  .pm-table tbody tr:nth-child(even) { background:#fafbfc; }
  .pm-table th:last-child, .pm-table td:last-child { border-right:0; }
  .pm-table th .bi { display:block; font-size:.7rem; margin-bottom:.1rem; color:var(--sap-brand); }
  .pm-table th .th-label { font-size:.6rem; text-transform:none; letter-spacing:0; color:var(--sap-text-muted); }

  .pm-emp-name { font-weight:600; color:var(--sap-text); }
  .pm-emp-sub  { font-size:.68rem; color:var(--sap-text-muted); }

  .pm-check { width:16px; height:16px; cursor:pointer; accent-color:var(--sap-brand); }

  .pm-note-btn { background:none; border:0; color:var(--sap-brand);
    font-size:.7rem; cursor:pointer; text-decoration:underline; }

  .pm-note-input { display:none; margin-top:.25rem; }
  .pm-note-input.show { display:block; }
  .pm-note-input input { width:100%; font-size:.7rem; padding:.2rem .3rem;
    border:1px solid var(--sap-border); border-radius:.25rem; }

  .pm-actions { display:flex; gap:.5rem; margin-top:1rem; }

  .pm-history-list { list-style:none; margin:0; padding:0; }
  .pm-history-list li { padding:.5rem 0; border-bottom:1px solid var(--sap-border-soft);
    font-size:.8rem; display:flex; justify-content:space-between; align-items:flex-start; gap:1rem; }
  .pm-history-list li:last-child { border-bottom:0; }
  .pm-history-q { font-family:"72Mono",monospace; font-weight:700; color:var(--sap-brand); }
  .pm-history-main { min-width:0; }
  .pm-history-side { display:flex; flex-direction:column; align-items:flex-end; gap:.3rem; flex-shrink:0; }
  .pm-history-link { font-size:.72rem; color:var(--sap-brand); text-decoration:none; }
  .pm-history-link:hover { text-decoration:underline; }
  .pm-history-remark { font-size:.72rem; color:var(--sap-negative); margin-top:.25rem; }

  .pm-status { display:inline-flex; align-items:center; gap:.3rem; font-size:.7rem;
    font-weight:600; padding:.22rem .6rem; border-radius:.75rem;
    white-space:nowrap; border:1px solid transparent; }
  .pm-status.is-critical { background:#fff8f1; color:var(--sap-critical); border-color:#fbe0c8; }
  .pm-status.is-good     { background:#f1fdf6; color:var(--sap-positive); border-color:#d6f0e0; }
  .pm-status.is-bad      { background:#fef4f4; color:var(--sap-negative); border-color:#f7d2d2; }

  @media (max-width: 991px) {
    .pm-table { font-size:.7rem; }
    .pm-table thead th { padding:.35rem .2rem; font-size:.6rem; }
  }
</style>

<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb">
      <i class="bi bi-house-door"></i> Home / <strong>Preventive Maintenance</strong>
    </div>
    <h1 class="sap-page-title">Preventive Maintenance Checklist</h1>
  </div>
  <div class="d-flex gap-2">
    <a href="<?= BASE_URL ?>/reports/pm_report.php" class="sap-btn sap-btn-outline">
      <i class="bi bi-file-earmark-bar-graph"></i> View Reports
    </a>
  </div>
</div>

<?php if ($error): ?>
  <div class="sap-message is-error"><i class="bi bi-exclamation-circle"></i><span><?= e($error) ?></span></div>
<?php endif; ?>
<?php if ($ok): ?>
  <div class="sap-message is-success"><i class="bi bi-check-circle"></i><span><?= e($ok) ?></span></div>
<?php endif; ?>

<?php if ($alreadySubmitted): ?>
  <div class="sap-message is-info">
    <i class="bi bi-info-circle-fill"></i>
    <div>
      You have already submitted a checklist for <strong><?= e("{$currentYear}-Q{$currentQuarter}") ?></strong>.
      You can submit additional checklists below if needed — every submission is reviewed by the Branch Manager.
    </div>
  </div>
<?php endif; ?>

<!-- ===================== FORM ===================== -->
<form method="post" id="pmForm">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">

<div class="sap-card">
  <div class="sap-card-header">
    <i class="bi bi-clipboard-check"></i> Checklist Details
  </div>
  <div class="sap-card-body">
    <div class="row g-3">
      <div class="col-md-4">
        <label class="sap-form-label">Department</label>
        <select name="department_id" id="deptFilter" class="sap-form-control"
                onchange="window.location='?dept='+this.value">
          <option value="">-- All departments --</option>
          <?php foreach ($departments as $d): ?>
            <option value="<?= (int)$d['id'] ?>" <?= $deptFilter == $d['id'] ? 'selected' : '' ?>>
              <?= e($d['department_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-4">
        <label class="sap-form-label">Technician Name</label>
        <input name="technician_name" class="sap-form-control"
               value="<?= e($u['full_name']) ?>" required>
      </div>
      <div class="col-md-4">
        <label class="sap-form-label">Date</label>
        <input type="date" name="checklist_date" class="sap-form-control"
               value="<?= e(date('Y-m-d')) ?>" required>
      </div>
      <div class="col-md-12">
        <label class="sap-form-label">Notes (optional)</label>
        <textarea name="notes" class="sap-form-control" rows="2"
                  placeholder="Any observations about this quarter's maintenance"></textarea>
      </div>
    </div>
  </div>
</div>

<div class="sap-card">
  <div class="sap-card-header">
    <i class="bi bi-list-check"></i> Maintenance Items
  </div>
  <div class="sap-card-body p-2">
    <div class="table-responsive">
      <table class="pm-table" id="pmTable">
        <thead>
          <tr>
            <th style="width:35px">#</th>
            <th style="min-width:180px">Full Employee Name</th>
            <?php foreach (PM_ITEMS as $num => $meta): ?>
              <th title="<?= e($meta['label']) ?>" style="min-width:60px">
                <i class="bi bi-check2-square"></i>
                <span class="th-label"><?= $num ?></span>
              </th>
            <?php endforeach; ?>
            <th style="min-width:60px">
              <i class="bi bi-pencil"></i>
              <span class="th-label">Note</span>
            </th>
          </tr>
          <tr>
            <th colspan="2"></th>
            <?php foreach (PM_ITEMS as $meta): ?>
              <th><span class="th-label" style="font-size:.58rem"><?= e($meta['label']) ?></span></th>
            <?php endforeach; ?>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php $i = 0; foreach ($employees as $emp): $i++; ?>
            <tr data-empid="<?= (int)$emp['id'] ?>">
              <td><?= $i ?></td>
              <td>
                <input type="hidden" name="employees[<?= (int)$emp['id'] ?>][name]"
                       value="<?= e($emp['full_name']) ?>">
                <div class="pm-emp-name"><?= e($emp['full_name']) ?></div>
                <div class="pm-emp-sub">
                  <?= e($emp['department_name'] ?? '—') ?>
                  <?php if ($emp['employee_id']): ?>
                    · <?= e($emp['employee_id']) ?>
                  <?php endif; ?>
                </div>
              </td>
              <?php foreach (PM_ITEMS as $num => $meta): ?>
                <td>
                  <input type="checkbox" class="pm-check"
                         name="employees[<?= (int)$emp['id'] ?>][items][<?= (int)$num ?>]"
                         value="1">
                </td>
              <?php endforeach; ?>
              <td>
                <button type="button" class="pm-note-btn" onclick="toggleNote(this)">+ note</button>
                <div class="pm-note-input">
                  <input type="text"
                         name="employees[<?= (int)$emp['id'] ?>][notes][1]"
                         placeholder="…">
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$employees): ?>
            <tr>
              <td colspan="<?= 3 + count(PM_ITEMS) ?>" style="text-align:center;padding:2rem;color:var(--sap-text-muted)">
                No employees in the selected department.
              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <div class="pm-actions">
      <button type="submit" class="sap-btn sap-btn-emphasized">
        <i class="bi bi-check2-circle"></i> Submit Checklist
      </button>
      <button type="button" class="sap-btn sap-btn-outline" onclick="checkAll(true)">
        <i class="bi bi-check-all"></i> Check all
      </button>
      <button type="button" class="sap-btn sap-btn-outline" onclick="checkAll(false)">
        <i class="bi bi-x-circle"></i> Uncheck all
      </button>
    </div>
  </div>
</div>

</form>

<!-- ===================== HISTORY ===================== -->
<?php if ($history): ?>
<div class="sap-card">
  <div class="sap-card-header"><i class="bi bi-clock-history"></i> My Recent Submissions</div>
  <div class="sap-card-body p-0">
    <ul class="pm-history-list" style="padding:.5rem 1rem">
      <?php foreach ($history as $h):
        $hBucket = $bucketOf($h);
        $hQuarter = (string)($h['quarter_label'] ?? '');
        $hDate    = (string)($h['checklist_date'] ?? '');
        $hSubmit  = (string)($h['submitted_at'] ?? '');
        $hAppr    = $h['approver_name'] ?? null;
        $hRemark  = $h['approval_remarks'] ?? null;
      ?>
        <li>
          <div class="pm-history-main">
            <div>
              <span class="pm-history-q"><?= e($hQuarter !== '' ? $hQuarter : '—') ?></span>
              <?php if ($hDate !== ''): ?>
                — <?= e(date('M j, Y', strtotime($hDate))) ?>
              <?php endif; ?>
            </div>
            <div class="pm-emp-sub">
              <?php if ($hSubmit !== ''): ?>
                Submitted <?= e(date('M j, Y H:i', strtotime($hSubmit))) ?>
              <?php else: ?>
                Submitted —
              <?php endif; ?>
              <?php if (!empty($hAppr)): ?>
                · Reviewed by <?= e($hAppr) ?>
              <?php endif; ?>
            </div>
            <?php if ($hBucket === 'REJECTED' && !empty($hRemark)): ?>
              <div class="pm-history-remark">
                <i class="bi bi-exclamation-circle"></i> <?= e($hRemark) ?>
              </div>
            <?php endif; ?>
          </div>
          <div class="pm-history-side">
            <?php if (function_exists('pm_status_badge')): ?>
              <?= pm_status_badge($hBucket) ?>
            <?php else: ?>
              <span class="pm-status <?= $hBucket === 'APPROVED' ? 'is-good' : ($hBucket === 'REJECTED' ? 'is-bad' : 'is-critical') ?>">
                <?= e($hBucket) ?>
              </span>
            <?php endif; ?>
            <a class="pm-history-link" href="<?= BASE_URL ?>/ict/pm_view.php?id=<?= (int)$h['id'] ?>">
              View details
            </a>
          </div>
        </li>
      <?php endforeach; ?>
    </ul>
  </div>
</div>
<?php endif; ?>

<script>
function toggleNote(btn) {
  const wrap = btn.nextElementSibling;
  wrap.classList.toggle('show');
  if (wrap.classList.contains('show')) {
    const input = wrap.querySelector('input');
    if (input) input.focus();
    btn.textContent = 'hide note';
  } else {
    btn.textContent = '+ note';
  }
}

function checkAll(state) {
  document.querySelectorAll('.pm-check').forEach(c => c.checked = state);
}

document.getElementById('pmForm').addEventListener('submit', e => {
  const total = document.querySelectorAll('.pm-check:checked').length;
  if (total === 0) {
    if (!confirm('No items are checked. Submit anyway?')) {
      e.preventDefault();
    }
  }
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>