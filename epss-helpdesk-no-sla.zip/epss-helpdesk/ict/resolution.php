<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('ICT_STAFF');
$pageTitle = 'Resolved by Me';
$stmt = db()->prepare("SELECT t.*, c.category_name FROM tickets t
    JOIN categories c ON c.id=t.category_id
    WHERE t.assigned_technician_id=? AND t.status IN ('RESOLVED_PENDING_REQUESTER_CONFIRMATION','CLOSED')
    ORDER BY t.resolved_at DESC");
$stmt->execute([$u['id']]);
$tickets = $stmt->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h4 class="mb-3">Resolved by Me</h4>
<div class="card"><div class="card-body">
<table class="table table-hover">
<thead><tr><th>#</th><th>Subject</th><th>Category</th><th>Status</th><th>Resolved</th><th></th></tr></thead>
<tbody>
<?php foreach ($tickets as $t): ?>
<tr>
  <td><?= e($t['ticket_number']) ?></td>
  <td><?= e($t['subject']) ?></td>
  <td><?= e($t['category_name']) ?></td>
  <td><?= status_badge($t['status']) ?></td>
  <td><small><?= $t['resolved_at'] ? e(date('Y-m-d H:i', strtotime($t['resolved_at']))) : '-' ?></small></td>
  <td><a href="ticket_view.php?id=<?= (int)$t['id'] ?>" class="btn btn-sm btn-outline-primary">View</a></td>
</tr>
<?php endforeach; ?>
</tbody></table>
</div></div>
<?php include __DIR__ . '/../includes/footer.php'; ?>