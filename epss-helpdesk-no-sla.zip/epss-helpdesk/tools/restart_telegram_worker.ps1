# ============================================================================
#  Restarts the "EPSS Telegram Worker" scheduled task so the bot loads the
#  current PHP code. Ending a scheduled task does not always kill its child
#  php.exe, and that orphan keeps the worker lock, so any session-0 php.exe is
#  stopped as well. Run as Administrator.
# ============================================================================
$ErrorActionPreference = 'Continue'
$taskName = 'EPSS Telegram Worker'

Write-Host "Stopping task: $taskName"
Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue | Out-Null

Get-CimInstance Win32_Process -Filter "Name = 'php.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.SessionId -eq 0 } |
    ForEach-Object {
        Write-Host "  stopping php.exe pid $($_.ProcessId) (session 0)"
        Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
    }

Start-Sleep -Seconds 2

Write-Host "Starting task: $taskName"
Start-ScheduledTask -TaskName $taskName

Start-Sleep -Seconds 4
Get-ScheduledTask -TaskName $taskName | Select-Object TaskName, State | Format-List

$running = @(Get-CimInstance Win32_Process -Filter "Name = 'php.exe'" -ErrorAction SilentlyContinue |
             Where-Object { $_.SessionId -eq 0 })
if ($running.Count -gt 0) {
    Write-Host ("Worker php.exe PIDs: " + (($running | ForEach-Object { $_.ProcessId }) -join ', '))
} else {
    Write-Host "WARNING: no worker php.exe in session 0 - check logs\telegram_worker.log"
}
