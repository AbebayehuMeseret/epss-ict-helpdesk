@echo off
REM ============================================================================
REM  Keeps tools\telegram_worker.php running and appends its output to
REM  logs\telegram_worker.log (rotated to .old at 5 MB).
REM  Started at boot by the "EPSS Telegram Worker" scheduled task.
REM ============================================================================
setlocal
set "PHP=C:\xampp\php\php.exe"
if not exist "%PHP%" set "PHP=php"
cd /d "%~dp0.."
set "LOG=%~dp0..\logs\telegram_worker.log"
if not exist "%~dp0..\logs" mkdir "%~dp0..\logs"

:loop
REM One poller only: the worker takes an exclusive lock, so a second copy exits at once.
for %%A in ("%LOG%") do if %%~zA GTR 5242880 move /y "%LOG%" "%LOG%.old" >nul 2>&1
echo [%DATE% %TIME%] starting worker>>"%LOG%"
"%PHP%" tools\telegram_worker.php>>"%LOG%" 2>&1
echo [%DATE% %TIME%] worker exited, restarting in 5 seconds>>"%LOG%"
timeout /t 5 >nul
goto loop
