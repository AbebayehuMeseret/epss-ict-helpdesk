@echo off
REM ============================================================================
REM  Removes the "EPSS Telegram Worker" boot task and stops the running worker.
REM  Run as Administrator.
REM ============================================================================
setlocal
set "TASK=EPSS Telegram Worker"

schtasks /query /tn "%TASK%" >nul 2>&1
if errorlevel 1 (
  echo   The task "%TASK%" is not installed.
) else (
  schtasks /end /tn "%TASK%" >nul 2>&1
  schtasks /delete /tn "%TASK%" /f >nul 2>&1
  echo   Removed the task "%TASK%".
)

REM Stop the worker that the task started (only php.exe running the worker).
for /f "tokens=2 delims==" %%P in ('wmic process where "name='php.exe' and commandline like '%%telegram_worker.php%%'" get processid /value 2^>nul') do (
  echo   Stopping worker pid %%P
  taskkill /f /pid %%P >nul 2>&1
)

echo.
echo   Done. The Telegram bot no longer starts automatically.
if /i not "%~1"=="/quiet" pause
