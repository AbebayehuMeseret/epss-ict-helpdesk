@echo off
REM ============================================================================
REM  Registers the Telegram bot worker as a Windows scheduled task.
REM
REM  The task runs tools\start_telegram_worker.bat as SYSTEM at every boot —
REM  before anyone logs in — and keeps it running (auto-restart on failure).
REM
REM  Run this file as Administrator (right-click -> "Run as administrator").
REM  Remove it again with tools\uninstall_telegram_autostart.bat
REM ============================================================================
setlocal
set "TASK=EPSS Telegram Worker"
set "BAT=%~dp0start_telegram_worker.bat"
set "PS1=%~dp0register_telegram_task.ps1"

if not exist "%BAT%" (
  echo ERROR: %BAT% not found.
  if /i not "%~1"=="/quiet" pause
  exit /b 1
)
if not exist "%PS1%" (
  echo ERROR: %PS1% not found.
  if /i not "%~1"=="/quiet" pause
  exit /b 1
)

echo.
echo   Task : %TASK%
echo   Runs : %BAT%
echo.

set "SW="
if /i "%~1"=="/quiet" set "SW=-Quiet"
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" %SW%
if errorlevel 1 (
  echo.
  echo ERROR: could not register the scheduled task.
  echo        Right-click this file and choose "Run as administrator".
  if /i not "%~1"=="/quiet" pause
  exit /b 1
)

echo.
echo   Done. "%TASK%" starts the Telegram bot automatically at every boot.
echo   Log file: %~dp0..\logs\telegram_worker.log
echo.
schtasks /query /tn "%TASK%" /fo LIST | findstr /i "TaskName Status"
if /i not "%~1"=="/quiet" pause
