# ============================================================================
#  Registers the EPSS Telegram worker as a Windows scheduled task that starts
#  at every boot (before anyone logs in) and keeps running indefinitely.
#
#  Called by tools\install_telegram_autostart.bat — run that as Administrator.
# ============================================================================
param([switch]$Quiet)

$ErrorActionPreference = 'Stop'

$taskName = 'EPSS Telegram Worker'
$bat      = Join-Path $PSScriptRoot 'start_telegram_worker.bat'
$workDir  = Split-Path -Parent $PSScriptRoot

if (-not (Test-Path $bat)) { throw "Worker launcher not found: $bat" }

# Escape for XML (a folder name may contain & or ').
$batXml = [System.Security.SecurityElement]::Escape($bat)
$dirXml = [System.Security.SecurityElement]::Escape($workDir)

$xml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Description>EPSS Helpdesk - Telegram bot polling worker (keeps tools\telegram_worker.php running).</Description>
    <Author>EPSS Helpdesk</Author>
  </RegistrationInfo>
  <Triggers>
    <BootTrigger>
      <Enabled>true</Enabled>
      <Delay>PT20S</Delay>
    </BootTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>S-1-5-18</UserId>
      <RunLevel>HighestAvailable</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <IdleSettings>
      <StopOnIdleEnd>false</StopOnIdleEnd>
      <RestartOnIdle>false</RestartOnIdle>
    </IdleSettings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <RunOnlyIfIdle>false</RunOnlyIfIdle>
    <WakeToRun>false</WakeToRun>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
    <Priority>7</Priority>
    <RestartOnFailure>
      <Interval>PT1M</Interval>
      <Count>999</Count>
    </RestartOnFailure>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>cmd.exe</Command>
      <Arguments>/c "$batXml"</Arguments>
      <WorkingDirectory>$dirXml</WorkingDirectory>
    </Exec>
  </Actions>
</Task>
"@

# Re-register on top of any previous version of the task.
Register-ScheduledTask -TaskName $taskName -Xml $xml -Force | Out-Null

# Start it now so the bot is online without waiting for a reboot.
Start-ScheduledTask -TaskName $taskName

if (-not $Quiet) {
    Write-Host ''
    Write-Host "  Registered task : $taskName"
    Write-Host "  Runs            : $bat"
    Write-Host "  Account         : SYSTEM (starts at boot, no login needed)"
    Write-Host ''
}
