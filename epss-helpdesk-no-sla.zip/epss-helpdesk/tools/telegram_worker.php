<?php
declare(strict_types=1);
/**
 * Always-on Telegram listener for local servers (no public URL needed).
 * Run from a console:   php tools/telegram_worker.php
 * Keep it running:      tools\start_telegram_worker.bat (installs a boot task:
 *                       tools\install_telegram_autostart.bat).
 * Linux servers:        systemd or supervisor.
 *
 * Exit codes:
 *   0  normal stop
 *   3  another worker already holds the lock (started twice)
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('CLI only'); }

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/telegram.php';

/* ---------------------------------------------------------------------------
   Single instance.
   Two pollers would both call getUpdates: Telegram answers 409 Conflict to one
   of them and the updates it grabbed are lost. The lock also covers a boot
   task racing a manual start.
   --------------------------------------------------------------------------- */
$lockDir = dirname(__DIR__) . '/logs';
if (!is_dir($lockDir)) { @mkdir($lockDir, 0775, true); }
$lockPath = $lockDir . '/telegram_worker.lock';
$lockHandle = @fopen($lockPath, 'c');
if (!$lockHandle || !flock($lockHandle, LOCK_EX | LOCK_NB)) {
    fwrite(STDERR, "[" . date('Y-m-d H:i:s') . "] Another Telegram worker is already running (lock: {$lockPath}) - exiting.\n");
    exit(3);
}

echo "[" . date('H:i:s') . "] Telegram worker started (pid " . getmypid() . "). Ctrl+C to stop.\n";

while (true) {
    try {
        $n = tg_poll_once(25);                 // long-poll: returns instantly when a message arrives
        if ($n) echo "[" . date('H:i:s') . "] handled {$n} update(s)\n";
    } catch (Throwable $e) {
        echo "[" . date('H:i:s') . "] " . $e->getMessage() . "\n";
        sleep(10);                             // back off on errors / no internet
    }
}
