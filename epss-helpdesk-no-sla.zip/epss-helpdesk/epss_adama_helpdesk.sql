-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 28, 2026 at 09:35 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `epss_adama_helpdesk`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) DEFAULT NULL,
  `module` varchar(100) DEFAULT NULL,
  `record_id` bigint(20) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `module`, `record_id`, `description`, `ip_address`, `user_agent`, `created_at`) VALUES
(1, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:02:06'),
(2, 1, 'PasswordChanged', 'users', 1, 'Password changed', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:02:28'),
(3, 1, 'ToggleDepartment', 'departments', 5, 'Toggled', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:05:29'),
(4, 1, 'ToggleDepartment', 'departments', 5, 'Toggled', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:05:33'),
(5, 1, 'UpdateSettings', 'settings', NULL, 'Settings updated', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:07:18'),
(6, 1, 'UpdateSettings', 'settings', NULL, 'Settings updated', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:07:25'),
(7, 1, 'UpdateDepartment', 'departments', 5, 'Updated department Transport Management', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:14:56'),
(8, 1, 'UpdateDepartment', 'departments', 3, 'Updated department General Service', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:15:20'),
(9, 1, 'UpdateDepartment', 'departments', 4, 'Updated department warehouse management and shiping', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:15:48'),
(10, 1, 'CreateDepartment', 'departments', 9, 'Marketing & Customer Service', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:16:15'),
(11, 1, 'CreateDepartment', 'departments', 10, 'QMS', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:16:46'),
(12, 1, 'CreateUser', 'users', 2, 'Created user AlemnehN', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:17:58'),
(13, 1, 'ResetPassword', 'users', 2, 'Password reset', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:18:14'),
(14, 1, 'Logout', 'auth', 1, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:18:24'),
(15, 2, 'Login', 'auth', 2, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:18:35'),
(16, 2, 'PasswordChanged', 'users', 2, 'Password changed', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:19:08'),
(17, 2, 'Logout', 'auth', 2, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:21:49'),
(18, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:21:59'),
(19, 1, 'CreateUser', 'users', 4, 'Created user ZemenF', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:23:04'),
(20, 1, 'Logout', 'auth', 1, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:23:25'),
(21, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:23:54'),
(22, 1, 'Logout', 'auth', 1, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:24:09'),
(23, 4, 'Login', 'auth', 4, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:24:18'),
(24, 4, 'PasswordChanged', 'users', 4, 'Password changed', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:24:32'),
(25, 4, 'Logout', 'auth', 4, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:26:41'),
(26, 2, 'Login', 'auth', 2, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 11:26:52'),
(27, 2, 'Logout', 'auth', 2, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:18:51'),
(28, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:18:59'),
(29, 1, 'CreateUser', 'users', 5, 'Created user AbMessi', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:19:29'),
(30, 1, 'Logout', 'auth', 1, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:19:37'),
(31, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:19:54'),
(32, 1, 'Logout', 'auth', 1, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:20:07'),
(33, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:20:28'),
(34, 1, 'ResetPassword', 'users', 5, 'Password reset', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:20:37'),
(35, 1, 'Logout', 'auth', 1, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:20:44'),
(36, 5, 'Login', 'auth', 5, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:20:52'),
(37, 5, 'PasswordChanged', 'users', 5, 'Password changed', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:21:06'),
(38, 5, 'Logout', 'auth', 5, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:21:20'),
(39, 4, 'Login', 'auth', 4, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:21:30'),
(40, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:26:05'),
(41, 1, 'Logout', 'auth', 1, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:26:10'),
(42, 4, 'Login', 'auth', 4, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:26:17'),
(43, 4, 'CreateTicket', 'tickets', 1, 'Created EPSS-ICT-AD-2026-000001', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:28:13'),
(44, 4, 'Logout', 'auth', 4, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:28:24'),
(45, 2, 'Login', 'auth', 2, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:28:35'),
(46, 2, 'APPROVE', 'tickets', 1, 'TL action approve on EPSS-ICT-AD-2026-000001', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:28:52'),
(47, 2, 'Logout', 'auth', 2, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:29:01'),
(48, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:29:16'),
(49, 1, 'Logout', 'auth', 1, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:29:34'),
(50, 5, 'Login', 'auth', 5, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:29:41'),
(51, 5, 'ACCEPT', 'tickets', 1, 'ICT action accept', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:30:09'),
(52, 5, 'RESOLVE', 'tickets', 1, 'ICT action resolve', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:31:08'),
(53, 5, 'Logout', 'auth', 5, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:31:19'),
(54, 2, 'Login', 'auth', 2, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:31:31'),
(55, 2, 'CONFIRM', 'tickets', 1, 'TL verification confirm', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:31:50'),
(56, 2, 'Logout', 'auth', 2, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:32:14'),
(57, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:32:21'),
(58, 1, 'Logout', 'auth', 1, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 12:55:36'),
(59, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 13:55:06'),
(60, 1, 'UpdateKPI', 'kpis', 4, 'Updated KPI Hardware Support SLA Compliance', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 13:56:45'),
(61, 1, 'UpdateKPI', 'kpis', 4, 'Updated KPI Hardware Support SLA Compliance', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 13:57:50'),
(62, 1, 'Logout', 'auth', 1, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 14:11:47'),
(63, 2, 'Login', 'auth', 2, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 14:11:57'),
(64, 2, 'Logout', 'auth', 2, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 14:12:19'),
(65, 4, 'Login', 'auth', 4, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 14:12:26'),
(66, 4, 'Logout', 'auth', 4, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 14:13:01'),
(67, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 14:13:08'),
(68, 4, 'Login', 'auth', 4, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 16:12:17'),
(69, 4, 'CreateTicket', 'tickets', 2, 'Created EPSS-ICT-AD-2026-000002', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 16:12:43'),
(70, 4, 'Logout', 'auth', 4, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 16:13:16'),
(71, 2, 'Login', 'auth', 2, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 16:13:26'),
(72, 2, 'APPROVE', 'tickets', 2, 'TL action approve on EPSS-ICT-AD-2026-000002', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 16:13:50'),
(73, 2, 'Logout', 'auth', 2, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 16:13:57'),
(74, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 16:14:10'),
(75, 1, 'Logout', 'auth', 1, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 16:14:25'),
(76, 5, 'Login', 'auth', 5, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 16:14:41'),
(77, 5, 'ACCEPT', 'tickets', 2, 'ICT action accept', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 16:15:01'),
(78, 5, 'RESOLVE', 'tickets', 2, 'ICT action resolve', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 16:15:25'),
(79, 5, 'Logout', 'auth', 5, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 16:15:37'),
(80, 2, 'Login', 'auth', 2, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 16:15:50'),
(81, 2, 'CONFIRM', 'tickets', 2, 'TL verification confirm', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 16:16:00'),
(82, 2, 'Logout', 'auth', 2, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 16:16:22'),
(83, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 16:16:30'),
(84, 1, 'DeleteSubcategory', 'subcategories', 29, 'Deleted subcategory ERP', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 16:44:27'),
(85, 1, 'DeleteSubcategory', 'subcategories', 27, 'Deleted subcategory Active Directory', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 16:44:32'),
(86, 1, 'TogglePriority', 'priorities', 4, 'Status toggled', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 16:49:05'),
(87, 1, 'Logout', 'auth', 1, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 17:10:29'),
(88, 4, 'Login', 'auth', 4, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 17:12:14'),
(89, 4, 'Logout', 'auth', 4, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 17:15:59'),
(90, 2, 'Login', 'auth', 2, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 17:16:09'),
(91, 2, 'Logout', 'auth', 2, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 17:24:56'),
(92, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 17:25:08'),
(93, 1, 'UpdateSettings', 'settings', NULL, 'Settings updated', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 17:26:04'),
(94, 1, 'Logout', 'auth', 1, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 17:36:28'),
(95, 4, 'Login', 'auth', 4, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 17:36:37'),
(96, 4, 'Logout', 'auth', 4, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 17:37:06'),
(97, 2, 'Login', 'auth', 2, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 17:37:18'),
(98, 2, 'Logout', 'auth', 2, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 17:50:04'),
(99, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 17:50:12'),
(100, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 18:40:55'),
(101, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-26 23:14:30'),
(102, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-27 21:06:11'),
(103, 1, 'Logout', 'auth', 1, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-27 21:10:05'),
(104, 2, 'Login', 'auth', 2, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-27 21:11:14'),
(105, 2, 'Logout', 'auth', 2, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-27 21:12:07'),
(106, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-27 21:54:01'),
(107, 1, 'DeleteDepartment', 'departments', 8, 'Deleted department Administration', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-27 22:17:17'),
(108, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-27 22:20:29'),
(109, 1, 'Login', 'auth', 1, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-28 08:46:23'),
(110, 1, 'Logout', 'auth', 1, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-28 08:46:31'),
(111, 2, 'Login', 'auth', 2, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-28 08:46:39'),
(112, 2, 'Logout', 'auth', 2, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-28 08:47:17'),
(113, 4, 'Login', 'auth', 4, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-28 08:47:30'),
(114, 4, 'CreateTicket', 'tickets', 3, 'Created EPSS-ICT-AD-2026-000003', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-28 08:48:49'),
(115, 4, 'Logout', 'auth', 4, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-28 08:49:01'),
(116, 2, 'Login', 'auth', 2, 'User logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-28 08:49:09'),
(117, 2, 'APPROVE', 'tickets', 3, 'TL action approve on EPSS-ICT-AD-2026-000003', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-28 08:49:56'),
(118, 2, 'Logout', 'auth', 2, 'User logged out', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-09-28 08:50:00');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE') DEFAULT 'ACTIVE',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `description`, `status`, `created_at`) VALUES
(1, 'Network Support', 'Network related issues', 'ACTIVE', '2026-09-26 10:36:19'),
(2, 'ICT Support', 'General ICT assistance', 'ACTIVE', '2026-09-26 10:36:19'),
(3, 'Software Support', 'Software related issues', 'ACTIVE', '2026-09-26 10:36:19'),
(4, 'Hardware Support', 'Hardware related issues', 'ACTIVE', '2026-09-26 10:36:19'),
(5, 'System Support', 'System and account related issues', 'ACTIVE', '2026-09-26 10:36:19');

-- --------------------------------------------------------

--
-- Table structure for table `chat_conversations`
--

CREATE TABLE `chat_conversations` (
  `id` bigint(20) NOT NULL,
  `ticket_id` bigint(20) DEFAULT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `last_message_at` datetime DEFAULT current_timestamp(),
  `status` enum('OPEN','CLOSED') DEFAULT 'OPEN'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chat_conversations`
--

INSERT INTO `chat_conversations` (`id`, `ticket_id`, `subject`, `created_by`, `created_at`, `last_message_at`, `status`) VALUES
(1, NULL, 'i need asupport', 4, '2026-09-26 14:12:57', '2026-09-26 14:12:57', 'OPEN'),
(2, NULL, 'ok', 1, '2026-09-26 14:13:22', '2026-09-26 14:13:22', 'OPEN');

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` bigint(20) NOT NULL,
  `conversation_id` bigint(20) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `body` text NOT NULL,
  `attachment_id` bigint(20) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chat_participants`
--

CREATE TABLE `chat_participants` (
  `id` bigint(20) NOT NULL,
  `conversation_id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `joined_at` datetime DEFAULT current_timestamp(),
  `last_read_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chat_participants`
--

INSERT INTO `chat_participants` (`id`, `conversation_id`, `user_id`, `joined_at`, `last_read_at`) VALUES
(1, 1, 4, '2026-09-26 14:12:57', '0000-00-00 00:00:00'),
(2, 1, 1, '2026-09-26 14:12:57', NULL),
(3, 2, 1, '2026-09-26 14:13:22', '0000-00-00 00:00:00'),
(4, 2, 4, '2026-09-26 14:13:22', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `department_code` varchar(30) NOT NULL,
  `department_name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE') DEFAULT 'ACTIVE',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `department_code`, `department_name`, `description`, `status`, `created_at`) VALUES
(1, 'FIN', 'Finance', 'Finance Department', 'ACTIVE', '2026-09-26 10:36:19'),
(2, 'HR', 'Human Resources', 'Human Resources Department', 'ACTIVE', '2026-09-26 10:36:19'),
(3, 'GS', 'General Service', 'GS Department', 'ACTIVE', '2026-09-26 10:36:19'),
(4, 'WIM', 'warehouse management and shiping', 'WIM Department', 'ACTIVE', '2026-09-26 10:36:19'),
(5, 'TM', 'Transport Management', 'TM Department', 'ACTIVE', '2026-09-26 10:36:19'),
(6, 'DM', 'Demand Management', 'Demand Management Department', 'ACTIVE', '2026-09-26 10:36:19'),
(7, 'ICT', 'ICT', 'Information and Communication Technology', 'ACTIVE', '2026-09-26 10:36:19'),
(9, 'MCX', 'Marketing & Customer Service', 'MCX Department', 'ACTIVE', '2026-09-26 11:16:15'),
(10, 'Quality', 'QMS', 'QMS Department', 'ACTIVE', '2026-09-26 11:16:46');

-- --------------------------------------------------------

--
-- Table structure for table `kpis`
--

CREATE TABLE `kpis` (
  `id` int(11) NOT NULL,
  `kpi_name` varchar(200) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `target_percentage` decimal(5,2) DEFAULT 100.00,
  `measurement_period` enum('MONTHLY','QUARTERLY','YEARLY') DEFAULT 'MONTHLY',
  `status` enum('ACTIVE','INACTIVE') DEFAULT 'ACTIVE',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kpis`
--

INSERT INTO `kpis` (`id`, `kpi_name`, `category_id`, `description`, `target_percentage`, `measurement_period`, `status`, `created_at`) VALUES
(1, 'Network Support SLA Compliance', 1, 'Percentage of network tickets resolved within SLA target', 100.00, 'MONTHLY', 'ACTIVE', '2026-09-26 10:36:20'),
(2, 'ICT Support SLA Compliance', 2, 'Percentage of ICT tickets resolved within SLA target', 100.00, 'MONTHLY', 'ACTIVE', '2026-09-26 10:36:20'),
(3, 'Software Support SLA Compliance', 3, 'Percentage of software tickets resolved within SLA target', 100.00, 'MONTHLY', 'ACTIVE', '2026-09-26 10:36:20'),
(4, 'Hardware Support SLA Compliance', 4, 'Percentage of hardware tickets resolved within SLA target', 100.00, 'MONTHLY', 'ACTIVE', '2026-09-26 10:36:20'),
(5, 'System Support SLA Compliance', 5, 'Percentage of system tickets resolved within SLA target', 100.00, 'MONTHLY', 'ACTIVE', '2026-09-26 10:36:20');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ticket_id` bigint(20) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `notification_type` varchar(50) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `ticket_id`, `title`, `message`, `notification_type`, `is_read`, `created_at`) VALUES
(1, 2, 1, 'New Ticket Awaiting Approval', 'Ticket EPSS-ICT-AD-2026-000001 requires your approval.', 'approval', 1, '2026-09-26 12:28:13'),
(2, 5, 1, 'Ticket Approved', 'Ticket EPSS-ICT-AD-2026-000001 is approved and ready for ICT.', 'approval', 0, '2026-09-26 12:28:52'),
(3, 2, 1, 'Verification Required', 'ICT resolved EPSS-ICT-AD-2026-000001. Please verify.', 'verify', 1, '2026-09-26 12:31:08'),
(4, 4, 1, 'Ticket Resolved', 'Your ticket EPSS-ICT-AD-2026-000001 has been resolved pending TL verification.', 'info', 1, '2026-09-26 12:31:08'),
(5, 4, 1, 'Ticket Closed', 'Your ticket EPSS-ICT-AD-2026-000001 has been closed.', 'success', 1, '2026-09-26 12:31:50'),
(6, 5, 1, 'Ticket Closed', 'Ticket EPSS-ICT-AD-2026-000001 verified and closed.', 'success', 0, '2026-09-26 12:31:50'),
(7, 2, 2, 'New Ticket Awaiting Approval', 'Ticket EPSS-ICT-AD-2026-000002 requires your approval.', 'approval', 1, '2026-09-26 16:12:43'),
(8, 5, 2, 'Ticket Approved', 'Ticket EPSS-ICT-AD-2026-000002 is approved and ready for ICT.', 'approval', 0, '2026-09-26 16:13:50'),
(9, 2, 2, 'Verification Required', 'ICT resolved EPSS-ICT-AD-2026-000002. Please verify.', 'verify', 1, '2026-09-26 16:15:25'),
(10, 4, 2, 'Ticket Resolved', 'Your ticket EPSS-ICT-AD-2026-000002 has been resolved pending TL verification.', 'info', 0, '2026-09-26 16:15:25'),
(11, 4, 2, 'Ticket Closed', 'Your ticket EPSS-ICT-AD-2026-000002 has been closed.', 'success', 0, '2026-09-26 16:16:00'),
(12, 5, 2, 'Ticket Closed', 'Ticket EPSS-ICT-AD-2026-000002 verified and closed.', 'success', 0, '2026-09-26 16:16:00'),
(13, 2, 3, 'New Ticket Awaiting Approval', 'Ticket EPSS-ICT-AD-2026-000003 requires your approval.', 'approval', 0, '2026-09-28 08:48:49'),
(14, 5, 3, 'Ticket Approved', 'Ticket EPSS-ICT-AD-2026-000003 is approved and ready for ICT.', 'approval', 0, '2026-09-28 08:49:56');

-- --------------------------------------------------------

--
-- Table structure for table `priorities`
--

CREATE TABLE `priorities` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `level` int(11) NOT NULL DEFAULT 1,
  `response_target_minutes` int(11) DEFAULT NULL,
  `resolution_target_minutes` int(11) DEFAULT NULL,
  `color` varchar(20) DEFAULT 'secondary',
  `status` enum('ACTIVE','INACTIVE') DEFAULT 'ACTIVE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `priorities`
--

INSERT INTO `priorities` (`id`, `name`, `level`, `response_target_minutes`, `resolution_target_minutes`, `color`, `status`) VALUES
(1, 'Low', 1, 1440, 4320, 'secondary', 'ACTIVE'),
(2, 'Medium', 2, 480, 1440, 'info', 'ACTIVE'),
(3, 'High', 3, 120, 480, 'warning', 'ACTIVE'),
(4, 'Critical', 4, 30, 240, 'danger', 'INACTIVE');

-- --------------------------------------------------------

--
-- Table structure for table `sla_pauses`
--

CREATE TABLE `sla_pauses` (
  `id` bigint(20) NOT NULL,
  `ticket_id` bigint(20) NOT NULL,
  `paused_at` datetime DEFAULT current_timestamp(),
  `resumed_at` datetime DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

CREATE TABLE `subcategories` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE') DEFAULT 'ACTIVE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`id`, `category_id`, `name`, `description`, `status`) VALUES
(1, 1, 'Internet not working', NULL, 'ACTIVE'),
(2, 1, 'LAN problem', NULL, 'ACTIVE'),
(3, 1, 'Wi-Fi problem', NULL, 'ACTIVE'),
(4, 1, 'Network cable problem', NULL, 'ACTIVE'),
(5, 1, 'Switch problem', NULL, 'ACTIVE'),
(6, 1, 'Router problem', NULL, 'ACTIVE'),
(7, 1, 'IP address problem', NULL, 'ACTIVE'),
(8, 1, 'DNS problem', NULL, 'ACTIVE'),
(9, 2, 'General IT assistance', NULL, 'ACTIVE'),
(10, 2, 'Printer configuration', NULL, 'ACTIVE'),
(11, 2, 'Email assistance', NULL, 'ACTIVE'),
(12, 2, 'Peripheral configuration', NULL, 'ACTIVE'),
(13, 3, 'Application installation', NULL, 'ACTIVE'),
(14, 3, 'Application error', NULL, 'ACTIVE'),
(15, 3, 'Microsoft Office', NULL, 'ACTIVE'),
(16, 3, 'Antivirus', NULL, 'ACTIVE'),
(17, 3, 'Browser problem', NULL, 'ACTIVE'),
(18, 4, 'Desktop computer', NULL, 'ACTIVE'),
(19, 4, 'Laptop', NULL, 'ACTIVE'),
(20, 4, 'Monitor', NULL, 'ACTIVE'),
(21, 4, 'Keyboard', NULL, 'ACTIVE'),
(22, 4, 'Mouse', NULL, 'ACTIVE'),
(23, 4, 'Printer', NULL, 'ACTIVE'),
(24, 4, 'Scanner', NULL, 'ACTIVE'),
(25, 4, 'UPS', NULL, 'ACTIVE'),
(26, 5, 'User account', NULL, 'ACTIVE'),
(28, 5, 'SAP', NULL, 'ACTIVE'),
(30, 5, 'System access', NULL, 'ACTIVE'),
(31, 5, 'Password reset', NULL, 'ACTIVE');

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`setting_key`, `setting_value`, `description`, `updated_at`) VALUES
('allowed_ext', 'jpg,jpeg,png,gif,pdf,doc,docx,xls,xlsx,txt,zip', 'Allowed extensions', '2026-09-26 10:36:20'),
('branch_name', 'Adama Branch', 'Branch name', '2026-09-26 10:36:20'),
('kpi_default_target', '100.00', 'Default KPI target percentage', '2026-09-26 10:36:20'),
('max_upload_size', '10485760', 'Max upload bytes (10MB)', '2026-09-26 10:36:20'),
('org_name', 'Ethiopian Pharmaceuticals Supply Service', 'Organization name', '2026-09-26 10:36:20'),
('sla_start_point', 'APPROVAL', 'When SLA starts: CREATION|APPROVAL|ASSIGNMENT', '2026-09-26 10:36:20'),
('sla_use_working_hours', '0', 'Use working hours for SLA', '2026-09-26 10:36:20'),
('system_name', 'EPSS Adama ICT Helpdesk System', 'System name', '2026-09-26 10:36:20'),
('ticket_counter', '3', 'Last ticket number', '2026-09-28 08:48:49'),
('ticket_prefix', 'EPSS-ICT-AD', 'Ticket number prefix', '2026-09-26 11:07:18'),
('ticket_year', '2026', 'Ticket numbering year', '2026-09-26 10:36:20'),
('timezone', 'Africa/Addis_Ababa', 'Default timezone', '2026-09-26 10:36:20'),
('work_days', '1,2,3,4,5,6,7', 'Working days (1=Mon)', '2026-09-26 17:26:04'),
('work_end', '17:30', 'Working hours end', '2026-09-26 10:36:20'),
('work_start', '08:30', 'Working hours start', '2026-09-26 10:36:20');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `id` bigint(20) NOT NULL,
  `ticket_number` varchar(50) NOT NULL,
  `requester_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `team_leader_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `priority_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `location` varchar(150) DEFAULT NULL,
  `asset_number` varchar(100) DEFAULT NULL,
  `preferred_contact` varchar(150) DEFAULT NULL,
  `status` varchar(80) NOT NULL DEFAULT 'PENDING_TEAM_LEADER_APPROVAL',
  `assigned_technician_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `team_leader_approved_at` datetime DEFAULT NULL,
  `ict_started_at` datetime DEFAULT NULL,
  `resolved_at` datetime DEFAULT NULL,
  `team_leader_verified_at` datetime DEFAULT NULL,
  `closed_at` datetime DEFAULT NULL,
  `sla_deadline` datetime DEFAULT NULL,
  `sla_paused_minutes` int(11) DEFAULT 0,
  `rejection_reason` text DEFAULT NULL,
  `clarification_reason` text DEFAULT NULL,
  `verification_comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`id`, `ticket_number`, `requester_id`, `department_id`, `team_leader_id`, `category_id`, `subcategory_id`, `priority_id`, `subject`, `description`, `location`, `asset_number`, `preferred_contact`, `status`, `assigned_technician_id`, `created_at`, `team_leader_approved_at`, `ict_started_at`, `resolved_at`, `team_leader_verified_at`, `closed_at`, `sla_deadline`, `sla_paused_minutes`, `rejection_reason`, `clarification_reason`, `verification_comment`) VALUES
(1, 'EPSS-ICT-AD-2026-000001', 4, 1, 2, 2, 11, 1, 'IT support', 'test', NULL, NULL, NULL, 'CLOSED', 5, '2026-09-26 12:28:13', '2026-09-26 12:28:52', '2026-09-26 12:30:09', '2026-09-26 12:31:08', '2026-09-26 12:31:50', '2026-09-26 12:31:50', '2026-09-29 12:28:52', 0, NULL, NULL, ''),
(2, 'EPSS-ICT-AD-2026-000002', 4, 1, 2, 3, 15, 1, 'IT support', 'test', NULL, NULL, NULL, 'CLOSED', 5, '2026-09-26 16:12:43', '2026-09-26 16:13:50', '2026-09-26 16:15:01', '2026-09-26 16:15:25', '2026-09-26 16:16:00', '2026-09-26 16:16:00', '2026-09-29 16:13:50', 0, NULL, NULL, ''),
(3, 'EPSS-ICT-AD-2026-000003', 4, 1, 2, 1, 1, 2, 'my internet is not working can you fix them', 'network problem', NULL, NULL, NULL, 'APPROVED_FOR_ICT', NULL, '2026-09-28 08:48:49', '2026-09-28 08:49:56', NULL, NULL, NULL, NULL, '2026-09-29 08:49:56', 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ticket_attachments`
--

CREATE TABLE `ticket_attachments` (
  `id` bigint(20) NOT NULL,
  `ticket_id` bigint(20) NOT NULL,
  `uploaded_by` int(11) NOT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `stored_name` varchar(255) DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `file_type` varchar(100) DEFAULT NULL,
  `file_size` bigint(20) DEFAULT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_comments`
--

CREATE TABLE `ticket_comments` (
  `id` bigint(20) NOT NULL,
  `ticket_id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `is_internal` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_history`
--

CREATE TABLE `ticket_history` (
  `id` bigint(20) NOT NULL,
  `ticket_id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `old_status` varchar(80) DEFAULT NULL,
  `new_status` varchar(80) DEFAULT NULL,
  `action` varchar(100) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ticket_history`
--

INSERT INTO `ticket_history` (`id`, `ticket_id`, `user_id`, `old_status`, `new_status`, `action`, `comment`, `created_at`) VALUES
(1, 1, 4, NULL, 'PENDING_TEAM_LEADER_APPROVAL', 'Ticket Created', NULL, '2026-09-26 12:28:13'),
(2, 1, 2, 'PENDING_TEAM_LEADER_APPROVAL', 'APPROVED_FOR_ICT', 'Approved by Team Leader', 'please', '2026-09-26 12:28:52'),
(3, 1, 5, 'APPROVED_FOR_ICT', 'IN_PROGRESS', 'ICT Accepted Ticket', NULL, '2026-09-26 12:30:09'),
(4, 1, 5, 'IN_PROGRESS', 'RESOLVED_PENDING_TEAM_LEADER_VERIFICATION', 'Work Completed - Sent for Verification', 'test', '2026-09-26 12:31:08'),
(5, 1, 2, 'RESOLVED_PENDING_TEAM_LEADER_VERIFICATION', 'CLOSED', 'Verified and Closed', '', '2026-09-26 12:31:50'),
(6, 2, 4, NULL, 'PENDING_TEAM_LEADER_APPROVAL', 'Ticket Created', NULL, '2026-09-26 16:12:43'),
(7, 2, 2, 'PENDING_TEAM_LEADER_APPROVAL', 'APPROVED_FOR_ICT', 'Approved by Team Leader', '', '2026-09-26 16:13:50'),
(8, 2, 5, 'APPROVED_FOR_ICT', 'IN_PROGRESS', 'ICT Accepted Ticket', NULL, '2026-09-26 16:15:01'),
(9, 2, 5, 'IN_PROGRESS', 'RESOLVED_PENDING_TEAM_LEADER_VERIFICATION', 'Work Completed - Sent for Verification', 'test', '2026-09-26 16:15:25'),
(10, 2, 2, 'RESOLVED_PENDING_TEAM_LEADER_VERIFICATION', 'CLOSED', 'Verified and Closed', '', '2026-09-26 16:16:00'),
(11, 3, 4, NULL, 'PENDING_TEAM_LEADER_APPROVAL', 'Ticket Created', NULL, '2026-09-28 08:48:49'),
(12, 3, 2, 'PENDING_TEAM_LEADER_APPROVAL', 'APPROVED_FOR_ICT', 'Approved by Team Leader', 'ASAP', '2026-09-28 08:49:56');

-- --------------------------------------------------------

--
-- Table structure for table `ticket_work_logs`
--

CREATE TABLE `ticket_work_logs` (
  `id` bigint(20) NOT NULL,
  `ticket_id` bigint(20) NOT NULL,
  `technician_id` int(11) NOT NULL,
  `diagnosis` text DEFAULT NULL,
  `action_taken` text DEFAULT NULL,
  `root_cause` text DEFAULT NULL,
  `resolution` text DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ticket_work_logs`
--

INSERT INTO `ticket_work_logs` (`id`, `ticket_id`, `technician_id`, `diagnosis`, `action_taken`, `root_cause`, `resolution`, `remarks`, `started_at`, `completed_at`, `created_at`) VALUES
(1, 1, 5, 'printer solution', 'networking the printers', 'printer pool not running', 'test', '', '2026-09-26 12:30:09', '2026-09-26 12:31:08', '2026-09-26 12:31:08'),
(2, 2, 5, 'test', 'test', 'test', 'test', '', '2026-09-26 16:15:01', '2026-09-26 16:15:25', '2026-09-26 16:15:25');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(50) DEFAULT NULL,
  `full_name` varchar(150) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('ADMIN','TEAM_LEADER','EMPLOYEE','ICT_STAFF') NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  `team_leader_id` int(11) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL,
  `must_change_password` tinyint(1) DEFAULT 0,
  `failed_login_attempts` int(11) DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE','SUSPENDED') DEFAULT 'ACTIVE',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `employee_id`, `full_name`, `username`, `email`, `phone`, `password_hash`, `role`, `department_id`, `team_leader_id`, `position`, `must_change_password`, `failed_login_attempts`, `locked_until`, `last_login`, `status`, `created_at`, `updated_at`) VALUES
(1, 'ADMIN001', 'System Administrator', 'admin', 'admin@epss-adama.gov.et', NULL, '$2y$10$hVfdPxCGO4z/rAdsUKVBw.Jca/PLwCAcxYt7R2gj8OIqmRI0Uf5P.', 'ADMIN', NULL, NULL, 'System Administrator', 0, 0, NULL, '2026-09-28 08:46:23', 'ACTIVE', '2026-09-26 10:36:20', '2026-09-28 08:46:23'),
(2, '1000', 'Alemneh Nigussie', 'AlemnehN', NULL, NULL, '$2y$10$E7yQo/5FUujsLQTVikfUPuyrptLBlozInuCzzQQRTCu5sX9FffHaq', 'TEAM_LEADER', 1, NULL, 'Finance Admin Team Leader', 0, 0, NULL, '2026-09-28 08:49:09', 'ACTIVE', '2026-09-26 11:17:58', '2026-09-28 08:49:09'),
(4, '100011', 'Zemene Feleke', 'ZemenF', NULL, NULL, '$2y$10$5DWKeimpB5YVOCmJ7vQ56uWj8x8GzcMDkFJidFNNimF.fvcb/nv/K', 'EMPLOYEE', 1, 2, NULL, 0, 0, NULL, '2026-09-28 08:47:30', 'ACTIVE', '2026-09-26 11:23:04', '2026-09-28 08:47:30'),
(5, '100012', 'Abebayehu Meseret', 'AbMessi', NULL, NULL, '$2y$10$FYiVVu.oJ9U0yhCPh94XleUpKSMRpQS4Th1JcPaEziAuk/bo7ZjA6', 'ICT_STAFF', 7, NULL, NULL, 0, 0, NULL, '2026-09-26 16:14:41', 'ACTIVE', '2026-09-26 12:19:29', '2026-09-26 16:14:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_audit_user` (`user_id`),
  ADD KEY `idx_audit_created` (`created_at`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chat_conversations`
--
ALTER TABLE `chat_conversations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ticket_id` (`ticket_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `idx_conv_status` (`status`),
  ADD KEY `idx_conv_last` (`last_message_at`);

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `attachment_id` (`attachment_id`),
  ADD KEY `idx_msg_conv` (`conversation_id`,`created_at`);

--
-- Indexes for table `chat_participants`
--
ALTER TABLE `chat_participants`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_conv_user` (`conversation_id`,`user_id`),
  ADD KEY `idx_part_user` (`user_id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `department_code` (`department_code`);

--
-- Indexes for table `kpis`
--
ALTER TABLE `kpis`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ticket_id` (`ticket_id`),
  ADD KEY `idx_notif_user` (`user_id`,`is_read`);

--
-- Indexes for table `priorities`
--
ALTER TABLE `priorities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sla_pauses`
--
ALTER TABLE `sla_pauses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ticket_id` (`ticket_id`);

--
-- Indexes for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_subcat_cat` (`category_id`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`setting_key`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ticket_number` (`ticket_number`),
  ADD KEY `fk_tickets_subcat` (`subcategory_id`),
  ADD KEY `fk_tickets_tech` (`assigned_technician_id`),
  ADD KEY `idx_tickets_number` (`ticket_number`),
  ADD KEY `idx_tickets_status` (`status`),
  ADD KEY `idx_tickets_created` (`created_at`),
  ADD KEY `idx_tickets_dept` (`department_id`),
  ADD KEY `idx_tickets_tl` (`team_leader_id`),
  ADD KEY `idx_tickets_requester` (`requester_id`),
  ADD KEY `idx_tickets_cat` (`category_id`),
  ADD KEY `idx_tickets_priority` (`priority_id`);

--
-- Indexes for table `ticket_attachments`
--
ALTER TABLE `ticket_attachments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uploaded_by` (`uploaded_by`),
  ADD KEY `idx_attach_ticket` (`ticket_id`);

--
-- Indexes for table `ticket_comments`
--
ALTER TABLE `ticket_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_comments_ticket` (`ticket_id`);

--
-- Indexes for table `ticket_history`
--
ALTER TABLE `ticket_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_history_ticket` (`ticket_id`);

--
-- Indexes for table `ticket_work_logs`
--
ALTER TABLE `ticket_work_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `technician_id` (`technician_id`),
  ADD KEY `idx_worklog_ticket` (`ticket_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `employee_id` (`employee_id`),
  ADD KEY `idx_users_role` (`role`),
  ADD KEY `idx_users_dept` (`department_id`),
  ADD KEY `idx_users_tl` (`team_leader_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=119;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `chat_conversations`
--
ALTER TABLE `chat_conversations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `chat_messages`
--
ALTER TABLE `chat_messages`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chat_participants`
--
ALTER TABLE `chat_participants`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `kpis`
--
ALTER TABLE `kpis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `priorities`
--
ALTER TABLE `priorities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sla_pauses`
--
ALTER TABLE `sla_pauses`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subcategories`
--
ALTER TABLE `subcategories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ticket_attachments`
--
ALTER TABLE `ticket_attachments`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ticket_comments`
--
ALTER TABLE `ticket_comments`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ticket_history`
--
ALTER TABLE `ticket_history`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `ticket_work_logs`
--
ALTER TABLE `ticket_work_logs`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chat_conversations`
--
ALTER TABLE `chat_conversations`
  ADD CONSTRAINT `chat_conversations_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `chat_conversations_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD CONSTRAINT `chat_messages_ibfk_1` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_messages_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `chat_messages_ibfk_3` FOREIGN KEY (`attachment_id`) REFERENCES `ticket_attachments` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `chat_participants`
--
ALTER TABLE `chat_participants`
  ADD CONSTRAINT `chat_participants_ibfk_1` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_participants_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `kpis`
--
ALTER TABLE `kpis`
  ADD CONSTRAINT `kpis_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sla_pauses`
--
ALTER TABLE `sla_pauses`
  ADD CONSTRAINT `sla_pauses_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD CONSTRAINT `subcategories_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `fk_tickets_cat` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `fk_tickets_dept` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  ADD CONSTRAINT `fk_tickets_priority` FOREIGN KEY (`priority_id`) REFERENCES `priorities` (`id`),
  ADD CONSTRAINT `fk_tickets_requester` FOREIGN KEY (`requester_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_tickets_subcat` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategories` (`id`),
  ADD CONSTRAINT `fk_tickets_tech` FOREIGN KEY (`assigned_technician_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_tickets_tl` FOREIGN KEY (`team_leader_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `ticket_attachments`
--
ALTER TABLE `ticket_attachments`
  ADD CONSTRAINT `ticket_attachments_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ticket_attachments_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `ticket_comments`
--
ALTER TABLE `ticket_comments`
  ADD CONSTRAINT `ticket_comments_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ticket_comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `ticket_history`
--
ALTER TABLE `ticket_history`
  ADD CONSTRAINT `ticket_history_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ticket_history_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `ticket_work_logs`
--
ALTER TABLE `ticket_work_logs`
  ADD CONSTRAINT `ticket_work_logs_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ticket_work_logs_ibfk_2` FOREIGN KEY (`technician_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  ADD CONSTRAINT `fk_users_teamleader` FOREIGN KEY (`team_leader_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
