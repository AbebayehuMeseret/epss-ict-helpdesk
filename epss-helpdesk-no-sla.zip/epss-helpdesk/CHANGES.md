# Changes in this update

## Fixed (crashes)
- `includes/functions.php` had lost `is_waiting_status()`, `waiting_meta()` and `is_overdue()`. Team Leader > Team Tickets,
  Admin > All Tickets, Admin/Team/Reports pages called them and died with "undefined function". Restored.
- `ticket_view` hold action queried a non-existent column (`to_status`) when a ticket was already on hold. Fixed.
- Employee "respond" could be posted by hand on ANY ticket (even CLOSED) and push it back to pending approval. Now guarded.

## Workflow (accept -> resolve -> requester confirms)
- New `includes/workflow.php`: accept / hold / resume / assign / resolve enforced on the server (row-locked, one transaction).
- ICT must ACCEPT before holding or resolving; only the holder can resolve; resolution note required.
- Requester + Team Leader are notified when ICT accepts (in-app, Telegram to requester).
- Requester's reply to "Waiting for information" resumes the ticket automatically.
- Accept button now also works for ASSIGNED_TO_ICT and RETURNED_TO_ICT; "Resume Work" added.
- Five-step progress bar on the ICT, requester and Team Leader ticket pages.

## Error codes
- New `includes/errors.php` (registry, `AppError`, `app_fail()`, logging to `logs/app_errors.log`).
- New page Admin > Error Codes (`admin/error_codes.php`).
- All `die('...')`, raw `$e->getMessage()` (SQL leak), silent CSRF failures and hand-made 403 pages now use coded errors.

No database migration is required.
