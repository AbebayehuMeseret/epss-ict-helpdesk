<?php
declare(strict_types=1);
/**
 * Telegram notifications for the EPSS Helpdesk.
 * Same pattern as whatsapp.php: log -> send immediately -> keep FAILED rows
 * so they can be retried. Never throws; a Telegram outage must not break a ticket.
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';   // awaiting_confirmation_sql_in() and friends

function tg_setting(string $key, string $default = ''): string {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            foreach (db()->query("SELECT setting_key, setting_value FROM system_settings WHERE setting_key LIKE 'tg\\_%'")->fetchAll() as $r) {
                $cache[$r['setting_key']] = (string)$r['setting_value'];
            }
        } catch (Throwable $e) { /* table missing -> disabled */ }
    }
    return $cache[$key] ?? $default;
}

function tg_esc(?string $s): string {          // Telegram HTML parse mode
    return htmlspecialchars((string)$s, ENT_NOQUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Low-level Bot API call. */
function tg_api(string $method, array $params, int $timeout = 8): array {
    $token = tg_setting('tg_bot_token');
    if ($token === '' || str_starts_with($token, 'PUT-')) return ['ok' => false, 'error' => 'Bot token not set'];
    $ch = curl_init("https://api.telegram.org/bot{$token}/{$method}");
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($params, JSON_UNESCAPED_UNICODE),
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_CONNECTTIMEOUT => 4,
    ]);
    $resp = curl_exec($ch);
    $err  = curl_error($ch);
    curl_close($ch);
    if ($resp === false) return ['ok' => false, 'error' => 'Network: ' . $err];
    $json = json_decode($resp, true) ?: [];
    return ['ok' => (bool)($json['ok'] ?? false), 'response' => $resp,
            'error' => ($json['ok'] ?? false) ? null : ($json['description'] ?? 'Telegram error')];
}

function send_telegram_now(int $chatId, string $html, array $extra = []): array {
    if (tg_setting('tg_enabled', '0') !== '1') return ['ok' => false, 'error' => 'Telegram disabled'];
    return tg_api('sendMessage', array_merge([
        'chat_id' => $chatId, 'text' => mb_substr($html, 0, 4000),
        'parse_mode' => 'HTML', 'disable_web_page_preview' => true,
    ], $extra));
}

/** Send to one user (if they linked Telegram) and log the result. */
function telegram_notify_user(int $userId, string $html, ?int $ticketId = null, array $extra = []): bool {
    try {
        $pdo = db();
        $st = $pdo->prepare("SELECT telegram_chat_id FROM users WHERE id=? AND status='ACTIVE'");
        $st->execute([$userId]);
        $chat = (int)($st->fetchColumn() ?: 0);
        if (!$chat) return false;                       // user has not linked Telegram

        $res = send_telegram_now($chat, $html, $extra);
        $pdo->prepare("INSERT INTO telegram_log (user_id, chat_id, ticket_id, message, status, response, sent_at)
                       VALUES (?,?,?,?,?,?, IF(?='SENT', NOW(), NULL))")
            ->execute([$userId, $chat, $ticketId, mb_substr($html, 0, 4000),
                       $res['ok'] ? 'SENT' : 'FAILED',
                       mb_substr((string)($res['error'] ?? $res['response'] ?? ''), 0, 2000),
                       $res['ok'] ? 'SENT' : 'FAILED']);
        return $res['ok'];
    } catch (Throwable $e) {
        error_log('telegram_notify_user: ' . $e->getMessage());
        return false;
    }
}

/** Notify every active ICT technician who linked Telegram. */
function telegram_notify_ict(string $html, ?int $ticketId = null): int {
    $n = 0;
    try {
        foreach (db()->query("SELECT id FROM users WHERE role='ICT_STAFF' AND status='ACTIVE' AND telegram_chat_id IS NOT NULL")->fetchAll() as $r) {
            if (telegram_notify_user((int)$r['id'], $html, $ticketId)) $n++;
        }
    } catch (Throwable $e) { error_log('telegram_notify_ict: ' . $e->getMessage()); }
    return $n;
}

/** Re-send FAILED rows (call from cron or an admin button). */
function dispatch_telegram_failed(int $limit = 50): array {
    $pdo = db(); $sent = 0; $failed = 0;
    $rows = $pdo->query("SELECT * FROM telegram_log WHERE status='FAILED' ORDER BY id LIMIT " . (int)$limit)->fetchAll();
    foreach ($rows as $r) {
        $res = send_telegram_now((int)$r['chat_id'], $r['message']);
        $pdo->prepare("UPDATE telegram_log SET status=?, response=?, sent_at=IF(?, NOW(), NULL) WHERE id=?")
            ->execute([$res['ok'] ? 'SENT' : 'FAILED', mb_substr((string)($res['error'] ?? ''), 0, 2000), $res['ok'] ? 1 : 0, $r['id']]);
        $res['ok'] ? $sent++ : $failed++;
    }
    return ['sent' => $sent, 'failed' => $failed];
}

/* ---------- Message templates ---------- */

function tg_msg_new_ticket(array $t, string $requester, string $priority): string {
    return "🆕 <b>New ticket awaiting your approval</b>\n\n"
         . "Ticket: <b>" . tg_esc($t['ticket_number']) . "</b>\n"
         . "Subject: " . tg_esc($t['subject']) . "\n"
         . "From: " . tg_esc($requester) . "\n"
         . "Priority: " . tg_esc($priority) . "\n\n"
         . "Open <i>Pending Approvals</i> in the helpdesk to approve, reject or request clarification.";
}

/** ICT is informed at request stage: someone asked for support, Team Leader has not approved yet. */
function tg_msg_new_ticket_ict(array $t, string $requester, string $priority): string {
    return "🆕 <b>New ICT support request</b>\n\n"
         . "Ticket: <b>" . tg_esc($t['ticket_number']) . "</b>\n"
         . "Subject: " . tg_esc($t['subject']) . "\n"
         . "From: " . tg_esc($requester) . "\n"
         . ($priority !== '' ? "Priority: " . tg_esc($priority) . "\n" : '')
         . "\n⏳ Waiting for Team Leader approval. You will be notified when it is ready for ICT.";
}

function tg_msg_approved(array $t, string $approver, string $requester, ?string $comment = null): string {
    return "✅ <b>Ticket approved — ready for ICT</b>\n\n"
         . "Ticket: <b>" . tg_esc($t['ticket_number']) . "</b>\n"
         . "Subject: " . tg_esc($t['subject']) . "\n"
         . "Requester: " . tg_esc($requester) . "\n"
         . "Approved by: " . tg_esc($approver) . "\n"
         . ($comment ? "Comment: " . tg_esc($comment) . "\n" : '')
         . "\nPlease pick it up from your ICT dashboard.";
}

/** The requester is told ICT accepted the ticket and started work. */
function tg_msg_accepted(array $t, string $technician): string {
    return "🛠 <b>ICT accepted your request</b>\n\n"
         . "Ticket: <b>" . tg_esc($t['ticket_number']) . "</b>\n"
         . "Subject: " . tg_esc($t['subject']) . "\n"
         . "Technician: " . tg_esc($technician) . "\n\n"
         . "Work has started. You will be asked to confirm once it is resolved.";
}

/** ICT needs something from the requester; the ticket is on hold until they answer. */
function tg_msg_info_requested(array $t, string $technician, string $reason): string {
    return "❓ <b>ICT needs more information</b>\n\n"
         . "Ticket: <b>" . tg_esc($t['ticket_number']) . "</b>\n"
         . "Subject: " . tg_esc($t['subject']) . "\n"
         . "Technician: " . tg_esc($technician) . "\n"
         . ($reason !== '' ? "Needed: " . tg_esc($reason) . "\n" : '')
         . "\nOpen the ticket and add a comment with the details - ICT will continue as soon as you reply.";
}


function tg_msg_resolved(array $t, string $technician, ?string $workDone = null, int $minutes = 30): string {
    return "🔔 <b>Please confirm your fix</b>\n\n"
         . "Ticket: <b>" . tg_esc($t['ticket_number']) . "</b>\n"
         . "Subject: " . tg_esc($t['subject']) . "\n"
         . "Technician: " . tg_esc($technician) . "\n"
         . ($workDone ? "Work done: " . tg_esc($workDone) . "\n" : '')
         . "\nUse the buttons below, or open the helpdesk and choose "
         . "<b>Confirm &amp; Close Ticket</b> if the problem is fixed.\n"
         . "If it is still not working, press <b>Not Resolved</b> so ICT can continue.\n\n"
         . "⏱ <b>Please answer within {$minutes} minutes</b> — after that the ticket closes "
         . "automatically as confirmed.";
}

/** Buttons under the "please confirm" message. Only the requester's own copy works. */
function tg_confirm_keyboard(int $ticketId): array {
    return ['inline_keyboard' => [
        [['text' => '✅ Confirm & Close', 'callback_data' => 'cfm:' . $ticketId]],
        [['text' => '↩️ Not Resolved',    'callback_data' => 'rjk:' . $ticketId]],
    ]];
}

/** The requester pressed "Not Resolved" — ask which problem it is. */
function tg_reject_reasons(): array {
    return [
        'broken' => 'Still not working',
        'back'   => 'Problem came back',
        'partly' => 'Only partly fixed',
        'other'  => 'Something else is wrong',
    ];
}

function tg_reject_keyboard(int $ticketId): array {
    $rows = [];
    $pair = [];
    foreach (tg_reject_reasons() as $key => $label) {
        $pair[] = ['text' => $label, 'callback_data' => "rrj:{$ticketId}:{$key}"];
        if (count($pair) === 2) { $rows[] = $pair; $pair = []; }
    }
    if ($pair) $rows[] = $pair;
    $rows[] = [['text' => '✖️ Cancel', 'callback_data' => 'cxl:' . $ticketId]];
    return ['inline_keyboard' => $rows];
}

/** ICT is told the requester confirmed the fix in the helpdesk or in the bot. */
function tg_msg_confirmed(array $t, string $requester, string $via = 'web'): string {
    return "✅ <b>Requester confirmed the fix</b>\n\n"
         . "Ticket: <b>" . tg_esc($t['ticket_number']) . "</b>\n"
         . "Subject: " . tg_esc($t['subject']) . "\n"
         . "Requester: " . tg_esc($requester) . "\n\n"
         . "Confirmed " . ($via === 'telegram' ? 'from Telegram' : 'in the helpdesk')
         . ". The ticket is closed.";
}

/** ICT technician is told the requester says it is still broken (ticket returned). */
function tg_msg_reopened(array $t, string $requester, string $reason): string {
    return "⚠️ <b>Requester says it is NOT fixed</b>\n\n"
         . "Ticket: <b>" . tg_esc($t['ticket_number']) . "</b>\n"
         . "Subject: " . tg_esc($t['subject']) . "\n"
         . "Requester: " . tg_esc($requester) . "\n"
         . "Reason: " . tg_esc($reason) . "\n\n"
         . "The ticket is back with ICT (<i>Returned to ICT</i>). Please reopen the work and "
         . "resolve it again.";
}

/** Ticket closed because the requester never confirmed. $audience = requester|technician|teamleader. */
function tg_msg_auto_closed(array $t, string $requester, int $minutes, string $audience = 'requester'): string {
    $head = match ($audience) {
        'technician' => "✅ <b>Ticket closed automatically</b>",
        'teamleader' => "ℹ️ <b>Ticket closed automatically</b>",
        default      => "✔️ <b>Your ticket was closed automatically</b>",
    };

    $tail = match ($audience) {
        'technician' => "No requester confirmation arrived within {$minutes} minutes, so it was closed as confirmed. "
                      . "If they reopen the issue, a new ticket will reach you.",
        'teamleader' => "{$requester} did not confirm the fix within {$minutes} minutes, so the ticket was closed "
                      . "on their behalf.",
        default      => "You did not confirm the fix within {$minutes} minutes, so the ticket was closed "
                      . "automatically. If the problem comes back, create a new ticket or contact ICT.",
    };

    return $head . "\n\n"
         . "Ticket: <b>" . tg_esc($t['ticket_number']) . "</b>\n"
         . "Subject: " . tg_esc($t['subject']) . "\n"
         . "Requester: " . tg_esc($requester) . "\n\n"
         . $tail;
}


function tg_msg_bypassed(array $t, string $requester, int $minutes): string {
    return "⏭️ <b>Ticket forwarded to ICT</b>\n\n"
         . "Ticket: <b>" . tg_esc($t['ticket_number']) . "</b>\n"
         . "Subject: " . tg_esc($t['subject']) . "\n"
         . "Requester: " . tg_esc($requester) . "\n\n"
         . "You did not respond within {$minutes} minutes, so this ticket was approved for your team "
         . "automatically and sent to ICT. Open <i>Team Tickets</i> to follow its progress.";
}


/* ---------- Phone matching + settings helpers (used by webhook & admin page) ---------- */

/** Compare phones by their last 9 digits so 0911.., +251911.. and 251911.. all match. */
function tg_phone_key(?string $phone): string {
    $d = preg_replace('/\D+/', '', (string)$phone);
    return strlen($d) >= 9 ? substr($d, -9) : '';
}

/** Active users whose profile phone matches the one Telegram gave us. */
function tg_find_users_by_phone(string $phone): array {
    $key = tg_phone_key($phone);
    if ($key === '') return [];
    $out = [];
    $rows = db()->query("SELECT id, full_name, role, phone FROM users
                         WHERE status='ACTIVE' AND phone IS NOT NULL AND phone<>''")->fetchAll();
    foreach ($rows as $r) if (tg_phone_key($r['phone']) === $key) $out[] = $r;
    return $out;
}

function tg_save_setting(string $key, string $value): void {
    db()->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES (?,?)
                   ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)")->execute([$key, $value]);
}


/* ---------- Bot directories & lists (used by the incoming-message handlers) ---------- */

/** Active user linked to a Telegram chat, or null. */
function tg_bot_user(int $chatId): ?array {
    static $cache = [];
    if (array_key_exists($chatId, $cache)) return $cache[$chatId];
    $st = db()->prepare("SELECT u.id, u.full_name, u.role, u.department_id, u.team_leader_id,
                                d.department_name
                         FROM users u LEFT JOIN departments d ON d.id = u.department_id
                         WHERE u.telegram_chat_id = ? AND u.status = 'ACTIVE'");
    $st->execute([$chatId]);
    return $cache[$chatId] = ($st->fetch() ?: null);
}

function tg_role_label(string $role): string {
    return match ($role) {
        'ADMIN'          => 'Administrator',
        'TEAM_LEADER'    => 'Team Leader',
        'BRANCH_MANAGER' => 'Branch Manager',
        'ICT_STAFF'      => 'ICT Staff',
        default          => 'Employee',
    };
}

/** Emoji + short label for a ticket status. */
function tg_status_meta(string $status): array {
    return match ($status) {
        'PENDING_TEAM_LEADER_APPROVAL', 'PENDING_TL_APPROVAL' => ['⏳', 'Pending approval'],
        'APPROVED_FOR_ICT'          => ['✅', 'Approved, waiting ICT'],
        'ASSIGNED_TO_ICT'           => ['🧰', 'Assigned to ICT'],
        'IN_PROGRESS'               => ['🔧', 'In progress'],
        'WAITING_FOR_INFORMATION'   => ['❓', 'Waiting for info'],
        'WAITING_FOR_PARTS'         => ['📦', 'Waiting for parts'],
        'RETURNED_TO_ICT'           => ['↩️', 'Returned to ICT'],
        'RETURNED_TO_EMPLOYEE'      => ['↩️', 'Returned for info'],
        'RESOLVED_PENDING_REQUESTER_CONFIRMATION',
        'RESOLVED_PENDING_TEAM_LEADER_VERIFICATION' => ['🔔', 'Awaiting confirmation'],
        'CLOSED'                    => ['✔️', 'Closed'],
        'REJECTED'                  => ['❌', 'Rejected'],
        'CANCELLED'                 => ['🚫', 'Cancelled'],
        default                     => ['•', ucwords(strtolower(str_replace('_', ' ', $status)))],
    };
}

function tg_ago(?string $dt): string {
    if (!$dt) return '';
    $ts = strtotime($dt);
    if ($ts === false) return '';
    $d = time() - $ts;
    if ($d < 60)     return 'just now';
    if ($d < 3600)   return intdiv($d, 60) . 'm ago';
    if ($d < 86400)  return intdiv($d, 3600) . 'h ago';
    if ($d < 2592000) return intdiv($d, 86400) . 'd ago';
    return date('d M Y', $ts);
}

/** One ticket line-block for a list message. */
function tg_ticket_block(int $i, array $t, bool $withRequester = false, bool $withDept = false): string {
    [$icon, $label] = tg_status_meta((string)$t['status']);
    $out = ['<b>' . $i . '.</b> <code>' . tg_esc($t['ticket_number']) . '</code>',
            '    ' . tg_esc(mb_strimwidth((string)$t['subject'], 0, 70, '…'))];
    $meta = [$icon . ' ' . tg_esc($label)];
    if ($withRequester && !empty($t['requester_name'])) $meta[] = '👤 ' . tg_esc($t['requester_name']);
    if ($withDept && !empty($t['department_name']))     $meta[] = '🏢 ' . tg_esc($t['department_name']);
    if (!empty($t['category_name']))                    $meta[] = '🏷 ' . tg_esc($t['category_name']);
    $ago = tg_ago($t['created_at'] ?? null);
    if ($ago !== '') $meta[] = '⏱ ' . $ago;
    $out[] = '    ' . implode(' · ', $meta);
    return implode("\n", $out);
}

/** Build ready-to-send message chunks: header + blocks, each under Telegram's 4096 limit. */
function tg_make_chunks(string $header, array $blocks): array {
    if (!$blocks) return [$header . "\n\n<i>Nothing to show.</i>"];

    $chunks = []; $cur = '';
    foreach ($blocks as $b) {
        if ($cur !== '' && mb_strlen($cur . "\n\n" . $b) > 3200) { $chunks[] = $cur; $cur = ''; }
        $cur = $cur === '' ? $b : $cur . "\n\n" . $b;
    }
    if ($cur !== '') $chunks[] = $cur;

    $total = count($chunks);
    foreach ($chunks as $i => $c) {
        $chunks[$i] = $header . ($total > 1 ? "\n<i>Part " . ($i + 1) . " of {$total}</i>" : '') . "\n\n" . $c;
    }
    return $chunks;
}

/** Send chunks; the reply keyboard is attached to the first message only. */
function tg_send_chunks(int $chatId, array $chunks, array $extra = []): void {
    foreach ($chunks as $i => $c) tg_reply($chatId, $c, $i === 0 ? $extra : []);
}


/* ---------- Inline button presses (callback_query) ---------- */

/**
 * Replace a message in place. Passing no keyboard is how a used button is
 * retired, so a confirmation cannot be pressed twice from an old message.
 */
function tg_edit_message(int $chatId, int $messageId, string $text, ?array $keyboard = null): void {
    $params = ['chat_id' => $chatId, 'message_id' => $messageId,
               'text' => mb_substr($text, 0, 4000), 'parse_mode' => 'HTML'];
    if ($keyboard !== null) $params['reply_markup'] = $keyboard;
    tg_api('editMessageText', $params);
}

/** Telegram expects an answer to every callback, or the client spins for 30 s. */
function tg_answer_callback(string $callbackId, string $text = '', bool $showAlert = false): void {
    tg_api('answerCallbackQuery', ['callback_query_id' => $callbackId,
                                   'text' => mb_substr($text, 0, 190), 'show_alert' => $showAlert]);
}

/**
 * Confirm / Not Resolved buttons on the "please confirm your fix" message.
 *
 * The press carries only a ticket id, so everything that matters — is this chat
 * the linked requester, is the ticket actually awaiting confirmation — is read
 * back from the database instead of trusted from the callback data.
 */
function tg_handle_callback(array $cb): void {
    require_once __DIR__ . '/confirmation.php';

    $callbackId = (string)($cb['id'] ?? '');
    $chatId     = (int)($cb['message']['chat']['id'] ?? 0);
    $messageId  = (int)($cb['message']['message_id'] ?? 0);
    $baseText   = (string)($cb['message']['text'] ?? '');
    $parts      = explode(':', trim((string)($cb['data'] ?? '')));
    $op         = $parts[0] ?? '';
    $ticketId   = (int)($parts[1] ?? 0);

    $user = $chatId ? tg_bot_user($chatId) : null;
    if (!$user) {
        tg_answer_callback($callbackId, 'This chat is not connected to a helpdesk account. Send /start.', true);
        return;
    }

    /* A stale copy of the message (already answered, closed by the 30-minute rule,
       or someone else's ticket) must do nothing but explain itself. */
    $t = $ticketId ? ticket_awaiting_confirmation($ticketId, (int)$user['id']) : null;
    if (!$t && in_array($op, ['cfm', 'rjk', 'rrj'], true)) {
        tg_answer_callback($callbackId, 'This ticket is no longer awaiting your confirmation.', true);
        if ($baseText !== '') {
            tg_edit_message($chatId, $messageId, $baseText . "\n\n<i>⌛ These buttons have expired.</i>");
        }
        return;
    }

    switch ($op) {
        case 'cfm':
            $res = ticket_confirm_resolution($ticketId, (int)$user['id'], '', 'telegram');
            if (!$res['ok']) {
                tg_answer_callback($callbackId, (string)$res['error'], true);
                return;
            }
            tg_answer_callback($callbackId, 'Confirmed — the ticket is closed.');
            tg_edit_message($chatId, $messageId,
                $baseText . "\n\n✅ <b>Confirmed by you</b> — ticket closed.");
            return;

        case 'rjk':
            tg_answer_callback($callbackId, 'What is still wrong?');
            tg_edit_message($chatId, $messageId,
                $baseText . "\n\n↩️ <b>Not resolved — pick what still needs work:</b>",
                tg_reject_keyboard($ticketId));
            return;

        case 'rrj':
            $reasons = tg_reject_reasons();
            $reason  = $reasons[$parts[2] ?? ''] ?? null;
            if ($reason === null) {
                tg_answer_callback($callbackId, 'Unknown reason — please open the helpdesk.', true);
                return;
            }
            $res = ticket_reject_resolution($ticketId, (int)$user['id'], $reason, 'telegram');
            if (!$res['ok']) {
                tg_answer_callback($callbackId, (string)$res['error'], true);
                return;
            }
            tg_answer_callback($callbackId, 'Sent back to ICT.');
            tg_edit_message($chatId, $messageId,
                $baseText . "\n\n↩️ <b>Reported as not resolved</b> (" . tg_esc($reason)
                . ") — the ticket is back with ICT.");
            return;

        case 'cxl':
            tg_answer_callback($callbackId, 'No change made.');
            tg_edit_message($chatId, $messageId, $baseText, tg_confirm_keyboard($ticketId));
            return;
    }

    tg_answer_callback($callbackId, 'I did not understand that button.');
}

/* ---------- Incoming messages (shared by webhook AND polling) ---------- */

function tg_reply(int $chatId, string $text, array $extra = []): void {
    tg_api('sendMessage', array_merge(['chat_id' => $chatId, 'text' => $text, 'parse_mode' => 'HTML'], $extra));
}

function tg_link_user(int $userId, int $chatId): void {
    $pdo = db();
    $pdo->prepare("UPDATE users SET telegram_chat_id=NULL WHERE telegram_chat_id=?")->execute([$chatId]); // one chat <-> one user
    $pdo->prepare("UPDATE users SET telegram_chat_id=?, telegram_link_token=NULL WHERE id=?")->execute([$chatId, $userId]);
}

/* ---------- Role-aware menus ---------- */

function tg_menu_keyboard(string $role): array {
    $rows = match ($role) {
        'ADMIN' => [
            [['text' => '👥 Employees'], ['text' => '🎫 All Tickets']],
            [['text' => '⏳ Pending'],    ['text' => '📊 Counts']],
            [['text' => '👤 Connected Users'], ['text' => '❓ Help']],
        ],
        'TEAM_LEADER', 'BRANCH_MANAGER' => [
            [['text' => '⏳ Pending Approvals'], ['text' => '🎫 Team Tickets']],
            [['text' => '👥 Employees'],        ['text' => '📊 Counts']],
            [['text' => '❓ Help']],
        ],
        'ICT_STAFF' => [
            [['text' => '✅ Approved Queue'], ['text' => '🔧 Assigned to Me']],
            [['text' => '👥 Employees'],      ['text' => '📊 Counts']],
            [['text' => '❓ Help']],
        ],
        default => [
            [['text' => '🎫 My Tickets'], ['text' => '⏳ My Pending']],
            [['text' => '👥 Employees'],  ['text' => '📊 Counts']],
            [['text' => '❓ Help']],
        ],
    };
    return ['keyboard' => $rows, 'resize_keyboard' => true, 'is_persistent' => true];
}

function tg_menu_text(array $user): string {
    $isAdmin = (string)$user['role'] === 'ADMIN';
    return "👋 <b>" . tg_esc($user['full_name']) . "</b>\n"
         . '🏷 ' . tg_esc(tg_role_label((string)$user['role']))
         . (!empty($user['department_name']) ? ' · 🏢 ' . tg_esc($user['department_name']) : '')
         . "\n\n<b>Commands</b>\n"
         . "• 🎫 /tickets [open|closed|all] — ticket list for your role\n"
         . "• ⏳ /pending — tickets waiting on someone right now\n"
         . "• 👥 /employees [name or department] — staff directory\n"
         . ($isAdmin ? "• 👤 /users [name or chat id] — who is connected to this bot\n" : '')
         . "• 📊 /counts — how many tickets by status\n"
         . "• 🔎 /me — my helpdesk profile\n"
         . "• ❓ /help — this message\n"
         . "• 🔌 /stop — stop notifications";
}

/** Command list shown in Telegram's blue menu (setMyCommands). */
function tg_bot_commands(): array {
    return [
        ['command' => 'menu',      'description' => 'Open the main menu'],
        ['command' => 'tickets',   'description' => 'Ticket list (open | closed | all)'],
        ['command' => 'pending',   'description' => 'Tickets waiting for action'],
        ['command' => 'employees', 'description' => 'Employee / staff directory'],
        ['command' => 'users',     'description' => 'Who is connected to this bot (admin)'],
        ['command' => 'counts',    'description' => 'Number of tickets by status'],
        ['command' => 'me',        'description' => 'My helpdesk profile'],
        ['command' => 'help',      'description' => 'How to use this bot'],
        ['command' => 'stop',      'description' => 'Stop notifications'],
    ];
}

/* ---------- The lists themselves ---------- */

/** Tickets relevant to a role; $scope = open|closed|all. Returns message chunks. */
function tg_list_tickets(array $user, string $scope = 'open', ?int $onlyTechnician = null): array {
    $role = (string)$user['role'];
    $uid  = (int)$user['id'];
    $pdo  = db();

    $closedIn = "('CLOSED','REJECTED','CANCELLED')";
    $params   = [];
    $withReq  = false;
    $withDept = false;

    if ($role === 'EMPLOYEE') {
        $sql = "SELECT t.ticket_number,t.subject,t.status,t.created_at,c.category_name
                FROM tickets t LEFT JOIN categories c ON c.id = t.category_id
                WHERE t.requester_id = ?";
        $params[] = $uid;
        $header   = '🎫 <b>My tickets</b>';
    } elseif (in_array($role, ['TEAM_LEADER', 'BRANCH_MANAGER'], true)) {
        $sql = "SELECT t.ticket_number,t.subject,t.status,t.created_at,c.category_name,
                       req.full_name AS requester_name
                FROM tickets t LEFT JOIN categories c ON c.id = t.category_id
                JOIN users req ON req.id = t.requester_id
                WHERE (t.team_leader_id = ?";
        $params[] = $uid;
        if (empty($user['department_id'])) {
            $sql .= ')';                       // no department -> team only
        } else {
            $sql .= ' OR t.department_id = ?)';
            $params[] = (int)$user['department_id'];
        }
        $header   = '🎫 <b>My team\'s tickets</b>';
        $withReq  = true;
    } elseif ($role === 'ICT_STAFF') {
        $sql = "SELECT t.ticket_number,t.subject,t.status,t.created_at,c.category_name,
                       req.full_name AS requester_name, d.department_name
                FROM tickets t LEFT JOIN categories c ON c.id = t.category_id
                JOIN users req ON req.id = t.requester_id
                LEFT JOIN departments d ON d.id = t.department_id
                WHERE 1 = 1";
        $header   = $onlyTechnician
                    ? '🔧 <b>Assigned to me</b>'
                    : '✅ <b>ICT queue</b>';
        $withReq  = true;
        $withDept = true;
        if ($onlyTechnician) { $sql .= ' AND t.assigned_technician_id = ?'; $params[] = $uid; }
    } else { // ADMIN
        $sql = "SELECT t.ticket_number,t.subject,t.status,t.created_at,c.category_name,
                       req.full_name AS requester_name, d.department_name
                FROM tickets t LEFT JOIN categories c ON c.id = t.category_id
                JOIN users req ON req.id = t.requester_id
                LEFT JOIN departments d ON d.id = t.department_id
                WHERE 1 = 1";
        $header   = '🎫 <b>All tickets</b>';
        $withReq  = true;
        $withDept = true;
    }

    if ($scope === 'open') {
        $sql .= ($role === 'ICT_STAFF' && !$onlyTechnician)
            ? " AND t.status IN ('APPROVED_FOR_ICT','ASSIGNED_TO_ICT','IN_PROGRESS',
                                 'WAITING_FOR_INFORMATION','WAITING_FOR_PARTS','RETURNED_TO_ICT')"
            : " AND t.status NOT IN {$closedIn}";
    } elseif ($scope === 'closed') {
        $sql .= " AND t.status IN {$closedIn}";
    }
    $sql .= ' ORDER BY t.created_at DESC LIMIT 15';

    $st = $pdo->prepare($sql);
    $st->execute($params);
    $rows = $st->fetchAll();

    $label = $scope === 'open' ? 'open' : ($scope === 'closed' ? 'closed' : 'all');
    $header .= '  ·  ' . count($rows) . ' ' . $label . ' (latest 15)';

    $blocks = [];
    foreach ($rows as $i => $r) $blocks[] = tg_ticket_block($i + 1, $r, $withReq, $withDept);
    return tg_make_chunks($header, $blocks);
}

/** Tickets currently blocked on someone, per role. Returns message chunks. */
function tg_list_pending(array $user): array {
    $role = (string)$user['role'];
    $uid  = (int)$user['id'];
    $pdo  = db();

    $base = "SELECT t.ticket_number,t.subject,t.status,t.created_at,c.category_name,
                    req.full_name AS requester_name, d.department_name
             FROM tickets t LEFT JOIN categories c ON c.id = t.category_id
             JOIN users req ON req.id = t.requester_id
             LEFT JOIN departments d ON d.id = t.department_id
             WHERE ";

    if (in_array($role, ['TEAM_LEADER', 'BRANCH_MANAGER'], true)) {
        /* approvals to give + my own tickets that ICT resolved and I must confirm */
        $sql    = $base . "((t.status = 'PENDING_TEAM_LEADER_APPROVAL' AND t.team_leader_id = ?)
                         OR (t.status IN " . awaiting_confirmation_sql_in() . " AND t.requester_id = ?))
                           ORDER BY t.created_at LIMIT 20";
        $params = [$uid, $uid];
        $header = '⏳ <b>Waiting for your approval or confirmation</b>';
    } elseif ($role === 'ICT_STAFF') {
        $sql    = $base . "t.status = 'APPROVED_FOR_ICT'
                           ORDER BY t.created_at LIMIT 20";
        $params = [];
        $header = '✅ <b>Approved tickets waiting for ICT</b>';
    } elseif ($role === 'ADMIN') {
        $sql    = $base . "t.status IN ('PENDING_TEAM_LEADER_APPROVAL','APPROVED_FOR_ICT')
                           ORDER BY t.created_at LIMIT 20";
        $params = [];
        $header = '⏳ <b>Pending across the branch</b>';
    } else {
        $sql    = $base . "t.requester_id = ? AND t.status IN ('PENDING_TEAM_LEADER_APPROVAL','APPROVED_FOR_ICT')
                           ORDER BY t.created_at LIMIT 20";
        $params = [$uid];
        $header = '⏳ <b>My tickets waiting for approval</b>';
    }

    $st = $pdo->prepare($sql);
    $st->execute($params);
    $rows = $st->fetchAll();

    $header .= '  ·  ' . count($rows) . ' ticket(s)';
    $blocks = [];
    foreach ($rows as $i => $r) $blocks[] = tg_ticket_block($i + 1, $r, true, $role === 'ADMIN');
    return tg_make_chunks($header, $blocks);
}

/** Staff directory, scoped to what the role may see. Returns message chunks. */
function tg_list_employees(array $user, string $q = ''): array {
    $role  = (string)$user['role'];
    $sql   = "SELECT u.full_name, u.role, u.phone, u.position, d.department_name
              FROM users u LEFT JOIN departments d ON d.id = u.department_id
              WHERE u.status = 'ACTIVE'";
    $params = [];
    $scopeNote = 'the branch';

    if ($role === 'TEAM_LEADER') {
        $sql .= ' AND (u.team_leader_id = ?';
        $params[] = (int)$user['id'];
        if (!empty($user['department_id'])) { $sql .= ' OR u.department_id = ?'; $params[] = (int)$user['department_id']; }
        $sql .= ')';
        $scopeNote = 'my team';
    } elseif (!empty($user['department_id']) && $role !== 'ADMIN') {
        $sql .= ' AND u.department_id = ?';
        $params[] = (int)$user['department_id'];
        $scopeNote = 'my department';
    }

    $q = trim($q);
    if ($q !== '') {
        $sql .= ' AND (u.full_name LIKE ? OR d.department_name LIKE ? OR u.position LIKE ?)';
        $like = '%' . $q . '%';
        array_push($params, $like, $like, $like);
        $scopeNote .= ' · filter “' . $q . '”';
    }
    $sql .= ' ORDER BY d.department_name, u.full_name';

    $st = db()->prepare($sql);
    $st->execute($params);
    $rows = $st->fetchAll();

    $showPhone = in_array($role, ['ADMIN', 'TEAM_LEADER', 'BRANCH_MANAGER', 'ICT_STAFF'], true);
    $blocks = [];
    foreach ($rows as $i => $r) {
        $line = ['<b>' . ($i + 1) . '.</b> ' . tg_esc($r['full_name'])
                 . ' — <i>' . tg_esc(tg_role_label((string)$r['role'])) . '</i>'];
        $meta = [];
        if (!empty($r['department_name'])) $meta[] = '🏢 ' . tg_esc($r['department_name']);
        if (!empty($r['position']))        $meta[] = '💼 ' . tg_esc($r['position']);
        if ($showPhone && !empty($r['phone'])) $meta[] = '📱 ' . tg_esc($r['phone']);
        if ($meta) $line[] = '    ' . implode(' · ', $meta);
        $blocks[] = implode("\n", $line);
    }

    $header = '👥 <b>Employees</b> — ' . count($rows) . ' in ' . tg_esc($scopeNote);
    return tg_make_chunks($header, $blocks);
}

/**
 * Who is actually connected to the bot (users.telegram_chat_id is set), with the
 * last message we managed to send them and how many failed. Administrator only:
 * it exposes chat ids and delivery problems, which are debugging information.
 * Returns message chunks.
 */
function tg_list_connected(array $user, string $q = ''): array {
    if ((string)$user['role'] !== 'ADMIN') {
        return ['🔒 <b>Only the system administrator</b> can list the accounts connected to this bot.'];
    }

    $sql = "SELECT u.full_name, u.role, u.telegram_chat_id, u.status, d.department_name,
                   MAX(l.sent_at)     AS last_sent,
                   SUM(l.status='SENT')   AS sent_count,
                   SUM(l.status='FAILED') AS failed_count
            FROM users u
            LEFT JOIN departments d ON d.id = u.department_id
            LEFT JOIN telegram_log l ON l.user_id = u.id
            WHERE u.telegram_chat_id IS NOT NULL";
    $params = [];

    $q = trim($q);
    if ($q !== '') {
        $sql .= ' AND (u.full_name LIKE ? OR d.department_name LIKE ? OR CAST(u.telegram_chat_id AS CHAR) = ?)';
        $like = '%' . $q . '%';
        array_push($params, $like, $like, $q);
    }
    $sql .= ' GROUP BY u.id, u.full_name, u.role, u.telegram_chat_id, u.status, d.department_name
             ORDER BY last_sent DESC, u.full_name';

    $st = db()->prepare($sql);
    $st->execute($params);
    $rows = $st->fetchAll();

    if (!$rows) {
        return ['👤 <b>Connected Telegram users</b>' . "\n\n<i>Nobody has linked their account to this bot yet.</i>"];
    }

    $blocks = [];
    foreach ($rows as $i => $r) {
        $line = ['<b>' . ($i + 1) . '.</b> ' . tg_esc($r['full_name'])
                 . ' — <i>' . tg_esc(tg_role_label((string)$r['role'])) . '</i>'
                 . ((string)$r['status'] !== 'ACTIVE' ? ' · ⚠️ ' . tg_esc((string)$r['status']) : '')];
        $meta = [];
        $meta[] = !empty($r['department_name']) ? '🏢 ' . tg_esc($r['department_name']) : '🏢 no department';
        $meta[] = '🆔 <code>' . tg_esc((string)$r['telegram_chat_id']) . '</code>';
        $last   = !empty($r['last_sent']) ? tg_ago((string)$r['last_sent']) : 'never messaged';
        $meta[] = '📨 ' . $last;
        if ((int)$r['failed_count'] > 0) {
            $meta[] = '⚠️ ' . (int)$r['failed_count'] . ' failed';
        }
        $line[] = '    ' . implode(' · ', $meta);
        $blocks[] = implode("\n", $line);
    }

    $header = '👤 <b>Connected Telegram users</b> — ' . count($rows) . ' linked to @'
            . tg_esc(tg_setting('tg_bot_username', 'epssICTbot'));
    if ($q !== '') $header .= '  ·  filter “' . tg_esc($q) . '”';
    return tg_make_chunks($header, $blocks);
}

/** Quick numbers, role-dependent. Returns the message text. */
function tg_list_counts(array $user): string {
    $role = (string)$user['role'];
    $uid  = (int)$user['id'];
    $pdo  = db();
    $lines = [];

    $count = function (string $sql, array $p = []) use ($pdo): int {
        $st = $pdo->prepare($sql); $st->execute($p); return (int)$st->fetchColumn();
    };
    $statusRows = function (string $sql, array $p = []) use ($pdo): array {
        $st = $pdo->prepare($sql); $st->execute($p); return $st->fetchAll();
    };

    if ($role === 'EMPLOYEE') {
        $where  = 't.requester_id = ?';
        $params = [$uid];
        $header = '📊 <b>My ticket counts</b>';
    } elseif (in_array($role, ['TEAM_LEADER', 'BRANCH_MANAGER'], true)) {
        $where  = 't.team_leader_id = ?';
        $params = [$uid];
        $header = '📊 <b>My team\'s ticket counts</b>';
        $lines[] = '⏳ Awaiting my approval: <b>' . $count(
            "SELECT COUNT(*) FROM tickets t WHERE t.team_leader_id = ? AND t.status = 'PENDING_TEAM_LEADER_APPROVAL'", [$uid]) . '</b>';
    } elseif ($role === 'ICT_STAFF') {
        $where  = '1 = 1';
        $params = [];
        $header = '📊 <b>ICT ticket counts</b>';
        $lines[] = '✅ Approved, not picked up: <b>' . $count("SELECT COUNT(*) FROM tickets WHERE status = 'APPROVED_FOR_ICT'") . '</b>';
        $lines[] = '🔧 Assigned to me: <b>' . $count("SELECT COUNT(*) FROM tickets WHERE assigned_technician_id = ? AND status NOT IN ('CLOSED','REJECTED','CANCELLED')", [$uid]) . '</b>';
    } else {
        $where  = '1 = 1';
        $params = [];
        $header = '📊 <b>Branch ticket counts</b>';
    }

    $rows = $statusRows("SELECT t.status, COUNT(*) n FROM tickets t WHERE {$where} GROUP BY t.status", $params);
    $total = 0; $byStatus = [];
    foreach ($rows as $r) { $total += (int)$r['n']; $byStatus[$r['status']] = (int)$r['n']; }

    $lines[] = '🎫 Total tickets: <b>' . $total . '</b>';
    uksort($byStatus, fn($a, $b) => $byStatus[$b] <=> $byStatus[$a]);
    foreach ($byStatus as $s => $n) {
        [$icon, $label] = tg_status_meta((string)$s);
        $lines[] = $icon . ' ' . tg_esc($label) . ': <b>' . $n . '</b>';
    }

    return $header . "\n\n" . implode("\n", $lines);
}

/** Map a typed command or reply-keyboard button to [action, argument]. */
function tg_parse_text(string $text): array {
    $raw = trim($text);
    $low = mb_strtolower($raw);

    // Reply-keyboard buttons map to the same actions as the slash commands.
    $buttons = [
        '🎫 my tickets'      => 'mytickets',
        '⏳ my pending'      => 'mypending',
        '⏳ pending'         => 'pending',
        '⏳ pending approvals' => 'pending',
        '🎫 team tickets'    => 'teamtickets',
        '🎫 all tickets'     => 'teamtickets',
        '✅ approved queue'  => 'queue',
        '🔧 assigned to me'  => 'assigned',
        '👥 employees'       => 'employees',
        '👤 connected users' => 'users',
        '📊 counts'          => 'counts',
        '❓ help'            => 'help',
    ];

    if (isset($buttons[$low])) return [$buttons[$low], ''];

    $parts = preg_split('/\s+/', $raw, 2);
    $cmd   = mb_strtolower($parts[0] ?? '');
    $arg   = trim($parts[1] ?? '');

    $action = match ($cmd) {
        '/menu', '/start'        => 'menu',
        '/help', '/commands'     => 'help',
        '/tickets', '/ticket'    => 'tickets',
        '/pending'               => 'pending',
        '/employees', '/staff', '/directory' => 'employees',
        '/users', '/connected', '/linked'    => 'users',
        '/counts', '/stats'      => 'counts',
        '/me', '/profile'        => 'me',
        default                  => '',
    };
    return [$action, $arg];
}

/** Dispatcher for everything the bot accepts as text. */
function tg_dispatch_command(int $chatId, array $user, string $text): void {
    $role = (string)$user['role'];

    [$action, $arg] = tg_parse_text($text);

    switch ($action) {
        case 'menu':
        case 'help':
            tg_reply($chatId, tg_menu_text($user), ['reply_markup' => tg_menu_keyboard($role)]);
            return;
        case 'me':
            $lines = ['👤 <b>' . tg_esc($user['full_name']) . '</b>',
                      '🏷 ' . tg_esc(tg_role_label($role))];
            if (!empty($user['department_name'])) $lines[] = '🏢 ' . tg_esc($user['department_name']);
            $lines[] = '🔗 Telegram linked — notifications on. Send /stop to turn them off.';
            tg_reply($chatId, implode("\n", $lines), ['reply_markup' => tg_menu_keyboard($role)]);
            return;
        case 'mytickets':
            tg_send_chunks($chatId, tg_list_tickets($user, 'open'), ['reply_markup' => tg_menu_keyboard($role)]);
            return;
        case 'teamtickets':
            tg_send_chunks($chatId, tg_list_tickets($user, 'open'), ['reply_markup' => tg_menu_keyboard($role)]);
            return;
        case 'queue':
            tg_send_chunks($chatId, tg_list_tickets($user, 'open'), ['reply_markup' => tg_menu_keyboard($role)]);
            return;
        case 'assigned':
            tg_send_chunks($chatId, tg_list_tickets($user, 'open', (int)$user['id']), ['reply_markup' => tg_menu_keyboard($role)]);
            return;
        case 'mypending':
        case 'pending':
            tg_send_chunks($chatId, tg_list_pending($user), ['reply_markup' => tg_menu_keyboard($role)]);
            return;
        case 'employees':
            tg_send_chunks($chatId, tg_list_employees($user, $arg), ['reply_markup' => tg_menu_keyboard($role)]);
            return;
        case 'users':
            tg_send_chunks($chatId, tg_list_connected($user, $arg), ['reply_markup' => tg_menu_keyboard($role)]);
            return;
        case 'counts':
            tg_reply($chatId, tg_list_counts($user), ['reply_markup' => tg_menu_keyboard($role)]);
            return;
        case 'tickets':
            $scope = in_array(mb_strtolower($arg), ['all', 'closed', 'open'], true)
                     ? mb_strtolower($arg) : 'open';
            tg_send_chunks($chatId, tg_list_tickets($user, $scope), ['reply_markup' => tg_menu_keyboard($role)]);
            return;
    }

    tg_reply($chatId, "I did not understand that.\n\n" . tg_menu_text($user),
             ['reply_markup' => tg_menu_keyboard($role)]);
}

/**
 * Handle one Telegram update. Linking works by:
 *   1) phone: /start -> "Share my phone number" -> matched to the profile phone
 *   2) token: Profile page -> Connect Telegram -> t.me/<bot>?start=<token>
 */
function tg_handle_update(array $update): void {
    if (isset($update['callback_query'])) {           // inline button press
        tg_handle_callback($update['callback_query']);
        return;
    }

    $msg = $update['message'] ?? null;
    if (!$msg || ($msg['chat']['type'] ?? '') !== 'private') return;

    $chatId = (int)$msg['chat']['id'];
    $fromId = (int)($msg['from']['id'] ?? 0);
    $text   = trim((string)($msg['text'] ?? ''));
    $pdo    = db();
    $removeKb = ['reply_markup' => ['remove_keyboard' => true]];

    if (!empty($msg['contact'])) {
        $c = $msg['contact'];
        if ((int)($c['user_id'] ?? 0) !== $fromId) {          // must be the sender's own number
            tg_reply($chatId, '⚠️ Please use the button to share <b>your own</b> phone number.', $removeKb);
            return;
        }
        $matches = tg_find_users_by_phone((string)($c['phone_number'] ?? ''));
        if (count($matches) === 0) {
            tg_reply($chatId, "❌ This phone number is not registered in the helpdesk.\nAdd it on your <b>Profile</b> page (or ask the admin), then send /start again.", $removeKb);
        } elseif (count($matches) > 1) {
            tg_reply($chatId, "⚠️ This number is saved on more than one account. Please contact the administrator.", $removeKb);
        } else {
            tg_link_user((int)$matches[0]['id'], $chatId);
            $linked = tg_bot_user($chatId);
            tg_reply($chatId,
                "✅ Linked! Hello <b>" . tg_esc($matches[0]['full_name']) . "</b>, you will now receive helpdesk notifications here.\n\n"
                . ($linked ? tg_menu_text($linked) : ''),
                ['reply_markup' => tg_menu_keyboard((string)($linked['role'] ?? 'EMPLOYEE'))]);
        }
        return;
    }

    if (preg_match('/^\/start(?:\s+([A-Za-z0-9]{16,64}))?$/', $text, $m)) {
        $token = $m[1] ?? '';
        if ($token === '' && ($me = tg_bot_user($chatId))) {
            tg_reply($chatId,
                "Welcome back, <b>" . tg_esc($me['full_name']) . "</b>!\n\n" . tg_menu_text($me),
                ['reply_markup' => tg_menu_keyboard((string)$me['role'])]);
            return;
        }
        if ($token === '') {
            tg_reply($chatId,
                "Welcome to the <b>EPSS ICT Helpdesk</b> bot.\n\nTap the button below to share your phone number. It must match the phone saved on your helpdesk profile.",
                ['reply_markup' => [
                    'keyboard' => [[['text' => '📱 Share my phone number', 'request_contact' => true]]],
                    'resize_keyboard' => true, 'one_time_keyboard' => true,
                ]]);
            return;
        }
        $st = $pdo->prepare("SELECT id, full_name FROM users WHERE telegram_link_token=? AND status='ACTIVE'");
        $st->execute([$token]);
        $user = $st->fetch();
        if (!$user) { tg_reply($chatId, 'This link is invalid or already used. Generate a new one from your Profile page.'); return; }
        tg_link_user((int)$user['id'], $chatId);
        $linked = tg_bot_user($chatId);
        tg_reply($chatId,
            "✅ Linked! Hello <b>" . tg_esc($user['full_name']) . "</b>, you will now receive helpdesk notifications here.\n\n"
            . ($linked ? tg_menu_text($linked) : ''),
            ['reply_markup' => tg_menu_keyboard((string)($linked['role'] ?? 'EMPLOYEE'))]);
        return;
    }

    if ($text === '/stop') {
        $pdo->prepare("UPDATE users SET telegram_chat_id=NULL WHERE telegram_chat_id=?")->execute([$chatId]);
        tg_reply($chatId, 'Notifications turned off. Send /start to reconnect.', $removeKb);
        return;
    }

    $me = tg_bot_user($chatId);
    if (!$me) {
        tg_reply($chatId, "This chat is not connected to a helpdesk account yet.\n\nSend /start and tap “Share my phone number”, or open your Profile page and press <b>Connect Telegram</b>.");
        return;
    }

    tg_dispatch_command($chatId, $me, $text);
}

/* ---------- Polling (for servers with no public HTTPS address) ---------- */

/** Fetch new messages from Telegram and handle them. Returns how many updates were processed. */
function tg_poll_once(int $longPollSeconds = 0): int {
    $pdo = db();
    $st  = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key='tg_update_offset'");
    $st->execute();
    $offset = (int)($st->fetchColumn() ?: 0);

    $r = tg_api('getUpdates', ['offset' => $offset, 'timeout' => $longPollSeconds,
                               'allowed_updates' => ['message', 'callback_query']], $longPollSeconds + 10);
    if (!$r['ok']) throw new RuntimeException((string)$r['error']);

    $updates = json_decode((string)$r['response'], true)['result'] ?? [];
    foreach ($updates as $up) {
        try {
            tg_handle_update($up);
            tg_save_setting('tg_update_offset', (string)((int)$up['update_id'] + 1));
        } catch (Throwable $e) {
            // A dead connection (MySQL restart / idle timeout) must not stop the worker.
            error_log('tg_handle_update: ' . $e->getMessage());
            db(true);
            try { tg_save_setting('tg_update_offset', (string)((int)$up['update_id'] + 1)); } catch (Throwable $e2) { /* retry next loop */ }
        }
    }
    return count($updates);
}
