<?php
/**
 * Requester confirmation of an ICT resolution — the single place that flips a
 * resolved ticket to CLOSED (confirmed) or back to RETURNED_TO_ICT (rejected).
 *
 * Used by employee/ticket_view.php, teamleader/ticket_view.php,
 * teamleader/confirmations.php and the Telegram bot's inline buttons, so a
 * confirmation made in the bot produces exactly the same history, notifications
 * and audit trail as one made on the web page.
 *
 * A Team Leader who raised a ticket himself is its requester: he confirms his own
 * ticket here like anyone else, and is never notified twice about himself.
 */

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/errors.php';

if (!function_exists('confirmation_fail')) {
    /**
     * Failure result with a registered error code. 'error' carries the coded,
     * user-safe text ("[E-CNF-409] ..."), 'code' the bare code.
     */
    function confirmation_fail(string $code, string $detail = '', ?array $ticket = null): array
    {
        return ['ok' => false, 'error' => app_error_text($code, $detail), 'code' => $code, 'ticket' => $ticket];
    }
}

if (!function_exists('confirmation_from_exception')) {
    /** Unexpected failure while closing / returning a ticket: coded text, one log entry. */
    function confirmation_from_exception(Throwable $e, ?array $ticket = null): array
    {
        $info = app_exception_info($e);
        $text = '[' . $info['code'] . '] ' . $info['message'] . (!empty($info['ref']) ? ' (ref ' . $info['ref'] . ')' : '');
        return ['ok' => false, 'error' => $text, 'code' => $info['code'], 'ticket' => $ticket];
    }
}

if (!function_exists('confirmation_denied_code')) {
    /** Why can this user not confirm? Missing ticket, somebody else's ticket, or wrong status. */
    function confirmation_denied_code(int $ticketId, int $userId): string
    {
        try {
            $st = db()->prepare('SELECT requester_id FROM tickets WHERE id = ?');
            $st->execute([$ticketId]);
            $req = $st->fetchColumn();
            if ($req === false) {
                return 'E-TKT-404';
            }
            return (int)$req !== $userId ? 'E-CNF-403' : 'E-CNF-409';
        } catch (Throwable $e) {
            return 'E-CNF-409';
        }
    }
}

if (!function_exists('confirmation_technician_id')) {
    /**
     * Who did the work: the assigned technician, or — for tickets resolved before
     * the resolve step started recording it — the last technician with a work log.
     */
    function confirmation_technician_id(array $t): int
    {
        $techId = (int)($t['assigned_technician_id'] ?? 0);
        if ($techId) {
            return $techId;
        }

        try {
            $st = db()->prepare("SELECT technician_id FROM ticket_work_logs
                                 WHERE ticket_id = ? ORDER BY created_at DESC LIMIT 1");
            $st->execute([(int)$t['id']]);
            return (int)($st->fetchColumn() ?: 0);
        } catch (Throwable $e) {
            return 0;
        }
    }
}

if (!function_exists('ticket_awaiting_confirmation')) {
    /**
     * The ticket row when $userId is the requester and it awaits their confirmation,
     * or null when it does not apply.
     */
    function ticket_awaiting_confirmation(int $ticketId, int $userId): ?array
    {
        $st = db()->prepare("SELECT t.*, req.full_name AS requester_name, tech.full_name AS tech_name
                             FROM tickets t
                             JOIN users req ON req.id = t.requester_id
                             LEFT JOIN users tech ON tech.id = t.assigned_technician_id
                             WHERE t.id = ?");
        $st->execute([$ticketId]);
        $t = $st->fetch() ?: null;

        if (!$t || !in_array($t['status'], awaiting_confirmation_statuses(), true)) {
            return null;
        }
        return (int)$t['requester_id'] === $userId ? $t : null;
    }
}

if (!function_exists('ticket_confirm_resolution')) {
    /**
     * Close a resolved ticket because the requester confirmed the fix.
     *
     * @param string $via 'web' or 'telegram' — recorded in the audit description
     * @return array ['ok' => bool, 'error' => ?string, 'ticket' => ?array]
     */
    function ticket_confirm_resolution(int $ticketId, int $userId, string $comment = '', string $via = 'web'): array
    {
        $t = ticket_awaiting_confirmation($ticketId, $userId);
        if (!$t) {
            return confirmation_fail(confirmation_denied_code($ticketId, $userId));
        }

        $pdo = db();
        try {
            $pdo->beginTransaction();
            $now = date('Y-m-d H:i:s');

            /* Re-check the status in the UPDATE: a concurrent auto-close or a
               second press of the button must not produce a duplicate trail. */
            $st = $pdo->prepare("UPDATE tickets
                    SET status='CLOSED', closed_at=?, verification_comment=?
                    WHERE id=? AND status IN " . awaiting_confirmation_sql_in());
            $st->execute([$now, trim($comment), $ticketId]);
            if ($st->rowCount() !== 1) {
                $pdo->rollBack();
                return confirmation_fail('E-CNF-409', 'This ticket is no longer awaiting your confirmation.');
            }

            record_history($ticketId, $userId, (string)$t['status'], 'CLOSED',
                'Requester Confirmed - Ticket Closed', trim($comment) !== '' ? trim($comment) : null);

            $techId  = confirmation_technician_id($t);
            $tlId    = (int)($t['team_leader_id'] ?? 0);

            if ($techId && $techId !== $userId) {
                notify($techId, $ticketId, 'Ticket Closed',
                    "{$t['requester_name']} confirmed the fix on {$t['ticket_number']}. The ticket is closed.", 'success');
            }
            if ($tlId && $tlId !== $userId && $tlId !== $techId) {
                notify($tlId, $ticketId, 'Ticket Closed',
                    "{$t['requester_name']} confirmed the fix on {$t['ticket_number']}. The ticket is closed.", 'success');
            }

            audit('REQUESTER_CONFIRM', 'tickets', $ticketId,
                "Requester confirmed and closed {$t['ticket_number']} (via {$via})");
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            return confirmation_from_exception($e, $t);
        }

        try {
            require_once __DIR__ . '/telegram.php';
            if ($techId) {
                telegram_notify_user($techId, tg_msg_confirmed($t, (string)$t['requester_name'], $via), $ticketId);
            }
        } catch (Throwable $e) { error_log('TG confirm: ' . $e->getMessage()); }

        return ['ok' => true, 'error' => null, 'ticket' => $t];
    }
}

if (!function_exists('ticket_reject_resolution')) {
    /**
     * Send a resolved ticket back to ICT because the requester says it is not fixed.
     *
     * @return array ['ok' => bool, 'error' => ?string, 'ticket' => ?array]
     */
    function ticket_reject_resolution(int $ticketId, int $userId, string $reason, string $via = 'web'): array
    {
        $reason = trim($reason);
        if ($reason === '') {
            return confirmation_fail('E-CNF-422');
        }

        $t = ticket_awaiting_confirmation($ticketId, $userId);
        if (!$t) {
            return confirmation_fail(confirmation_denied_code($ticketId, $userId));
        }

        $pdo = db();
        try {
            $pdo->beginTransaction();

            $st = $pdo->prepare("UPDATE tickets SET status='RETURNED_TO_ICT'
                                 WHERE id=? AND status IN " . awaiting_confirmation_sql_in());
            $st->execute([$ticketId]);
            if ($st->rowCount() !== 1) {
                $pdo->rollBack();
                return confirmation_fail('E-CNF-409', 'This ticket is no longer awaiting your confirmation.');
            }

            record_history($ticketId, $userId, (string)$t['status'], 'RETURNED_TO_ICT',
                'Requester Reported Issue Not Resolved', $reason);

            $techId = confirmation_technician_id($t);
            $tlId   = (int)($t['team_leader_id'] ?? 0);

            if ($techId && $techId !== $userId) {
                notify($techId, $ticketId, 'Resolution Not Accepted',
                    "{$t['ticket_number']} was returned to ICT: {$reason}", 'warning');
            }
            if ($tlId && $tlId !== $userId && $tlId !== $techId) {
                notify($tlId, $ticketId, 'Resolution Not Accepted',
                    "{$t['requester_name']} reopened {$t['ticket_number']}: {$reason}", 'warning');
            }

            audit('REQUESTER_REJECT', 'tickets', $ticketId,
                "Requester returned {$t['ticket_number']} to ICT (via {$via}): {$reason}");
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            return confirmation_from_exception($e, $t);
        }

        try {
            require_once __DIR__ . '/telegram.php';
            if ($techId) {
                telegram_notify_user($techId, tg_msg_reopened($t, (string)$t['requester_name'], $reason), $ticketId);
            }
        } catch (Throwable $e) { error_log('TG reject: ' . $e->getMessage()); }

        return ['ok' => true, 'error' => null, 'ticket' => $t];
    }
}
