<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/escalation.php';
$u = require_login();

/* Forward tickets whose Team Leader did not respond in time (self-throttled) */
escalate_stale_approvals();

/* Close tickets whose requester did not confirm within the allowed time (self-throttled) */
escalate_stale_confirmations();

/* Unread notifications */
$unread = db()->prepare("SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0");
$unread->execute([$u['id']]);
$unreadCount = (int)$unread->fetchColumn();

/* Unread chat messages */
$chatUnread = 0;
try {
    $cs = db()->prepare("
        SELECT COUNT(*)
        FROM chat_messages m
        JOIN chat_participants cp
          ON cp.conversation_id = m.conversation_id
         AND cp.user_id = ?
        WHERE m.sender_id <> ?
          AND m.id > COALESCE(cp.last_read_at, 0)
    ");
    $cs->execute([$u['id'], $u['id']]);
    $chatUnread = (int)$cs->fetchColumn();
} catch (Throwable $e) { $chatUnread = 0; }

/* Role display label */
$roleLabel = [
    'ADMIN'          => 'Administrator',
    'BRANCH_MANAGER' => 'Branch Manager',
    'TEAM_LEADER'    => 'Team Leader',
    'ICT_STAFF'      => 'ICT Staff',
    'EMPLOYEE'       => 'Employee',
][$u['role']] ?? $u['role'];

/* User initial */
$initial = strtoupper(mb_substr($u['full_name'], 0, 1));

/* Home link per role */
$homeLink = [
    'ADMIN'          => BASE_URL . '/admin/dashboard.php',
    'BRANCH_MANAGER' => BASE_URL . '/teamleader/dashboard.php',
    'TEAM_LEADER'    => BASE_URL . '/teamleader/dashboard.php',
    'ICT_STAFF'      => BASE_URL . '/ict/dashboard.php',
    'EMPLOYEE'       => BASE_URL . '/employee/dashboard.php',
][$u['role']] ?? BASE_URL . '/public/index.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle ?? APP_NAME) ?> – <?= e(APP_NAME) ?></title>

<!-- Third-party CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.13.8/css/dataTables.bootstrap5.min.css" rel="stylesheet">

<!-- App CSS -->
<link href="<?= BASE_URL ?>/public/assets/css/style.css" rel="stylesheet">

<!-- SAP Fiori Horizon — Shell Bar -->
<style>
  :root {
    --sap-shellbar-bg:     #354a5f;
    --sap-shellbar-bg-2:   #354a5f;
    --sap-shellbar-text:   #ffffff;
    --sap-shellbar-muted:  #c8d4de;
    --sap-brand:           #0070f2;
    --sap-brand-dark:      #0057d2;
    --sap-border-soft:     #eaecf0;
    --sap-text:            #1d2d3e;
    --sap-text-muted:      #556b82;
    --sap-tile:            #ffffff;
    --sap-shellbar-h:      56px;
  }

  body {
    font-family: "72", "72full", Arial, Helvetica, sans-serif;
    -webkit-font-smoothing: antialiased;
  }

  /* ================= SAP Shell Bar ================= */
  .sap-shellbar {
    position: sticky;
    top: 0;
    z-index: 1040;
    height: var(--sap-shellbar-h);
    background: var(--sap-shellbar-bg);
    color: var(--sap-shellbar-text);
    display: flex;
    align-items: center;
    padding: 0 .6rem;
    gap: .25rem;
    box-shadow: 0 1px 3px rgba(34,53,72,.20);
  }

  .sap-shellbar-left {
    display: flex;
    align-items: center;
    gap: .25rem;
    flex-shrink: 0;
  }

  .sap-shell-icon-btn {
    display: inline-flex; align-items: center; justify-content: center;
    width: 38px; height: 38px;
    border-radius: .5rem;
    border: 0;
    background: transparent;
    color: var(--sap-shellbar-text);
    font-size: 1.1rem;
    cursor: pointer;
    transition: background .12s, color .12s;
    text-decoration: none;
    flex-shrink: 0;
  }
  .sap-shell-icon-btn:hover {
    background: rgba(255,255,255,.12);
    color: #fff;
  }
  .sap-shell-icon-btn:focus-visible {
    outline: 2px solid #fff; outline-offset: 2px;
  }

  .sap-shell-brand {
    display: flex;
    align-items: center;
    gap: .55rem;
    padding: .25rem .6rem;
    border-radius: .5rem;
    text-decoration: none;
    color: #fff;
    transition: background .12s;
    flex-shrink: 0;
  }
  .sap-shell-brand:hover { background: rgba(255,255,255,.10); color: #fff; }
  .sap-shell-brand img { height: 30px; width: auto; display: block; }
  .sap-shell-brand-text {
    display: flex; flex-direction: column; line-height: 1.1;
  }
  .sap-shell-brand-title {
    font-size: .8125rem; font-weight: 600; color: #fff;
    letter-spacing: .01em;
    white-space: nowrap;
  }
  .sap-shell-brand-sub {
    font-size: .65rem; color: var(--sap-shellbar-muted);
    text-transform: uppercase; letter-spacing: .06em;
    white-space: nowrap;
  }

  .sap-shellbar-search {
    flex: 1 1 auto;
    display: flex;
    justify-content: center;
    padding: 0 .5rem;
    max-width: 480px;
    margin: 0 auto;
  }
  .sap-shellbar-search-inner {
    position: relative;
    width: 100%;
  }
  .sap-shellbar-search-inner i {
    position: absolute;
    left: .7rem; top: 50%;
    transform: translateY(-50%);
    color: var(--sap-shellbar-muted);
    font-size: .85rem;
    pointer-events: none;
  }
  .sap-shellbar-search input {
    width: 100%;
    background: rgba(255,255,255,.12);
    border: 1px solid rgba(255,255,255,.10);
    color: #fff;
    border-radius: 1rem;
    padding: .42rem .85rem .42rem 2rem;
    font-size: .8125rem;
    transition: background .15s, border-color .15s, box-shadow .15s;
  }
  .sap-shellbar-search input::placeholder { color: var(--sap-shellbar-muted); }
  .sap-shellbar-search input:focus {
    outline: none;
    background: rgba(255,255,255,.20);
    border-color: #fff;
    box-shadow: 0 0 0 2px rgba(255,255,255,.25);
  }
  @media (max-width: 767px) { .sap-shellbar-search { display: none; } }

  .sap-shellbar-right {
    display: flex;
    align-items: center;
    gap: .15rem;
    margin-left: auto;
    flex-shrink: 0;
  }

  .sap-shell-notif { position: relative; }
  .sap-shell-notif .badge {
    position: absolute;
    top: 4px; right: 4px;
    background: #d12121;
    color: #fff;
    font-size: .62rem;
    font-weight: 700;
    padding: .12rem .35rem;
    border-radius: .75rem;
    min-width: 18px;
    text-align: center;
    line-height: 1;
    border: 2px solid var(--sap-shellbar-bg);
    transform: translate(35%, -25%);
  }

  .sap-shell-profile {
    display: inline-flex;
    align-items: center;
    gap: .55rem;
    padding: .25rem .5rem .25rem .25rem;
    border-radius: .5rem;
    background: transparent;
    border: 0;
    color: #fff;
    cursor: pointer;
    transition: background .12s;
    text-decoration: none;
    max-width: 240px;
  }
  .sap-shell-profile:hover { background: rgba(255,255,255,.12); color: #fff; }
  .sap-shell-profile:focus-visible { outline: 2px solid #fff; outline-offset: 2px; }
  .sap-shell-profile .avatar-circle {
    width: 34px; height: 34px;
    border-radius: 50%;
    background: linear-gradient(135deg, #0070f2, #0057d2);
    color: #fff;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    font-size: .85rem;
    flex-shrink: 0;
  }
  .sap-shell-profile-text {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    line-height: 1.15;
    overflow: hidden;
  }
  .sap-shell-profile-text strong {
    font-size: .78rem;
    font-weight: 600;
    color: #fff;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 150px;
  }
  .sap-shell-profile-text small {
    font-size: .68rem;
    color: var(--sap-shellbar-muted);
    white-space: nowrap;
  }
  @media (max-width: 767px) {
    .sap-shell-profile-text { display: none; }
  }

  .sap-shellbar .dropdown-menu {
    border-radius: .75rem;
    border: 0;
    box-shadow: 0 4px 24px rgba(34,53,72,.18), 0 0 0 1px rgba(34,53,72,.06);
    padding: .35rem;
    min-width: 240px;
    margin-top: .35rem;
  }
  .sap-shellbar .dropdown-item {
    display: flex;
    align-items: center;
    gap: .6rem;
    font-size: .8125rem;
    padding: .55rem .75rem;
    border-radius: .5rem;
    color: var(--sap-text);
    transition: background .12s, color .12s;
  }
  .sap-shellbar .dropdown-item:hover {
    background: #eaf4ff;
    color: var(--sap-brand);
  }
  .sap-shellbar .dropdown-item .bi {
    font-size: .9rem;
    width: 1.1rem;
    text-align: center;
    color: var(--sap-text-muted);
  }
  .sap-shellbar .dropdown-item:hover .bi { color: var(--sap-brand); }
  .sap-shellbar .dropdown-item.text-danger:hover {
    background: #fef4f4;
    color: #aa0808 !important;
  }
  .sap-shellbar .dropdown-item.text-danger:hover .bi { color: #aa0808; }

  .sap-shellbar .dropdown-menu .dropdown-user {
    padding: .55rem .75rem;
    display: flex; align-items: center; gap: .6rem;
  }
  .sap-shellbar .dropdown-menu .dropdown-user .avatar-circle {
    width: 32px; height: 32px; font-size: .8rem;
  }
  .sap-shellbar .dropdown-menu .dropdown-user strong {
    font-size: .82rem; color: var(--sap-text); display: block;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    max-width: 160px;
  }
  .sap-shellbar .dropdown-menu .dropdown-user small {
    font-size: .7rem; color: var(--sap-text-muted);
  }
  .sap-shellbar .dropdown-menu .dropdown-divider {
    margin: .3rem 0;
    border-color: var(--sap-border-soft);
  }

  .main-content {
    margin-left: var(--sidebar-w, 260px);
    min-height: 100vh;
    background: #f5f6f7;
  }
  @media (max-width: 991px) {
    .main-content { margin-left: 0; }
  }

  .sap-page-content { padding: 1.25rem; }
  @media (max-width: 767px) { .sap-page-content { padding: 1rem .75rem; } }

  .main-content > .container-fluid { padding: 1.25rem; }
  @media (max-width: 767px) { .main-content > .container-fluid { padding: 1rem .75rem; } }

  /* ================= ICT new-ticket toast ================= */
  @keyframes ictToastIn {
    from { opacity: 0; transform: translateX(20px); }
    to   { opacity: 1; transform: translateX(0); }
  }
</style>

<?php if (($u['role'] ?? '') === 'ICT_STAFF'): ?>
<!-- ============================================================
     ICT new-ticket sound + toast notifier
     - Shared AudioContext (single instance, reused)
     - Auto-resumes on every user interaction
     - "Enable notification sound" fallback button if blocked
     ============================================================ -->
<script>
(function () {
  'use strict';

  /* ---------- 1. Shared AudioContext --------------------------- */
  let audioCtx     = null;
  let soundUnlocked = false;

  function getCtx() {
    if (!audioCtx) {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return null;
      audioCtx = new Ctx();
    }
    return audioCtx;
  }

  async function resumeCtx() {
    const ctx = getCtx();
    if (!ctx) return false;
    try {
      if (ctx.state === 'suspended') {
        await ctx.resume();
      }
      soundUnlocked = (ctx.state === 'running');
      return soundUnlocked;
    } catch (e) {
      return false;
    }
  }

  /* ---------- 2. Sound: two-tone chime ------------------------ */
  async function playChime() {
    const ok = await resumeCtx();
    if (!ok) {
      console.warn('[ICT] AudioContext is not running. Sound was blocked by the browser.');
      return false;
    }
    const ctx = audioCtx;

    function tone(freq, start, duration, gainVal) {
      const osc  = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      const t0 = ctx.currentTime + start;
      gain.gain.setValueAtTime(0.0001, t0);
      gain.gain.linearRampToValueAtTime(gainVal, t0 + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);
      osc.connect(gain).connect(ctx.destination);
      osc.start(t0);
      osc.stop(t0 + duration + 0.05);
    }

    tone(880,     0.00, 0.18, 0.30); // A5
    tone(1174.66, 0.16, 0.30, 0.28); // D6
    return true;
  }

  /* ---------- 3. Toast ---------------------------------------- */
  function showToast(ticket) {
    const existing = document.getElementById('ictNewTicketToast');
    if (existing) existing.remove();

    const t = document.createElement('div');
    t.id = 'ictNewTicketToast';
    t.innerHTML = `
      <div style="display:flex;align-items:flex-start;gap:.6rem;">
        <div style="flex-shrink:0;width:32px;height:32px;border-radius:8px;
                    background:#eaf4ff;color:#0070f2;display:flex;align-items:center;
                    justify-content:center;font-size:1.1rem;">
          <i class="bi bi-bell-fill"></i>
        </div>
        <div style="flex:1;min-width:0;">
          <div style="font-weight:600;font-size:.875rem;color:#1d2d3e;">
            New ticket reached ICT
          </div>
          <div style="font-size:.78rem;color:#556b82;margin-top:.15rem;
                      overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"
               title="${ticket.subject}">
            <code style="background:#f4f5f7;padding:.05rem .3rem;
                         border-radius:.25rem;font-size:.72rem;">${ticket.ticket_number}</code>
            ${ticket.subject}
          </div>
          <div style="margin-top:.55rem;display:flex;gap:.4rem;">
            <a href="<?= BASE_URL ?>/ict/tickets.php"
               style="font-size:.75rem;font-weight:500;color:#0070f2;
                      text-decoration:none;padding:.25rem .55rem;
                      border:1px solid #cfe2f8;border-radius:.35rem;">
              Open Queue
            </a>
            <button onclick="document.getElementById('ictNewTicketToast').remove()"
                    style="font-size:.75rem;font-weight:500;color:#556b82;
                           background:transparent;border:0;cursor:pointer;
                           padding:.25rem .55rem;">
              Dismiss
            </button>
          </div>
        </div>
      </div>`;

    Object.assign(t.style, {
      position: 'fixed',
      bottom: '1.25rem',
      right: '1.25rem',
      zIndex: '9999',
      background: '#ffffff',
      border: '1px solid #eaecf0',
      borderLeft: '4px solid #0070f2',
      borderRadius: '.6rem',
      boxShadow: '0 8px 24px rgba(34,53,72,.18)',
      padding: '.85rem 1rem',
      maxWidth: '360px',
      fontFamily: '"72", "72full", Arial, Helvetica, sans-serif',
      animation: 'ictToastIn .28s cubic-bezier(.2,.8,.2,1)',
      transition: 'opacity .25s, transform .25s',
    });

    document.body.appendChild(t);

    setTimeout(() => {
      if (!t.parentNode) return;
      t.style.opacity = '0';
      t.style.transform = 'translateX(20px)';
      setTimeout(() => t.remove(), 260);
    }, 8000);
  }

  /* ---------- 4. Polling -------------------------------------- */
  /* window.BASE_URL is only defined by footer.php, which loads after this
     inline script — use the PHP constant so the poll resolves correctly. */
  const BASE = '<?= BASE_URL ?>';
  let lastCount = null;
  let firstDone = false;

  async function poll() {
    try {
      const r = await fetch(BASE + '/api/ict_pending.php', {
        credentials: 'same-origin',
        cache: 'no-store'
      });
      const d = await r.json();
      if (!d || !d.ok) return;

      if (!firstDone) {
        lastCount = d.pending;
        firstDone = true;
        return;
      }

      if (lastCount !== null && d.pending > lastCount) {
        playChime();
        if (d.latest) showToast(d.latest);
      }

      lastCount = d.pending;
    } catch (e) { /* silent */ }
  }

  /* ---------- 5. Unlock on EVERY interaction ------------------ */
  ['click', 'keydown', 'touchstart', 'pointerdown'].forEach(evt => {
    document.addEventListener(evt, () => { resumeCtx(); }, { passive: true });
  });

  /* Try to resume immediately — often works right after navigation. */
  resumeCtx();

  /* ---------- 6. Fallback "Enable sound" button --------------- */
  setTimeout(() => {
    if (soundUnlocked) return;

    const btn = document.createElement('button');
    btn.id = 'ictEnableSoundBtn';
    btn.type = 'button';
    btn.innerHTML = '<i class="bi bi-volume-up-fill"></i> Enable notification sound';
    Object.assign(btn.style, {
      position: 'fixed',
      bottom: '1.25rem',
      right: '1.25rem',
      zIndex: '9999',
      background: '#0070f2',
      color: '#fff',
      border: '0',
      borderRadius: '.5rem',
      padding: '.55rem .9rem',
      fontSize: '.8125rem',
      fontWeight: '600',
      fontFamily: '"72", "72full", Arial, Helvetica, sans-serif',
      boxShadow: '0 6px 20px rgba(0,112,242,.35)',
      cursor: 'pointer',
      display: 'inline-flex',
      alignItems: 'center',
      gap: '.4rem',
      animation: 'ictToastIn .3s ease-out',
    });

    btn.addEventListener('click', async () => {
      const ok = await playChime();   // plays a test chime AND unlocks
      if (ok) {
        btn.remove();
      } else {
        btn.innerHTML = '<i class="bi bi-x-circle-fill"></i> Still blocked — check browser settings';
        btn.style.background = '#aa0808';
      }
    });

    document.body.appendChild(btn);
  }, 3000);

  /* ---------- 7. Start polling -------------------------------- */
  setTimeout(poll, 2000);
  setInterval(poll, 15000);
})();
</script>
<?php endif; ?>
</head>
<body>

<?php include __DIR__ . '/sidebar.php'; ?>

<div class="main-content" id="mainContent">

  <!-- ================= SAP Fiori Shell Bar ================= -->
  <header class="sap-shellbar" role="banner">

    <div class="sap-shellbar-left">
      <button type="button"
              class="sap-shell-icon-btn d-lg-none"
              id="sidebarToggle"
              title="Toggle navigation"
              aria-label="Toggle navigation">
        <i class="bi bi-list"></i>
      </button>

      <a href="<?= e($homeLink) ?>"
         class="sap-shell-icon-btn"
         title="Home"
         aria-label="Home">
        <i class="bi bi-house-door"></i>
      </a>

      <a href="<?= e($homeLink) ?>" class="sap-shell-brand" title="<?= e(APP_NAME) ?>">
        <img src="<?= BASE_URL ?>/public/assets/img/epss-logo.png"
             alt="EPSS" onerror="this.style.display='none'">
        <span class="sap-shell-brand-text">
          <span class="sap-shell-brand-title">EPSS Helpdesk</span>
          <span class="sap-shell-brand-sub">Adama Branch</span>
        </span>
      </a>
    </div>

    <div class="sap-shellbar-search" role="search">
      <div class="sap-shellbar-search-inner">
        <i class="bi bi-search" aria-hidden="true"></i>
        <input type="search"
               id="shellSearch"
               placeholder="Search tickets, users, reports…"
               aria-label="Global search"
               autocomplete="off">
      </div>
    </div>

    <div class="sap-shellbar-right">

      <?php if ($u['role'] === 'EMPLOYEE'): ?>
        <a href="<?= BASE_URL ?>/employee/create_ticket.php"
           class="sap-shell-icon-btn"
           title="New Ticket"
           aria-label="New Ticket">
          <i class="bi bi-plus-circle"></i>
        </a>
      <?php elseif (in_array($u['role'], ['TEAM_LEADER','BRANCH_MANAGER'], true)): ?>
        <a href="<?= BASE_URL ?>/teamleader/create_ticket.php"
           class="sap-shell-icon-btn"
           title="New Ticket (Direct to ICT)"
           aria-label="New Ticket">
          <i class="bi bi-plus-circle"></i>
        </a>
      <?php endif; ?>

      <a href="<?= BASE_URL ?>/public/chat.php"
         class="sap-shell-icon-btn sap-shell-notif"
         title="Live Chat"
         aria-label="Live Chat">
        <i class="bi bi-chat-dots"></i>
        <?php if ($chatUnread > 0): ?>
          <span class="badge"><?= $chatUnread ?></span>
        <?php endif; ?>
      </a>

      <a href="<?= BASE_URL ?>/public/notifications.php"
         class="sap-shell-icon-btn sap-shell-notif"
         title="Notifications"
         aria-label="Notifications">
        <i class="bi bi-bell"></i>
        <?php if ($unreadCount > 0): ?>
          <span class="badge"><?= $unreadCount ?></span>
        <?php endif; ?>
      </a>

      <a href="<?= BASE_URL ?>/public/help.php"
         class="sap-shell-icon-btn d-none d-md-inline-flex"
         title="Help"
         aria-label="Help">
        <i class="bi bi-question-circle"></i>
      </a>

      <div class="dropdown">
        <button type="button"
                class="sap-shell-profile"
                data-bs-toggle="dropdown"
                aria-expanded="false"
                aria-label="User menu">
          <span class="avatar-circle"><?= e($initial) ?></span>
          <span class="sap-shell-profile-text">
            <strong><?= e($u['full_name']) ?></strong>
            <small><?= e($roleLabel) ?></small>
          </span>
        </button>

        <ul class="dropdown-menu dropdown-menu-end">
          <li>
            <div class="dropdown-user">
              <span class="avatar-circle"><?= e($initial) ?></span>
              <div>
                <strong><?= e($u['full_name']) ?></strong>
                <small><?= e($u['email'] ?: $u['username']) ?></small>
              </div>
            </div>
          </li>
          <li><hr class="dropdown-divider"></li>

          <li>
            <a class="dropdown-item" href="<?= BASE_URL ?>/public/profile.php">
              <i class="bi bi-person"></i> My Profile
            </a>
          </li>
          <li>
            <a class="dropdown-item" href="<?= BASE_URL ?>/public/change_password.php">
              <i class="bi bi-key"></i> Change Password
            </a>
          </li>
          <li>
            <a class="dropdown-item" href="<?= BASE_URL ?>/public/notifications.php">
              <i class="bi bi-bell"></i> Notifications
              <?php if ($unreadCount > 0): ?>
                <span class="badge bg-danger ms-auto"><?= $unreadCount ?></span>
              <?php endif; ?>
            </a>
          </li>
          <li>
            <a class="dropdown-item" href="<?= BASE_URL ?>/public/chat.php">
              <i class="bi bi-chat-dots"></i> Live Chat
              <?php if ($chatUnread > 0): ?>
                <span class="badge bg-danger ms-auto"><?= $chatUnread ?></span>
              <?php endif; ?>
            </a>
          </li>

          <li><hr class="dropdown-divider"></li>

          <li>
            <a class="dropdown-item text-danger" href="<?= BASE_URL ?>/public/logout.php">
              <i class="bi bi-box-arrow-right"></i> Sign Out
            </a>
          </li>
        </ul>
      </div>

    </div>
  </header>

  <main class="container-fluid py-4">