<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

function normalize_wa_phone(?string $phone): ?string {
    if (!$phone) return null;
    $cc = (string)setting('wa_country_code', '251');
    $p  = preg_replace('/\D+/', '', $phone);
    if ($p === '') return null;
    if (str_starts_with($p, $cc)) return $p;
    if (str_starts_with($p, '0'))  return $cc . substr($p, 1);
    if (strlen($p) === 9)          return $cc . $p;
    return $p;
}

function queue_whatsapp(int $userId, ?string $phone, string $message, ?int $ticketId = null): ?int {
    $phone = normalize_wa_phone($phone);
    if (!$phone) return null;
    $stmt = db()->prepare("INSERT INTO whatsapp_log (user_id, phone, message, status, ticket_id)
                           VALUES (?,?,?, 'QUEUED', ?)");
    $stmt->execute([$userId, $phone, mb_substr($message, 0, 4000), $ticketId]);
    return (int)db()->lastInsertId();
}

function send_whatsapp_now(string $phone, string $message): array {
    if (setting('wa_enabled', '0') !== '1') return ['ok' => false, 'error' => 'WhatsApp disabled'];
    $base = rtrim((string)setting('wa_api_url', 'http://localhost:3000'), '/');
    $key  = (string)setting('wa_api_key', '');
    if ($base === '' || $key === '') return ['ok' => false, 'error' => 'WA config missing'];

    $phone = normalize_wa_phone($phone);
    if (!$phone) return ['ok' => false, 'error' => 'Invalid phone'];

    $endpoint = $base . '/api/messages';
    $payload  = json_encode([
        'to' => $phone, 'type' => 'text', 'text' => ['body' => $message],
    ], JSON_UNESCAPED_UNICODE);

    $ch = curl_init($endpoint);
    curl_setopt_array($ch, [
        CURLOPT_POST => true, CURLOPT_POSTFIELDS => $payload,
        CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . $key,
            'Content-Type: application/json',
            'Accept: application/json',
        ],
    ]);
    $response = curl_exec($ch);
    $err      = curl_error($ch);
    $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($response === false) return ['ok' => false, 'error' => 'Network: ' . $err];

    $json = json_decode($response, true) ?: [];
    $ok = $httpCode >= 200 && $httpCode < 300 && (($json['success'] ?? true) !== false);
    return [
        'ok' => $ok, 'http' => $httpCode,
        'response' => $response,
        'error' => $ok ? null : ($json['error'] ?? ('HTTP ' . $httpCode)),
    ];
}

function dispatch_whatsapp_queue(int $limit = 50): array {
    $pdo  = db();
    $rows = $pdo->query("SELECT * FROM whatsapp_log WHERE status='QUEUED' ORDER BY id LIMIT $limit")->fetchAll();
    $sent = 0; $failed = 0;
    foreach ($rows as $row) {
        $res = send_whatsapp_now($row['phone'], $row['message']);
        if ($res['ok']) {
            $pdo->prepare("UPDATE whatsapp_log SET status='SENT', sent_at=NOW(), response=? WHERE id=?")
                ->execute([substr((string)($res['response'] ?? ''), 0, 2000), $row['id']]);
            $sent++;
        } else {
            $pdo->prepare("UPDATE whatsapp_log SET status='FAILED', response=? WHERE id=?")
                ->execute([substr(($res['error'] ?? '') . ' | ' . ($res['response'] ?? ''), 0, 2000), $row['id']]);
            $failed++;
        }
    }
    return ['sent' => $sent, 'failed' => $failed];
}