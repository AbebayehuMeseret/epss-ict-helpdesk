<?php
// Ensure BASE_URL is available even if this file is included in an unusual order
if (!defined('BASE_URL')) {
    require_once __DIR__ . '/../config/config.php';
}
?>
</main>

<footer class="text-center text-muted py-3 small border-top">
  &copy; <?= date('Y') ?> Ethiopian Pharmaceuticals Supply Service – Adama Branch
  &nbsp;|&nbsp; ICT Helpdesk System
</footer>

</div><!-- /.main-content -->

<script>
  window.BASE_URL = <?= json_encode(BASE_URL) ?>;
</script>

<!-- Third-party libraries (order matters: jQuery → DataTables → Bootstrap → Chart.js) -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>

<!-- Application script (with cache-busting ?v=) -->
<script src="<?= BASE_URL ?>/public/assets/js/app.js?v=<?= @filemtime(__DIR__ . '/../public/assets/js/app.js') ?: time() ?>"></script>

</body>
</html>
