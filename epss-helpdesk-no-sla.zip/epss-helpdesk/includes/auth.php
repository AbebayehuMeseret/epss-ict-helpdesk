<?php
declare(strict_types=1);

/**
 * includes/auth.php
 *
 * Authentication helpers. This file is the single owner of
 * current_user(), require_login() and require_role().
 *
 * db() lives in includes/functions.php, so functions.php must be
 * loaded first. (config/database.php only returns an array now.)
 */

require_once __DIR__ . '/functions.php';          // provides db(), e(), audit(), app_fail() ...
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/permissions.php';

/**
 * Return the currently logged-in user row (cached per request).
 * Pass true to force a fresh fetch from the database.
 */
function current_user(bool $fresh = false): ?array {
    static $u = null;
    if ($fresh) $u = null;

    if (empty($_SESSION['user_id'])) return null;

    if ($u === null) {
        $stmt = db()->prepare("
            SELECT u.*, d.department_name
            FROM users u
            LEFT JOIN departments d ON d.id = u.department_id
            WHERE u.id = ? AND u.status = 'ACTIVE'
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $u = $stmt->fetch() ?: null;
    }
    return $u;
}

/**
 * Require an authenticated session.
 * Handles session timeout and forces a password change when required.
 */
function require_login(): array {
    $u = current_user();

    if (!$u) {
        header('Location: ' . BASE_URL . '/public/login.php');
        exit;
    }

    // Session timeout
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > SESSION_TIMEOUT) {
        session_unset();
        session_destroy();
        header('Location: ' . BASE_URL . '/public/login.php?timeout=1');
        exit;
    }
    $_SESSION['last_activity'] = time();

    // Force password change on first login
    if ((int)$u['must_change_password'] === 1
        && basename($_SERVER['PHP_SELF']) !== 'change_password.php') {
        header('Location: ' . BASE_URL . '/public/change_password.php');
        exit;
    }

    return $u;
}

/**
 * Require one of the given roles.
 *
 * Special handling:
 *   Branch Manager is treated as a Team Leader everywhere in the system.
 *   Whenever 'TEAM_LEADER' is listed in $roles, 'BRANCH_MANAGER' is
 *   automatically accepted too.
 *
 * Examples:
 *   require_role('ADMIN')                    → only ADMIN
 *   require_role('TEAM_LEADER')              → TEAM_LEADER or BRANCH_MANAGER
 *   require_role('ADMIN','TEAM_LEADER')      → ADMIN, TEAM_LEADER, BRANCH_MANAGER
 *   require_role('ICT_STAFF')                → only ICT_STAFF
 */
function require_role(string ...$roles): array {
    $u = require_login();

    // Expand the allowed roles:
    // every time TEAM_LEADER appears, BRANCH_MANAGER is also allowed.
    $expanded = [];
    foreach ($roles as $r) {
        $expanded[] = $r;
        if ($r === 'TEAM_LEADER') {
            $expanded[] = 'BRANCH_MANAGER';
        }
    }
    $expanded = array_values(array_unique($expanded));

    if (!in_array($u['role'], $expanded, true)) {
        app_fail('E-AUTH-403');          // shared coded error page (includes/errors.php)
    }

    return $u;
}