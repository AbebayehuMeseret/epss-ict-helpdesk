<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../reports/kpi_calculator.php';

/**
 * Ethiopian calendar year that contains today.
 */
function annual_ec_current_year(): int {
    $year  = (int)date('Y');
    $month = (int)date('n');
    $day   = (int)date('j');
    return ($month > 9 || ($month === 9 && $day >= 11)) ? $year - 7 : $year - 8;
}

function annual_ec_start(int $ecYear): string {
    $gregYear = $ecYear + 7;
    $next     = $gregYear + 1;
    $leap     = ($next % 4 === 0 && ($next % 100 !== 0 || $next % 400 === 0));
    return sprintf('%04d-09-%02d', $gregYear, $leap ? 12 : 11);
}

function annual_ec_bounds(int $ecYear): array {
    $start = annual_ec_start($ecYear);
    $end   = date('Y-m-d', strtotime(annual_ec_start($ecYear + 1) . ' -1 day'));
    return [$start, $end];
}

/* =====================================================================
 * Annual plan targets (per E.C. year)
 * ===================================================================== */

function annual_plan_targets(int $ecYear): array {
    static $cache = [];
    if (isset($cache[$ecYear])) return $cache[$ecYear];
    try {
        $stmt = db()->prepare(
            "SELECT kpi_key, target_value, unit, source_file
             FROM annual_plan_targets WHERE ec_year = ?"
        );
        $stmt->execute([$ecYear]);
        $out = [];
        foreach ($stmt->fetchAll() as $r) {
            $out[$r['kpi_key']] = [
                'value'       => (float)$r['target_value'],
                'unit'        => (string)$r['unit'],
                'source_file' => (string)($r['source_file'] ?? ''),
            ];
        }
        return $cache[$ecYear] = $out;
    } catch (Throwable $e) {
        return $cache[$ecYear] = [];
    }
}

function annual_plan_targets_save(int $ecYear, array $rows, int $userId, string $source = ''): int {
    if (!$rows) return 0;
    $pdo = db();
    $stmt = $pdo->prepare(
        "INSERT INTO annual_plan_targets
            (ec_year, kpi_key, target_value, unit, source_file, updated_by)
         VALUES (?,?,?,?,?,?)
         ON DUPLICATE KEY UPDATE
            target_value = VALUES(target_value),
            unit         = VALUES(unit),
            source_file  = VALUES(source_file),
            updated_by   = VALUES(updated_by)"
    );
    $n = 0;
    foreach ($rows as $key => $row) {
        $key = preg_replace('/[^a-z0-9_]/i', '', (string)$key);
        if ($key === '' || !is_numeric($row['value'] ?? null)) continue;
        $stmt->execute([
            $ecYear, $key, (float)$row['value'],
            (string)($row['unit'] ?? '%') ?: '%',
            $source !== '' ? $source : null,
            $userId ?: null,
        ]);
        $n++;
    }
    return $n;
}

/* =====================================================================
 * Narrative defaults / storage
 * ===================================================================== */

function annual_report_defaults(int $ecYear): array {
    return [
        'overview' => implode("\n", [
            'The ICT team provides support across all departments of the branch.',
            'It ensures operational continuity, system availability and technology integration.',
            'It handles user requests, system maintenance and troubleshooting.',
            'ICT services are aligned with organizational goals and KPIs.',
        ]),
        'work_done_notes' => '',
        'impact_notes'    => '',
        'challenges' => implode("\n", [
            'Hardware failures due to aging equipment.',
            'Power instability.',
            'The surveillance camera intended for critical security monitoring is not operational due to a hardware failure.',
            'Lack of delegated responsible personnel for the surveillance camera.',
        ]),
        'recommendations' => implode("\n", [
            'Replace outdated ICT equipment.',
            'Increase power backup infrastructure.',
            'Expand the ICT team to meet growing demand.',
            'Introduce proactive user training programs.',
            'Improve monitoring of system performance and uptime.',
            'Develop applications for operations.',
        ]),
        'conclusion' => implode("\n", [
            "The ICT team played a critical role in ensuring EPSS efficiency.",
            "Significant work was done across all departments in {$ecYear} E.C.",
            'Continued support and resources are essential for maintaining progress.',
            'ICT is committed to continuous improvement and innovation.',
        ]),
    ];
}

function annual_report_fetch(int $ecYear): array {
    try {
        $stmt = db()->prepare("SELECT * FROM annual_ict_reports WHERE ec_year = ?");
        $stmt->execute([$ecYear]);
        return $stmt->fetch() ?: [];
    } catch (Throwable $e) {
        return [];
    }
}

function annual_report_values(int $ecYear): array {
    $defaults = annual_report_defaults($ecYear);
    $saved    = annual_report_fetch($ecYear);
    $user     = function_exists('current_user') ? current_user() : null;

    $values = [
        'presenter'   => $saved['presenter'] ?? ($user['full_name'] ?? 'System Administrator'),
        'report_date' => !empty($saved['report_date']) ? $saved['report_date'] : date('Y-m-d'),
    ];

    foreach (['overview', 'work_done_notes', 'impact_notes',
              'challenges', 'recommendations', 'conclusion'] as $key) {
        $savedText = isset($saved[$key]) ? trim((string)$saved[$key]) : '';
        $values[$key] = $savedText !== '' ? $savedText : $defaults[$key];
    }

    return $values;
}

function annual_report_save(int $ecYear, array $values, int $userId): void {
    $stmt = db()->prepare("INSERT INTO annual_ict_reports
        (ec_year, presenter, report_date, overview, work_done_notes, impact_notes,
         challenges, recommendations, conclusion, updated_by)
        VALUES (?,?,?,?,?,?,?,?,?,?)
        ON DUPLICATE KEY UPDATE
            presenter = VALUES(presenter),
            report_date = VALUES(report_date),
            overview = VALUES(overview),
            work_done_notes = VALUES(work_done_notes),
            impact_notes = VALUES(impact_notes),
            challenges = VALUES(challenges),
            recommendations = VALUES(recommendations),
            conclusion = VALUES(conclusion),
            updated_by = VALUES(updated_by)");

    $stmt->execute([
        $ecYear,
        $values['presenter'] ?: null,
        $values['report_date'] ?: null,
        $values['overview'] ?: null,
        $values['work_done_notes'] ?: null,
        $values['impact_notes'] ?: null,
        $values['challenges'] ?: null,
        $values['recommendations'] ?: null,
        $values['conclusion'] ?: null,
        $userId ?: null,
    ]);
}

function annual_report_bullets(string $text): array {
    $out = [];
    foreach (preg_split('/\R/u', $text) as $line) {
        $line = trim($line);
        $line = preg_replace('/^\s*(?:[-*•–—]|\d+[.)])\s*/u', '', $line);
        if ($line !== null && $line !== '') {
            $out[] = $line;
        }
    }
    return $out;
}

/* =====================================================================
 * Schema-adaptive ticket status helpers (defensive against schema drift)
 * ===================================================================== */

function annual_schema_columns(PDO $pdo, string $table): array {
    static $cache = [];
    if (isset($cache[$table])) return $cache[$table];
    try {
        $rows = $pdo->query("SHOW COLUMNS FROM `" . str_replace('`', '', $table) . "`")
                    ->fetchAll(PDO::FETCH_COLUMN);
        return $cache[$table] = array_map('strtolower', $rows ?: []);
    } catch (Throwable $e) {
        return $cache[$table] = [];
    }
}

function annual_ticket_status_column(PDO $pdo): ?string {
    static $col = false;
    if ($col !== false) return $col;
    $cols = annual_schema_columns($pdo, 'tickets');
    foreach (['status', 'ticket_status', 'state', 'ticket_state'] as $cand) {
        if (in_array($cand, $cols, true)) return $col = $cand;
    }
    return $col = null;
}

function annual_ticket_status_values(PDO $pdo): array {
    static $vals = null;
    if ($vals !== null) return $vals;
    $col = annual_ticket_status_column($pdo);
    if ($col === null) return $vals = [];
    try {
        return $vals = $pdo->query("SELECT DISTINCT `$col` FROM tickets")
                          ->fetchAll(PDO::FETCH_COLUMN);
    } catch (Throwable $e) {
        return $vals = [];
    }
}

function annual_ticket_status_match(PDO $pdo, array $buckets): ?string {
    $vals = annual_ticket_status_values($pdo);
    if (!$vals) return null;
    foreach ($buckets as $want) {
        foreach ($vals as $v) {
            if (strtoupper((string)$v) === strtoupper($want)) return (string)$v;
        }
    }
    foreach ($buckets as $want) {
        foreach ($vals as $v) {
            if (str_contains(strtoupper((string)$v), strtoupper($want))) return (string)$v;
        }
    }
    return null;
}

function annual_status_in_clause(?string $col, array $values): array {
    if ($col === null || !$values) return ['1=0', []];
    $ph = implode(',', array_fill(0, count($values), '?'));
    return ["`$col` IN ($ph)", array_values($values)];
}

/* =====================================================================
 * Core data builder — produces every number + narrative + plan comparison
 * ===================================================================== */

function annual_report_data(int $ecYear, array $narr): array {
    $pdo = db();
    [$start, $end] = annual_ec_bounds($ecYear);
    $startDt = $start . ' 00:00:00';
    $endDt   = $end   . ' 23:59:59';

    $one = static function (string $sql, array $params = []) use ($pdo) {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchColumn();
    };

    /* ---- Ticket status detection ---- */
    $statusCol   = annual_ticket_status_column($pdo);
    $closedVal   = annual_ticket_status_match($pdo, ['CLOSED', 'CLOSE', 'RESOLVED', 'DONE', 'COMPLETED']);
    $rejVal      = annual_ticket_status_match($pdo, ['REJECTED', 'CANCELLED', 'CANCELED', 'DECLINED', 'VOID']);
    $waitingVals = array_values(array_filter([
        annual_ticket_status_match($pdo, ['WAITING_FOR_PARTS', 'WAITING_PARTS', 'ON_HOLD_PARTS']),
        annual_ticket_status_match($pdo, ['WAITING_FOR_INFORMATION', 'WAITING_INFO', 'PENDING_INFO']),
    ]));

    /* ---- Ticket counters ---- */
    $ticketsTotal = (int)$one(
        "SELECT COUNT(*) FROM tickets WHERE created_at BETWEEN ? AND ?",
        [$startDt, $endDt]
    );

    $ticketsClosed = ($statusCol && $closedVal !== null)
        ? (int)$one(
            "SELECT COUNT(*) FROM tickets
             WHERE created_at BETWEEN ? AND ? AND `$statusCol` = ?",
            [$startDt, $endDt, $closedVal])
        : 0;

    $excludeForOpen = array_values(array_filter([$closedVal, $rejVal]));
    if ($statusCol && $excludeForOpen) {
        [$inOpen, $inOpenParams] = annual_status_in_clause($statusCol, $excludeForOpen);
        $ticketsOpen = (int)$one(
            "SELECT COUNT(*) FROM tickets
             WHERE created_at BETWEEN ? AND ? AND NOT ($inOpen)",
            array_merge([$startDt, $endDt], $inOpenParams));
    } else {
        $ticketsOpen = $statusCol ? $ticketsTotal : 0;
    }

    $ticketsCancelled = ($statusCol && $rejVal !== null)
        ? (int)$one(
            "SELECT COUNT(*) FROM tickets
             WHERE created_at BETWEEN ? AND ? AND `$statusCol` = ?",
            [$startDt, $endDt, $rejVal])
        : 0;

    if ($statusCol && $waitingVals) {
        [$inW, $inWParams] = annual_status_in_clause($statusCol, $waitingVals);
        $waiting = (int)$one(
            "SELECT COUNT(*) FROM tickets
             WHERE created_at BETWEEN ? AND ? AND $inW",
            array_merge([$startDt, $endDt], $inWParams));
    } else {
        $waiting = 0;
    }

    /* ---- Average resolution time ---- */
    $sla        = calculate_kpi_achievement($startDt, $endDt);
    $avgHours   = (float)($sla['avg_resolution_hr'] ?? 0);
    $avgHoursTx = number_format($avgHours, 1);

    /* ---- PM checklists ---- */
    $pmCols   = annual_schema_columns($pdo, 'pm_checklists');
    $pmStatus = in_array('status', $pmCols, true) ? 'status' : null;

    if ($pmStatus) {
        $pmRow = $pdo->prepare(
            "SELECT COUNT(*) AS total,
                    COALESCE(SUM(`$pmStatus`='APPROVED'),0) AS approved,
                    COALESCE(SUM(`$pmStatus`='PENDING'),0)  AS pending,
                    COALESCE(SUM(`$pmStatus`='REJECTED'),0) AS rejected
             FROM pm_checklists WHERE checklist_date BETWEEN ? AND ?"
        );
    } else {
        $pmRow = $pdo->prepare(
            "SELECT COUNT(*) AS total, 0 AS approved, 0 AS pending, 0 AS rejected
             FROM pm_checklists WHERE checklist_date BETWEEN ? AND ?"
        );
    }
    $pmRow->execute([$start, $end]);
    $pm = $pmRow->fetch() ?: ['total' => 0, 'approved' => 0, 'pending' => 0, 'rejected' => 0];

    $pmItems = $pdo->prepare(
        "SELECT COUNT(*) AS total, COALESCE(SUM(i.done),0) AS done
         FROM pm_checklist_items i
         JOIN pm_checklists c ON c.id = i.checklist_id
         WHERE c.checklist_date BETWEEN ? AND ?"
    );
    $pmItems->execute([$start, $end]);
    $pmItemRow    = $pmItems->fetch() ?: ['total' => 0, 'done' => 0];
    $pmItemsTotal = (int)$pmItemRow['total'];
    $pmItemsDone  = (int)$pmItemRow['done'];

    /* ---- Departments ---- */
    $deptCols = annual_schema_columns($pdo, 'departments');
    try {
        $departments = in_array('status', $deptCols, true)
            ? $pdo->query("SELECT department_name FROM departments
                           WHERE status='ACTIVE' ORDER BY department_name")
                  ->fetchAll(PDO::FETCH_COLUMN)
            : $pdo->query("SELECT department_name FROM departments ORDER BY department_name")
                  ->fetchAll(PDO::FETCH_COLUMN);
        $deptActive = count($departments);
    } catch (Throwable $e) {
        $departments = []; $deptActive = 0;
    }

    $deptCovered = (int)$one(
        "SELECT COUNT(DISTINCT d) FROM (
             SELECT department_id AS d FROM tickets
              WHERE created_at BETWEEN ? AND ? AND department_id IS NOT NULL
             UNION
             SELECT department_id AS d FROM pm_checklists
              WHERE checklist_date BETWEEN ? AND ? AND department_id IS NOT NULL
         ) x",
        [$startDt, $endDt, $start, $end]
    );

    /* ---- Top categories ---- */
    try {
        $topStmt = $pdo->prepare(
            "SELECT c.category_name, COUNT(*) AS cnt
             FROM tickets t JOIN categories c ON c.id = t.category_id
             WHERE t.created_at BETWEEN ? AND ?
             GROUP BY c.id, c.category_name
             ORDER BY cnt DESC LIMIT 3"
        );
        $topStmt->execute([$startDt, $endDt]);
        $topCategories = $topStmt->fetchAll();
    } catch (Throwable $e) {
        $topCategories = [];
    }

    /* ---- KPI framework ---- */
    try {
        $kpiCols = annual_schema_columns($pdo, 'kpis');
        $kpiFramework = in_array('status', $kpiCols, true)
            ? $pdo->query("SELECT kpi_name FROM kpis WHERE status='ACTIVE' ORDER BY id")
                  ->fetchAll(PDO::FETCH_COLUMN)
            : $pdo->query("SELECT kpi_name FROM kpis ORDER BY id")
                  ->fetchAll(PDO::FETCH_COLUMN);
    } catch (Throwable $e) {
        $kpiFramework = [];
    }

    /* ---- Percentages ---- */
    $resolutionPct = $ticketsTotal > 0 ? round($ticketsClosed / $ticketsTotal * 100, 1) : 0.0;
    $deptPct       = $deptActive   > 0 ? round($deptCovered  / $deptActive   * 100, 1) : 0.0;
    $pmPct         = $pmItemsTotal > 0 ? round($pmItemsDone  / $pmItemsTotal * 100, 1) : 0.0;

    $count = static fn($n): string => number_format((float)$n);

    /* ---- KPI cards (with plan target comparison) ---- */
    $planTargets = annual_plan_targets($ecYear);

    $kpiDefs = [
        [
            'key'   => 'resolution_pct',
            'label' => 'Percentage of Networking and ICT Support',
            'value' => $resolutionPct,
            'note'  => $ticketsTotal > 0
                ? $count($ticketsClosed) . ' of ' . $count($ticketsTotal) . ' requests completed'
                : 'No support requests recorded in the period',
        ],
        [
            'key'   => 'dept_pct',
            'label' => 'Percentage of Process Supported with Supply Chain Technology',
            'value' => $deptPct,
            'note'  => $deptActive > 0
                ? $count($deptCovered) . ' of ' . $count($deptActive) . ' active departments supported'
                : 'No active departments recorded',
        ],
        [
            'key'   => 'pm_pct',
            'label' => 'Percentage of Server Manageability',
            'value' => $pmPct,
            'note'  => $pmItemsTotal > 0
                ? $count($pmItemsDone) . ' of ' . $count($pmItemsTotal) . ' maintenance items completed'
                : 'No preventive maintenance checklist submitted',
        ],
    ];

    foreach ($kpiDefs as &$k) {
        $target = $planTargets[$k['key']] ?? null;
        if ($target !== null) {
            $t = (float)$target['value'];
            $a = (float)$k['value'];
            $diff = round($a - $t, 1);
            $met  = $diff >= 0;
            $k['target']        = $t;
            $k['target_unit']   = $target['unit'];
            $k['target_status'] = $met ? 'MET' : 'BELOW';
            $k['target_diff']   = $diff;
            $k['note'] .= sprintf(
                ' · Target %s%s · %s (%+.1f pts)',
                number_format($t, 1), $target['unit'],
                $met ? 'achieved' : 'missed',
                $diff
            );
        } else {
            $k['target']        = null;
            $k['target_unit']   = null;
            $k['target_status'] = null;
            $k['target_diff']   = null;
        }
    }
    unset($k);

    $kpis = array_map(static function (array $k): array {
        unset($k['key']);
        return $k;
    }, $kpiDefs);

    /* ---- Auto narrative bullets ---- */
    $autoWork = [
        'Logged ' . $count($ticketsTotal) . ' ICT support requests across '
            . $count($deptCovered) . ' departments.',
        'Completed ' . $count($ticketsClosed) . ' requests and ended the period with '
            . $count($ticketsOpen) . ' still in progress.',
        'Delivered ' . $count((int)$pm['approved']) . ' approved preventive maintenance checklists covering '
            . $count($pmItemsDone) . ' completed maintenance items.',
        'Average resolution time was ' . $avgHoursTx . ' hours.',
    ];
    if ($topCategories) {
        $autoWork[] = 'Main support areas: ' . implode(', ', array_map(
            static fn(array $c): string => $c['category_name'] . ' (' . (int)$c['cnt'] . ')',
            $topCategories
        )) . '.';
    }
    $autoWork[] = 'Maintained server uptime and network availability.';
    $autoWork[] = 'Supported implementation and smooth operation of SAP modules.';
    $autoWork[] = 'Ensured backup and data security for critical systems.';

    $autoImpact = [
        'Resolved ' . $count($ticketsClosed) . ' support requests, reducing system and network downtime.',
        'Enhanced user satisfaction and productivity across ' . $count($deptCovered) . ' departments.',
        'Ensured high availability of SAP, internet and intranet services.',
        'Supported continuous operations across all ' . $count($deptActive) . ' active departments.',
    ];
    if ($pmItemsTotal > 0) {
        $autoImpact[] = 'Completed ' . number_format($pmPct, 1) . '% of scheduled preventive maintenance items.';
    }

    $autoChallenges = [];
    if ($waiting > 0) {
        $autoChallenges[] = $count($waiting) . ' requests were waiting for spare parts or additional information at period end.';
    }
    if ((int)$pm['rejected'] > 0) {
        $autoChallenges[] = $count((int)$pm['rejected']) . ' preventive maintenance checklists required correction before approval.';
    }
    if ($ticketsOpen > 0 && count($autoChallenges) < 3) {
        $autoChallenges[] = $count($ticketsOpen) . ' support requests remained open at the end of the period.';
    }

    /* ---- Plan-vs-actual summary ---- */
    $targetsMet   = 0;
    $targetsTotal = 0;
    $targetLines  = [];
    foreach ($kpis as $k) {
        if ($k['target_status'] === null) continue;
        $targetsTotal++;
        $met = $k['target_status'] === 'MET';
        if ($met) $targetsMet++;
        $targetLines[] = sprintf(
            '%s: %s (actual %.1f%% vs target %.1f%%)',
            $k['label'],
            $met ? 'MET' : 'MISSED',
            (float)$k['value'], (float)$k['target']
        );
    }
    $overallTargetPct = $targetsTotal > 0
        ? round($targetsMet / $targetsTotal * 100, 1) : 0.0;

    return [
        'ec_year'            => $ecYear,
        'range_start'        => $start,
        'range_end'          => $end,
        'presenter'          => $narr['presenter'] ?: 'System Administrator',
        'report_date'        => $narr['report_date'],
        'report_date_label'  => date('F j, Y', strtotime($narr['report_date'] ?: 'now')),
        'departments'        => $departments,
        'dept_active'        => $deptActive,
        'dept_covered'       => $deptCovered,
        'tickets_total'      => $ticketsTotal,
        'tickets_closed'     => $ticketsClosed,
        'tickets_open'       => $ticketsOpen,
        'tickets_cancelled'  => $ticketsCancelled,
        'resolution_pct'     => $resolutionPct,
        'avg_hours'          => $avgHours,
        'waiting'            => $waiting,
        'pm_total'           => (int)$pm['total'],
        'pm_approved'        => (int)$pm['approved'],
        'pm_pending'         => (int)$pm['pending'],
        'pm_rejected'        => (int)$pm['rejected'],
        'pm_items_total'     => $pmItemsTotal,
        'pm_items_done'      => $pmItemsDone,
        'pm_pct'             => $pmPct,
        'kpis'               => $kpis,
        'kpi_framework'      => $kpiFramework,
        'plan_targets'       => $planTargets,
        'targets_met'        => $targetsMet,
        'targets_total'      => $targetsTotal,
        'targets_met_pct'    => $overallTargetPct,
        'target_lines'       => $targetLines,
        'bullets'            => [
            'overview'        => annual_report_bullets($narr['overview']),
            'work'            => array_merge($autoWork, annual_report_bullets($narr['work_done_notes'])),
            'impact'          => array_merge($autoImpact, annual_report_bullets($narr['impact_notes'])),
            'challenges'      => array_merge(annual_report_bullets($narr['challenges']), $autoChallenges),
            'recommendations' => annual_report_bullets($narr['recommendations']),
            'conclusion'      => annual_report_bullets($narr['conclusion']),
        ],
    ];
}

/**
 * Auto-compose narrative fields from data + plan targets.
 * Returns the six textarea values ready to drop into the edit form.
 */
function annual_report_autofill(int $ecYear): array {
    $narr = annual_report_values($ecYear);
    $data = annual_report_data($ecYear, $narr);

    $metLines  = [];
    $missLines = [];
    foreach ($data['kpis'] as $k) {
        if ($k['target_status'] === 'MET') {
            $metLines[] = sprintf('%s reached %.1f%% against a target of %.1f%%.',
                $k['label'], (float)$k['value'], (float)$k['target']);
        } elseif ($k['target_status'] === 'BELOW') {
            $missLines[] = sprintf('%s finished at %.1f%% against a target of %.1f%%.',
                $k['label'], (float)$k['value'], (float)$k['target']);
        }
    }

    $overallPct = (float)$data['targets_met_pct'];

    return [
        'overview' => implode("\n", $data['bullets']['overview']),
        'work_done_notes' => implode("\n", $metLines),
        'impact_notes' => implode("\n", [
            sprintf('%d of %d annual plan targets were met (%.1f%%).',
                $data['targets_met'], $data['targets_total'], $overallPct),
        ]),
        'challenges' => implode("\n", $missLines),
        'recommendations' => implode("\n", $data['targets_total'] > 0 && $data['targets_met'] === $data['targets_total']
            ? ['Maintain performance and tighten monitoring to sustain achieved targets.']
            : ['Focus next period on closing the gap on missed targets.',
               'Review the annual plan to ensure target realism for the next cycle.']),
        'conclusion' => implode("\n", [
            sprintf('The ICT team delivered %.1f%% of its annual plan targets in %d E.C.',
                $overallPct, $ecYear),
            'ICT remains committed to continuous improvement and innovation.',
        ]),
    ];
}

/* =====================================================================
 * Slide renderer
 * ===================================================================== */

function annual_report_list(array $items): string {
    $html = '<ul class="slide-list">';
    $n = 0;
    foreach ($items as $item) {
        $item = trim((string)$item);
        if ($item === '') continue;
        $html .= '<li>' . e($item) . '</li>';
        $n++;
    }
    $html .= '</ul>';
    return $n > 0 ? $html : '<p class="slide-caption">No items recorded.</p>';
}

function annual_report_slide_html(array $r): string {
    $year = (int)$r['ec_year'];
    $html = '';

    /* 1 — Cover */
    $html .= '<section class="slide slide-cover">'
        . '<div class="cover-kicker">Ethiopian Pharmaceuticals Supply Service</div>'
        . '<h1 class="cover-title">ICT Annual Report</h1>'
        . '<div class="cover-year">' . $year . ' E.C.</div>'
        . '<div class="cover-branch">Adama Branch · ICT Department</div>'
        . '<table class="cover-meta"><tr>'
        . '<td><span>Presented by</span><strong>' . e($r['presenter']) . '</strong></td>'
        . '<td><span>Date</span><strong>' . e($r['report_date_label']) . '</strong></td>'
        . '</tr></table>'
        . '</section>';

    $slide = static function (string $eyebrow, string $title, string $body) use ($year): string {
        return '<section class="slide">'
            . '<div class="slide-eyebrow">' . e($eyebrow) . '</div>'
            . '<h2>' . e($title) . '</h2>'
            . $body
            . '<div class="slide-foot">EPSS Adama Branch · ICT Annual Report ' . $year . ' E.C.</div>'
            . '</section>';
    };

    /* 2 — Overview */
    $html .= $slide('01 · Overview', 'Overview of ICT Support',
        annual_report_list($r['bullets']['overview']));

    /* 3 — Departments */
    $cells = [];
    foreach ($r['departments'] as $dep) $cells[] = '<td>' . e($dep) . '</td>';
    if (count($cells) % 2 !== 0) $cells[] = '<td></td>';
    $rows = '';
    for ($i = 0; $i < count($cells); $i += 2) {
        $rows .= '<tr>' . $cells[$i] . ($cells[$i + 1] ?? '<td></td>') . '</tr>';
    }
    $deptBody = $cells
        ? '<table class="dept-table">' . $rows . '</table>'
        : '<p class="slide-caption">No active departments recorded.</p>';
    $deptBody .= '<p class="slide-caption">' . (int)$r['dept_covered'] . ' of '
        . (int)$r['dept_active'] . ' active departments used ICT services during the period.</p>';
    $html .= $slide('02 · Coverage', 'Departments Supported by ICT', $deptBody);

    /* 4 — KPIs (with plan targets) */
    $kpiCells = [];
    foreach ($r['kpis'] as $kpi) {
        $badge = '';
        if (!empty($kpi['target_status'])) {
            $badgeClass = $kpi['target_status'] === 'MET' ? 'kpi-badge-met' : 'kpi-badge-miss';
            $badge = '<div class="' . $badgeClass . '">' . e($kpi['target_status']) . '</div>';
        }
        $kpiCells[] = '<td class="kpi-card">'
            . '<div class="kpi-value">' . number_format((float)$kpi['value'], 1) . '%</div>'
            . $badge
            . '<div class="kpi-label">' . e($kpi['label']) . '</div>'
            . '<div class="kpi-note">' . e($kpi['note']) . '</div>'
            . '</td>';
    }
    $kpiRows = '';
    for ($i = 0; $i < count($kpiCells); $i += 2) {
        $kpiRows .= '<tr>' . $kpiCells[$i] . ($kpiCells[$i + 1] ?? '<td></td>') . '</tr>';
    }
    $kpiBody = '<table class="kpi-table">' . $kpiRows . '</table>';
    if ($r['kpi_framework']) {
        $kpiBody .= '<p class="slide-caption">KPI register: '
            . e(implode(' · ', $r['kpi_framework'])) . '</p>';
    }
    if (!empty($r['targets_total'])) {
        $kpiBody .= '<p class="slide-caption">Annual plan targets met: <strong>'
            . (int)$r['targets_met'] . ' of ' . (int)$r['targets_total']
            . ' (' . number_format((float)$r['targets_met_pct'], 1) . '%)</strong></p>';
    }
    $html .= $slide('03 · Performance', 'ICT Key Performance Indicators', $kpiBody);

    /* 5 — Work done */
    $workBody = '<table class="stat-strip"><tr>'
        . '<td><strong>' . number_format((float)$r['tickets_total']) . '</strong><span>requests</span></td>'
        . '<td><strong>' . number_format((float)$r['tickets_closed']) . '</strong><span>completed</span></td>'
        . '<td><strong>' . number_format((float)$r['pm_approved']) . '</strong><span>PM checklists</span></td>'
        . '<td><strong>' . number_format((float)$r['avg_hours'], 1) . '</strong><span>avg hours</span></td>'
        . '</tr></table>'
        . annual_report_list($r['bullets']['work']);
    $html .= $slide('04 · Delivery', 'ICT Work Done in ' . $year . ' E.C.', $workBody);

    /* 6 — Impact */
    $html .= $slide('05 · Impact', 'Impact and Achievements',
        annual_report_list($r['bullets']['impact']));

    /* 7 — Challenges */
    $html .= $slide('06 · Challenges', 'Challenges Encountered',
        annual_report_list($r['bullets']['challenges']));

    /* 8 — Recommendations */
    $html .= $slide('07 · Outlook', 'Recommendations and Future Plans',
        annual_report_list($r['bullets']['recommendations']));

    /* 9 — Conclusion */
    $conclusion = annual_report_list($r['bullets']['conclusion'])
        . '<p class="closing-line">Prepared by the ICT Department, EPSS Adama Branch.</p>';
    $html .= $slide('08 · Conclusion', 'Conclusion', $conclusion);

    return $html;
}