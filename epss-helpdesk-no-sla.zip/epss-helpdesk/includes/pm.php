<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

/**
 * The 15 canonical checklist items — order matters.
 * key => human label
 */
const PM_ITEMS = [
    1  => ['code' => 'delete_temp_windows',     'label' => 'Delete temp windows file'],
    2  => ['code' => 'delete_temp_interrupt',   'label' => 'Delete temporarily interrupt file'],
    3  => ['code' => 'clean_recycle_bin',       'label' => 'Clean recycling bin'],
    4  => ['code' => 'delete_browser_cache',    'label' => 'Delete browser history and cache files'],
    5  => ['code' => 'delete_archive_files',    'label' => 'Delete and archive files'],
    6  => ['code' => 'disk_cleanup',            'label' => 'Disk cleanup'],
    7  => ['code' => 'disk_defragment',         'label' => 'Disk defragment'],
    8  => ['code' => 'uninstall_unused',        'label' => 'Uninstall unused non-archivable files'],
    9  => ['code' => 'activate_office_network', 'label' => 'Activate office network'],
    10 => ['code' => 'windows_update',          'label' => 'Windows update'],
    11 => ['code' => 'activate_windows',        'label' => 'Activate Windows'],
    12 => ['code' => 'blow_dust',               'label' => 'Blowing'],
    13 => ['code' => 'major_computer_updates',  'label' => 'Running major computer updates'],
    14 => ['code' => 'printer_scanner_copier',  'label' => 'Printer, scanner, copier'],
    15 => ['code' => 'others',                  'label' => 'Others'],
];

/**
 * Return the quarter number (1-4) for a given date string.
 */
function pm_quarter_of(string $date): int {
    return (int)ceil((int)date('n', strtotime($date)) / 3);
}

/**
 * Current year/quarter label like "2026-Q4".
 */
function pm_quarter_label(?string $date = null): string {
    $date = $date ?? date('Y-m-d');
    return date('Y', strtotime($date)) . '-Q' . pm_quarter_of($date);
}

/**
 * Has this technician already submitted a checklist for the given year/quarter?
 */
function pm_has_submission(int $techId, int $year, int $quarter): bool {
    $stmt = db()->prepare("SELECT COUNT(*) FROM pm_checklists
                           WHERE technician_id=? AND year=? AND quarter=?");
    $stmt->execute([$techId, $year, $quarter]);
    return (int)$stmt->fetchColumn() > 0;
}

/**
 * Send quarterly reminders to all active ICT technicians.
 * Called from a cron job on the configured day of the first month of each quarter.
 * Idempotent: only sends once per quarter.
 */
function pm_send_quarterly_reminders(): array {
    if (setting('pm_enabled', '1') !== '1') {
        return ['ok' => false, 'error' => 'Module disabled'];
    }

    $now      = new DateTime('now');
    $month    = (int)$now->format('n');
    $day      = (int)$now->format('j');
    $year     = (int)$now->format('Y');
    $quarter  = (int)ceil($month / 3);

    /* Only fire on the configured day of the first month of the quarter */
    $fireDay = (int)setting('pm_quarter_days', '1');
    if (!in_array($month, [1, 4, 7, 10], true) || $day !== $fireDay) {
        return ['ok' => false, 'error' => 'Not scheduled today'];
    }

    /* Idempotency guard */
    $stmt = db()->prepare("SELECT COUNT(*) FROM pm_reminders WHERE year=? AND quarter=?");
    $stmt->execute([$year, $quarter]);
    if ((int)$stmt->fetchColumn() > 0) {
        return ['ok' => false, 'error' => 'Already sent this quarter'];
    }

    /* Notify all active ICT technicians */
    $techs = db()->query("SELECT id, full_name FROM users
                          WHERE role='ICT_STAFF' AND status='ACTIVE'")->fetchAll();

    $label = "{$year}-Q{$quarter}";
    foreach ($techs as $t) {
        /* In-app notification */
        notify((int)$t['id'], null,
            "Quarterly Preventive Maintenance due ({$label})",
            "It's time to run the quarterly Preventive Maintenance checklist for your assigned department.",
            'pm');

        /* WhatsApp (if enabled) */
        if (setting('wa_enabled','0') === '1') {
            try {
                require_once __DIR__ . '/whatsapp.php';
                $stmt2 = db()->prepare("SELECT phone FROM users WHERE id=?");
                $stmt2->execute([$t['id']]);
                $phone = $stmt2->fetchColumn();
                if ($phone) {
                    queue_whatsapp((int)$t['id'], $phone,
                        "🔧 EPSS ICT — Quarterly Preventive Maintenance ({$label})\n\n"
                      . "Please complete the preventive maintenance checklist for your department.\n"
                      . BASE_URL . "/ict/preventive_maintenance.php",
                        null);
                }
            } catch (Throwable $e) { /* silent */ }
        }
    }

    db()->prepare("INSERT INTO pm_reminders (year, quarter) VALUES (?,?)")
        ->execute([$year, $quarter]);

    return ['ok' => true, 'sent_to' => count($techs), 'quarter' => $label];
}

/**
 * Label, colour class and icon for a checklist approval status.
 */
function pm_status_meta(string $status): array {
    return match (strtoupper($status)) {
        'APPROVED' => ['label' => 'Approved',         'class' => 'is-good',     'icon' => 'bi-check2-circle'],
        'REJECTED' => ['label' => 'Rejected',         'class' => 'is-bad',      'icon' => 'bi-x-circle'],
        default    => ['label' => 'Pending Approval', 'class' => 'is-critical', 'icon' => 'bi-hourglass-split'],
    };
}

/**
 * Render the approval-status pill used by the PM pages.
 */
function pm_status_badge(string $status): string {
    $meta = pm_status_meta($status);
    return '<span class="pm-status ' . $meta['class'] . '">'
         . '<i class="bi ' . $meta['icon'] . '"></i> ' . e($meta['label'])
         . '</span>';
}

/**
 * Number of checklists waiting for the Branch Manager.
 */
function pm_pending_approvals_count(): int {
    try {
        return (int)db()->query("SELECT COUNT(*) FROM pm_checklists WHERE status='PENDING'")
                        ->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}

/**
 * Tell the Branch Manager(s) that a checklist needs a decision.
 * Falls back to the administrators when no active Branch Manager exists, so a
 * submission can never wait for an approver who is not there.
 */
function pm_notify_approvers(int $checklistId, string $technicianName, string $quarterLabel): void {
    $pdo = db();
    $approvers = $pdo->query("SELECT id FROM users
                              WHERE role='BRANCH_MANAGER' AND status='ACTIVE'")->fetchAll();
    if (!$approvers) {
        $approvers = $pdo->query("SELECT id FROM users
                                  WHERE role='ADMIN' AND status='ACTIVE'")->fetchAll();
    }

    $title = "Preventive maintenance awaiting approval ({$quarterLabel})";
    $body  = "{$technicianName} submitted the {$quarterLabel} preventive maintenance checklist. "
           . "Review and approve it from PM Approvals.";
    foreach ($approvers as $a) {
        notify((int)$a['id'], null, $title, $body, 'pm');
    }
}

/**
 * Fetch department stats for reporting.
 */
function pm_report(int $year, int $quarter, ?int $departmentId = null): array {
    $pdo = db();
    $sql = "SELECT c.id, c.technician_name, c.department_id, c.checklist_date,
                   d.department_name,
                   COUNT(i.id) AS items_total,
                   SUM(i.done)  AS items_done
            FROM pm_checklists c
            LEFT JOIN departments d ON d.id = c.department_id
            LEFT JOIN pm_checklist_items i ON i.checklist_id = c.id
            WHERE c.year=? AND c.quarter=?";
    $params = [$year, $quarter];
    if ($departmentId) {
        $sql .= " AND c.department_id=?";
        $params[] = $departmentId;
    }
    $sql .= " GROUP BY c.id ORDER BY c.checklist_date DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}