<?php
$role    = $u['role'];
$current = basename($_SERVER['PHP_SELF']);

/* Branch Manager shares the Team Leader menu */
$isTeamRole = in_array($role, ['TEAM_LEADER', 'BRANCH_MANAGER'], true);

/* =====================================================
   Menu per role — flat list, no sections
   ===================================================== */
if ($role === 'ADMIN') {
    $menu = [
        ['dashboard.php',        'Dashboard',              'speedometer2'],
        ['users.php',            'Users',                  'people'],
        ['departments.php',      'Departments',            'building'],
        ['categories.php',       'Categories',             'tags'],
        ['priorities.php',       'Priorities',             'flag'],
        ['kpis.php',             'KPI Management',         'graph-up'],
        ['kpi_measurements.php', 'KPI Measurements',       'clipboard-data'],
        ['/ict/pm_approvals.php', 'PM Approvals',          'clipboard2-check'],
        ['tickets.php',          'All Tickets',            'ticket-detailed'],
        ['reports.php',          'Reports',                'file-earmark-bar-graph'],
        ['annual_report.php',    'Annual ICT Report',      'file-earmark-slides'],
        ['annual_plan_upload.php',     'Plan',           'cloud-arrow-up'],
        ['telegram.php',         'Telegram Bot',           'telegram'],
        ['audit_logs.php',       'Audit Logs',             'shield-check'],
        ['error_codes.php',      'Error Codes',            'bug'],
        ['settings.php',         'Settings',               'gear'],
    ];
    $root = BASE_URL . '/admin/';
} elseif ($isTeamRole) {
    $menu = [
        ['dashboard.php',     'Dashboard',            'speedometer2'],
        ['create_ticket.php', 'New Ticket',           'plus-circle'],
        ['approvals.php',     'Pending Approvals',    'check2-square'],
        ['/ict/pm_approvals.php', 'PM Approvals',      'clipboard2-check'],
        ['confirmations.php', 'My Confirmations',     'patch-check'],
        ['tickets.php',       'Team Tickets',         'ticket-detailed'],
        ['reports.php',       'Team Reports',         'file-earmark-bar-graph'],
        ['availability.php',  'My Availability',      'person-badge'],
    ];
    $root = BASE_URL . '/teamleader/';
} elseif ($role === 'ICT_STAFF') {
    $menu = [
        ['dashboard.php',              'Dashboard',                'speedometer2'],
        ['tickets.php',                'Approved Tickets',         'inbox'],
        ['assigned.php',               'Assigned to Me',           'person-check'],
        ['resolution.php',             'Resolved by Me',           'check2-circle'],
        ['preventive_maintenance.php', 'Preventive Maintenance',   'clipboard-check'],
    ];
    $root = BASE_URL . '/ict/';
} else {
    $menu = [
        ['dashboard.php',    'Dashboard',   'speedometer2'],
        ['create_ticket.php','New Ticket',  'plus-circle'],
        ['tickets.php',      'My Tickets',  'ticket-detailed'],
    ];
    $root = BASE_URL . '/employee/';
}

/* ---- Chat unread count ---- */
$chatUnread = 0;
if (!empty($u['id'])) {
    try {
        $s = db()->prepare("
            SELECT COUNT(*)
            FROM chat_messages m
            JOIN chat_participants cp
              ON cp.conversation_id = m.conversation_id
             AND cp.user_id = ?
            WHERE m.sender_id <> ?
              AND m.id > COALESCE(cp.last_read_at, 0)
        ");
        $s->execute([$u['id'], $u['id']]);
        $chatUnread = (int)$s->fetchColumn();
    } catch (Throwable $e) {
        $chatUnread = 0;
    }
}
/* ---- Own tickets awaiting the Team Leader's confirmation ---- */
$awaitingMyConfirm = 0;
if (($isTeamRole || $role === 'EMPLOYEE') && !empty($u['id'])) {
    try {
        $s = db()->prepare("SELECT COUNT(*) FROM tickets
                            WHERE requester_id = ? AND status IN " . awaiting_confirmation_sql_in());
        $s->execute([(int)$u['id']]);
        $awaitingMyConfirm = (int)$s->fetchColumn();
    } catch (Throwable $e) {
        $awaitingMyConfirm = 0;
    }
}
/* ---- PM checklists waiting for the Branch Manager (or an admin) ---- */
$pmPending = 0;
if (in_array($role, ['ADMIN', 'BRANCH_MANAGER'], true)) {
    try {
        $pmPending = (int)db()->query("SELECT COUNT(*) FROM pm_checklists WHERE status='PENDING'")
                              ->fetchColumn();
    } catch (Throwable $e) {
        $pmPending = 0;
    }
}
?>
<aside class="sidebar" id="sidebar">

  <!-- ============ Navigation ============ -->
  <nav class="sidebar-nav-wrap" aria-label="Main navigation">
    <ul class="sidebar-nav">
      <?php foreach ($menu as [$file, $label, $icon]):
          $href   = str_starts_with($file, '/') ? BASE_URL . $file : $root . $file;
          $active = $current === basename($file);
          $badge  = match ($file) {
              'confirmations.php'      => $awaitingMyConfirm,
              'tickets.php'            => $role === 'EMPLOYEE' ? $awaitingMyConfirm : 0,
              '/ict/pm_approvals.php'  => $pmPending,
              default                  => 0,
          };
      ?>
        <li class="sidebar-item">
          <a href="<?= $href ?>"
             class="<?= $active ? 'active' : '' ?>"
             title="<?= e($label) ?>">
            <span class="sidebar-item-icon">
              <i class="bi bi-<?= $icon ?>" aria-hidden="true"></i>
            </span>
            <span class="sidebar-item-label"><?= e($label) ?></span>
            <?php if ($badge > 0): ?>
              <span class="sidebar-badge"><?= $badge > 99 ? '99+' : $badge ?></span>
            <?php endif; ?>
          </a>
        </li>
      <?php endforeach; ?>

      <!-- ============ ICT Assistant (every role) ============ -->
      <li class="sidebar-item">
        <a href="<?= BASE_URL ?>/public/assistant.php"
           class="<?= $current === 'assistant.php' ? 'active' : '' ?>"
           title="ICT Assistant">
          <span class="sidebar-item-icon">
            <i class="bi bi-robot" aria-hidden="true"></i>
          </span>
          <span class="sidebar-item-label">ICT Assistant</span>
        </a>
      </li>

      <!-- ============ Live Chat (every role) ============ -->
      <li class="sidebar-item">
        <a href="<?= BASE_URL ?>/public/chat.php"
           class="<?= $current === 'chat.php' ? 'active' : '' ?>"
           title="Live Chat">
          <span class="sidebar-item-icon">
            <i class="bi bi-chat-dots" aria-hidden="true"></i>
          </span>
          <span class="sidebar-item-label">Live Chat</span>
          <?php if ($chatUnread > 0): ?>
            <span class="sidebar-badge" id="sidebarChatBadge">
              <?= $chatUnread > 99 ? '99+' : $chatUnread ?>
            </span>
          <?php else: ?>
            <span class="sidebar-badge d-none" id="sidebarChatBadge">0</span>
          <?php endif; ?>
        </a>
      </li>

      <!-- ============ Logout ============ -->
      <li class="sidebar-item">
        <a href="<?= BASE_URL ?>/public/logout.php" title="Logout">
          <span class="sidebar-item-icon">
            <i class="bi bi-box-arrow-right" aria-hidden="true"></i>
          </span>
          <span class="sidebar-item-label">Logout</span>
        </a>
      </li>
    </ul>
  </nav>

</aside>