<?php
/**
 * Team Leader auto-forward ("bypass") for pending approvals.
 * ---------------------------------------------------------------------------
 * If a Team Leader does not approve (or reject/return) a ticket within
 * TL_BYPASS_MINUTES, the ticket is forwarded to ICT automatically, exactly as
 * if it had been approved, and the Team Leader is told that the ticket went to
 * ICT on their team's behalf because they did not respond.
 *
 * The check is cheap and self-throttling (once a minute), so it can be called
 * from every authenticated page load and still work without a scheduler.
 * cron/approval_escalation.php calls it with $force for scheduled runs.
 * ---------------------------------------------------------------------------
 */

require_once __DIR__ . '/functions.php';

if (!function_exists('tl_bypass_minutes')) {
    /**
     * Minutes a ticket may wait for its Team Leader. Override with the
     * system setting `tl_bypass_minutes` (default 15).
     */
    function tl_bypass_minutes(): int
    {
        $minutes = (int) setting('tl_bypass_minutes', '15');
        return $minutes > 0 ? $minutes : 15;
    }
}

if (!function_exists('requester_confirm_minutes')) {
    /**
     * Minutes a requester has to confirm (or reject) an ICT resolution before
     * the ticket closes automatically. Override with the system setting
     * `requester_confirm_minutes` (default 30).
     */
    function requester_confirm_minutes(): int
    {
        $minutes = 0;

        /* system_settings is the table the rest of the app writes (tg_*, ...),
           so an admin can change the window there without code changes. */
        try {
            $st = db()->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'requester_confirm_minutes'");
            $st->execute();
            $minutes = (int) $st->fetchColumn();
        } catch (Throwable $e) {
            $minutes = 0;
        }

        if ($minutes <= 0) {
            $minutes = (int) setting('requester_confirm_minutes', '30');
        }

        return $minutes > 0 ? $minutes : 30;
    }
}

if (!function_exists('escalate_stale_confirmations')) {
    /**
     * Close tickets whose requester never confirmed the ICT resolution.
     *
     * The requester is told when ICT resolves a ticket; if they neither confirm
     * nor send it back within REQUESTER_CONFIRM_MINUTES (30 by default) the
     * ticket is confirmed and closed automatically — the same "the system acts
     * for you because you were silent" rule already used for Team Leaders.
     * Requester, Team Leader and technician are all told what happened.
     *
     * @return int number of tickets closed by this call
     */
    function escalate_stale_confirmations(bool $force = false): int
    {
        try {
            $pdo     = db();
            $minutes = requester_confirm_minutes();

            /* One sweep a minute, however many page loads or worker loops run. */
            if (!$force) {
                $st = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key='requester_confirm_last_run'");
                $st->execute();
                if (time() - (int)($st->fetchColumn() ?: 0) < 60) {
                    return 0;
                }
            }
            $pdo->prepare("INSERT INTO system_settings (setting_key, setting_value, description)
                           VALUES ('requester_confirm_last_run', ?, 'Last automatic confirmation sweep')
                           ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)")
                ->execute([(string) time()]);

            $stmt = $pdo->prepare("SELECT t.*, req.full_name AS requester_name
                FROM tickets t
                JOIN users req ON req.id = t.requester_id
                WHERE t.status IN " . awaiting_confirmation_sql_in() . "
                  AND COALESCE(t.resolved_at, t.created_at) <= DATE_SUB(NOW(), INTERVAL ? MINUTE)
                ORDER BY t.resolved_at
                LIMIT 50");
            $stmt->execute([$minutes]);
            $stale = $stmt->fetchAll();
            if (!$stale) {
                return 0;
            }

            $close = $pdo->prepare("UPDATE tickets
                SET status = 'CLOSED', closed_at = NOW(), verification_comment = ?
                WHERE id = ? AND status IN " . awaiting_confirmation_sql_in());

            $closed = 0;

            foreach ($stale as $t) {
                $ticketId = (int) $t['id'];
                $note = "Confirmed automatically: the requester did not respond within {$minutes} minutes, "
                      . "so the ticket was closed on their behalf.";

                /* Only the caller that flips the status notifies. */
                $close->execute([$note, $ticketId]);
                if ($close->rowCount() !== 1) {
                    continue;
                }

                $closed++;

                record_history(
                    $ticketId,
                    (int) $t['requester_id'],
                    (string) $t['status'],
                    'CLOSED',
                    'Auto-confirmed and closed (no requester response)',
                    $note
                );

                notify(
                    (int) $t['requester_id'],
                    $ticketId,
                    'Ticket Closed Automatically',
                    "You did not confirm the fix on {$t['ticket_number']} within {$minutes} minutes, "
                      . "so the ticket was closed automatically. If the problem returns, open a new ticket "
                      . "or contact ICT.",
                    'warning'
                );

                /* A Team Leader who raised the ticket is the requester: he was already told above. */
                $tlIsOther = !empty($t['team_leader_id'])
                          && (int) $t['team_leader_id'] !== (int) $t['requester_id'];

                if ($tlIsOther) {
                    notify(
                        (int) $t['team_leader_id'],
                        $ticketId,
                        'Ticket Closed (no requester response)',
                        "{$t['ticket_number']} was closed automatically: {$t['requester_name']} did not "
                          . "confirm the fix within {$minutes} minutes.",
                        'info'
                    );
                }

                if (!empty($t['assigned_technician_id'])) {
                    notify(
                        (int) $t['assigned_technician_id'],
                        $ticketId,
                        'Ticket Closed Automatically',
                        "{$t['ticket_number']} was closed automatically — {$t['requester_name']} did not "
                          . "confirm the fix within {$minutes} minutes.",
                        'success'
                    );
                }

                /* Telegram -> requester, technician and Team Leader. */
                try {
                    require_once __DIR__ . '/telegram.php';
                    $requester = (string) ($t['requester_name'] ?? '');

                    telegram_notify_user(
                        (int) $t['requester_id'],
                        tg_msg_auto_closed($t, $requester, $minutes, 'requester'),
                        $ticketId
                    );
                    if (!empty($t['assigned_technician_id'])) {
                        telegram_notify_user(
                            (int) $t['assigned_technician_id'],
                            tg_msg_auto_closed($t, $requester, $minutes, 'technician'),
                            $ticketId
                        );
                    }
                    if ($tlIsOther) {
                        telegram_notify_user(
                            (int) $t['team_leader_id'],
                            tg_msg_auto_closed($t, $requester, $minutes, 'teamleader'),
                            $ticketId
                        );
                    }
                } catch (Throwable $e) {
                    error_log('TG auto-confirm: ' . $e->getMessage());
                }

                audit('AUTO_CONFIRM', 'tickets', $ticketId,
                      "Auto-closed {$t['ticket_number']} after {$minutes} minutes without requester confirmation");
            }

            return $closed;
        } catch (Throwable $e) {
            error_log('escalate_stale_confirmations: ' . $e->getMessage());
            return 0;
        }
    }
}

if (!function_exists('escalate_stale_approvals')) {
    /**
     * Forward every ticket that has waited too long for Team Leader approval.
     *
     * @return int number of tickets forwarded by this call
     */
    function escalate_stale_approvals(bool $force = false): int
    {
        try {
            $pdo     = db();
            $minutes = tl_bypass_minutes();

            /* Throttle: at most one sweep a minute, no matter how many page
               loads happen. A missing row means "never run". */
            if (!$force) {
                $st = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key='tl_bypass_last_run'");
                $st->execute();
                if (time() - (int)($st->fetchColumn() ?: 0) < 60) {
                    return 0;
                }
            }
            $pdo->prepare("INSERT INTO system_settings (setting_key, setting_value, description)
                           VALUES ('tl_bypass_last_run', ?, 'Last Team Leader auto-forward sweep')
                           ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)")
                ->execute([(string) time()]);

            $stmt = $pdo->prepare("SELECT t.*, req.full_name AS requester_name
                FROM tickets t
                JOIN users req ON req.id = t.requester_id
                WHERE t.status = 'PENDING_TEAM_LEADER_APPROVAL'
                  AND t.created_at <= DATE_SUB(NOW(), INTERVAL ? MINUTE)
                ORDER BY t.created_at
                LIMIT 50");
            $stmt->execute([$minutes]);
            $stale = $stmt->fetchAll();
            if (!$stale) {
                return 0;
            }

            $icts = $pdo->query("SELECT id FROM users WHERE role='ICT_STAFF' AND status='ACTIVE'")
                        ->fetchAll();

            $icUpdate = $pdo->prepare("UPDATE tickets
                SET status = 'APPROVED_FOR_ICT', team_leader_approved_at = NOW()
                WHERE id = ? AND status = 'PENDING_TEAM_LEADER_APPROVAL'");

            $forwarded = 0;

            foreach ($stale as $t) {
                $ticketId = (int) $t['id'];

                /* Only the caller that actually flips the status notifies, so a
                   concurrent sweep or a real approval can never double-send. */
                $icUpdate->execute([$ticketId]);
                if ($icUpdate->rowCount() !== 1) {
                    continue;
                }

                $forwarded++;

                record_history(
                    $ticketId,
                    (int) $t['team_leader_id'],
                    'PENDING_TEAM_LEADER_APPROVAL',
                    'APPROVED_FOR_ICT',
                    'Auto-forwarded to ICT (no Team Leader response)',
                    "No approval within {$minutes} minutes — the ticket was forwarded to ICT on the team's behalf."
                );

                notify(
                    (int) $t['team_leader_id'],
                    $ticketId,
                    'Ticket Forwarded to ICT',
                    "You did not respond to {$t['ticket_number']} within {$minutes} minutes, so it was approved "
                      . "for your team automatically and sent to ICT. Please review it on your Team Tickets page.",
                    'warning'
                );

                foreach ($icts as $ict) {
                    notify(
                        (int) $ict['id'],
                        $ticketId,
                        'Ticket Approved (auto)',
                        "Ticket {$t['ticket_number']} was forwarded to ICT without Team Leader approval after {$minutes} minutes.",
                        'approval'
                    );
                }

                /* Telegram -> Team Leader (why it moved) and ICT (pick it up). */
                try {
                    require_once __DIR__ . '/telegram.php';
                    telegram_notify_user(
                        (int) $t['team_leader_id'],
                        tg_msg_bypassed($t, (string) ($t['requester_name'] ?? ''), $minutes),
                        $ticketId
                    );
                    telegram_notify_ict(
                        tg_msg_approved($t, 'Team Leader (auto-forward)',
                                        (string) ($t['requester_name'] ?? ''),
                                        "No Team Leader response within {$minutes} minutes."),
                        $ticketId
                    );
                } catch (Throwable $e) { error_log('TG bypass: ' . $e->getMessage()); }

                audit('AUTO_FORWARD', 'tickets', $ticketId,
                      "Auto-forwarded {$t['ticket_number']} to ICT after {$minutes} minutes");
            }

            return $forwarded;
        } catch (Throwable $e) {
            error_log('escalate_stale_approvals: ' . $e->getMessage());
            return 0;
        }
    }
}
