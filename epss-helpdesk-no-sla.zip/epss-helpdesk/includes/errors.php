<?php
declare(strict_types=1);

/**
 * includes/errors.php
 * ---------------------------------------------------------------------------
 * Central error-code registry for the EPSS Helpdesk.
 *
 * Every failure the user can see carries a code of the form
 *
 *     E-<AREA>-<NNN>        e.g.  E-TKT-409
 *
 * AREA says which part of the system failed (AUTH, REQ, TKT, CNF, UPL, DB ...)
 * and NNN is unique inside that area. Where an HTTP status fits naturally the
 * number mirrors it (E-TKT-404 = 404, E-REQ-419 = 419 ...), so the code alone
 * tells a user, a technician and the administrator what kind of problem it is.
 *
 * Usage
 * -----
 *   throw new AppError('E-TKT-409');                    // friendly default text
 *   throw new AppError('E-TKT-409', 'Custom detail.');  // custom text, same code
 *   app_fail('E-TKT-404');                              // render error page and exit
 *   $msg = app_exception_message($e);                   // "[E-DB-501] ... (ref R...)"
 *
 * Problems that are the system's fault (HTTP 5xx, database errors, unexpected
 * exceptions) are written to logs/app_errors.log with a short reference id that
 * is shown to the user; the administrator finds the full details by that id on
 * Admin -> Error Codes. Raw SQL / exception text is never shown to users.
 * ---------------------------------------------------------------------------
 */

if (!function_exists('app_error_areas')) {
    /** Area prefix => human label. */
    function app_error_areas(): array
    {
        return [
            'AUTH' => 'Sign-in & permissions',
            'REQ'  => 'Request / form',
            'VAL'  => 'Validation',
            'TKT'  => 'Ticket workflow (ICT)',
            'CNF'  => 'Requester confirmation',
            'UPL'  => 'File upload',
            'PM'   => 'Preventive maintenance',
            'USR'  => 'Users & profile',
            'RPT'  => 'Reports & export',
            'DB'   => 'Database',
            'SYS'  => 'System',
        ];
    }
}

if (!function_exists('app_error_registry')) {
    /**
     * code => [http, title, message, hint]
     * message = default text shown to the user; hint = what to do next.
     */
    function app_error_registry(): array
    {
        return [
            /* ---- AUTH ---------------------------------------------------- */
            'E-AUTH-401' => [401, 'Sign-in required',
                'You need to sign in to continue.',
                'Sign in again - your session may have expired.'],
            'E-AUTH-403' => [403, 'Access denied',
                'Your account does not have permission to open this page.',
                'Ask an administrator to check your role if you think this is a mistake.'],
            'E-AUTH-406' => [403, 'Permission missing',
                'Your role is not allowed to perform this action.',
                'Ask an administrator to check your role.'],

            /* ---- REQ (request / form) ------------------------------------ */
            'E-REQ-400' => [400, 'Bad request',
                'The request is incomplete or contains an invalid value.',
                'Go back and use the buttons on the page instead of editing the address.'],
            'E-REQ-419' => [419, 'Security token expired',
                'Your form expired or could not be verified. Reload the page and try again.',
                'This happens when a page stays open for a long time or the session ended.'],
            'E-REQ-422' => [422, 'Missing or invalid input',
                'Some required information is missing or invalid.',
                'Check the highlighted fields and submit again.'],

            /* ---- VAL (generic validation raised by pages) ---------------- */
            'E-VAL-422' => [422, 'Validation failed',
                'The information you entered was rejected.',
                'Correct the value described in the message and try again.'],

            /* ---- TKT (ICT workflow) -------------------------------------- */
            'E-TKT-404' => [404, 'Ticket not found',
                'That ticket does not exist or you do not have access to it.',
                'Open the ticket from your own ticket list.'],
            'E-TKT-409' => [409, 'Action not allowed in this status',
                'This action is not available for the ticket in its current status.',
                'Reload the ticket - someone may already have moved it on.'],
            'E-TKT-422' => [422, 'Resolution note required',
                'Describe the work you performed before marking the ticket as resolved.',
                'Fill in "Action Taken" so the requester knows what was done.'],
            'E-TKT-423' => [409, 'Ticket belongs to another technician',
                'This ticket is assigned to another technician.',
                'Ask them, or any ICT colleague, to assign it to you first.'],
            'E-TKT-424' => [422, 'Invalid technician',
                'The selected person is not an active ICT technician.',
                'Pick a technician from the list.'],
            'E-TKT-428' => [428, 'Accept the ticket first',
                'Accept the ticket before you work on it or mark it as resolved.',
                'Press "Accept Ticket" - the request then shows as In Progress for the requester.'],

            /* ---- CNF (requester confirmation) ---------------------------- */
            'E-CNF-403' => [403, 'Only the requester can confirm',
                'Only the person who raised this ticket can confirm or reject its resolution.',
                'Ask the requester to confirm from their own account.'],
            'E-CNF-409' => [409, 'Not awaiting confirmation',
                'This ticket is not awaiting confirmation. It may already be closed or sent back to ICT.',
                'Reload the ticket to see its current status.'],
            'E-CNF-422' => [422, 'Reason required',
                'Please tell us why the issue is not resolved.',
                'Describe what is still wrong so ICT can continue.'],

            /* ---- UPL (file upload) --------------------------------------- */
            'E-UPL-400' => [400, 'Upload failed',
                'The file could not be uploaded.',
                'Try again. If it keeps failing, use a smaller file.'],
            'E-UPL-413' => [413, 'File too large or empty',
                'The file is empty or larger than the allowed size.',
                'Compress the file or choose another one.'],
            'E-UPL-415' => [415, 'File type not allowed',
                'This type of file is not allowed.',
                'Use a common document, image or archive format (see Settings -> allowed extensions).'],
            'E-UPL-500' => [500, 'Could not store the file',
                'The server could not save the uploaded file.',
                'Administrator: check that uploads/tickets exists and is writable.'],

            /* ---- PM ------------------------------------------------------- */
            'E-PM-404'  => [404, 'Checklist not found',
                'The preventive maintenance checklist was not found.',
                'Open it from the Preventive Maintenance list.'],

            /* ---- USR ------------------------------------------------------ */
            'E-USR-404' => [404, 'Profile not found',
                'The user profile was not found.',
                'Sign out and sign in again.'],

            /* ---- RPT ------------------------------------------------------ */
            'E-RPT-500' => [500, 'Report could not be generated',
                'The report could not be generated. The details were logged.',
                'Try again; if it repeats, give the reference to the administrator.'],
            'E-RPT-501' => [501, 'PDF library missing',
                'PDF export needs the Dompdf library, which is not installed.',
                'Administrator: run "composer require dompdf/dompdf".'],

            /* ---- DB ------------------------------------------------------- */
            'E-DB-500'  => [500, 'Database unavailable',
                'The system cannot reach its database. Please contact the administrator.',
                'Administrator: check that MySQL is running and config/database.php is correct.'],
            'E-DB-501'  => [500, 'Database error',
                'A database error occurred. The details were logged for the administrator.',
                'Try again; if it repeats, give the reference to the administrator.'],

            /* ---- SYS ------------------------------------------------------ */
            'E-SYS-500' => [500, 'Unexpected error',
                'Something went wrong on our side. The details were logged for the administrator.',
                'Try again; if it repeats, give the reference to the administrator.'],
        ];
    }
}

if (!function_exists('app_error_def')) {
    /**
     * Definition of one code as an associative array; unknown codes fall back
     * to E-SYS-500 so a typo can never produce a blank error.
     *
     * @return array{code:string,http:int,title:string,message:string,hint:string}
     */
    function app_error_def(string $code): array
    {
        $reg = app_error_registry();
        if (!isset($reg[$code])) {
            $code = 'E-SYS-500';
        }
        [$http, $title, $message, $hint] = $reg[$code];
        return [
            'code'    => $code,
            'http'    => (int)$http,
            'title'   => $title,
            'message' => $message,
            'hint'    => $hint,
        ];
    }
}

if (!class_exists('AppError')) {
    /**
     * An error with a registered code. Throw it from anywhere; pages show
     * app_exception_message($e), or let it bubble up to the global handler,
     * which renders the error page.
     */
    class AppError extends RuntimeException
    {
        private string $errCode;

        public function __construct(string $errCode, string $detail = '', ?Throwable $previous = null)
        {
            $def = app_error_def($errCode);
            parent::__construct($detail !== '' ? $detail : $def['message'], $def['http'], $previous);
            $this->errCode = $def['code'];
        }

        public function errorCode(): string
        {
            return $this->errCode;
        }
    }
}

/* =====================================================================
 * Logging
 * ===================================================================== */

if (!function_exists('app_error_log_file')) {
    function app_error_log_file(): string
    {
        return __DIR__ . '/../logs/app_errors.log';
    }
}

if (!function_exists('app_error_ref')) {
    /** Short reference id the user can quote, e.g. R261110-143502-A3F9. */
    function app_error_ref(): string
    {
        try {
            $rand = strtoupper(bin2hex(random_bytes(2)));
        } catch (Throwable $e) {
            $rand = strtoupper(dechex(mt_rand(4096, 65535)));
        }
        return 'R' . date('ymd-His') . '-' . $rand;
    }
}

if (!function_exists('app_error_log')) {
    /**
     * Append one JSON line to logs/app_errors.log and mirror it to the PHP
     * error log. Never throws. Returns the reference id.
     */
    function app_error_log(string $code, string $detail = '', ?Throwable $e = null): string
    {
        $ref = app_error_ref();

        $entry = [
            't'      => date('Y-m-d H:i:s'),
            'ref'    => $ref,
            'code'   => $code,
            'user'   => (int)($_SESSION['user_id'] ?? 0),
            'role'   => (string)($_SESSION['role'] ?? ''),
            'url'    => mb_substr((string)($_SERVER['REQUEST_URI'] ?? (PHP_SAPI === 'cli' ? 'cli' : '')), 0, 300),
            'detail' => mb_substr(str_replace(["\r", "\n"], ' ', $detail), 0, 1000),
            'exc'    => $e ? get_class($e) : '',
            'where'  => $e ? basename($e->getFile()) . ':' . $e->getLine() : '',
            'msg'    => $e ? mb_substr(str_replace(["\r", "\n"], ' ', $e->getMessage()), 0, 1000) : '',
        ];

        try {
            $file = app_error_log_file();
            $dir  = dirname($file);
            if (!is_dir($dir)) {
                @mkdir($dir, 0775, true);
            }
            if (is_file($file) && @filesize($file) > 2 * 1024 * 1024) {   // rotate at 2 MB
                @rename($file, $file . '.1');
            }
            @file_put_contents($file, json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n",
                FILE_APPEND | LOCK_EX);
        } catch (Throwable $ignore) {
            /* logging must never break the request */
        }

        error_log(sprintf('[%s] %s %s %s', $code, $ref, $entry['detail'], $entry['msg']));
        return $ref;
    }
}

if (!function_exists('app_error_log_tail')) {
    /**
     * Most recent entries of the error log, newest first.
     *
     * @return array<int,array<string,mixed>>
     */
    function app_error_log_tail(int $max = 200): array
    {
        $file = app_error_log_file();
        if (!is_file($file) || !is_readable($file)) {
            return [];
        }
        $lines = @file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
        $lines = array_slice($lines, -$max);

        $out = [];
        foreach (array_reverse($lines) as $line) {
            $row = json_decode($line, true);
            if (is_array($row)) {
                $out[] = $row;
            }
        }
        return $out;
    }
}

/* =====================================================================
 * Turning exceptions into coded messages
 * ===================================================================== */

if (!function_exists('app_exception_info')) {
    /**
     * Classify any Throwable.
     *
     *  - AppError                     -> its own code (logged when HTTP >= 500)
     *  - PDOException                 -> E-DB-501, SQL text hidden, logged
     *  - RuntimeException & friends   -> E-VAL-422, the message is shown as written
     *                                    (the app throws these with user-friendly text)
     *  - anything else (TypeError ...) -> E-SYS-500, hidden, logged
     *
     * @return array{code:string,http:int,title:string,message:string,hint:string,ref:?string,detail:string}
     */
    function app_exception_info(Throwable $e): array
    {
        $ref = null;

        if ($e instanceof AppError) {
            $def = app_error_def($e->errorCode());
            if ($def['http'] >= 500) {
                $ref = app_error_log($def['code'], $e->getMessage(), $e);
            }
            $def['message'] = $e->getMessage();
            return $def + ['ref' => $ref, 'detail' => $e->getMessage()];
        }

        if ($e instanceof PDOException) {
            $def = app_error_def('E-DB-501');
            $ref = app_error_log($def['code'], 'SQL error', $e);
            return $def + ['ref' => $ref, 'detail' => $e->getMessage()];
        }

        if ($e instanceof RuntimeException
            || $e instanceof InvalidArgumentException
            || $e instanceof DomainException) {
            $def = app_error_def('E-VAL-422');
            $def['message'] = $e->getMessage() !== '' ? $e->getMessage() : $def['message'];
            return $def + ['ref' => null, 'detail' => $e->getMessage()];
        }

        $def = app_error_def('E-SYS-500');
        $ref = app_error_log($def['code'], 'Unhandled ' . get_class($e), $e);
        return $def + ['ref' => $ref, 'detail' => $e->getMessage()];
    }
}

if (!function_exists('app_exception_message')) {
    /**
     * One-line, user-safe text for inline alerts:
     *   "[E-TKT-409] This action is not available ... "
     *   "[E-DB-501] A database error occurred ... (ref R261110-143502-A3F9)"
     * Replaces the old raw-message pattern in page catch blocks (which could expose SQL).
     */
    function app_exception_message(Throwable $e): string
    {
        $info = app_exception_info($e);
        $text = '[' . $info['code'] . '] ' . $info['message'];
        if (!empty($info['ref'])) {
            $text .= ' (ref ' . $info['ref'] . ')';
        }
        return $text;
    }
}

if (!function_exists('app_error_text')) {
    /** "[CODE] message" for a registered code without throwing anything. */
    function app_error_text(string $code, string $detail = ''): string
    {
        $def = app_error_def($code);
        return '[' . $def['code'] . '] ' . ($detail !== '' ? $detail : $def['message']);
    }
}

/* =====================================================================
 * Rendering
 * ===================================================================== */

if (!function_exists('app_wants_json')) {
    function app_wants_json(): bool
    {
        $uri = (string)($_SERVER['SCRIPT_NAME'] ?? '');
        if (strpos($uri, '/api/') !== false) {
            return true;
        }
        $accept = (string)($_SERVER['HTTP_ACCEPT'] ?? '');
        if (stripos($accept, 'application/json') !== false && stripos($accept, 'text/html') === false) {
            return true;
        }
        return strcasecmp((string)($_SERVER['HTTP_X_REQUESTED_WITH'] ?? ''), 'XMLHttpRequest') === 0
            || (($_GET['format'] ?? '') === 'json');
    }
}

if (!function_exists('app_error_render')) {
    /**
     * Output an error page (or JSON for API calls) for an info array produced
     * by app_exception_info() / app_error_def(), then stop.
     */
    function app_error_render(array $info): void
    {
        $code  = (string)$info['code'];
        $http  = (int)$info['http'];
        $title = (string)$info['title'];
        $msg   = (string)$info['message'];
        $hint  = (string)($info['hint'] ?? '');
        $ref   = (string)($info['ref'] ?? '');
        $isAdmin = (($_SESSION['role'] ?? '') === 'ADMIN');
        $detail  = $isAdmin ? (string)($info['detail'] ?? '') : '';

        if (PHP_SAPI === 'cli') {
            fwrite(STDERR, "[$code] $msg" . ($ref !== '' ? " (ref $ref)" : '') . PHP_EOL);
            exit(1);
        }

        if (!headers_sent()) {
            http_response_code($http > 0 ? $http : 500);
        }

        /* ---- JSON (API / AJAX) ---------------------------------------- */
        if (app_wants_json()) {
            if (!headers_sent()) {
                header('Content-Type: application/json; charset=utf-8');
            }
            /* "error" stays a string so existing front-end code keeps working;
               "code" and "ref" are new siblings. */
            echo json_encode([
                'ok'    => false,
                'error' => '[' . $code . '] ' . $msg,
                'code'  => $code,
                'ref'   => $ref !== '' ? $ref : null,
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $h = static fn(string $s): string => htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $base = defined('BASE_URL') ? (string)BASE_URL : '';

        /* ---- Output already started (error in the middle of a page): small inline alert ---- */
        if (headers_sent()) {
            echo '<div style="margin:1rem;padding:.9rem 1.1rem;border-left:4px solid #aa0808;background:#fef4f4;'
               . 'color:#1d2d3e;font:14px Arial,sans-serif;border-radius:.4rem">'
               . '<strong>[' . $h($code) . '] ' . $h($title) . '</strong><br>' . $h($msg)
               . ($ref !== '' ? '<br><small>Reference: ' . $h($ref) . '</small>' : '')
               . '</div>';
            exit;
        }

        $tone = $http >= 500 ? '#aa0808' : ($http === 403 || $http === 401 ? '#aa0808' : '#e76500');
        $bg   = $http >= 500 || $http === 403 || $http === 401 ? '#fef4f4' : '#fff8f1';
        $icon = $http >= 500 ? 'bi-exclamation-octagon-fill'
              : ($http === 403 || $http === 401 ? 'bi-shield-lock-fill' : 'bi-exclamation-triangle-fill');
        ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= $h($code) ?> - <?= $h($title) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body { font-family:"72","72full",Arial,Helvetica,sans-serif; background:#f5f6f7; color:#1d2d3e;
           display:flex; align-items:center; justify-content:center; min-height:100vh; padding:1.5rem; }
    .box { background:#fff; border-radius:.75rem; padding:2.25rem 2rem; max-width:520px; width:100%; text-align:center;
           box-shadow:0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06); }
    .icon { width:64px; height:64px; border-radius:50%; display:inline-flex; align-items:center;
            justify-content:center; font-size:2rem; margin-bottom:1rem; background:<?= $bg ?>; color:<?= $tone ?>; }
    .code { display:inline-block; font-family:"72Mono","Courier New",monospace; font-weight:600; font-size:.85rem;
            padding:.2rem .65rem; border-radius:.75rem; background:<?= $bg ?>; color:<?= $tone ?>;
            border:1px solid <?= $tone ?>33; margin-bottom:.6rem; }
    h1 { font-size:1.25rem; font-weight:600; margin:0 0 .5rem; }
    p  { color:#556b82; font-size:.9rem; margin:0 0 .75rem; }
    .hint { font-size:.8rem; background:#f5f6f7; border-radius:.5rem; padding:.55rem .75rem; margin-bottom:1rem; color:#556b82; }
    .ref  { font-size:.75rem; color:#556b82; margin-bottom:1rem; }
    .ref code { color:#1d2d3e; }
    details { text-align:left; font-size:.75rem; color:#556b82; margin-bottom:1rem; }
    .btn-primary { background:#0070f2; border-color:#0070f2; border-radius:.5rem; padding:.55rem 1.1rem; font-size:.875rem; }
    .btn-primary:hover { background:#0057d2; border-color:#0057d2; }
  </style>
</head>
<body>
  <div class="box">
    <div class="icon"><i class="bi <?= $icon ?>"></i></div><br>
    <span class="code"><?= $h($code) ?></span>
    <h1><?= $h($title) ?></h1>
    <p><?= $h($msg) ?></p>
    <?php if ($hint !== ''): ?><div class="hint"><i class="bi bi-lightbulb"></i> <?= $h($hint) ?></div><?php endif; ?>
    <?php if ($ref !== ''): ?>
      <div class="ref">Reference: <code><?= $h($ref) ?></code> &mdash; quote this when you contact ICT.</div>
    <?php endif; ?>
    <?php if ($detail !== ''): ?>
      <details><summary>Technical detail (administrators only)</summary><code><?= $h($detail) ?></code></details>
    <?php endif; ?>
    <a href="javascript:history.back()" class="btn btn-outline-secondary btn-sm me-1"><i class="bi bi-arrow-left"></i> Back</a>
    <a href="<?= $h($base) ?>/public/index.php" class="btn btn-primary"><i class="bi bi-house-door"></i> Dashboard</a>
  </div>
</body>
</html>
        <?php
        exit;
    }
}

if (!function_exists('app_fail')) {
    /**
     * Stop the request with a coded error page (or JSON for API calls).
     *
     *   app_fail('E-TKT-404');
     *   app_fail('E-TKT-409', 'Custom text shown to the user for this case');
     *   app_fail('E-DB-500', '', $pdoException);     // logs $pdoException
     *
     * $detail replaces the default user-facing text. Codes with HTTP >= 500, or
     * any call that passes an exception, are written to logs/app_errors.log and
     * the page shows the reference id; administrators also see the exception text.
     */
    function app_fail(string $code, string $detail = '', ?Throwable $e = null): void
    {
        $def = app_error_def($code);
        $ref = null;
        if ($e !== null || $def['http'] >= 500) {
            $ref = app_error_log($def['code'], $detail, $e);
        }
        $tech = $e !== null ? $e->getMessage() : '';
        if ($detail !== '') {
            $def['message'] = $detail;
        }
        app_error_render($def + ['ref' => $ref, 'detail' => $tech !== '' ? $tech : $detail]);
    }
}

/* =====================================================================
 * Global handler: an exception nobody caught becomes a coded page
 * instead of a blank screen or a stack trace. Web requests only.
 * ===================================================================== */

if (PHP_SAPI !== 'cli' && !defined('APP_ERROR_HANDLER_SET')) {
    define('APP_ERROR_HANDLER_SET', true);
    set_exception_handler(static function (Throwable $e): void {
        $info = app_exception_info($e);
        app_error_render($info);
    });
}
