<?php
declare(strict_types=1);
/**
 * includes/functions.php
 *
 * Central helper library. Every function below is guarded with
 * function_exists() so that if the project already defines a helper
 * elsewhere (e.g. auth.php), that version keeps precedence.
 *
 * NOTE: db() is defined ONLY here. config/database.php must just
 * return a configuration array (no functions).
 */

/* Coded errors (AppError, app_fail(), app_exception_message()) */
require_once __DIR__ . '/errors.php';

/* =====================================================================
 * Database
 * ===================================================================== */

if (!function_exists('db')) {
    /**
     * Shared PDO handle.
     *
     * Reads ../config/database.php (which returns an array). If a key is
     * missing it falls back to DB_* constants, then to safe defaults.
     *
     * @param bool $reconnect Pass true to drop the cached connection and
     *                        open a new one (useful for long-running workers).
     */
    function db(bool $reconnect = false): PDO
    {
        static $pdo = null;

        if ($reconnect) {
            $pdo = null;
        }
        if ($pdo instanceof PDO) {
            return $pdo;
        }

        // ---- Load config ------------------------------------------------
        $cfgFile = __DIR__ . '/../config/database.php';
        $cfg     = [];

        if (is_file($cfgFile)) {
            $loaded = require $cfgFile;
            if (is_array($loaded)) {
                $cfg = $loaded;
            }
        }

        $host    = $cfg['host']    ?? (defined('DB_HOST')    ? DB_HOST    : '127.0.0.1');
        $port    = (int)($cfg['port'] ?? (defined('DB_PORT') ? DB_PORT    : 3306));
        $name    = $cfg['name']    ?? $cfg['database']
                                   ?? (defined('DB_NAME')    ? DB_NAME    : 'epss_adama_helpdesk');
        $user    = $cfg['user']    ?? (defined('DB_USER')    ? DB_USER    : 'root');
        $pass    = $cfg['pass']    ?? $cfg['password']
                                   ?? (defined('DB_PASS')    ? DB_PASS    : '');
        $charset = $cfg['charset'] ?? (defined('DB_CHARSET') ? DB_CHARSET : 'utf8mb4');

        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=%s',
            $host,
            $port,
            $name,
            $charset
        );

        try {
            $pdo = new PDO($dsn, $user, $pass, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            // Real reason goes to logs/app_errors.log; the user sees E-DB-500 and a reference.
            app_fail('E-DB-500', '', $e);
        }

        return $pdo;
    }
}

/* =====================================================================
 * Escaping & output
 * ===================================================================== */

if (!function_exists('e')) {
    function e($value): string
    {
        return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

if (!function_exists('redirect')) {
    function redirect(string $url): void
    {
        header('Location: ' . $url);
        exit;
    }
}

/* =====================================================================
 * CSRF
 * ===================================================================== */

if (!function_exists('csrf_token')) {
    function csrf_token(): string
    {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
}

if (!function_exists('verify_csrf')) {
    function verify_csrf(?string $token): bool
    {
        return is_string($token)
            && !empty($_SESSION['csrf_token'])
            && hash_equals($_SESSION['csrf_token'], $token);
    }
}

/* =====================================================================
 * Auth / current user
 * ===================================================================== */

/*
 * current_user(), require_login() and require_role() are defined in
 * includes/auth.php (the single source of truth). Do not redefine them here.
 */

/* =====================================================================
 * Settings cache
 * ===================================================================== */

if (!function_exists('setting')) {
    function setting(string $key, $default = null)
    {
        static $cache = null;
        if ($cache === null) {
            $cache = [];
            try {
                foreach (db()->query("SELECT setting_key, setting_value FROM system_settings") as $r) {
                    $cache[$r['setting_key']] = $r['setting_value'];
                }
            } catch (Throwable $e) {
                $cache = [];
            }
        }
        return $cache[$key] ?? $default;
    }
}

/* =====================================================================
 * Flash messages
 * ===================================================================== */

if (!function_exists('flash')) {
    /**
     * flash('success', 'Saved.');   // set
     * $msg = flash('success');      // read & clear
     */
    function flash(string $key, ?string $value = null)
    {
        if ($value !== null) {
            $_SESSION['flash'][$key] = $value;
            return null;
        }
        $out = $_SESSION['flash'][$key] ?? null;
        unset($_SESSION['flash'][$key]);
        return $out;
    }
}

/* =====================================================================
 * Form "old input" helper
 * ===================================================================== */

if (!function_exists('old')) {
    function old(string $key, $default = '')
    {
        return $_SESSION['old'][$key] ?? $default;
    }
}

/* =====================================================================
 * Notifications
 * ===================================================================== */

if (!function_exists('notify')) {
    /**
     * Insert a notification row.
     *
     * notify($userId, $refId, $title, $body = '', $type = 'info')
     *
     * $refId is what the pages pass as the 2nd argument: the TICKET id. It is
     * stored in notifications.ticket_id when that column exists, otherwise in
     * notifications.from_user_id. Never throws, so a notification problem
     * cannot break the request.
     */
    function notify(?int $userId, ?int $refId, string $title, string $body = '', string $type = 'info'): void
    {
        if ($userId === null || $userId <= 0) {
            return;
        }
        try {
            $cols = table_columns('notifications');
            if (!$cols) {
                error_log('notify(): notifications table not found');
                return;
            }

            $map = ['user_id' => $userId];
            if (in_array('ticket_id', $cols, true)) {
                $map['ticket_id'] = $refId;
            } elseif (in_array('from_user_id', $cols, true)) {
                $map['from_user_id'] = $refId;
            }
            if (in_array('title', $cols, true)) {
                $map['title'] = $title;
            }
            if (in_array('body', $cols, true)) {
                $map['body'] = $body !== '' ? $body : null;
            } elseif (in_array('message', $cols, true)) {
                $map['message'] = $body !== '' ? $body : $title;
            }
            if (in_array('type', $cols, true)) {
                $map['type'] = $type;
            }
            if (in_array('is_read', $cols, true)) {
                $map['is_read'] = 0;
            }

            $names = array_keys($map);
            $marks = array_fill(0, count($names), '?');
            if (in_array('created_at', $cols, true)) {
                $names[] = 'created_at';
                $marks[] = 'NOW()';
            }

            db()->prepare(sprintf(
                'INSERT INTO notifications (%s) VALUES (%s)',
                implode(',', array_map(static fn($n) => "`$n`", $names)),
                implode(',', $marks)
            ))->execute(array_values($map));
        } catch (Throwable $e) {
            error_log('notify() failed: ' . $e->getMessage());
        }
    }
}

/* =====================================================================
 * AUDIT
 * ===================================================================== */

if (!function_exists('audit')) {
    /**
     * Record an audit event.
     *
     *   audit(string $action, string $module, $recordId = null, string $description = '')
     *
     * - $recordId is the entity id (ticket id, user id, PM checklist id) or 0/null
     *   for global events (e.g. Settings changes).
     * - The acting user is resolved automatically from the current session.
     */
    function audit(string $action, string $module, $recordId = null, string $description = ''): void
    {
        /* ---------- 1. Resolve the acting user -------------------------- */
        $userId = null;

        if (!empty($_SESSION['user']['id'])) {
            $userId = (int)$_SESSION['user']['id'];
        } elseif (!empty($_SESSION['user_id'])) {
            $userId = (int)$_SESSION['user_id'];
        } elseif (!empty($_SESSION['auth']['user_id'])) {
            $userId = (int)$_SESSION['auth']['user_id'];
        } elseif (!empty($_SESSION['auth']['user']['id'])) {
            $userId = (int)$_SESSION['auth']['user']['id'];
        } elseif (!empty($_SESSION['uid'])) {
            $userId = (int)$_SESSION['uid'];
        } elseif (function_exists('current_user')) {
            $cu = current_user();
            if (is_array($cu) && !empty($cu['id'])) {
                $userId = (int)$cu['id'];
            }
        }

        /* ---------- 2. Normalise record id ------------------------------ */
        $recordId = ($recordId === null || $recordId === '' || $recordId === 0 || $recordId === '0')
            ? null
            : (int)$recordId;

        /* ---------- 3. Client IP / User Agent --------------------------- */
        // REMOTE_ADDR cannot be spoofed by the client. Only trust
        // X-Forwarded-For if you run behind a reverse proxy you control.
        $ip = $_SERVER['REMOTE_ADDR'] ?? null;
        if (defined('TRUST_PROXY') && TRUST_PROXY && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = trim(explode(',', (string)$_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
        }
        $ua = isset($_SERVER['HTTP_USER_AGENT'])
            ? substr((string)$_SERVER['HTTP_USER_AGENT'], 0, 255)
            : null;

        /* ---------- 4. Insert ------------------------------------------- */
        try {
            db()->prepare(
                "INSERT INTO audit_logs
                    (user_id, action, module, record_id, description, ip_address, user_agent, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, NOW())"
            )->execute([
                $userId,
                $action,
                $module,
                $recordId,
                $description !== '' ? $description : null,
                $ip,
                $ua,
            ]);
        } catch (Throwable $e) {
            // Auditing must never break the request that triggered it.
            error_log('audit() failed: ' . $e->getMessage());
        }
    }
}

/* =====================================================================
 * Diagnostic (safe to leave in production — call only when needed)
 * ===================================================================== */

if (!function_exists('audit_debug_session')) {
    function audit_debug_session(): void
    {
        $keys = array_keys($_SESSION ?? []);
        error_log('AUDIT DEBUG — session keys: ' . implode(', ', $keys));
        error_log('AUDIT DEBUG — $_SESSION[user]: ' . print_r($_SESSION['user'] ?? null, true));
        if (function_exists('current_user')) {
            error_log('AUDIT DEBUG — current_user(): ' . print_r(current_user(), true));
        }
    }
}

/* =====================================================================
 * Ticket numbers
 * ===================================================================== */

if (!function_exists('generate_ticket_number')) {
    /**
     * Generate a unique ticket number.
     * Safe to call inside OR outside an existing transaction.
     * Only begins/commits its own transaction if none is active.
     */
    function generate_ticket_number(): string
    {
        $pdo = db();
        $own = !$pdo->inTransaction();
        if ($own) {
            $pdo->beginTransaction();
        }
        try {
            $row  = $pdo->query(
                "SELECT setting_value FROM system_settings WHERE setting_key='ticket_counter' FOR UPDATE"
            )->fetch();
            $next = (int)($row['setting_value'] ?? 0) + 1;
            $pdo->prepare("UPDATE system_settings SET setting_value=? WHERE setting_key='ticket_counter'")
                ->execute([$next]);
            if ($own) {
                $pdo->commit();
            }

            $prefix = setting('ticket_prefix', 'EPSS-ICT');
            $year   = setting('ticket_year', date('Y'));
            return sprintf('%s-%s-%06d', $prefix, $year, $next);
        } catch (Throwable $e) {
            if ($own && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }
}

/* =====================================================================
 * Ticket workflow helpers
 * ===================================================================== */

if (!function_exists('awaiting_confirmation_statuses')) {
    /**
     * Ticket statuses meaning "ICT resolved it, waiting for the requester to confirm".
     *
     * tickets.status is a VARCHAR in this schema (not an ENUM), so nothing can be
     * auto-detected from the column - the old detection found nothing and fell back
     * to names that never occur, which hid every confirmation from requesters.
     * The names are fixed here instead:
     *   RESOLVED_PENDING_REQUESTER_CONFIRMATION            (current)
     *   RESOLVED_PENDING_TEAM_LEADER_VERIFICATION          (legacy rows from before the change)
     * Override with an AWAITING_CONFIRMATION_STATUSES constant (array or comma list) if ever needed.
     */
    function awaiting_confirmation_statuses(): array
    {
        static $list = null;
        if ($list !== null) {
            return $list;
        }

        if (defined('AWAITING_CONFIRMATION_STATUSES')) {
            $v    = AWAITING_CONFIRMATION_STATUSES;
            $list = is_array($v)
                ? array_values($v)
                : array_values(array_filter(array_map('trim', explode(',', (string)$v))));
            if ($list) {
                return $list;
            }
        }

        $list = ['RESOLVED_PENDING_REQUESTER_CONFIRMATION', 'RESOLVED_PENDING_TEAM_LEADER_VERIFICATION'];
        return $list;
    }
}

if (!function_exists('awaiting_confirmation_sql_in')) {
    /**
     * Returns a quoted SQL list, e.g. ('RESOLVED_BY_ICT','PENDING_...'),
     * ready to append after "status IN ".
     */
    function awaiting_confirmation_sql_in(): string
    {
        $pdo = db();
        return '(' . implode(',', array_map(
            static fn(string $s): string => $pdo->quote($s),
            awaiting_confirmation_statuses()
        )) . ')';
    }
}

/* =====================================================================
 * Schema-tolerant helpers (used by the ticket helpers below)
 * ===================================================================== */

if (!function_exists('table_columns')) {
    /** Column names of a table, or [] if the table does not exist. */
    function table_columns(string $table): array
    {
        static $cache = [];
        if (isset($cache[$table])) {
            return $cache[$table];
        }
        $cols = [];
        if (preg_match('/^[A-Za-z0-9_]+$/', $table)) {
            try {
                foreach (db()->query("SHOW COLUMNS FROM `$table`") as $r) {
                    $cols[] = $r['Field'];
                }
            } catch (Throwable $e) {
                $cols = [];
            }
        }
        return $cache[$table] = $cols;
    }
}

if (!function_exists('pick_column')) {
    /** First candidate that exists in $cols and is not already in $used. */
    function pick_column(array $cols, array $candidates, array &$used): ?string
    {
        foreach ($candidates as $c) {
            if (in_array($c, $cols, true) && !in_array($c, $used, true)) {
                $used[] = $c;
                return $c;
            }
        }
        return null;
    }
}

/* =====================================================================
 * Ticket history
 * ===================================================================== */

if (!function_exists('record_history')) {
    /**
     * Add a row to the ticket history table. Never throws: a missing or
     * differently shaped history table is logged and skipped so it cannot
     * break ticket creation.
     */
    function record_history(int $ticketId, ?int $userId, ?string $oldStatus, ?string $newStatus,
                            ?string $action = '', ?string $remarks = null): void
    {
        $action  = (string)$action;
        $remarks = $remarks === null ? '' : (string)$remarks;
        try {
            $table = null;
            $cols  = [];
            foreach (['ticket_history', 'ticket_status_history', 'ticket_logs', 'ticket_timeline'] as $t) {
                $c = table_columns($t);
                if ($c) {
                    $table = $t;
                    $cols  = $c;
                    break;
                }
            }
            if ($table === null) {
                error_log('record_history(): no history table found');
                return;
            }

            $used = [];
            $map  = [];
            if ($c = pick_column($cols, ['ticket_id'], $used))                                   $map[$c] = $ticketId;
            if ($c = pick_column($cols, ['user_id', 'changed_by', 'actor_id', 'created_by'], $used)) $map[$c] = $userId;
            if ($c = pick_column($cols, ['old_status', 'from_status', 'previous_status'], $used))    $map[$c] = $oldStatus;
            if ($c = pick_column($cols, ['new_status', 'to_status', 'status'], $used))               $map[$c] = $newStatus;
            if ($c = pick_column($cols, ['action', 'title', 'event'], $used))                        $map[$c] = $action;
            if ($c = pick_column($cols, ['remarks', 'comment', 'comments', 'notes', 'description', 'details'], $used)) {
                $map[$c] = $remarks !== '' ? $remarks : null;
            }

            $names = array_keys($map);
            $marks = array_fill(0, count($names), '?');
            if (in_array('created_at', $cols, true) && !isset($map['created_at'])) {
                $names[] = 'created_at';
                $marks[] = 'NOW()';
            }

            $sql = sprintf(
                'INSERT INTO `%s` (%s) VALUES (%s)',
                $table,
                implode(',', array_map(static fn($n) => "`$n`", $names)),
                implode(',', $marks)
            );
            db()->prepare($sql)->execute(array_values($map));
        } catch (Throwable $e) {
            error_log('record_history() failed: ' . $e->getMessage());
        }
    }
}

/* =====================================================================
 * Attachments
 * ===================================================================== */

if (!function_exists('upload_attachment')) {
    /**
     * Validate, store and register one uploaded file for a ticket.
     * Throws AppError (E-UPL-400 / 413 / 415 / 500) with a user-friendly message on failure.
     *
     * Limits come from system settings: max_upload_size (bytes, default 10 MB)
     * and allowed_ext (comma-separated list).
     */
    function upload_attachment(int $ticketId, int $userId, array $file): void
    {
        if (empty($file['name'])) {
            return; // nothing uploaded
        }
        $err = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($err === UPLOAD_ERR_NO_FILE) {
            return;
        }
        if ($err !== UPLOAD_ERR_OK) {
            if ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE) {
                throw new AppError('E-UPL-413', 'The file is larger than the server allows.');
            }
            throw new AppError('E-UPL-400', 'File upload failed (PHP upload error ' . $err . ').');
        }
        if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            throw new AppError('E-UPL-400', 'The upload could not be verified.');
        }

        $maxSize = (int)setting('max_upload_size', 10485760);
        $size    = (int)($file['size'] ?? 0);
        if ($size <= 0 || ($maxSize > 0 && $size > $maxSize)) {
            throw new AppError('E-UPL-413', 'File is empty or larger than ' . (int)($maxSize / 1048576) . ' MB.');
        }

        $allowedRaw = (string)setting('allowed_ext', '');
        $allowed    = preg_split('/[\s,;|]+/', strtolower(str_replace('.', '', $allowedRaw)), -1, PREG_SPLIT_NO_EMPTY);
        if (!$allowed) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'txt', 'zip'];
        }
        $orig = basename((string)$file['name']);
        $ext  = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
        if ($ext === '' || !in_array($ext, $allowed, true)) {
            throw new AppError('E-UPL-415', 'File type ".' . $ext . '" is not allowed.');
        }

        $mime = null;
        if (function_exists('finfo_open')) {
            $fi = finfo_open(FILEINFO_MIME_TYPE);
            if ($fi) {
                $mime = finfo_file($fi, $file['tmp_name']) ?: null;
                finfo_close($fi);
            }
        }

        $dir = defined('UPLOAD_DIR') ? UPLOAD_DIR : (__DIR__ . '/../uploads/tickets/');
        $dir = rtrim($dir, "/\\") . DIRECTORY_SEPARATOR;
        if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
            throw new AppError('E-UPL-500', 'Upload folder cannot be created.');
        }

        // Path relative to the project root (pages link to it as "../<path>")
        $root   = realpath(__DIR__ . '/..');
        $real   = realpath($dir);
        $relDir = ($root && $real && strpos($real, $root) === 0)
            ? str_replace('\\', '/', ltrim(substr($real, strlen($root)), "\\/")) . '/'
            : 'uploads/tickets/';

        $stored = bin2hex(random_bytes(16)) . '.' . $ext;
        if (!move_uploaded_file($file['tmp_name'], $dir . $stored)) {
            throw new AppError('E-UPL-500', 'Could not save the uploaded file.');
        }

        // ---- register in the attachments table ---------------------------
        $table = null;
        $cols  = [];
        foreach (['ticket_attachments', 'attachments', 'ticket_files'] as $t) {
            $c = table_columns($t);
            if ($c) {
                $table = $t;
                $cols  = $c;
                break;
            }
        }
        if ($table === null) {
            @unlink($dir . $stored);
            throw new AppError('E-UPL-500', 'Attachments table not found.');
        }

        $used = [];
        $map  = [];
        if ($c = pick_column($cols, ['ticket_id'], $used))                                              $map[$c] = $ticketId;
        if ($c = pick_column($cols, ['uploaded_by', 'user_id', 'created_by'], $used))                   $map[$c] = $userId;
        if ($c = pick_column($cols, ['original_name', 'original_filename', 'file_name', 'filename'], $used)) $map[$c] = $orig;
        if ($c = pick_column($cols, ['file_path', 'path', 'filepath'], $used))                          $map[$c] = $relDir . $stored;
        if ($c = pick_column($cols, ['stored_name', 'stored_filename', 'filename', 'file_name'], $used)) $map[$c] = $stored;
        if ($c = pick_column($cols, ['file_size', 'size'], $used))                                      $map[$c] = $size;
        if ($c = pick_column($cols, ['mime_type', 'file_type', 'mime', 'type'], $used))                 $map[$c] = $mime;

        $names = array_keys($map);
        $marks = array_fill(0, count($names), '?');
        foreach (['uploaded_at', 'created_at'] as $tsCol) {
            if (in_array($tsCol, $cols, true) && !isset($map[$tsCol])) {
                $names[] = $tsCol;
                $marks[] = 'NOW()';
                break;
            }
        }

        try {
            $sql = sprintf(
                'INSERT INTO `%s` (%s) VALUES (%s)',
                $table,
                implode(',', array_map(static fn($n) => "`$n`", $names)),
                implode(',', $marks)
            );
            db()->prepare($sql)->execute(array_values($map));
        } catch (Throwable $e) {
            @unlink($dir . $stored);
            throw $e;
        }
    }
}

/* =====================================================================
 * Waiting-state helpers
 * (used by Team Leader > Team Tickets, the ICT ticket page and the report pages)
 * ===================================================================== */

if (!function_exists('is_waiting_status')) {
    /** Statuses that mean the ticket is blocked on someone outside ICT. */
    function is_waiting_status(?string $status): bool
    {
        return in_array((string)$status, ['WAITING_FOR_INFORMATION', 'WAITING_FOR_PARTS'], true);
    }
}

if (!function_exists('waiting_meta')) {
    /** Label + icon class + style class for a waiting status. */
    function waiting_meta(?string $status): array
    {
        switch ((string)$status) {
            case 'WAITING_FOR_INFORMATION':
                return ['label' => 'Waiting for Info', 'icon' => 'bi-question-circle', 'class' => 'is-critical'];
            case 'WAITING_FOR_PARTS':
                return ['label' => 'Waiting for Parts', 'icon' => 'bi-box-seam', 'class' => 'is-critical'];
            default:
                return ['label' => '', 'icon' => '', 'class' => 'is-neutral'];
        }
    }
}

/* =====================================================================
 * Status display
 * ===================================================================== */

if (!function_exists('status_meta')) {
    /**
     * [tone, bootstrap-icon, label] for a ticket status code.
     * Tones: good | critical | bad | info | neutral.
     */
    function status_meta(?string $status): array
    {
        static $map = [
            'OPEN'                         => ['info',     'circle',                 'Open'],
            'NEW'                          => ['info',     'star',                   'New'],
            'PENDING'                      => ['critical', 'hourglass-split',        'Pending'],
            'PENDING_APPROVAL'             => ['critical', 'hourglass-split',        'Pending Approval'],
            'PENDING_TEAM_LEADER_APPROVAL' => ['critical', 'hourglass-split',        'Pending Approval'],
            'AWAITING_APPROVAL'            => ['critical', 'hourglass-split',        'Awaiting Approval'],
            'APPROVED'                     => ['good',     'check2-circle',          'Approved'],
            'APPROVED_FOR_ICT'             => ['info',     'check2-circle',          'Approved for ICT'],
            'ASSIGNED'                     => ['info',     'person-check',           'Assigned'],
            'ASSIGNED_TO_ICT'              => ['info',     'person-check',           'Assigned to ICT'],
            'IN_PROGRESS'                  => ['info',     'arrow-repeat',           'In Progress'],
            'INPROGRESS'                   => ['info',     'arrow-repeat',           'In Progress'],
            'WORKING'                      => ['info',     'arrow-repeat',           'In Progress'],
            'WAITING'                      => ['critical', 'pause-circle',           'Waiting'],
            'WAITING_FOR_PARTS'            => ['critical', 'pause-circle',           'Waiting for Parts'],
            'WAITING_FOR_INFORMATION'      => ['critical', 'question-circle',        'Waiting for Info'],
            'ON_HOLD'                      => ['critical', 'pause-circle',           'On Hold'],
            'RESOLVED'                     => ['good',     'check2-circle',          'Resolved'],
            'RESOLVED_PENDING_REQUESTER_CONFIRMATION'
                                           => ['critical', 'hourglass-split',        'Awaiting Requester'],
            'RESOLVED_PENDING_TEAM_LEADER_VERIFICATION'
                                           => ['critical', 'hourglass-split',        'Awaiting Team Leader'],
            'RETURNED_TO_ICT'              => ['critical', 'arrow-counterclockwise', 'Returned to ICT'],
            'CLOSED'                       => ['good',     'check2-all',             'Closed'],
            'COMPLETED'                    => ['good',     'check2-all',             'Completed'],
            'DONE'                         => ['good',     'check2-all',             'Done'],
            'REJECTED'                     => ['bad',      'x-circle',               'Rejected'],
            'CANCELLED'                    => ['bad',      'slash-circle',           'Cancelled'],
            'CANCELED'                     => ['bad',      'slash-circle',           'Cancelled'],
            'DECLINED'                     => ['bad',      'x-circle',               'Declined'],
            'ESCALATED'                    => ['bad',      'arrow-up-circle',        'Escalated'],
            'DRAFT'                        => ['neutral',  'pencil',                 'Draft'],
            'ARCHIVED'                     => ['neutral',  'archive',                'Archived'],
        ];

        $raw = trim((string)$status);
        if ($raw === '') {
            return ['neutral', 'circle', '-'];
        }
        $key = strtoupper(preg_replace('/[^A-Z0-9]+/i', '_', $raw));

        if (isset($map[$key])) {
            return $map[$key];
        }
        // Any other "resolved, waiting for confirmation" status of your schema
        if (in_array($raw, awaiting_confirmation_statuses(), true)) {
            return ['critical', 'hourglass-split', 'Awaiting Requester'];
        }
        return ['neutral', 'circle', ucwords(strtolower(str_replace('_', ' ', $raw)))];
    }
}

if (!function_exists('status_label')) {
    /** Human-readable text for a ticket status, e.g. WAITING_FOR_PARTS -> Waiting for Parts. */
    function status_label(?string $status): string
    {
        return status_meta($status)[2];
    }
}

if (!function_exists('status_badge')) {
    /**
     * Status pill (HTML, already escaped). Uses inline styles so it looks the
     * same on every page, and also carries the sap-status classes.
     * $size is optional and adds an "is-<size>" class.
     */
    function status_badge(?string $status, string $size = ''): string
    {
        static $tones = [
            'good'     => ['#f1fdf6', '#256f3a', '#d6f0e0'],
            'critical' => ['#fff8f1', '#e76500', '#fbe0c8'],
            'bad'      => ['#fef4f4', '#aa0808', '#f7d2d2'],
            'info'     => ['#eaf4ff', '#0070f2', '#cfe2f8'],
            'neutral'  => ['#f4f5f7', '#5b738b', '#e4e7eb'],
        ];

        [$tone, $icon, $label] = status_meta($status);
        [$bg, $fg, $bd] = $tones[$tone] ?? $tones['neutral'];

        $sizeClass = $size !== '' ? ' is-' . preg_replace('/[^a-z]/', '', strtolower($size)) : '';
        $style = "display:inline-flex;align-items:center;gap:.3rem;font-size:.72rem;font-weight:600;"
               . "padding:.2rem .6rem;border-radius:.75rem;white-space:nowrap;"
               . "background:$bg;color:$fg;border:1px solid $bd;";

        return '<span class="sap-status is-' . e($tone) . e($sizeClass) . '" style="' . e($style) . '">'
             . '<i class="bi bi-' . e($icon) . '"></i> ' . e($label) . '</span>';
    }
}