<?php
declare(strict_types=1);

/**
 * includes/workflow.php
 * ---------------------------------------------------------------------------
 * The ICT side of the ticket life cycle, enforced on the SERVER (hiding a
 * button in the page is not enough - anyone can post a form by hand):
 *
 *   Requester raises ticket -> Team Leader approves (APPROVED_FOR_ICT)
 *     -> ICT ACCEPTS            APPROVED_FOR_ICT / ASSIGNED_TO_ICT / RETURNED_TO_ICT -> IN_PROGRESS
 *     -> ICT works              IN_PROGRESS  <->  WAITING_FOR_INFORMATION / WAITING_FOR_PARTS
 *     -> ICT marks RESOLVED     IN_PROGRESS / WAITING_*  -> RESOLVED_PENDING_REQUESTER_CONFIRMATION
 *     -> Requester CONFIRMS     -> CLOSED          (includes/confirmation.php)
 *        or says "not resolved" -> RETURNED_TO_ICT  (back to step "ICT accepts")
 *
 * Rules enforced here (each failure has its own error code, see includes/errors.php):
 *   - A ticket can only be worked on after it has been accepted (E-TKT-428).
 *   - Only the technician who holds the ticket can hold/resume/resolve it (E-TKT-423).
 *   - Resolving needs a written note of the work done (E-TKT-422).
 *   - Every action runs in one transaction on a row-locked ticket, so two
 *     technicians pressing "Accept" at the same moment cannot both win (E-TKT-409).
 *
 * All function names start with wf_ or ict_ so they cannot collide with the
 * page-local helpers some pages declare (status_meta(), prio_hex() ...).
 * ---------------------------------------------------------------------------
 */

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/errors.php';
require_once __DIR__ . '/escalation.php';      // requester_confirm_minutes()

/* =====================================================================
 * Status groups
 * ===================================================================== */

if (!function_exists('wf_acceptable_statuses')) {
    /** Waiting for an ICT technician to accept (first time, after assignment, or after the requester sent it back). */
    function wf_acceptable_statuses(): array
    {
        return ['APPROVED_FOR_ICT', 'ASSIGNED_TO_ICT', 'RETURNED_TO_ICT'];
    }
}

if (!function_exists('wf_waiting_statuses')) {
    /** ICT accepted it but is blocked on someone else. */
    function wf_waiting_statuses(): array
    {
        return ['WAITING_FOR_INFORMATION', 'WAITING_FOR_PARTS'];
    }
}

if (!function_exists('wf_ict_active_statuses')) {
    /** Every status in which the ticket is still in ICT's hands. */
    function wf_ict_active_statuses(): array
    {
        return array_merge(wf_acceptable_statuses(), ['IN_PROGRESS'], wf_waiting_statuses());
    }
}

if (!function_exists('wf_status_label')) {
    function wf_status_label(?string $status): string
    {
        static $labels = [
            'PENDING_TEAM_LEADER_APPROVAL'            => 'Pending Team Leader Approval',
            'RETURNED_TO_EMPLOYEE'                    => 'Returned to Requester',
            'APPROVED_FOR_ICT'                        => 'Approved for ICT',
            'ASSIGNED_TO_ICT'                         => 'Assigned to ICT',
            'IN_PROGRESS'                             => 'In Progress',
            'WAITING_FOR_INFORMATION'                 => 'Waiting for Information',
            'WAITING_FOR_PARTS'                       => 'Waiting for Parts',
            'RESOLVED_PENDING_REQUESTER_CONFIRMATION' => 'Awaiting Requester Confirmation',
            'RETURNED_TO_ICT'                         => 'Returned to ICT',
            'CLOSED'                                  => 'Closed',
            'REJECTED'                                => 'Rejected',
            'CANCELLED'                               => 'Cancelled',
        ];
        $s = (string)$status;
        return $labels[$s] ?? ucwords(strtolower(str_replace('_', ' ', $s)));
    }
}

/* =====================================================================
 * Small helpers
 * ===================================================================== */

if (!function_exists('wf_check_csrf')) {
    /** Throws E-REQ-419 instead of silently ignoring a post with a bad token. */
    function wf_check_csrf(): void
    {
        $token = $_POST['csrf'] ?? null;
        if (!is_string($token) || !verify_csrf($token)) {
            throw new AppError('E-REQ-419');
        }
    }
}

if (!function_exists('wf_user_name')) {
    function wf_user_name(int $userId, string $fallback = 'another technician'): string
    {
        try {
            $st = db()->prepare('SELECT full_name FROM users WHERE id = ?');
            $st->execute([$userId]);
            $name = $st->fetchColumn();
            return is_string($name) && $name !== '' ? $name : $fallback;
        } catch (Throwable $e) {
            return $fallback;
        }
    }
}

if (!function_exists('wf_lock_ticket')) {
    /**
     * Open a transaction and return the ticket row locked FOR UPDATE.
     * The caller must commit or roll back.
     *
     * @throws AppError E-REQ-400 (bad id) / E-TKT-404 (not found)
     */
    function wf_lock_ticket(int $ticketId): array
    {
        if ($ticketId <= 0) {
            throw new AppError('E-REQ-400', 'Invalid ticket id.');
        }
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $st = $pdo->prepare('SELECT * FROM tickets WHERE id = ? FOR UPDATE');
            $st->execute([$ticketId]);
            $t = $st->fetch();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
        if (!$t) {
            $pdo->rollBack();
            throw new AppError('E-TKT-404');
        }
        return $t;
    }
}

if (!function_exists('wf_telegram')) {
    /** Best-effort Telegram message after the database commit. Never throws. */
    function wf_telegram(int $userId, string $html, int $ticketId, array $extra = []): void
    {
        if ($userId <= 0) {
            return;
        }
        try {
            require_once __DIR__ . '/telegram.php';
            telegram_notify_user($userId, $html, $ticketId, $extra);
        } catch (Throwable $e) {
            error_log('workflow telegram: ' . $e->getMessage());
        }
    }
}

/* =====================================================================
 * 1. ICT ACCEPTS the request
 * ===================================================================== */

if (!function_exists('ict_accept_ticket')) {
    /**
     * The technician takes the ticket: status -> IN_PROGRESS, technician and start
     * time are recorded, and the requester (and Team Leader) are told that ICT has
     * started working on the request.
     *
     * @return array the ticket row as it was before the change
     * @throws AppError E-TKT-404 / E-TKT-409 / E-TKT-423
     */
    function ict_accept_ticket(int $ticketId, array $user): array
    {
        $pdo = db();
        $uid = (int)$user['id'];
        $t   = wf_lock_ticket($ticketId);

        try {
            $status   = (string)$t['status'];
            $assigned = (int)($t['assigned_technician_id'] ?? 0);

            if ($status === 'IN_PROGRESS' && $assigned === $uid) {
                throw new AppError('E-TKT-409', 'You have already accepted this ticket.');
            }
            if (!in_array($status, wf_acceptable_statuses(), true)) {
                throw new AppError('E-TKT-409',
                    'This ticket cannot be accepted while it is "' . wf_status_label($status) . '".');
            }
            if ($assigned > 0 && $assigned !== $uid) {
                throw new AppError('E-TKT-423',
                    'This ticket is assigned to ' . wf_user_name($assigned) . '. Ask them, or any ICT colleague, to assign it to you first.');
            }

            $now = date('Y-m-d H:i:s');
            $pdo->prepare("UPDATE tickets
                              SET status='IN_PROGRESS', assigned_technician_id=?, ict_started_at=IFNULL(ict_started_at, ?)
                            WHERE id=?")
                ->execute([$uid, $now, $ticketId]);

            $again = ($status === 'RETURNED_TO_ICT');
            record_history($ticketId, $uid, $status, 'IN_PROGRESS',
                $again ? 'ICT Accepted Ticket Again (returned by requester)' : 'ICT Accepted Ticket', null);

            $who = (string)$user['full_name'];
            notify((int)$t['requester_id'], $ticketId, 'ICT Accepted Your Request',
                "{$who} from ICT accepted your ticket {$t['ticket_number']} and has started working on it.", 'info');
            $tlId = (int)($t['team_leader_id'] ?? 0);
            if ($tlId > 0 && $tlId !== (int)$t['requester_id'] && $tlId !== $uid) {
                notify($tlId, $ticketId, 'Ticket Accepted by ICT',
                    "{$who} accepted {$t['ticket_number']}. Work is in progress.", 'info');
            }

            audit('ACCEPT', 'tickets', $ticketId, "ICT accepted {$t['ticket_number']}");
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }

        try {
            require_once __DIR__ . '/telegram.php';
            wf_telegram((int)$t['requester_id'], tg_msg_accepted($t, (string)$user['full_name']), $ticketId);
        } catch (Throwable $e) {
            error_log('workflow accept telegram: ' . $e->getMessage());
        }
        return $t;
    }
}

/* =====================================================================
 * 2. ICT works: hold / resume / re-assign
 * ===================================================================== */

if (!function_exists('ict_wait_ticket')) {
    /**
     * Put an accepted ticket on hold.
     *
     * @param string $kind   'info' (waiting for the requester) or 'parts'
     * @param string $reason required for 'info' - the requester needs to know what to supply
     * @throws AppError E-REQ-422 / E-TKT-404 / E-TKT-409 / E-TKT-423 / E-TKT-428
     */
    function ict_wait_ticket(int $ticketId, array $user, string $kind, string $reason): array
    {
        $isInfo    = ($kind === 'info');
        $newStatus = $isInfo ? 'WAITING_FOR_INFORMATION' : 'WAITING_FOR_PARTS';
        $reason    = trim($reason);
        if ($isInfo && $reason === '') {
            throw new AppError('E-REQ-422', 'Tell the requester what information you need.');
        }

        $pdo = db();
        $uid = (int)$user['id'];
        $t   = wf_lock_ticket($ticketId);

        try {
            $status   = (string)$t['status'];
            $assigned = (int)($t['assigned_technician_id'] ?? 0);

            if (in_array($status, wf_acceptable_statuses(), true)) {
                throw new AppError('E-TKT-428');
            }
            if ($status !== 'IN_PROGRESS' && !in_array($status, wf_waiting_statuses(), true)) {
                throw new AppError('E-TKT-409',
                    'A ticket that is "' . wf_status_label($status) . '" cannot be put on hold.');
            }
            if ($assigned > 0 && $assigned !== $uid) {
                throw new AppError('E-TKT-423',
                    'This ticket is held by ' . wf_user_name($assigned) . '.');
            }

            /* Do not spam the Team Leader if nothing changed. */
            $alreadyWaiting = ($status === $newStatus);
            $lastReason     = null;
            if ($alreadyWaiting) {
                try {
                    $q = $pdo->prepare('SELECT comment FROM ticket_history
                                         WHERE ticket_id = ? AND new_status = ? AND comment IS NOT NULL
                                         ORDER BY created_at DESC, id DESC LIMIT 1');
                    $q->execute([$ticketId, $newStatus]);
                    $lastReason = $q->fetchColumn() ?: null;
                } catch (Throwable $e) {
                    $lastReason = null;
                }
            }
            $changed = (!$alreadyWaiting) || ($lastReason !== $reason);

            $pdo->prepare('UPDATE tickets SET status = ?, assigned_technician_id = COALESCE(assigned_technician_id, ?) WHERE id = ?')
                ->execute([$newStatus, $uid, $ticketId]);

            record_history($ticketId, $uid, $status, $newStatus,
                $isInfo ? 'Waiting for Information' : 'Waiting for Parts',
                $reason !== '' ? $reason : null);

            if ($changed) {
                $title = $isInfo
                    ? "Ticket {$t['ticket_number']} needs more info"
                    : "Ticket {$t['ticket_number']} waiting on parts";
                $body = $isInfo
                    ? "ICT has requested more information from the requester on ticket {$t['ticket_number']} - \"{$t['subject']}\"."
                    : "ICT has paused ticket {$t['ticket_number']} - \"{$t['subject']}\" while spare parts are sourced.";
                if ($reason !== '') {
                    $body .= "\nReason: {$reason}";
                }
                $tlId = (int)($t['team_leader_id'] ?? 0);
                if ($tlId > 0 && $tlId !== (int)$t['requester_id']) {
                    notify($tlId, $ticketId, $title, $body, 'ticket_waiting');
                }

                if ($isInfo) {
                    notify((int)$t['requester_id'], $ticketId, 'Information Requested',
                        "ICT needs more information about your ticket {$t['ticket_number']}."
                        . ($reason !== '' ? "\nReason: {$reason}" : '')
                        . "\nAdd a comment on the ticket with the details and ICT will continue.", 'warning');
                } else {
                    notify((int)$t['requester_id'], $ticketId, 'Ticket Paused - Waiting for Parts',
                        "Your ticket {$t['ticket_number']} is temporarily on hold while ICT obtains spare parts.", 'info');
                }
            }

            audit($isInfo ? 'WAIT_INFO' : 'WAIT_PARTS', 'tickets', $ticketId, "ICT put {$t['ticket_number']} on hold ({$newStatus})");
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }

        if ($changed) {
            if ($isInfo) {
                try {
                    require_once __DIR__ . '/telegram.php';
                    wf_telegram((int)$t['requester_id'], tg_msg_info_requested($t, (string)$user['full_name'], $reason), $ticketId);
                } catch (Throwable $e) {
                    error_log('workflow wait telegram: ' . $e->getMessage());
                }
            }
            /* WhatsApp copy to the Team Leader (optional integration). */
            if (setting('wa_enabled', '0') === '1') {
                try {
                    require_once __DIR__ . '/whatsapp.php';
                    $st = $pdo->prepare('SELECT phone FROM users WHERE id = ?');
                    $st->execute([(int)$t['team_leader_id']]);
                    $phone = $st->fetchColumn();
                    if (!empty($phone)) {
                        $label = $isInfo ? 'Waiting for Information' : 'Waiting for Parts';
                        queue_whatsapp((int)$t['team_leader_id'], (string)$phone,
                            ($isInfo ? '❓' : '📦') . " *EPSS ICT - {$label}*\n\n"
                            . "Ticket: {$t['ticket_number']}\n"
                            . "Subject: {$t['subject']}\n"
                            . ($reason !== '' ? "Reason: {$reason}\n" : '')
                            . "\nPlease review on your Team Tickets page.",
                            $ticketId);
                    }
                } catch (Throwable $e) {
                    error_log('workflow whatsapp: ' . $e->getMessage());
                }
            }
        }
        return $t;
    }
}

if (!function_exists('ict_resume_ticket')) {
    /**
     * Back to work after a hold: WAITING_* -> IN_PROGRESS.
     *
     * @throws AppError E-TKT-404 / E-TKT-409 / E-TKT-423
     */
    function ict_resume_ticket(int $ticketId, array $user): array
    {
        $pdo = db();
        $uid = (int)$user['id'];
        $t   = wf_lock_ticket($ticketId);

        try {
            $status   = (string)$t['status'];
            $assigned = (int)($t['assigned_technician_id'] ?? 0);

            if (!in_array($status, wf_waiting_statuses(), true)) {
                throw new AppError('E-TKT-409', 'Only a ticket that is on hold can be resumed.');
            }
            if ($assigned > 0 && $assigned !== $uid) {
                throw new AppError('E-TKT-423', 'This ticket is held by ' . wf_user_name($assigned) . '.');
            }

            $pdo->prepare("UPDATE tickets SET status='IN_PROGRESS', assigned_technician_id=COALESCE(assigned_technician_id, ?) WHERE id=?")
                ->execute([$uid, $ticketId]);
            record_history($ticketId, $uid, $status, 'IN_PROGRESS', 'Work Resumed', null);

            notify((int)$t['requester_id'], $ticketId, 'Work Resumed',
                "ICT is working on your ticket {$t['ticket_number']} again.", 'info');

            audit('RESUME', 'tickets', $ticketId, "ICT resumed {$t['ticket_number']}");
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
        return $t;
    }
}

if (!function_exists('ict_assign_ticket')) {
    /**
     * Hand the ticket to a technician (possibly yourself). The technician must then
     * ACCEPT it, so status becomes ASSIGNED_TO_ICT.
     *
     * @throws AppError E-TKT-404 / E-TKT-409 / E-TKT-424
     */
    function ict_assign_ticket(int $ticketId, array $user, int $technicianId): array
    {
        $pdo = db();
        $uid = (int)$user['id'];

        /* The target must be a real, active ICT technician (this was never checked before). */
        $st = $pdo->prepare("SELECT id, full_name FROM users WHERE id = ? AND role = 'ICT_STAFF' AND status = 'ACTIVE'");
        $st->execute([$technicianId]);
        $tech = $st->fetch();
        if (!$tech) {
            throw new AppError('E-TKT-424');
        }

        $t = wf_lock_ticket($ticketId);
        try {
            $status   = (string)$t['status'];
            $assigned = (int)($t['assigned_technician_id'] ?? 0);

            if (!in_array($status, wf_ict_active_statuses(), true)) {
                throw new AppError('E-TKT-409',
                    'A ticket that is "' . wf_status_label($status) . '" cannot be assigned.');
            }
            if ($assigned === $technicianId && $status === 'ASSIGNED_TO_ICT') {
                throw new AppError('E-TKT-409', $tech['full_name'] . ' is already assigned to this ticket.');
            }

            $pdo->prepare("UPDATE tickets SET assigned_technician_id=?, status='ASSIGNED_TO_ICT' WHERE id=?")
                ->execute([$technicianId, $ticketId]);
            record_history($ticketId, $uid, $status, 'ASSIGNED_TO_ICT', 'Assigned to ICT', 'Assigned to ' . $tech['full_name']);

            if ($technicianId !== $uid) {
                notify($technicianId, $ticketId, 'Ticket Assigned',
                    "Ticket {$t['ticket_number']} was assigned to you by {$user['full_name']}. Please accept it to start work.", 'assignment');
            }

            audit('ASSIGN', 'tickets', $ticketId, "Assigned {$t['ticket_number']} to {$tech['full_name']}");
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
        return $t;
    }
}

/* =====================================================================
 * 3. ICT marks the ticket RESOLVED -> requester must confirm
 * ===================================================================== */

if (!function_exists('ict_resolve_ticket')) {
    /**
     * The technician reports the work done. The ticket moves to
     * RESOLVED_PENDING_REQUESTER_CONFIRMATION; the requester is notified (in-app and
     * Telegram, with Confirm / Not Resolved buttons) and has requester_confirm_minutes()
     * to answer before the ticket closes automatically.
     *
     * @param array|null $evidence an entry of $_FILES (optional)
     * @throws AppError E-TKT-404 / E-TKT-409 / E-TKT-422 / E-TKT-423 / E-TKT-428 / E-UPL-*
     */
    function ict_resolve_ticket(int $ticketId, array $user, string $actionTaken, ?array $evidence = null): array
    {
        $actionTaken = trim($actionTaken);
        if ($actionTaken === '') {
            throw new AppError('E-TKT-422');
        }

        $pdo = db();
        $uid = (int)$user['id'];
        $t   = wf_lock_ticket($ticketId);

        try {
            $status   = (string)$t['status'];
            $assigned = (int)($t['assigned_technician_id'] ?? 0);

            if (in_array($status, wf_acceptable_statuses(), true)) {
                throw new AppError('E-TKT-428');
            }
            if ($status !== 'IN_PROGRESS' && !in_array($status, wf_waiting_statuses(), true)) {
                throw new AppError('E-TKT-409',
                    'A ticket that is "' . wf_status_label($status) . '" cannot be marked as resolved.');
            }
            if ($assigned > 0 && $assigned !== $uid) {
                throw new AppError('E-TKT-423',
                    'This ticket is held by ' . wf_user_name($assigned) . '. Only that technician can resolve it.');
            }

            $now = date('Y-m-d H:i:s');

            $pdo->prepare('INSERT INTO ticket_work_logs
                    (ticket_id, technician_id, diagnosis, action_taken, root_cause, resolution, remarks, started_at, completed_at)
                    VALUES (?, ?, NULL, ?, NULL, NULL, NULL, ?, ?)')
                ->execute([$ticketId, $uid, $actionTaken, $t['ict_started_at'] ?? $now, $now]);

            if ($evidence !== null && !empty($evidence['name'])) {
                upload_attachment($ticketId, $uid, $evidence);
            }

            $pdo->prepare("UPDATE tickets
                              SET status='RESOLVED_PENDING_REQUESTER_CONFIRMATION', resolved_at=?,
                                  assigned_technician_id=COALESCE(assigned_technician_id, ?),
                                  ict_started_at=IFNULL(ict_started_at, ?)
                            WHERE id=?")
                ->execute([$now, $uid, $now, $ticketId]);

            record_history($ticketId, $uid, $status, 'RESOLVED_PENDING_REQUESTER_CONFIRMATION',
                'Work Completed - Awaiting Requester Confirmation', $actionTaken);

            notify((int)$t['requester_id'], $ticketId, 'Confirm Your Resolution',
                "ICT has resolved your ticket {$t['ticket_number']}. Please confirm the fix so the ticket can be closed.", 'verify');
            $tlId = (int)($t['team_leader_id'] ?? 0);
            if ($tlId > 0 && $tlId !== (int)$t['requester_id']) {
                notify($tlId, $ticketId, 'Ticket Resolved',
                    "ICT resolved {$t['ticket_number']}. It is awaiting the requester's confirmation.", 'info');
            }

            audit('RESOLVE', 'tickets', $ticketId, "ICT resolved {$t['ticket_number']}");
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }

        try {
            require_once __DIR__ . '/telegram.php';
            wf_telegram((int)$t['requester_id'],
                tg_msg_resolved($t, (string)$user['full_name'], $actionTaken, requester_confirm_minutes()),
                $ticketId, ['reply_markup' => tg_confirm_keyboard($ticketId)]);
        } catch (Throwable $e) {
            error_log('workflow resolve telegram: ' . $e->getMessage());
        }
        return $t;
    }
}

/* =====================================================================
 * 4. Requester answers an information request
 * ===================================================================== */

if (!function_exists('wf_requester_replied')) {
    /**
     * Called after the requester adds a comment. If ICT had put the ticket on hold
     * waiting for information, the ticket goes straight back to IN_PROGRESS and the
     * technician is told - the requester no longer has to wait for ICT to notice.
     *
     * @return bool true when the ticket was resumed
     */
    function wf_requester_replied(int $ticketId, int $userId, string $comment = ''): bool
    {
        $pdo = db();
        $t   = wf_lock_ticket($ticketId);

        try {
            if ((string)$t['status'] !== 'WAITING_FOR_INFORMATION' || (int)$t['requester_id'] !== $userId) {
                $pdo->rollBack();
                return false;
            }

            $pdo->prepare("UPDATE tickets SET status='IN_PROGRESS' WHERE id=?")->execute([$ticketId]);
            record_history($ticketId, $userId, 'WAITING_FOR_INFORMATION', 'IN_PROGRESS',
                'Requester Provided Information', trim($comment) !== '' ? trim($comment) : null);

            $techId = (int)($t['assigned_technician_id'] ?? 0);
            if ($techId > 0) {
                notify($techId, $ticketId, 'Information Provided',
                    "The requester answered your question on {$t['ticket_number']}. The ticket is back in progress.", 'info');
            }
            audit('REQUESTER_REPLY', 'tickets', $ticketId, "Requester supplied information on {$t['ticket_number']}");
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }

        if (!empty($t['assigned_technician_id'])) {
            wf_telegram((int)$t['assigned_technician_id'],
                "💬 <b>Requester provided the information</b>\n\nTicket: <b>" . htmlspecialchars((string)$t['ticket_number'], ENT_QUOTES, 'UTF-8')
                . "</b>\nThe ticket is back in progress.", $ticketId);
        }
        return true;
    }
}

/* =====================================================================
 * Progress stepper (shown on every ticket page)
 * ===================================================================== */

if (!function_exists('wf_stepper')) {
    /**
     * Five-step progress bar:  Requested > Approved > Accepted by ICT > Resolved by ICT > Confirmed.
     * Returns '' for rejected / cancelled tickets (the status badge already says it).
     *
     * @param array  $t        ticket row (needs status and the *_at timestamps)
     * @param string $techName technician name shown under "Accepted by ICT"
     */
    function wf_stepper(array $t, string $techName = ''): string
    {
        static $cssDone = false;

        $status = (string)($t['status'] ?? '');
        $doneByStatus = [
            'PENDING_TEAM_LEADER_APPROVAL'              => 1,
            'RETURNED_TO_EMPLOYEE'                      => 1,
            'APPROVED_FOR_ICT'                          => 2,
            'ASSIGNED_TO_ICT'                           => 2,
            'RETURNED_TO_ICT'                           => 2,
            'IN_PROGRESS'                               => 3,
            'WAITING_FOR_INFORMATION'                   => 3,
            'WAITING_FOR_PARTS'                         => 3,
            'RESOLVED_PENDING_REQUESTER_CONFIRMATION'   => 4,
            'RESOLVED_PENDING_TEAM_LEADER_VERIFICATION' => 4,
            'CLOSED'                                    => 5,
        ];
        if (!isset($doneByStatus[$status])) {
            return '';
        }
        $done = $doneByStatus[$status];

        $steps = [
            ['Requested',       'bi-send',          $t['created_at'] ?? null,               ''],
            ['Approved',        'bi-person-check',  $t['team_leader_approved_at'] ?? null,  ''],
            ['Accepted by ICT', 'bi-tools',         $t['ict_started_at'] ?? null,           $techName],
            ['Resolved by ICT', 'bi-check2-circle', $t['resolved_at'] ?? null,              ''],
            ['Confirmed',       'bi-patch-check',   $t['closed_at'] ?? null,                ''],
        ];

        $hold = in_array($status, wf_waiting_statuses(), true);
        $notes = [
            1 => 'Waiting for Team Leader',
            2 => $status === 'RETURNED_TO_ICT' ? 'Returned by requester'
                : ($status === 'ASSIGNED_TO_ICT' ? 'Waiting for technician' : 'Waiting for ICT'),
            3 => $status === 'WAITING_FOR_INFORMATION' ? 'On hold - information needed'
                : ($status === 'WAITING_FOR_PARTS' ? 'On hold - parts needed' : 'Work in progress'),
            4 => 'Waiting for requester',
        ];

        $h = static fn(string $s): string => htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

        $out = '';
        if (!$cssDone) {
            $cssDone = true;
            $out .= '<style>'
                . '.wf-steps{display:flex;background:#fff;border-radius:.75rem;padding:1rem .75rem .85rem;margin-bottom:1rem;'
                . 'box-shadow:0 0 0 1px rgba(34,53,72,.10),0 2px 8px 0 rgba(34,53,72,.06);}'
                . '.wf-step{flex:1 1 0;min-width:0;text-align:center;position:relative;padding:0 .25rem;}'
                . '.wf-step+.wf-step::before{content:"";position:absolute;top:17px;right:50%;width:100%;height:3px;background:#d9d9d9;z-index:0;}'
                . '.wf-step.is-done+.wf-step::before,.wf-step.is-done+.wf-step.is-current::before{background:#256f3a;}'
                . '.wf-dot{position:relative;z-index:1;width:36px;height:36px;border-radius:50%;display:inline-flex;align-items:center;'
                . 'justify-content:center;font-size:1rem;background:#f4f5f7;color:#8396a8;border:2px solid #d9d9d9;}'
                . '.wf-step.is-done .wf-dot{background:#256f3a;border-color:#256f3a;color:#fff;}'
                . '.wf-step.is-current .wf-dot{background:#fff;border-color:#0070f2;color:#0070f2;box-shadow:0 0 0 4px rgba(0,112,242,.15);}'
                . '.wf-step.is-current.is-hold .wf-dot{border-color:#e76500;color:#e76500;box-shadow:0 0 0 4px rgba(231,101,0,.15);}'
                . '.wf-label{display:block;font-size:.78rem;font-weight:600;margin-top:.4rem;color:#1d2d3e;}'
                . '.wf-step.is-todo .wf-label{color:#8396a8;font-weight:500;}'
                . '.wf-sub{display:block;font-size:.68rem;color:#556b82;line-height:1.35;word-break:break-word;}'
                . '.wf-step.is-current .wf-sub{color:#0057d2;font-weight:600;}'
                . '.wf-step.is-current.is-hold .wf-sub{color:#e76500;}'
                . '@media(max-width:575px){.wf-label{font-size:.68rem}.wf-sub{font-size:.62rem}.wf-dot{width:30px;height:30px;font-size:.85rem}'
                . '.wf-step+.wf-step::before{top:14px}}'
                . '</style>';
        }

        $out .= '<div class="wf-steps" role="list" aria-label="Ticket progress">';
        foreach ($steps as $i => [$label, $icon, $when, $who]) {
            $isDone    = $i < $done;
            $isCurrent = ($i === $done);
            $class     = $isDone ? 'is-done' : ($isCurrent ? 'is-current' : 'is-todo');
            if ($isCurrent && $hold) {
                $class .= ' is-hold';
            }

            $sub = '';
            if ($isDone) {
                $parts = [];
                $ts = $when ? strtotime((string)$when) : false;
                if ($ts) {
                    $parts[] = date('d M, H:i', $ts);
                }
                if ($who !== '') {
                    $parts[] = $who;
                }
                $sub = implode(' - ', $parts);
            } elseif ($isCurrent && isset($notes[$i])) {
                $sub = $notes[$i];
            }

            $out .= '<div class="wf-step ' . $class . '" role="listitem">'
                  . '<span class="wf-dot"><i class="bi ' . ($isDone ? 'bi-check-lg' : $h($icon)) . '"></i></span>'
                  . '<span class="wf-label">' . $h($label) . '</span>'
                  . ($sub !== '' ? '<span class="wf-sub">' . $h($sub) . '</span>' : '')
                  . '</div>';
        }
        return $out . '</div>';
    }
}
