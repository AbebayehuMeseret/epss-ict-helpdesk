# EPSS Adama Branch — ICT Helpdesk System

A complete web-based ICT Helpdesk and Ticket Management System for the Ethiopian
Pharmaceuticals Supply Service (EPSS) — Adama Branch.

## Stack
- PHP 8.x (PDO, prepared statements)
- MySQL 8.x / MariaDB
- Bootstrap 5, Bootstrap Icons
- Chart.js, DataTables
- Session auth, CSRF, RBAC
- TCPDF/Dompdf (PDF), PhpSpreadsheet (Excel)

## Installation (XAMPP on Windows)

1. Copy the `epss-helpdesk` folder to `C:\xampp\htdocs\`.
2. Start Apache and MySQL in XAMPP.
3. Import the database:
   - Open phpMyAdmin → Import → run `epss_adama_helpdesk.sql`
   - Then run `database/pm_approval_migration.sql` (creates the preventive maintenance tables when
     they are missing and adds the Branch Manager approval step).
   - Then run `database/annual_report_migration.sql` (creates `annual_ict_reports`, which stores the
     editable narrative sections of the annual ICT report per E.C. year).
   - Upgrading an existing installation: also run `database/migration_requester_confirmation.sql`
     (moves tickets that were awaiting Team Leader verification to requester confirmation and
     backfills the technician / resolution time on tickets ICT had already resolved) and
     `database/telegram_migration.sql`. All four migrations are safe to run more than once.
4. Configure `config/database.php` (DB_HOST, DB_NAME, DB_USER, DB_PASS).
5. Ensure `uploads/tickets/` exists and is writable.
6. Visit <http://localhost/epss-helpdesk/>.

## Default Admin
- **Username:** `admin`
- **Password:** `Admin@123` (must be changed on first login)

## Roles
- **Administrator** — full access, users, departments, categories, KPIs, reports, settings.
- **Team Leader** — approves, returns, or rejects tickets for team members. Tickets the Team Leader creates
  themselves go straight to ICT, and the Team Leader (as the requester) confirms the fix once ICT resolves them.
- **Branch Manager** — uses the Team Leader menus for tickets, and approves or rejects the quarterly
  preventive maintenance checklists submitted by ICT technicians.
- **Employee** — creates their own tickets and confirms when a resolution is done.
- **ICT Staff** — accepts approved tickets, works on them, marks them resolved, and submits the quarterly
  preventive maintenance checklist.

## Workflow
Employee creates a ticket → Team Leader approves → ICT technician accepts → ICT technician marks it resolved →
the requester confirms the fix → ticket closed. If the requester reports the issue is not resolved, the ticket
returns to ICT. Rejection and clarification loops are fully supported.

### ICT life cycle — accept, work, resolve, confirm

| Step | Who | Ticket status afterwards | Who is told |
|---|---|---|---|
| Request | Requester | `PENDING_TEAM_LEADER_APPROVAL` → `APPROVED_FOR_ICT` | Team Leader, then ICT |
| **Accept** | ICT technician | `IN_PROGRESS` | **Requester + Team Leader** (in-app, Telegram to requester) |
| Hold (optional) | ICT technician | `WAITING_FOR_INFORMATION` / `WAITING_FOR_PARTS` | Requester, Team Leader |
| Resume | ICT technician, or the requester by answering | `IN_PROGRESS` | Requester / technician |
| **Resolve** | ICT technician (note of work done is required) | `RESOLVED_PENDING_REQUESTER_CONFIRMATION` | Requester (in-app + Telegram buttons) |
| **Confirm** | Requester | `CLOSED` | Technician, Team Leader |
| Not resolved | Requester (reason required) | `RETURNED_TO_ICT` → ICT accepts again | Technician |

The rules are enforced on the server in `includes/workflow.php` (not just by hiding buttons), inside one
transaction on a row-locked ticket:

- A ticket must be **accepted before it can be put on hold or resolved** (`E-TKT-428`).
- Only the technician who holds the ticket can hold, resume or resolve it (`E-TKT-423`); a colleague takes over by
  assigning it to themselves.
- Two technicians pressing *Accept* at the same moment cannot both succeed (`E-TKT-409`).
- *Resolve* needs a written note, *Waiting for Info* needs the question for the requester.
- When ICT is **Waiting for Information**, the requester's reply (a comment on the ticket) puts the ticket straight
  back **In Progress** and tells the technician.
- Every ticket page shows a five-step progress bar: Requested → Approved → Accepted by ICT → Resolved by ICT → Confirmed.

### Error codes

Every error shown to a user carries a code `E-<AREA>-<NNN>` (for example `E-TKT-409`, `E-REQ-419`, `E-DB-501`).
The area says where it happened (AUTH, REQ, VAL, TKT, CNF, UPL, PM, USR, RPT, DB, SYS); the number mirrors the HTTP
status where one fits. Codes live in one registry, `includes/errors.php`:

```php
throw new AppError('E-TKT-409');                 // friendly default text
throw new AppError('E-TKT-409', 'Custom text');  // same code, custom text
app_fail('E-TKT-404');                           // error page (JSON for /api/ calls) and stop
$msg = app_exception_message($e);                // "[E-DB-501] ... (ref R261110-143502-A3F9)"
```

Faults on the server side (HTTP 5xx, database errors, unexpected exceptions) are written to `logs/app_errors.log`
with a reference id that the user sees; raw SQL or exception text is never shown to users. Administrators open
**Admin → Error Codes** to see every code with its meaning and fix, and to look up a reference from a user.
Uncaught exceptions are turned into a coded `E-SYS-500` page instead of a blank screen.

If a Team Leader does not approve (or return/reject) a ticket within **15 minutes**, it is forwarded to ICT
automatically and the Team Leader is notified that it was bypassed on their team's behalf. The window can be
changed with the `tl_bypass_minutes` system setting. The check runs on page loads and can also be scheduled:
`php cron/approval_escalation.php` (every minute).

Requesters who linked Telegram on their Profile page also receive a bot message asking them to confirm the
resolution, and Team Leaders receive one when a ticket is bypassed. Telegram needs
`database/telegram_migration.sql` to be applied once.

### Confirming a resolution — the 30-minute rule

When ICT marks a ticket resolved, the requester gets an in-app notification and a Telegram message asking them
to confirm, and the ticket page shows how many minutes are left. They must confirm (or send it back) within
**30 minutes**; if they forget, the ticket is confirmed and closed automatically, with the history note
*“Confirmed automatically: the requester did not respond within 30 minutes”*. Requester, Team Leader and
technician are all told what happened (in-app + Telegram).

The window is the `requester_confirm_minutes` setting (default 30). The sweep runs on page loads, in the
Telegram worker loop, and from `php cron/confirmation_escalation.php` — all self-throttled to once a minute.

This applies to Team Leaders too: on a ticket a Team Leader created, the Team Leader is the requester and gets the
same **Confirm & Close Ticket / Not Resolved** card on their own ticket page (Team Leader → Team Tickets → open the
ticket), the same in-app and Telegram prompts, and the same 30-minute auto-close. The dashboard shows a banner while
any of their own tickets await confirmation.

**Team Leader → My Confirmations** (`teamleader/confirmations.php`, with a live count in the sidebar) collects exactly
those tickets in one place — the work ICT performed, the minutes left on each, and the two buttons — so a Team Leader
does not have to hunt through Team Tickets to close his own.

The same two buttons are attached to the Telegram message itself: **✅ Confirm & Close** closes the ticket, and
**↩️ Not Resolved** asks which problem remains (still not working / problem came back / only partly fixed / something
else) before sending it back to ICT. The press is checked against the database — only the requester linked to that
chat can act on their own ticket, and an expired or someone else's button does nothing but say so. Confirming in the
bot writes the same history, notifications and audit rows as confirming on the web page
(`includes/confirmation.php` is the one place that does it).

If the requester answers **Not Resolved**, the ticket goes back to `RETURNED_TO_ICT` and the assigned
technician is notified again in-app **and** on Telegram with the reason the fix was rejected.

### Telegram bot — lists staff can ask for

After linking (Profile page → **Connect Telegram**, or `/start` and *Share my phone number*), staff
send commands to `@epssICTbot` and get lists back, scoped to their role:

| Command | What it lists |
|---|---|
| `/tickets` | Employee: my tickets · Team Leader / Branch Manager: my team's tickets · ICT: the ICT queue · Admin: all tickets. Add `open`, `closed` or `all`. |
| `/pending` | Tickets waiting on someone now — approvals to give (TL), approved but not yet picked up (ICT), my tickets awaiting approval (employee), everything pending (admin). |
| `/employees` | Staff directory: name, role, department, position, phone (phone is hidden from plain employees). Filter with `/employees finance`. |
| `/users` | **Administrator only.** Everyone connected to the bot: name, role, department, chat id, when we last reached them and how many sends failed. Filter with `/users 900001` or `/users Alem`. |
| `/counts` | Ticket totals per status, scoped to the role. |
| `/me` · `/help` · `/menu` | My profile · command help · the button menu (also shown as a keyboard after linking). |

Press **Update command menu** on Admin → Telegram Bot to publish the command list to Telegram's blue
menu. The lists read the same tables as the web pages, so a ticket appears here the moment it is created.

The confirmation buttons arrive as `callback_query` updates, not messages. After upgrading, restart the
worker (`tools/restart_telegram_worker.ps1`) and, if you use webhook mode, press **Register webhook** again
so Telegram keeps sending button presses.

### Who is connected to the bot — Admin panel

**Admin → Telegram Bot → “Bot connections — all staff”** lists every active account — employees included,
not just Team Leaders and ICT — and marks each one **Linked** or **Not linked**. Filter by role, by link
status or by name/username/phone/department, and the card header keeps a running tally of how many are
linked, how many are not, and how many have no phone on file for the current role and search.

Each row shows the chat id, when we last reached that person and how many sends failed, which is how you
spot a stale link. A **Not linked** employee is silently missing every resolution message — including the
Confirm / Not Resolved buttons — so treat the red **without a phone** badge as a to-do list: the bot
matches on phone number, so an account with no phone saved on its profile can never link until ICT adds one.

Linked rows get **Send test** (proves the chat id is still alive) and **Unlink** (frees the number so the
person can re-link from a new account). The same view from a phone is `/users` in the bot, above.

**Admin → User Management** carries a **Notification bot** column on every row and a *Bot: linked / not
linked* filter, so you can see it while adding or editing staff.

### Telegram bot — automatic start on reboot (Windows)

Incoming bot messages are read by a polling worker (`tools/telegram_worker.php`), so the bot only
answers while that worker is running. Register it once and it starts with Windows, before anyone
logs in, and keeps itself alive:

1. Right-click `tools/install_telegram_autostart.bat` → **Run as administrator**.
   It registers the scheduled task **EPSS Telegram Worker** (runs as `SYSTEM`, trigger *At startup*)
   and starts the bot immediately.
2. Check it at any time with `schtasks /query /tn "EPSS Telegram Worker" /v /fo LIST` (as administrator).
3. Remove it with `tools/uninstall_telegram_autostart.bat` (also as administrator).

Worker output is appended to `logs/telegram_worker.log` (rotated at 5 MB). The launcher restarts PHP
with a 5-second back-off if it exits, and the worker refuses to start twice so two pollers can never
fight over `getUpdates`. To run it by hand instead, double-click `tools/start_telegram_worker.bat`.
On Linux, run `php tools/telegram_worker.php` from a systemd unit or supervisor instead.

## Preventive maintenance approval

ICT Staff → **Preventive Maintenance** → fill in the quarterly checklist → **Submit Checklist**.
The submission is saved as **Pending Approval** and every active Branch Manager is notified.

The Branch Manager signs in and opens **PM Approvals** in the sidebar (a red badge shows how many are
waiting). Each row carries the technician, department, quarter, employee count and completed-item
score; **Review & Decide** opens the full checklist matrix. From there the Branch Manager can

- **Approve Checklist** (remarks optional), or
- **Reject with Remarks** (a reason is required).

The decision is written to `pm_checklists` (`status`, `approved_by`, `approved_at`,
`approval_remarks`), recorded in the audit log, and the technician receives an in-app notification.
The technician sees the status and rejection remarks under **My Recent Submissions** and can open
the checklist read-only; a rejected checklist can be corrected and submitted again. The queue also
offers Approved / Rejected / All filters, and administrators can open it for oversight.

Upgrading an existing installation requires `database/pm_approval_migration.sql`; it adds the
approval columns and treats checklists submitted before the workflow existed as already approved.

## Annual ICT Report

Administrators open **Annual ICT Report** in the sidebar. Pick an Ethiopian calendar year (defaults
to the current one) and the page shows the reporting period plus a nine-slide preview: cover,
overview, departments supported, KPIs, work done, impact, challenges, recommendations and conclusion.
The period for E.C. year *Y* runs from 11 September *Y+7* to 10 September *Y+8* (for example,
2017 E.C. = 11 September 2024 – 10 September 2025).

Ticket, preventive-maintenance and department figures are calculated live from the helpdesk for
the selected period; the three report KPIs map as follows:

| Report KPI | Source |
|---|---|
| Percentage of Networking and ICT Support | Closed ÷ created requests |
| Percentage of Process Supported with Supply Chain Technology | Departments with tickets/PM ÷ active departments |
| Percentage of Server Manageability | Completed ÷ scheduled PM checklist items |

The overview, challenges, recommendations, conclusion and optional extra notes are editable (one
bullet per line) and saved per E.C. year in `annual_ict_reports`, so a finished year keeps its wording
when a new year is started. **Save & Download PDF** produces an A4 landscape, nine-page PDF named
`EPSS_ICT_Annual_Report_<year>_EC.pdf`. Only administrators can open the page or export the PDF.

## File Upload Security
- MIME-type validation
- Extension whitelist
- Blocked executables
- Randomised filenames
- Stored under `uploads/tickets/`

## License
Internal use — Ethiopian Pharmaceuticals Supply Service.