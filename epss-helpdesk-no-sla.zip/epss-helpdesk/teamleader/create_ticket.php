<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('TEAM_LEADER');   // also accepts BRANCH_MANAGER
$pageTitle = 'Create Ticket (Direct to ICT)';

$pdo = db(); $error = '';

/* Fixed list of locations — edit these three values if the branch names change */
$locations = ['Pool Office', 'Main Warehouse', 'Cold Room'];

$cats    = $pdo->query("SELECT * FROM categories    WHERE status='ACTIVE' ORDER BY category_name")->fetchAll();
$pris    = $pdo->query("SELECT * FROM priorities     WHERE status='ACTIVE' ORDER BY level")->fetchAll();
$subcats = $pdo->query("SELECT * FROM subcategories  WHERE status='ACTIVE' ORDER BY name")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf'] ?? null)) {
        $error = 'Invalid session.';
    } elseif (!in_array($_POST['location'] ?? '', $locations, true)) {
        $error = 'Please select a valid location.';
    } else {
        try {
            $pdo->beginTransaction();

            $ticketNumber = generate_ticket_number();
            $now = date('Y-m-d H:i:s');

            $catId  = (int)$_POST['category_id'];
            $subId  = $_POST['subcategory_id'] ? (int)$_POST['subcategory_id'] : null;
            $prioId = (int)$_POST['priority_id'];
            $loc    = $_POST['location'];

            /* Build subject + description from the chosen values */
            $catName = $pdo->query("SELECT category_name FROM categories WHERE id=" . $catId)->fetchColumn() ?: 'ICT issue';
            $subName = $subId
                ? ($pdo->query("SELECT name FROM subcategories WHERE id=" . $subId)->fetchColumn() ?: null)
                : null;

            $subject = $subName ?: $catName;
            $description =
                "Reported issue: " . ($subName ?: $catName) . "\n" .
                "Location: " . $loc . "\n" .
                "Reported by: " . $u['full_name'] . " (Team Leader)\n" .
                "Time: " . $now;

            /* Insert already APPROVED_FOR_ICT — auto-approved by the TL */
            $stmt = $pdo->prepare("INSERT INTO tickets
                (ticket_number, requester_id, department_id, team_leader_id, category_id, subcategory_id,
                 priority_id, subject, description, location,
                 status, created_at, team_leader_approved_at)
                VALUES (?,?,?,?,?,?,?,?,?,?, 'APPROVED_FOR_ICT', ?, ?)");

            $stmt->execute([
                $ticketNumber,
                $u['id'],                                       // requester = the TL
                $u['department_id'] ?: null,
                $u['id'],                                       // team_leader_id = the TL itself
                $catId,
                $subId,
                $prioId,
                $subject,
                $description,
                $loc,
                $now,
                $now,                                           // approved = now
            ]);
            $ticketId = (int)$pdo->lastInsertId();

            /* Attachment */
            if (!empty($_FILES['attachment']['name'])) {
                upload_attachment($ticketId, (int)$u['id'], $_FILES['attachment']);
            }

            /* History */
            record_history($ticketId, (int)$u['id'], null, 'APPROVED_FOR_ICT',
                'Ticket Created by Team Leader', 'Auto-approved — sent directly to ICT.');

            /* Notify every active ICT technician */
            $icts = $pdo->query("SELECT id FROM users WHERE role='ICT_STAFF' AND status='ACTIVE'")->fetchAll();
            foreach ($icts as $i) {
                notify((int)$i['id'], $ticketId,
                    'New Ticket from Team Leader',
                    "Ticket {$ticketNumber} was created by {$u['full_name']} and is ready for ICT.",
                    'approval');
            }

            audit('CreateTicketTL','tickets',$ticketId,"TL created {$ticketNumber} (direct to ICT)");

            $pdo->commit();

            try {
                require_once __DIR__ . '/../includes/telegram.php';
                telegram_notify_ict(
                    tg_msg_approved(['ticket_number' => $ticketNumber, 'subject' => $subject],
                                    (string)$u['full_name'], (string)$u['full_name'], 'Created by Team Leader (auto-approved)'),
                    $ticketId);
            } catch (Throwable $e) { error_log('TG TL ticket: ' . $e->getMessage()); }
            header("Location: ticket_view.php?id={$ticketId}&created=1");
            exit;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = app_exception_message($e);
        }
    }
}

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:#0070f2; --sap-brand-dark:#0057d2;
    --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500;
    --sap-negative:#aa0808;
    --sap-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
  }
  body, .main-content { background: var(--sap-bg) !important;
    font-family: "72","72full",Arial,Helvetica,sans-serif !important; color: var(--sap-text); }

  .sap-page-header { display:flex; justify-content:space-between; align-items:flex-start;
    margin-bottom:1rem; flex-wrap:wrap; gap:.75rem; }
  .sap-page-title { font-size:1.625rem; font-weight:400; margin:0; }
  .sap-breadcrumb { font-size:.8125rem; color:var(--sap-text-muted); margin-bottom:.25rem; }

  .sap-message { display:flex; gap:.6rem; padding:.85rem 1rem; border-radius:.5rem;
    font-size:.84rem; line-height:1.5; border-left:3px solid; margin-bottom:1rem; }
  .sap-message .bi { flex-shrink:0; font-size:1rem; margin-top:.05rem; }
  .sap-message.is-info  { background:#eaf4ff; color:#0a4a9c; border-left-color:var(--sap-brand); }
  .sap-message.is-error { background:#fef4f4; color:var(--sap-negative); border-left-color:var(--sap-negative); }

  .sap-card { background:var(--sap-tile); border-radius:.75rem; box-shadow:var(--sap-shadow); overflow:hidden; }
  .sap-card-section { padding:1.25rem 1.5rem; border-bottom:1px solid var(--sap-border-soft); }
  .sap-card-section:last-child { border-bottom:0; }
  .sap-card-section-title { font-size:.8125rem; font-weight:700; text-transform:uppercase;
    letter-spacing:.06em; color:var(--sap-text-muted); display:flex; align-items:center; gap:.45rem; margin-bottom:1rem; }
  .sap-card-section-title .bi { color:var(--sap-brand); font-size:.95rem; }

  .sap-form-label { display:block; font-size:.75rem; text-transform:uppercase;
    letter-spacing:.04em; color:var(--sap-text-muted); font-weight:600; margin-bottom:.35rem; }
  .sap-form-label .req { color: var(--sap-negative); margin-left:.15rem; }
  .sap-form-group { margin-bottom:1rem; }
  .sap-form-group:last-child { margin-bottom:0; }

  .sap-form-control { width:100%; font-size:.875rem; font-family:inherit;
    color:var(--sap-text); background:#fff; border:1px solid var(--sap-border);
    border-radius:.5rem; padding:.6rem .8rem; outline:none;
    transition: border-color .15s, box-shadow .15s; }
  .sap-form-control:focus { border-color:var(--sap-brand); box-shadow:0 0 0 3px rgba(0,112,242,.15); }
  select.sap-form-control { appearance:none;
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'><path fill='%23556b82' d='M3 5l3 3 3-3z'/></svg>");
    background-repeat:no-repeat; background-position:right .75rem center; padding-right:2rem; }
  .sap-form-hint { font-size:.72rem; color:var(--sap-text-muted); margin-top:.3rem; line-height:1.4; }
  .sap-form-hint code { background:#f4f5f7; padding:.05rem .3rem; border-radius:.25rem; font-size:.7rem; }

  .sap-file { display:flex; align-items:center; gap:.75rem;
    border:1px dashed var(--sap-border); border-radius:.5rem;
    padding:.65rem .85rem; background:#fafbfc; cursor:pointer;
    transition: border-color .15s, background .15s; }
  .sap-file:hover { border-color:var(--sap-brand); background:#f4f9ff; }
  .sap-file-icon { width:34px; height:34px; border-radius:.4rem;
    background:#eaf4ff; color:var(--sap-brand);
    display:inline-flex; align-items:center; justify-content:center; font-size:1rem; flex-shrink:0; }
  .sap-file-info { font-size:.8125rem; color:var(--sap-text); flex:1;
    overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  .sap-file-input { display:none; }
  .sap-file-btn { font-size:.75rem; color:var(--sap-brand);
    border:1px solid var(--sap-brand); border-radius:.4rem;
    padding:.25rem .55rem; background:#fff; white-space:nowrap; }

  .sap-action-bar { display:flex; align-items:center; justify-content:space-between;
    gap:.5rem; flex-wrap:wrap; background:var(--sap-tile);
    border-radius:.75rem; box-shadow:var(--sap-shadow);
    padding:.75rem 1.15rem; margin-top:1rem;
    position:sticky; bottom:1rem; z-index:20; }
  .sap-action-bar-info { font-size:.78rem; color:var(--sap-text-muted);
    display:flex; align-items:center; gap:.35rem; }
  .sap-action-bar-info .bi { color:var(--sap-brand); }

  .sap-btn { display:inline-flex; align-items:center; gap:.4rem;
    font-size:.875rem; font-weight:500; border-radius:.5rem;
    padding:.55rem 1rem; border:1px solid transparent; background:transparent;
    color:var(--sap-brand); cursor:pointer; line-height:1;
    text-decoration:none; white-space:nowrap;
    transition: background .15s, color .15s; font-family:inherit; }
  .sap-btn:hover { background:#eaf4ff; color:var(--sap-brand-dark); }
  .sap-btn.sap-btn-emphasized { background:var(--sap-brand); color:#fff;
    box-shadow:0 1px 2px rgba(34,53,72,.15); }
  .sap-btn.sap-btn-emphasized:hover { background:var(--sap-brand-dark); color:#fff; }
</style>

<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb">
      <i class="bi bi-house-door"></i> Home / Tickets / <strong>New Ticket</strong>
    </div>
    <h1 class="sap-page-title">Create Ticket — Direct to ICT</h1>
  </div>
  <a href="tickets.php" class="sap-btn">
    <i class="bi bi-arrow-left"></i> Back
  </a>
</div>

<div class="sap-message is-info">
  <i class="bi bi-lightning-charge-fill"></i>
  <div>
    <strong>This ticket will skip the Team Leader approval step.</strong><br>
    Because you are a Team Leader / Branch Manager, your ticket goes straight to the ICT queue.
  </div>
</div>

<?php if ($error): ?>
  <div class="sap-message is-error">
    <i class="bi bi-exclamation-circle"></i>
    <span><?= e($error) ?></span>
  </div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data" id="ticketForm">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">

<div class="sap-card">

  <!-- ============ Section 1: Classification ============ -->
  <div class="sap-card-section">
    <div class="sap-card-section-title">
      <i class="bi bi-tags"></i> Classification
    </div>

    <div class="row g-3">
      <div class="col-md-4">
        <div class="sap-form-group">
          <label class="sap-form-label" for="cat">
            Category<span class="req">*</span>
          </label>
          <select name="category_id" id="cat" class="sap-form-control" required>
            <option value="">-- Select --</option>
            <?php foreach ($cats as $c): ?>
              <option value="<?= (int)$c['id'] ?>"><?= e($c['category_name']) ?></option>
            <?php endforeach; ?>
          </select>
          <div class="sap-form-hint">Choose the support area that matches the issue.</div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="sap-form-group">
          <label class="sap-form-label" for="sub">Subcategory</label>
          <select name="subcategory_id" id="sub" class="sap-form-control">
            <option value="">-- None --</option>
          </select>
          <div class="sap-form-hint">Pick a specific problem if one is listed.</div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="sap-form-group">
          <label class="sap-form-label" for="prio">
            Priority<span class="req">*</span>
          </label>
          <select name="priority_id" id="prio" class="sap-form-control" required>
            <?php foreach ($pris as $p): ?>
              <option value="<?= (int)$p['id'] ?>"><?= e($p['name']) ?></option>
            <?php endforeach; ?>
          </select>
          <div class="sap-form-hint">Choose honestly — misusing <strong>Critical</strong> delays real emergencies.</div>
        </div>
      </div>
    </div>
  </div>

  <!-- ============ Section 2: Location ============ -->
  <div class="sap-card-section">
    <div class="sap-card-section-title">
      <i class="bi bi-geo-alt"></i> Location
    </div>

    <div class="row g-3">
      <div class="col-md-6">
        <div class="sap-form-group">
          <label class="sap-form-label" for="loc">
            Where is the problem?<span class="req">*</span>
          </label>
          <select name="location" id="loc" class="sap-form-control" required>
            <option value="">-- Select location --</option>
            <?php foreach ($locations as $loc): ?>
              <option value="<?= e($loc) ?>" <?= (($_POST['location'] ?? '') === $loc) ? 'selected' : '' ?>>
                <?= e($loc) ?>
              </option>
            <?php endforeach; ?>
          </select>
          <div class="sap-form-hint">Choose the area where the issue occurred.</div>
        </div>
      </div>
    </div>
  </div>

  <!-- ============ Section 3: Attachment ============ -->
  <div class="sap-card-section">
    <div class="sap-card-section-title">
      <i class="bi bi-paperclip"></i> Attachment
    </div>

    <div class="sap-form-group">
      <label class="sap-file" for="fileInput">
        <span class="sap-file-icon"><i class="bi bi-cloud-upload"></i></span>
        <span class="sap-file-info" id="fileInfo">No file selected — click to browse</span>
        <span class="sap-file-btn"><i class="bi bi-folder2-open"></i> Browse</span>
        <input type="file"
               id="fileInput"
               name="attachment"
               class="sap-file-input"
               accept=".jpg,.jpeg,.png,.gif,.pdf,.doc,.docx,.xls,.xlsx,.txt,.zip">
      </label>
      <div class="sap-form-hint">
        Optional. Max size
        <strong><?= (int)(((int)setting('max_upload_size', 10485760)) / 1024 / 1024) ?> MB</strong>
        · Allowed: <code><?= e(setting('allowed_ext','')) ?></code>
      </div>
    </div>
  </div>

</div><!-- /.sap-card -->

<!-- ============ Sticky action bar ============ -->
<div class="sap-action-bar">
  <div class="sap-action-bar-info">
    <i class="bi bi-lightning-charge-fill"></i>
    <span>Sending directly to ICT — no approval step required.</span>
  </div>
  <div class="d-flex gap-2">
    <a href="tickets.php" class="sap-btn">
      <i class="bi bi-x-lg"></i> Cancel
    </a>
    <button type="submit" class="sap-btn sap-btn-emphasized">
      <i class="bi bi-send"></i> Send to ICT
    </button>
  </div>
</div>

</form>

<script>
/* Subcategory filter */
(function () {
  const subcats = <?= json_encode($subcats) ?>;
  const catSel  = document.getElementById('cat');
  const subSel  = document.getElementById('sub');

  function refreshSubcats() {
    const cid = catSel.value;
    subSel.innerHTML = '<option value="">-- None --</option>';
    subcats
      .filter(s => String(s.category_id) === String(cid))
      .forEach(s => {
        const o = document.createElement('option');
        o.value = s.id;
        o.textContent = s.name;
        subSel.appendChild(o);
      });
  }
  catSel.addEventListener('change', refreshSubcats);
  refreshSubcats();
})();

/* File input display */
(function () {
  const input = document.getElementById('fileInput');
  const info  = document.getElementById('fileInfo');
  if (!input || !info) return;

  input.addEventListener('change', () => {
    if (input.files.length) {
      const f = input.files[0];
      const kb = (f.size / 1024).toFixed(1);
      const mb = (f.size / 1024 / 1024).toFixed(2);
      const size = f.size > 1024 * 1024 ? mb + ' MB' : kb + ' KB';
      info.textContent = f.name + '  ·  ' + size;
    } else {
      info.textContent = 'No file selected — click to browse';
    }
  });
})();
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>