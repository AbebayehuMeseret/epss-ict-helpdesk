<?php
/**
 * Team Leader → My Awaiting Confirmation
 * ---------------------------------------------------------------------------
 * Tickets the Team Leader raised for himself that ICT has resolved. He is the
 * requester here, so this is where he confirms the fix or sends it back — the
 * same two actions the Confirm / Not Resolved buttons perform in Telegram.
 * ---------------------------------------------------------------------------
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/confirmation.php';
require_once __DIR__ . '/../includes/escalation.php';
$u = require_role('TEAM_LEADER');
$pdo = db();
$id  = (int)$u['id'];

$pageTitle = 'My Awaiting Confirmation';
$notice = '';
$error  = '';

/* ---- POST: confirm or send one of my own tickets back to ICT ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf($_POST['csrf'] ?? null)
    && in_array($_POST['action'] ?? '', ['confirm_resolution', 'reject_resolution'], true)) {
    $ticketId = (int)($_POST['ticket_id'] ?? 0);
    $act      = $_POST['action'];

    $res = $act === 'confirm_resolution'
        ? ticket_confirm_resolution($ticketId, $id, trim((string)($_POST['comment'] ?? '')))
        : ticket_reject_resolution($ticketId, $id, trim((string)($_POST['reason'] ?? '')));

    if ($res['ok']) {
        $number = $res['ticket']['ticket_number'];
        $notice = $act === 'confirm_resolution'
            ? "{$number} confirmed and closed."
            : "{$number} was sent back to ICT with your reason.";
    } else {
        $error = (string)$res['error'];
    }
}

$confirmMinutes = requester_confirm_minutes();

$stmt = $pdo->prepare("SELECT t.*, c.category_name, p.name AS priority_name, p.color AS priority_color,
                              tech.full_name AS tech_name,
                              (SELECT action_taken FROM ticket_work_logs w
                                WHERE w.ticket_id = t.id ORDER BY w.created_at DESC LIMIT 1) AS work_done
                       FROM tickets t
                       JOIN categories c ON c.id = t.category_id
                       JOIN priorities p ON p.id = t.priority_id
                       LEFT JOIN users tech ON tech.id = t.assigned_technician_id
                       WHERE t.requester_id = ? AND t.status IN " . awaiting_confirmation_sql_in() . "
                       ORDER BY COALESCE(t.resolved_at, t.created_at)");
$stmt->execute([$id]);
$tickets = $stmt->fetchAll();

/* Tickets I confirmed recently, so the list has an end to it. */
$stmt = $pdo->prepare("SELECT t.ticket_number, t.subject, t.closed_at, t.verification_comment
                       FROM tickets t
                       WHERE t.requester_id = ? AND t.status = 'CLOSED' AND t.closed_at IS NOT NULL
                       ORDER BY t.closed_at DESC LIMIT 5");
$stmt->execute([$id]);
$recentlyClosed = $stmt->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:#0070f2; --sap-brand-dark:#0057d2;
    --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500;
    --sap-negative:#aa0808; --sap-neutral:#5b738b;
    --sap-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
  }
  body, .main-content { background: var(--sap-bg) !important;
    font-family: "72","72full",Arial,Helvetica,sans-serif !important; color: var(--sap-text); }

  .sap-page-header { background: var(--sap-tile); border-radius: .75rem;
    box-shadow: var(--sap-shadow); padding: 1.1rem 1.4rem; margin-bottom: 1rem;
    display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap; }
  .sap-page-title { font-size: 1.375rem; font-weight: 600; margin: 0;
    display: flex; align-items: center; gap: .55rem; }
  .sap-page-title .bi { color: var(--sap-brand); }
  .sap-page-sub { font-size: .82rem; color: var(--sap-text-muted); margin: .2rem 0 0; }

  .sap-status { display: inline-flex; align-items: center; gap: .3rem;
    font-size: .72rem; font-weight: 600; padding: .2rem .6rem;
    border-radius: .75rem; white-space: nowrap; border: 1px solid transparent; }
  .sap-status.is-good     { background:#f1fdf6; color: var(--sap-positive); border-color:#d6f0e0; }
  .sap-status.is-critical { background:#fff8f1; color: var(--sap-critical); border-color:#fbe0c8; }
  .sap-status.is-bad      { background:#fef4f4; color: var(--sap-negative); border-color:#f7d2d2; }
  .sap-status.is-info     { background:#eaf4ff; color: var(--sap-brand);    border-color:#cfe2f8; }
  .sap-status.is-neutral  { background:#f4f5f7; color: var(--sap-neutral);  border-color:#e4e7eb; }

  .sap-btn { display: inline-flex; align-items: center; gap: .4rem;
    font-size: .8125rem; font-weight: 500; border-radius: .5rem;
    padding: .5rem .9rem; border: 1px solid transparent; background: transparent;
    color: var(--sap-brand); cursor: pointer; line-height: 1; text-decoration: none;
    white-space: nowrap; transition: background .15s, color .15s; font-family: inherit; }
  .sap-btn:hover { background: #eaf4ff; color: var(--sap-brand-dark); }
  .sap-btn.sap-btn-emphasized { background: var(--sap-positive); color: #fff; }
  .sap-btn.sap-btn-emphasized:hover { background: #1d5d2e; color: #fff; }

  .sap-form-control { width: 100%; font-size: .875rem; font-family: inherit;
    color: var(--sap-text); background: #fff; border: 1px solid var(--sap-border);
    border-radius: .5rem; padding: .55rem .75rem;
    transition: border-color .15s, box-shadow .15s; outline: none; resize: vertical; }
  .sap-form-control:focus { border-color: var(--sap-brand);
    box-shadow: 0 0 0 3px rgba(0,112,242,.15); }

  .sap-message { display: flex; align-items: flex-start; gap: .6rem;
    padding: .75rem 1rem; border-radius: .5rem; font-size: .8125rem; line-height: 1.4;
    margin-bottom: .75rem; border-left: 3px solid; }
  .sap-message.is-success { background:#f1fdf6; color: var(--sap-positive); border-left-color: var(--sap-positive); }
  .sap-message.is-warning { background:#fff8f1; color: var(--sap-critical); border-left-color: var(--sap-critical); }
  .sap-message .bi { flex-shrink: 0; font-size: .95rem; margin-top: .05rem; }

  .cf-card { background: var(--sap-tile); border-radius: .75rem; margin-bottom: 1rem;
    box-shadow: var(--sap-shadow); overflow: hidden; }
  .cf-card-header { padding: .8rem 1.15rem; border-bottom: 1px solid var(--sap-border-soft); font-size: .8125rem;
    font-weight: 700; text-transform: uppercase; letter-spacing: .05em; color: var(--sap-text-muted);
    display: flex; align-items: center; justify-content: space-between; gap: .5rem; }
  .cf-ticket { padding: 1rem 1.15rem; border-bottom: 1px solid var(--sap-border-soft); }
  .cf-ticket:last-child { border-bottom: 0; }
  .cf-number { font-family: "72Mono","Courier New",monospace; font-size: .78rem; font-weight: 700;
    color: var(--sap-brand); text-decoration: none; }
  .cf-number:hover { text-decoration: underline; }
  .cf-subject { font-size: .95rem; font-weight: 600; color: var(--sap-text); margin: .15rem 0 .35rem; }
  .cf-meta { font-size: .75rem; color: var(--sap-text-muted); display: flex; gap: .9rem; flex-wrap: wrap; }
  .cf-clock { font-size: .78rem; font-weight: 600; color: var(--sap-critical); margin-top: .5rem; }
  .cf-work { font-size: .8rem; color: var(--sap-text); background: #fafbfc; border: 1px solid var(--sap-border-soft);
    border-radius: .5rem; padding: .55rem .75rem; margin-top: .6rem; }
  .cf-actions { display: flex; gap: .6rem; flex-wrap: wrap; align-items: flex-start; margin-top: .8rem; }
  .cf-reason { flex: 1 1 240px; }
  .cf-empty { text-align: center; padding: 2rem 1rem; color: var(--sap-text-muted); font-size: .85rem; }
  .cf-closed { padding: .7rem 1.15rem; border-bottom: 1px solid var(--sap-border-soft); font-size: .82rem; }
  .cf-closed:last-child { border-bottom: 0; }
</style>

<div class="sap-page-header">
  <div>
    <h1 class="sap-page-title"><i class="bi bi-patch-check"></i> My Awaiting Confirmation</h1>
    <p class="sap-page-sub">
      Tickets you raised that ICT has resolved. Nothing closes until you confirm the fix —
      or <?= (int)$confirmMinutes ?> minutes pass.
    </p>
  </div>
  <div class="d-flex gap-2 flex-wrap">
    <span class="sap-status <?= $tickets ? 'is-critical' : 'is-good' ?>">
      <i class="bi bi-hourglass-split"></i> <?= count($tickets) ?> awaiting you
    </span>
  </div>
</div>

<?php if ($notice !== ''): ?>
  <div class="sap-message is-success" style="margin-bottom:1rem">
    <i class="bi bi-check2-circle"></i><span><?= e($notice) ?></span>
  </div>
<?php endif; ?>

<?php if ($error !== ''): ?>
  <div class="sap-message is-warning" style="margin-bottom:1rem">
    <i class="bi bi-exclamation-circle"></i><span><?= e($error) ?></span>
  </div>
<?php endif; ?>

<div class="cf-card">
  <div class="cf-card-header">
    <span><i class="bi bi-list-check"></i> Resolved — waiting for your answer</span>
    <span style="font-size:.7rem;font-weight:500;text-transform:none;letter-spacing:0"><?= count($tickets) ?> ticket<?= count($tickets) === 1 ? '' : 's' ?></span>
  </div>

  <?php if (!$tickets): ?>
    <div class="cf-empty">
      <i class="bi bi-inbox" style="font-size:1.75rem;opacity:.4;display:block;margin-bottom:.4rem"></i>
      None of your own tickets are waiting for you right now.
    </div>
  <?php else: ?>
    <?php foreach ($tickets as $t):
      $resolvedTs  = !empty($t['resolved_at']) ? strtotime((string)$t['resolved_at']) : time();
      $minutesLeft = max(0, $confirmMinutes - (int)floor((time() - $resolvedTs) / 60));
      $tid         = (int)$t['id'];
    ?>
      <div class="cf-ticket">
        <a class="cf-number" href="ticket_view.php?id=<?= $tid ?>"><?= e($t['ticket_number']) ?></a>
        <div class="cf-subject"><?= e($t['subject']) ?></div>
        <div class="cf-meta">
          <span><i class="bi bi-tag"></i> <?= e($t['category_name']) ?></span>
          <span class="sap-status <?= e(match ($t['priority_color']) {
              'danger'=>'is-bad','warning'=>'is-critical','info'=>'is-info',
              'success'=>'is-good', default => 'is-neutral' }) ?>"><?= e($t['priority_name']) ?></span>
          <span><i class="bi bi-person-tools"></i>
            <?= $t['tech_name'] ? e($t['tech_name']) : 'ICT' ?></span>
          <span><i class="bi bi-clock"></i>
            resolved <?= $t['resolved_at'] ? e(date('Y-m-d H:i', strtotime((string)$t['resolved_at']))) : '—' ?></span>
        </div>

        <?php if (!empty($t['work_done'])): ?>
          <div class="cf-work"><strong>Work performed:</strong> <?= e($t['work_done']) ?></div>
        <?php endif; ?>

        <div class="cf-clock">
          <i class="bi bi-hourglass-split"></i>
          <?php if ($minutesLeft > 0): ?>
            about <strong><?= (int)$minutesLeft ?> minute<?= $minutesLeft === 1 ? '' : 's' ?></strong> left —
            after that the ticket closes automatically as confirmed.
          <?php else: ?>
            past the <?= (int)$confirmMinutes ?>-minute deadline — it closes on the next automatic check
            unless you act now.
          <?php endif; ?>
        </div>

        <div class="cf-actions">
          <form method="post">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="confirm_resolution">
            <input type="hidden" name="ticket_id" value="<?= $tid ?>">
            <button type="submit" class="sap-btn sap-btn-emphasized">
              <i class="bi bi-check2-circle"></i> Confirm &amp; Close Ticket
            </button>
          </form>

          <form method="post" class="cf-reason d-flex gap-2">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="reject_resolution">
            <input type="hidden" name="ticket_id" value="<?= $tid ?>">
            <input type="text" name="reason" class="sap-form-control" required
                   placeholder="Why is it not fixed? e.g. the printer still jams"
                   style="font-size:.82rem">
            <button type="submit" class="sap-btn" style="border:1px solid var(--sap-border)">
              <i class="bi bi-arrow-return-right"></i> Not Resolved
            </button>
          </form>
        </div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<?php if ($recentlyClosed): ?>
  <div class="cf-card">
    <div class="cf-card-header">
      <span><i class="bi bi-check2-all"></i> Recently confirmed by you</span>
    </div>
    <?php foreach ($recentlyClosed as $c): ?>
      <div class="cf-closed">
        <strong><?= e($c['subject']) ?></strong>
        <div class="cf-meta">
          <span><?= e($c['ticket_number']) ?></span>
          <span><i class="bi bi-lock"></i> closed <?= e(date('Y-m-d H:i', strtotime((string)$c['closed_at']))) ?></span>
          <?php if (trim((string)$c['verification_comment']) !== ''): ?>
            <span><i class="bi bi-chat-left-text"></i>
              confirmed automatically when the note says: <?= e(mb_strimwidth((string)$c['verification_comment'], 0, 90, '…')) ?></span>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>