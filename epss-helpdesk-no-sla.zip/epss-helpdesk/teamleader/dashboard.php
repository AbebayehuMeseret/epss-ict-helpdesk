<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('TEAM_LEADER');
$pageTitle = 'Team Leader Dashboard';
$pdo = db();
$id = (int)$u['id'];

/* ===================== KPI counts ===================== */
$stats = [
  'pending_approval' => (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE team_leader_id=$id AND status='PENDING_TEAM_LEADER_APPROVAL'")->fetchColumn(),
  'approved'         => (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE team_leader_id=$id AND status IN ('APPROVED_FOR_ICT','ASSIGNED_TO_ICT','IN_PROGRESS')")->fetchColumn(),
  /* team members' tickets waiting for THEM to confirm (own tickets are counted in my_confirm) */
  'pending_verify'   => (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE team_leader_id=$id AND requester_id<>$id AND status IN " . awaiting_confirmation_sql_in())->fetchColumn(),
  /* tickets I raised myself that ICT has resolved: I must confirm them */
  'my_confirm'       => (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE requester_id=$id AND status IN " . awaiting_confirmation_sql_in())->fetchColumn(),
  'closed'           => (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE team_leader_id=$id AND status='CLOSED'")->fetchColumn(),
  'rejected'         => (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE team_leader_id=$id AND status='REJECTED'")->fetchColumn(),
];

/* ===================== Chart data ===================== */

/* 1. Tickets by Category */
$byCat = $pdo->query("SELECT c.category_name, COUNT(t.id) cnt
    FROM categories c
    LEFT JOIN tickets t ON t.category_id = c.id AND t.team_leader_id = $id
    GROUP BY c.id HAVING cnt > 0 ORDER BY cnt DESC")->fetchAll();

/* 2. Tickets by Status (pie) */
$byStatus = $pdo->query("SELECT status, COUNT(*) cnt
    FROM tickets WHERE team_leader_id = $id
    GROUP BY status ORDER BY cnt DESC")->fetchAll();

/* 3. Tickets by Priority (pie) */
$byPriority = $pdo->query("SELECT p.name, p.color, COUNT(t.id) cnt
    FROM priorities p
    LEFT JOIN tickets t ON t.priority_id = p.id AND t.team_leader_id = $id
    GROUP BY p.id HAVING cnt > 0 ORDER BY p.level")->fetchAll();

/* 4. Monthly trend — last 12 months */
$monthly = $pdo->query("SELECT DATE_FORMAT(created_at,'%Y-%m') ym, COUNT(*) cnt
    FROM tickets
    WHERE team_leader_id = $id AND created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
    GROUP BY ym ORDER BY ym")->fetchAll();

/* 5. Monthly Created vs Closed */
$createdRows = $pdo->query("SELECT DATE_FORMAT(created_at,'%Y-%m') ym, COUNT(*) cnt
    FROM tickets
    WHERE team_leader_id = $id AND created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
    GROUP BY ym ORDER BY ym")->fetchAll();
$closedRows = $pdo->query("SELECT DATE_FORMAT(closed_at,'%Y-%m') ym, COUNT(*) cnt
    FROM tickets
    WHERE team_leader_id = $id
      AND closed_at IS NOT NULL
      AND closed_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
    GROUP BY ym ORDER BY ym")->fetchAll();

$createdMap = [];
foreach ($createdRows as $r) $createdMap[$r['ym']] = (int)$r['cnt'];
$closedMap = [];
foreach ($closedRows as $r) $closedMap[$r['ym']] = (int)$r['cnt'];

$allMonths = array_values(array_unique(array_merge(array_keys($createdMap), array_keys($closedMap))));
sort($allMonths);
$createdSeries = array_map(fn($m) => $createdMap[$m] ?? 0, $allMonths);
$closedSeries  = array_map(fn($m) => $closedMap[$m]  ?? 0, $allMonths);

/* 6. Top 5 requesters in this team */
$topRequesters = $pdo->query("SELECT req.full_name, COUNT(t.id) cnt
    FROM users req
    JOIN tickets t ON t.requester_id = req.id
    WHERE t.team_leader_id = $id
    GROUP BY req.id ORDER BY cnt DESC LIMIT 5")->fetchAll();

/* ===================== Avg resolution ===================== */
$avg = $pdo->query("SELECT AVG(TIMESTAMPDIFF(MINUTE, ict_started_at, closed_at))
    FROM tickets
    WHERE team_leader_id=$id AND closed_at IS NOT NULL AND ict_started_at IS NOT NULL")->fetchColumn();
$avgHrs = $avg ? round($avg / 60, 1) : 0;

/* Total tickets for the team */
$totalTickets = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE team_leader_id=$id")->fetchColumn();

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:#0070f2; --sap-brand-dark:#0057d2;
    --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500;
    --sap-negative:#aa0808; --sap-neutral:#5b738b;
    --sap-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
    --sap-shadow-hover: 0 0 0 1px rgba(34,53,72,.15), 0 8px 24px 0 rgba(34,53,72,.12);
  }
  body, .main-content { background: var(--sap-bg) !important;
    font-family: "72","72full",Arial,Helvetica,sans-serif !important; color: var(--sap-text); }

  .sap-page-header { display:flex; justify-content:space-between; align-items:flex-start;
    margin-bottom:1rem; flex-wrap:wrap; gap:.75rem; }
  .sap-page-title { font-size:1.625rem; font-weight:400; margin:0; }
  .sap-breadcrumb { font-size:.8125rem; color:var(--sap-text-muted); margin-bottom:.25rem; }

  .sap-status { display:inline-flex; align-items:center; gap:.3rem;
    font-size:.72rem; font-weight:600; padding:.25rem .65rem;
    border-radius:.75rem; white-space:nowrap; border:1px solid transparent; }
  .sap-status.is-info     { background:#eaf4ff; color:var(--sap-brand);    border-color:#cfe2f8; }
  .sap-status.is-critical { background:#fff8f1; color:var(--sap-critical); border-color:#fbe0c8; }
  .sap-status.is-good     { background:#f1fdf6; color:var(--sap-positive); border-color:#d6f0e0; }
  .sap-status.is-bad      { background:#fef4f4; color:var(--sap-negative); border-color:#f7d2d2; }

  .sap-tile {
    background:var(--sap-tile); border-radius:.75rem; box-shadow:var(--sap-shadow);
    padding:1rem 1.15rem; position:relative; overflow:hidden; height:100%;
    transition: box-shadow .2s, transform .2s;
    text-decoration:none; color:var(--sap-text); display:block;
    opacity:0; transform: translateY(10px);
    animation: sapFadeUp .5s cubic-bezier(.2,.8,.2,1) forwards;
  }
  .sap-tile:hover { box-shadow: var(--sap-shadow-hover); transform: translateY(-2px); color:var(--sap-text); }
  .sap-tile::before { content:""; position:absolute; top:0; left:0; right:0; height:3px; background:var(--sap-brand); }
  .sap-tile.is-critical::before { background: var(--sap-critical); }
  .sap-tile.is-good::before     { background: var(--sap-positive); }
  .sap-tile.is-bad::before      { background: var(--sap-negative); }
  .sap-tile.is-neutral::before  { background: var(--sap-neutral); }
  .sap-tile-head { display:flex; align-items:center; gap:.45rem; font-size:.72rem;
    text-transform:uppercase; letter-spacing:.04em; color:var(--sap-text-muted);
    font-weight:600; margin-bottom:.35rem; }
  .sap-tile-value { font-family:"72Mono","Courier New",monospace; font-size:2rem;
    font-weight:600; line-height:1.05; font-variant-numeric: tabular-nums; }
  .sap-tile-foot { font-size:.72rem; color:var(--sap-text-muted); margin-top:.35rem; }
  @keyframes sapFadeUp { to { opacity:1; transform: translateY(0); } }
  .sap-tile:nth-child(1) { animation-delay: .00s; }
  .sap-tile:nth-child(2) { animation-delay: .06s; }
  .sap-tile:nth-child(3) { animation-delay: .12s; }
  .sap-tile:nth-child(4) { animation-delay: .18s; }
  .sap-tile:nth-child(5) { animation-delay: .24s; }
  .sap-tile:nth-child(6) { animation-delay: .30s; }

  .sap-card { background:var(--sap-tile); border-radius:.75rem;
    box-shadow:var(--sap-shadow); overflow:hidden; height:100%; margin-bottom:1rem; }
  .sap-card-header { padding:.85rem 1.15rem; border-bottom:1px solid var(--sap-border-soft);
    font-size:.875rem; font-weight:600; display:flex; align-items:center; justify-content:space-between; gap:.5rem; }
  .sap-card-header .bi { color: var(--sap-brand); margin-right: .4rem; }
  .sap-card-body { padding:1rem 1.15rem; }
  .sap-chart-wrap { position: relative; height: 260px; }

  .sap-section-label {
    font-size:.75rem; text-transform:uppercase; letter-spacing:.06em;
    color: var(--sap-brand); font-weight:700;
    margin: 1rem 0 .5rem;
    display:flex; align-items:center; gap:.4rem;
  }
  .sap-section-label::before { content:""; display:inline-block; width:3px; height:12px;
    background: var(--sap-brand); border-radius:2px; }

  @media (prefers-reduced-motion: reduce) {
    .sap-tile { animation: none !important; opacity: 1 !important; transform: none !important; }
  }
</style>

<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb"><i class="bi bi-house-door"></i> Home / <strong>Team Leader Dashboard</strong></div>
    <h1 class="sap-page-title">Welcome, <?= e($u['full_name']) ?></h1>
  </div>
  <div class="d-flex gap-2 flex-wrap">
    <span class="sap-status is-critical"><i class="bi bi-hourglass"></i> <?= (int)$stats['pending_approval'] ?> pending</span>
    <span class="sap-status"><i class="bi bi-tools"></i> <?= (int)$stats['approved'] ?> in progress</span>
    <span class="sap-status is-bad"><i class="bi bi-patch-check"></i> <?= (int)$stats['pending_verify'] ?> awaiting requester</span>
  </div>
</div>

<?php if ($stats['my_confirm'] > 0): ?>
  <div class="sap-card mb-3" style="border-left:3px solid var(--sap-positive)">
    <div class="sap-card-body d-flex align-items-center justify-content-between gap-3 flex-wrap">
      <div>
        <strong><i class="bi bi-patch-check" style="color:var(--sap-positive)"></i>
          <?= (int)$stats['my_confirm'] ?> of your own ticket<?= $stats['my_confirm'] === 1 ? ' is' : 's are' ?> waiting for your confirmation</strong>
        <div class="text-muted" style="font-size:.82rem">ICT has resolved <?= $stats['my_confirm'] === 1 ? 'it' : 'them' ?>. Confirm the fix or send <?= $stats['my_confirm'] === 1 ? 'it' : 'them' ?> back to ICT.</div>
      </div>
      <a href="confirmations.php" class="sap-btn sap-btn-emphasized"><i class="bi bi-check2-circle"></i> Review &amp; Confirm</a>
    </div>
  </div>
<?php endif; ?>

<!-- ================= KPI Tiles ================= -->
<div class="sap-section-label">Key Performance Indicators</div>
<div class="row g-3 mb-3">
  <?php
  $tiles = [
    ['Pending Approval',       $stats['pending_approval'], 'critical', 'hourglass',      'Awaiting your review',    'approvals.php'],
    ['Approved / In Progress', $stats['approved'],         'info',     'tools',          'Sent to ICT',             'tickets.php'],
    ['Awaiting Requester',     $stats['pending_verify'],   'critical', 'patch-check',    'Resolved, not yet confirmed', 'tickets.php'],
    ['My Confirmations',       $stats['my_confirm'],       $stats['my_confirm'] > 0 ? 'critical' : 'neutral', 'person-check', 'Tickets I raised, waiting on me', 'confirmations.php'],
    ['Closed',                 $stats['closed'],           'good',     'check2-all',     'Confirmed by requester',  'tickets.php'],
    ['Rejected',               $stats['rejected'],         'bad',      'x-circle',       'Declined by you',         'tickets.php'],
  ];
  foreach ($tiles as [$label, $val, $tone, $icon, $foot, $href]): ?>
    <div class="col-6 col-md-4 col-lg-2">
      <a href="<?= e($href) ?>" class="sap-tile is-<?= $tone ?>">
        <div class="sap-tile-head"><i class="bi bi-<?= $icon ?>"></i> <?= e($label) ?></div>
        <div class="sap-tile-value" data-count="<?= (int)$val ?>">0</div>
        <div class="sap-tile-foot"><?= e($foot) ?></div>
      </a>
    </div>
  <?php endforeach; ?>
</div>

<!-- ================= Avg resolution ================= -->
<div class="sap-section-label">Resolution Time</div>
<div class="row g-3 mb-3">
  <div class="col-lg-6">
    <div class="sap-card h-100">
      <div class="sap-card-header">
        <span><i class="bi bi-clock-history"></i> Average Resolution Time</span>
        <span class="sap-status is-info"><i class="bi bi-stopwatch"></i> Hours</span>
      </div>
      <div class="sap-card-body">
        <div style="display:flex;align-items:baseline;gap:.5rem">
          <div style="font-family:'72Mono','Courier New',monospace;font-size:2rem;font-weight:600"
               data-count="<?= $avgHrs ?>" data-decimals="1">0</div>
          <div class="text-muted small">hrs</div>
        </div>
        <div class="small text-muted mt-1">
          Measured from ICT start to ticket closure, across closed team tickets.
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ================= Chart row 1 ================= -->
<div class="sap-section-label">Analytics — Overview</div>
<div class="row g-3">
  <div class="col-lg-6">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-tags"></i> Team Tickets by Category</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartCategory"></canvas></div></div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-diagram-3"></i> Tickets by Status</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartStatus"></canvas></div></div>
    </div>
  </div>
</div>

<!-- ================= Chart row 2 ================= -->
<div class="sap-section-label">Analytics — Distributions</div>
<div class="row g-3">
  <div class="col-lg-4">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-flag"></i> Tickets by Priority</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartPriority"></canvas></div></div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-person-lines-fill"></i> Top Requesters</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartTopReq"></canvas></div></div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-graph-up-arrow"></i> Monthly Trend</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartMonthly"></canvas></div></div>
    </div>
  </div>
</div>

<!-- ================= Chart row 3 ================= -->
<div class="sap-section-label">Analytics — Trends</div>
<div class="row g-3">
  <div class="col-lg-8">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-graph-up"></i> Monthly Created vs Closed</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartCreatedVsClosed"></canvas></div></div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="sap-card">
      <div class="sap-card-header"><span><i class="bi bi-pie-chart"></i> Status Share</span></div>
      <div class="sap-card-body"><div class="sap-chart-wrap"><canvas id="chartStatusShare"></canvas></div></div>
    </div>
  </div>
</div>

<script>
/* ================= Data from PHP ================= */
const catLabels     = <?= json_encode(array_column($byCat,'category_name')) ?>;
const catData       = <?= json_encode(array_map('intval', array_column($byCat,'cnt'))) ?>;

const statusLabels  = <?= json_encode(array_map(fn($r)=>str_replace('_',' ', $r['status']), $byStatus)) ?>;
const statusData    = <?= json_encode(array_map('intval', array_column($byStatus,'cnt'))) ?>;

const priorityLabels = <?= json_encode(array_column($byPriority,'name')) ?>;
const priorityData   = <?= json_encode(array_map('intval', array_column($byPriority,'cnt'))) ?>;
const priorityColors = <?= json_encode(array_map(fn($r)=>'#'.ltrim(match($r['color']){
    'danger'=>'bb0000','warning'=>'e76500','info'=>'0070f2','primary'=>'0057d2',
    'success'=>'256f3a','secondary'=>'5b738b','dark'=>'354a5f',
    default=>'5b738b'}, '#'), $byPriority)) ?>;

const topReqLabels = <?= json_encode(array_column($topRequesters,'full_name')) ?>;
const topReqData   = <?= json_encode(array_map('intval', array_column($topRequesters,'cnt'))) ?>;

const monthlyLabels = <?= json_encode(array_column($monthly,'ym')) ?>;
const monthlyData   = <?= json_encode(array_map('intval', array_column($monthly,'cnt'))) ?>;

const cvMonths  = <?= json_encode($allMonths) ?>;
const cvCreated = <?= json_encode($createdSeries) ?>;
const cvClosed  = <?= json_encode($closedSeries) ?>;

/* ================= Colors ================= */
const SAP = {
  brand:      '#0070f2',
  brandMid:   '#34495e',
  brandDark:  '#1a252f',
  positive:   '#256f3a',
  critical:   '#e76500',
  negative:   '#aa0808',
  neutral:    '#5b738b',
  palette:    ['#0070f2','#0057d2','#256f3a','#e76500','#aa0808','#5b738b','#7858a0','#0097b2'],
  grid:       '#e5e5e5',
  text:       '#556b82'
};

/* ================= Count-up animation ================= */
function animateCount(el) {
  const target   = parseFloat(el.dataset.count || '0');
  const decimals = parseInt(el.dataset.decimals || '0', 10);
  const duration = 900;
  let done = false;

  const render = (v) => {
    el.textContent = decimals ? v.toFixed(decimals) : Math.round(v).toLocaleString();
  };

  const finalise = () => {
    if (done) return;
    done = true;
    clearTimeout(fallback);
    render(target);
    el.dataset.value = String(target);
  };

  /* The tile markup ships a literal "0". Guarantee the real count replaces it
     even when requestAnimationFrame is throttled away (hidden/background tab,
     reduced motion, print) — otherwise the dashboard shows 0 for everything. */
  const fallback = setTimeout(finalise, 1200);

  if (document.visibilityState !== 'visible' ||
      window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    finalise();
    return;
  }

  const start = performance.now();
  const tick = (now) => {
    if (done) return;
    const t = Math.min(1, (now - start) / duration);
    render(target * (1 - Math.pow(1 - t, 3)));
    if (t < 1) requestAnimationFrame(tick); else finalise();
  };
  requestAnimationFrame(tick);
}

/* ================= Init =================
   This inline block is emitted before includes/footer.php loads Chart.js from
   the CDN, so touching `Chart` at the top level threw a ReferenceError and
   killed the whole script — every KPI tile stayed at 0 and no chart was drawn.
   The counters now run first (they never need Chart.js) and the Chart.js
   defaults are applied inside the handler, behind a guard. */
document.addEventListener('DOMContentLoaded', () => {

  /* KPI counters */
  document.querySelectorAll('[data-count]').forEach(animateCount);

  /* SLA bar */
  document.querySelectorAll('[data-width]').forEach((el, i) => {
    setTimeout(() => { el.style.width = el.dataset.width + '%'; }, 300 + i * 120);
  });

  /* Chart.js defaults (only when the CDN script actually loaded) */
  if (typeof Chart !== 'undefined') {
    Chart.defaults.font.family = "'72', Arial, Helvetica, sans-serif";
    Chart.defaults.font.size = 12;
    Chart.defaults.color = SAP.text;
    Chart.defaults.animation.duration = 1200;
    Chart.defaults.animation.easing = 'easeOutQuart';
  }

  /* Skip chart construction cleanly when Chart.js could not be loaded */
  const stagger = (fn, delay) => setTimeout(() => { if (typeof Chart !== 'undefined') fn(); }, delay);

  /* 1. Team tickets by category — horizontal bar */
  stagger(() => new Chart(document.getElementById('chartCategory'), {
    type: 'bar',
    data: {
      labels: catLabels,
      datasets: [{
        label: 'Tickets', data: catData,
        backgroundColor: SAP.brand,
        hoverBackgroundColor: SAP.brandMid,
        borderRadius: 4, barThickness: 18
      }]
    },
    options: {
      indexAxis: 'y', responsive: true, maintainAspectRatio: false,
      animation: { duration: 1400, easing: 'easeOutQuart' },
      plugins: { legend: { display: false } },
      scales: {
        x: { beginAtZero: true, grid: { color: SAP.grid }, ticks: { precision: 0 } },
        y: { grid: { display: false } }
      }
    }
  }), 150);

  /* 2. Tickets by status — doughnut */
  stagger(() => new Chart(document.getElementById('chartStatus'), {
    type: 'doughnut',
    data: {
      labels: statusLabels,
      datasets: [{
        data: statusData,
        backgroundColor: SAP.palette,
        borderColor: '#fff', borderWidth: 2, hoverOffset: 8
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: { duration: 1400, animateRotate: true, animateScale: true, easing: 'easeOutQuart' },
      cutout: '62%',
      plugins: { legend: { position: 'right', labels: { boxWidth: 10, padding: 10, font: { size: 10 } } } }
    }
  }), 300);

  /* 3. Tickets by priority — pie */
  stagger(() => new Chart(document.getElementById('chartPriority'), {
    type: 'pie',
    data: {
      labels: priorityLabels,
      datasets: [{
        data: priorityData,
        backgroundColor: priorityColors,
        borderColor: '#fff', borderWidth: 2, hoverOffset: 8
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: { duration: 1400, animateRotate: true, animateScale: true, easing: 'easeOutQuart' },
      plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, padding: 10, font: { size: 11 } } } }
    }
  }), 450);

  /* 4. Top requesters — horizontal bar */
  stagger(() => new Chart(document.getElementById('chartTopReq'), {
    type: 'bar',
    data: {
      labels: topReqLabels,
      datasets: [{
        label: 'Tickets', data: topReqData,
        backgroundColor: SAP.brandMid,
        borderRadius: 4, barThickness: 18
      }]
    },
    options: {
      indexAxis: 'y', responsive: true, maintainAspectRatio: false,
      animation: { duration: 1400, easing: 'easeOutQuart' },
      plugins: { legend: { display: false } },
      scales: {
        x: { beginAtZero: true, grid: { color: SAP.grid }, ticks: { precision: 0 } },
        y: { grid: { display: false } }
      }
    }
  }), 600);

  /* 5. Monthly trend — line */
  stagger(() => new Chart(document.getElementById('chartMonthly'), {
    type: 'line',
    data: {
      labels: monthlyLabels,
      datasets: [{
        label: 'Tickets', data: monthlyData,
        borderColor: SAP.brand,
        backgroundColor: 'rgba(0,112,242,.12)',
        fill: true, tension: .35,
        pointRadius: 3, pointBackgroundColor: SAP.brand,
        pointBorderColor: '#fff', pointBorderWidth: 2
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: { duration: 1600, easing: 'easeOutQuart' },
      plugins: { legend: { display: false } },
      scales: {
        y: { beginAtZero: true, grid: { color: SAP.grid }, ticks: { precision: 0 } },
        x: { grid: { display: false } }
      }
    }
  }), 750);

  /* 6. Monthly created vs closed — dual line */
  stagger(() => new Chart(document.getElementById('chartCreatedVsClosed'), {
    type: 'line',
    data: {
      labels: cvMonths,
      datasets: [
        { label: 'Created', data: cvCreated,
          borderColor: SAP.brand, backgroundColor: 'rgba(0,112,242,.12)',
          fill: true, tension: .35,
          pointRadius: 3, pointBackgroundColor: SAP.brand,
          pointBorderColor: '#fff', pointBorderWidth: 2 },
        { label: 'Closed', data: cvClosed,
          borderColor: SAP.positive, backgroundColor: 'rgba(37,111,58,.12)',
          fill: true, tension: .35,
          pointRadius: 3, pointBackgroundColor: SAP.positive,
          pointBorderColor: '#fff', pointBorderWidth: 2 }
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: { duration: 1600, easing: 'easeOutQuart' },
      plugins: { legend: { position: 'bottom' } },
      scales: {
        y: { beginAtZero: true, grid: { color: SAP.grid }, ticks: { precision: 0 } },
        x: { grid: { display: false } }
      }
    }
  }), 900);

  /* 7. Status share — polar area pie */
  stagger(() => new Chart(document.getElementById('chartStatusShare'), {
    type: 'polarArea',
    data: {
      labels: statusLabels,
      datasets: [{
        data: statusData,
        backgroundColor: SAP.palette,
        borderColor: '#fff', borderWidth: 2
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: { duration: 1400, animateRotate: true, animateScale: true, easing: 'easeOutQuart' },
      plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, padding: 8, font: { size: 10 } } } },
      scales: { r: { beginAtZero: true, grid: { color: SAP.grid }, ticks: { backdropColor: 'transparent' } } }
    }
  }), 1050);
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>