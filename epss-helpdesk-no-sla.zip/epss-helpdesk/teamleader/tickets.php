<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('TEAM_LEADER');
$pdo = db();

$filter = $_GET['filter'] ?? '';

$openStatuses = ['PENDING_TL_APPROVAL', 'PENDING_TEAM_LEADER_APPROVAL',
                 'APPROVED_FOR_ICT', 'ASSIGNED_TO_ICT', 'IN_PROGRESS', 'RETURNED_TO_ICT',
                 'WAITING_FOR_INFORMATION', 'WAITING_FOR_PARTS'];
$statusIn = "('" . implode("','", array_merge($openStatuses, awaiting_confirmation_statuses())) . "')";

$sql = "SELECT t.*, c.category_name,
               req.full_name AS requester_name,
               tech.full_name AS tech_name,
               p.name AS priority_name, p.color AS priority_color
        FROM tickets t
        JOIN categories c ON c.id = t.category_id
        JOIN priorities p ON p.id = t.priority_id
        JOIN users req ON req.id = t.requester_id
        LEFT JOIN users tech ON tech.id = t.assigned_technician_id
        WHERE t.team_leader_id = ?
          AND t.status IN {$statusIn}";

$params = [$u['id']];

if ($filter === 'waiting') {
    $sql .= " AND t.status IN ('WAITING_FOR_INFORMATION','WAITING_FOR_PARTS')";
}

$sql .= " ORDER BY
            CASE WHEN t.status IN ('WAITING_FOR_INFORMATION','WAITING_FOR_PARTS')
                 THEN 0 ELSE 1 END,
            t.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$tickets = $stmt->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:#0070f2; --sap-brand-dark:#0057d2;
    --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500;
    --sap-negative:#aa0808; --sap-neutral:#5b738b;
    --sap-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
  }
  body, .main-content { background: var(--sap-bg) !important;
    font-family: "72","72full",Arial,Helvetica,sans-serif !important; color: var(--sap-text); }

  .sap-page-header { background: var(--sap-tile); border-radius: .75rem;
    box-shadow: var(--sap-shadow); padding: 1.1rem 1.4rem; margin-bottom: 1rem;
    display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap; }
  .sap-page-title { font-size: 1.375rem; font-weight: 600; margin: 0;
    display: flex; align-items: center; gap: .55rem; }
  .sap-page-title .bi { color: var(--sap-brand); }
  .sap-page-sub { font-size: .82rem; color: var(--sap-text-muted); margin: .2rem 0 0; }

  .sap-filter-tabs { display: flex; gap: .35rem; flex-wrap: wrap; }
  .sap-filter-tab { font-size: .78rem; font-weight: 500; padding: .35rem .8rem;
    border-radius: 999px; border: 1px solid var(--sap-border); color: var(--sap-text-muted);
    text-decoration: none; background: #fff; }
  .sap-filter-tab:hover { border-color: var(--sap-brand); color: var(--sap-brand); }
  .sap-filter-tab.is-active { background: var(--sap-brand); color: #fff; border-color: var(--sap-brand); }

  .sap-card { background: var(--sap-tile); border-radius: .75rem;
    box-shadow: var(--sap-shadow); overflow: hidden; margin-bottom: 1rem; }
  .sap-card-header { padding: .8rem 1.15rem; border-bottom: 1px solid var(--sap-border-soft);
    font-size: .8125rem; font-weight: 700; text-transform: uppercase; letter-spacing: .05em;
    color: var(--sap-text-muted); display: flex; align-items: center; justify-content: space-between; gap: .5rem; }
  .sap-card-header .title-wrap { display: flex; align-items: center; gap: .45rem; }
  .sap-card-header .bi { color: var(--sap-brand); font-size: .95rem; }

  .sap-table { width: 100%; border-collapse: separate; border-spacing: 0; font-size: .84rem; }
  .sap-table thead th { text-align: left; font-size: .7rem; text-transform: uppercase;
    letter-spacing: .04em; color: var(--sap-text-muted); font-weight: 700;
    padding: .7rem 1rem; border-bottom: 1px solid var(--sap-border-soft); background: #fafbfc; }
  .sap-table tbody td { padding: .85rem 1rem; border-bottom: 1px solid var(--sap-border-soft); vertical-align: middle; }
  .sap-table tbody tr:last-child td { border-bottom: 0; }
  .sap-table tbody tr:hover { background: #fafbfc; }
  .sap-table a.ticket-link { color: var(--sap-brand); text-decoration: none; font-weight: 600;
    font-family: "72Mono","Courier New",monospace; }
  .sap-table a.ticket-link:hover { text-decoration: underline; }
  .sap-row-subject { color: var(--sap-text); }
  .sap-row-meta { font-size: .72rem; color: var(--sap-text-muted); margin-top: .1rem; }

  .sap-status { display: inline-flex; align-items: center; gap: .3rem;
    font-size: .72rem; font-weight: 600; padding: .2rem .6rem;
    border-radius: .75rem; white-space: nowrap; border: 1px solid transparent; }
  .sap-status.is-good     { background:#f1fdf6; color: var(--sap-positive); border-color:#d6f0e0; }
  .sap-status.is-critical { background:#fff8f1; color: var(--sap-critical); border-color:#fbe0c8; }
  .sap-status.is-bad      { background:#fef4f4; color: var(--sap-negative); border-color:#f7d2d2; }
  .sap-status.is-info     { background:#eaf4ff; color: var(--sap-brand);    border-color:#cfe2f8; }
  .sap-status.is-neutral  { background:#f4f5f7; color: var(--sap-neutral);  border-color:#e4e7eb; }

  .sap-prio { display: inline-flex; align-items: center; gap: .35rem;
    font-size: .72rem; font-weight: 600; padding: .2rem .6rem;
    border-radius: .75rem; color: #fff; white-space: nowrap; }
  .sap-prio .swatch { width: 7px; height: 7px; border-radius: 50%; background: rgba(255,255,255,.75); }

  .sap-empty { text-align: center; padding: 2rem 1rem; color: var(--sap-text-muted); font-size: .85rem; }
  .sap-empty .bi { font-size: 1.75rem; opacity: .4; display: block; margin-bottom: .4rem; }

  .sap-btn { display: inline-flex; align-items: center; gap: .4rem;
    font-size: .8125rem; font-weight: 500; border-radius: .5rem;
    padding: .5rem .9rem; border: 1px solid transparent; background: transparent;
    color: var(--sap-brand); cursor: pointer; line-height: 1; text-decoration: none;
    white-space: nowrap; transition: background .15s, color .15s; font-family: inherit; }
  .sap-btn:hover { background: #eaf4ff; color: var(--sap-brand-dark); }
  .sap-btn.sap-btn-emphasized { background: var(--sap-brand); color: #fff; }
  .sap-btn.sap-btn-emphasized:hover { background: var(--sap-brand-dark); color: #fff; }
</style>

<div class="sap-page-header">
  <div>
    <h1 class="sap-page-title"><i class="bi bi-people"></i> Team Tickets</h1>
    <p class="sap-page-sub">Tickets raised by your team that need your approval or attention.</p>
  </div>
  <div class="sap-filter-tabs">
    <a href="tickets.php" class="sap-filter-tab <?= $filter === '' ? 'is-active' : '' ?>">All</a>
    <a href="tickets.php?filter=waiting" class="sap-filter-tab <?= $filter === 'waiting' ? 'is-active' : '' ?>">
      <i class="bi bi-pause-circle"></i> Waiting
    </a>
  </div>
</div>

<div class="sap-card">
  <div class="sap-card-header">
    <span class="title-wrap"><i class="bi bi-list-ul"></i>
      <?= $filter === 'waiting' ? 'Blocked Tickets' : 'All Team Tickets' ?>
    </span>
    <span style="font-size:.7rem;color:var(--sap-text-muted);font-weight:500;text-transform:none;letter-spacing:0">
      <?= count($tickets) ?> ticket<?= count($tickets) === 1 ? '' : 's' ?>
    </span>
  </div>

  <?php if (!$tickets): ?>
    <div class="sap-empty">
      <i class="bi bi-inbox"></i>
      <?= $filter === 'waiting' ? 'No tickets are currently blocked.' : 'No tickets in your team queue.' ?>
    </div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="sap-table">
        <thead>
          <tr>
            <th>Ticket</th>
            <th>Requester</th>
            <th>Priority</th>
            <th>Status</th>
            <th>Technician</th>
            <th>Updated</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($tickets as $row): ?>
            <tr>
              <td>
                <a class="ticket-link" href="ticket_view.php?id=<?= (int)$row['id'] ?>">
                  <?= e($row['ticket_number']) ?>
                </a>
                <div class="sap-row-meta"><?= e($row['subject']) ?></div>
              </td>
              <td>
                <div class="sap-row-subject"><?= e($row['requester_name']) ?></div>
                <div class="sap-row-meta"><?= e($row['category_name']) ?></div>
              </td>
              <td>
                <span class="sap-prio" style="background:<?= e(match ($row['priority_color']) {
                    'danger'=>'#aa0808','warning'=>'#e76500','info'=>'#0070f2',
                    'primary'=>'#0057d2','success'=>'#256f3a','secondary'=>'#5b738b',
                    'dark'=>'#354a5f', default=>'#5b738b' }) ?>">
                  <span class="swatch"></span> <?= e($row['priority_name']) ?>
                </span>
              </td>
              <td>
                <?= status_badge($row['status']) ?>
                <?php if ((int)$row['requester_id'] === (int)$u['id']
                           && in_array($row['status'], awaiting_confirmation_statuses(), true)): ?>
                  <div style="margin-top:.35rem">
                    <span class="sap-status is-critical"><i class="bi bi-patch-check"></i> Your confirmation needed</span>
                  </div>
                <?php endif; ?>
                <?php if (is_waiting_status($row['status'])): $wm = waiting_meta($row['status']); ?>
                  <div style="margin-top:.35rem">
                    <span class="sap-status <?= e($wm['class']) ?>" title="<?= e($wm['label']) ?>">
                      <i class="bi <?= e($wm['icon']) ?>"></i> <?= e($wm['label']) ?>
                    </span>
                  </div>
                <?php endif; ?>
              </td>
              <td>
                <?php if (!empty($row['tech_name'])): ?>
                  <?= e($row['tech_name']) ?>
                <?php else: ?>
                  <span style="color:var(--sap-text-muted)">—</span>
                <?php endif; ?>
              </td>
              <td>
                <span class="sap-row-meta" style="margin:0">
                  <?= e(date('Y-m-d H:i', strtotime($row['updated_at'] ?? $row['created_at']))) ?>
                </span>
              </td>
              <td style="text-align:right">
                <a class="sap-btn" href="ticket_view.php?id=<?= (int)$row['id'] ?>">
                  Open <i class="bi bi-arrow-right"></i>
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>