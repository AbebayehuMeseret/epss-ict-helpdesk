<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/escalation.php';
require_once __DIR__ . '/../includes/workflow.php';
$u = require_role('TEAM_LEADER');
$pdo = db();
$id  = (int)$u['id'];
$tid = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT t.*, c.category_name, sc.name AS subcat_name,
    p.name AS priority_name, p.color AS priority_color,
    req.full_name AS requester_name,
    tech.full_name AS tech_name,
    d.department_name
    FROM tickets t
    JOIN categories c ON c.id=t.category_id
    LEFT JOIN subcategories sc ON sc.id=t.subcategory_id
    JOIN priorities p ON p.id=t.priority_id
    JOIN users req ON req.id=t.requester_id
    LEFT JOIN users tech ON tech.id=t.assigned_technician_id
    LEFT JOIN departments d ON d.id=t.department_id
    WHERE t.id=? AND (t.team_leader_id=? OR t.requester_id=?)");
$stmt->execute([$tid, $id, $id]);
$t = $stmt->fetch();
if (!$t) { app_fail('E-TKT-404', 'Ticket not found, or it is not in your team.'); }

/* A Team Leader who raised the ticket is its REQUESTER: after ICT resolves it,
   they must confirm the fix (or send it back) just like any other requester. */
$isRequester       = (int)$t['requester_id'] === $id;
$awaitingMyConfirm = $isRequester && user_can('tickets.confirm')
    && in_array($t['status'], awaiting_confirmation_statuses(), true);
$actionError = '';

/* ---- POST with a bad / expired token: say so (E-REQ-419) instead of doing nothing ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !verify_csrf($_POST['csrf'] ?? null)) {
    $actionError = app_error_text('E-REQ-419');
}

/* ---- POST: confirm or reject the ICT resolution (own tickets only) ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf($_POST['csrf'] ?? null)
    && in_array($_POST['action'] ?? '', ['confirm_resolution', 'reject_resolution'], true)) {
    require_once __DIR__ . '/../includes/confirmation.php';
    $act = $_POST['action'];

    if (!$isRequester) {
        $actionError = app_error_text('E-CNF-403');
    } elseif (!$awaitingMyConfirm) {
        $actionError = app_error_text('E-CNF-409');
    } else {
        $res = $act === 'confirm_resolution'
            ? ticket_confirm_resolution($tid, $id, trim((string)($_POST['confirm_comment'] ?? '')))
            : ticket_reject_resolution($tid, $id, trim((string)($_POST['reason'] ?? '')));

        if ($res['ok']) {
            header("Location: ticket_view.php?id={$tid}"); exit;
        }
        $actionError = (string)$res['error'];
    }
}

/* ---- POST: add comment ---- */
if (!empty($_POST['comment']) && empty($_POST['action']) && verify_csrf($_POST['csrf'] ?? null)) {
    $pdo->prepare("INSERT INTO ticket_comments (ticket_id,user_id,comment) VALUES (?,?,?)")
        ->execute([$tid, $id, trim($_POST['comment'])]);
    /* A Team Leader who raised the ticket is its requester: answering ICT's question resumes the work. */
    if ($isRequester) {
        try { wf_requester_replied($tid, $id, trim((string)$_POST['comment'])); }
        catch (Throwable $e) { error_log('TL reply resume: ' . app_exception_message($e)); }
    }
    header("Location: ticket_view.php?id={$tid}"); exit;
}

$history = $pdo->prepare("SELECT h.*, u.full_name FROM ticket_history h
    JOIN users u ON u.id=h.user_id WHERE h.ticket_id=? ORDER BY h.created_at");
$history->execute([$tid]); $history = $history->fetchAll();

$attachments = $pdo->prepare("SELECT * FROM ticket_attachments WHERE ticket_id=? ORDER BY uploaded_at");
$attachments->execute([$tid]); $attachments = $attachments->fetchAll();

$comments = $pdo->prepare("SELECT c.*, u.full_name FROM ticket_comments c
    JOIN users u ON u.id=c.user_id WHERE c.ticket_id=? ORDER BY c.created_at");
$comments->execute([$tid]); $comments = $comments->fetchAll();

$work = $pdo->prepare("SELECT w.*, u.full_name FROM ticket_work_logs w
    JOIN users u ON u.id=w.technician_id WHERE w.ticket_id=? ORDER BY w.created_at DESC");
$work->execute([$tid]); $work = $work->fetchAll();

/* ---- Helpers (same as employee version) ---- */
function status_meta(string $status): array {
    return match ($status) {
        'PENDING_TEAM_LEADER_APPROVAL'              => ['Pending Team Leader Approval','critical','hourglass-split'],
        'RETURNED_TO_EMPLOYEE'                      => ['Returned to Employee','critical','arrow-return-left'],
        'APPROVED_FOR_ICT'                          => ['Approved for ICT','info','check2-circle'],
        'ASSIGNED_TO_ICT'                           => ['Assigned to ICT','info','person-check'],
        'IN_PROGRESS'                               => ['In Progress','info','tools'],
        'WAITING_FOR_INFORMATION'                   => ['Waiting for Information','neutral','pause-circle'],
        'WAITING_FOR_PARTS'                         => ['Waiting for Parts','neutral','pause-circle'],
        'WORK_COMPLETED'                            => ['Work Completed','good','check2'],
        'RESOLVED_PENDING_REQUESTER_CONFIRMATION'   => ['Awaiting Requester Confirmation','critical','patch-check'],
        'RESOLVED_PENDING_TEAM_LEADER_VERIFICATION' => ['Awaiting Requester Confirmation','critical','patch-check'],
        'RETURNED_TO_ICT'                           => ['Returned to ICT','critical','arrow-return-right'],
        'REJECTED'                                  => ['Rejected','bad','x-circle'],
        'CLOSED'                                    => ['Closed','good','check2-all'],
        'CANCELLED'                                 => ['Cancelled','neutral','slash-circle'],
        default                                     => [str_replace('_',' ',$status),'neutral','circle'],
    };
}
function prio_hex(string $c): string {
    return match ($c) {
        'danger'=>'#aa0808','warning'=>'#e76500','info'=>'#0070f2',
        'primary'=>'#0057d2','success'=>'#256f3a','secondary'=>'#5b738b',
        'dark'=>'#354a5f', default=>'#5b738b' };
}

[$statusLabel, $statusTone, $statusIcon] = status_meta($t['status']);
if ($awaitingMyConfirm) { $statusLabel = 'Awaiting Your Confirmation'; }
$prioHex = prio_hex($t['priority_color']);
$needsAction = $t['status'] === 'PENDING_TEAM_LEADER_APPROVAL';

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:#0070f2; --sap-brand-dark:#0057d2;
    --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500;
    --sap-negative:#aa0808; --sap-neutral:#5b738b;
    --sap-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
  }
  body, .main-content { background: var(--sap-bg) !important;
    font-family: "72","72full",Arial,Helvetica,sans-serif !important; color: var(--sap-text); }

  .sap-obj-header { background: var(--sap-tile); border-radius: .75rem;
    box-shadow: var(--sap-shadow); padding: 1.1rem 1.4rem; margin-bottom: 1rem; }
  .sap-breadcrumb { font-size: .78rem; color: var(--sap-text-muted);
    margin-bottom: .35rem; display: flex; align-items: center; gap: .3rem; }
  .sap-breadcrumb a { color: var(--sap-brand); text-decoration: none; }
  .sap-breadcrumb a:hover { text-decoration: underline; }
  .sap-obj-title { font-size: 1.375rem; font-weight: 600;
    margin: 0 0 .25rem; display: flex; align-items: center; gap: .6rem; flex-wrap: wrap; }
  .sap-obj-id { font-family: "72Mono","Courier New",monospace; font-size: 1rem;
    color: var(--sap-brand); background: #eaf4ff; border: 1px solid #cfe2f8;
    padding: .1rem .55rem; border-radius: .35rem; }
  .sap-obj-subject { font-size: .9rem; color: var(--sap-text-muted); margin: 0; }
  .sap-obj-pills { display: flex; gap: .4rem; flex-wrap: wrap; margin-top: .75rem; }

  .sap-status { display: inline-flex; align-items: center; gap: .3rem;
    font-size: .72rem; font-weight: 600; padding: .2rem .6rem;
    border-radius: .75rem; white-space: nowrap; border: 1px solid transparent; }
  .sap-status.is-good     { background:#f1fdf6; color: var(--sap-positive); border-color:#d6f0e0; }
  .sap-status.is-critical { background:#fff8f1; color: var(--sap-critical); border-color:#fbe0c8; }
  .sap-status.is-bad      { background:#fef4f4; color: var(--sap-negative); border-color:#f7d2d2; }
  .sap-status.is-info     { background:#eaf4ff; color: var(--sap-brand);    border-color:#cfe2f8; }
  .sap-status.is-neutral  { background:#f4f5f7; color: var(--sap-neutral);  border-color:#e4e7eb; }

  .sap-prio { display: inline-flex; align-items: center; gap: .35rem;
    font-size: .72rem; font-weight: 600; padding: .2rem .6rem;
    border-radius: .75rem; color: #fff; white-space: nowrap; }
  .sap-prio .swatch { width: 7px; height: 7px; border-radius: 50%; background: rgba(255,255,255,.75); }

  .sap-card { background: var(--sap-tile); border-radius: .75rem;
    box-shadow: var(--sap-shadow); overflow: hidden; margin-bottom: 1rem; }
  .sap-card:last-child { margin-bottom: 0; }
  .sap-card-header { padding: .8rem 1.15rem; border-bottom: 1px solid var(--sap-border-soft);
    font-size: .8125rem; font-weight: 700; text-transform: uppercase; letter-spacing: .05em;
    color: var(--sap-text-muted); display: flex; align-items: center; justify-content: space-between; gap: .5rem; }
  .sap-card-header .title-wrap { display: flex; align-items: center; gap: .45rem; }
  .sap-card-header .bi { color: var(--sap-brand); font-size: .95rem; }
  .sap-card-body { padding: 1rem 1.15rem; }

  .sap-action-card { border-left: 3px solid var(--sap-critical); }
  .sap-action-card .sap-card-header { color: var(--sap-critical); }
  .sap-action-card .sap-card-header .bi { color: var(--sap-critical); }

  .sap-info-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: .85rem 1.25rem; }
  .sap-info-label { font-size: .68rem; text-transform: uppercase; letter-spacing: .05em;
    font-weight: 600; color: var(--sap-text-muted); margin-bottom: .15rem; }
  .sap-info-value { font-size: .875rem; color: var(--sap-text); word-break: break-word; }
  .sap-info-value.mono { font-family: "72Mono","Courier New",monospace; }

  .sap-desc { white-space: pre-wrap; font-size: .875rem; line-height: 1.65;
    background: #fafbfc; border: 1px solid var(--sap-border-soft);
    border-radius: .5rem; padding: .85rem 1rem; margin-top: .35rem; }

  .sap-message { display: flex; align-items: flex-start; gap: .6rem;
    padding: .75rem 1rem; border-radius: .5rem; font-size: .8125rem; line-height: 1.4;
    margin-bottom: .75rem; border-left: 3px solid; }
  .sap-message.is-error   { background:#fef4f4; color: var(--sap-negative); border-left-color:var(--sap-negative); }
  .sap-message.is-warning { background:#fff8f1; color: var(--sap-critical); border-left-color:var(--sap-critical); }
  .sap-message.is-info    { background:#eaf4ff; color: var(--sap-brand);    border-left-color:var(--sap-brand); }
  .sap-message .bi { flex-shrink: 0; font-size: .95rem; margin-top: .05rem; }

  .sap-form-control { width: 100%; font-size: .875rem; font-family: inherit;
    color: var(--sap-text); background: #fff; border: 1px solid var(--sap-border);
    border-radius: .5rem; padding: .55rem .75rem;
    transition: border-color .15s, box-shadow .15s; outline: none; resize: vertical; }
  .sap-form-control:focus { border-color: var(--sap-brand);
    box-shadow: 0 0 0 3px rgba(0,112,242,.15); }

  .sap-btn { display: inline-flex; align-items: center; gap: .4rem;
    font-size: .8125rem; font-weight: 500; border-radius: .5rem;
    padding: .5rem .9rem; border: 1px solid transparent; background: transparent;
    color: var(--sap-brand); cursor: pointer; line-height: 1; text-decoration: none;
    white-space: nowrap; transition: background .15s, color .15s; font-family: inherit; }
  .sap-btn:hover { background: #eaf4ff; color: var(--sap-brand-dark); }
  .sap-btn.sap-btn-emphasized { background: var(--sap-brand); color: #fff;
    box-shadow: 0 1px 2px rgba(34,53,72,.15); }
  .sap-btn.sap-btn-emphasized:hover { background: var(--sap-brand-dark); color: #fff; }
  .sap-btn.sap-btn-success { background: var(--sap-positive); color: #fff; }
  .sap-btn.sap-btn-success:hover { background: #1d5d2e; color: #fff; }
  .sap-btn.sap-btn-warning { background: var(--sap-critical); color: #fff; }
  .sap-btn.sap-btn-warning:hover { background: #cc5800; color: #fff; }
  .sap-btn.sap-btn-danger  { background: var(--sap-negative); color: #fff; }
  .sap-btn.sap-btn-danger:hover { background: #8a0606; color: #fff; }
  .sap-btn.sap-btn-icon { padding: .45rem .55rem; }

  .sap-timeline { list-style: none; margin: 0; padding: .25rem 0 .25rem 1.5rem; position: relative; }
  .sap-timeline::before { content: ''; position: absolute; left: .35rem; top: .4rem; bottom: .4rem;
    width: 2px; background: linear-gradient(180deg, var(--sap-brand) 0%, var(--sap-border-soft) 100%);
    border-radius: 1px; }
  .sap-timeline li { position: relative; padding: 0 0 .95rem 0; font-size: .84rem; }
  .sap-timeline li:last-child { padding-bottom: 0; }
  .sap-timeline li::before { content: ''; position: absolute;
    left: -1.35rem; top: .28rem; width: 10px; height: 10px; border-radius: 50%;
    background: #fff; border: 2px solid var(--sap-brand);
    box-shadow: 0 0 0 3px rgba(0,112,242,.10); }
  .sap-timeline li.is-latest::before { background: var(--sap-brand);
    box-shadow: 0 0 0 4px rgba(0,112,242,.20); }
  .sap-tl-action { font-weight: 600; color: var(--sap-text); display: block; }
  .sap-tl-meta { font-size: .72rem; color: var(--sap-text-muted); margin-top: .1rem; }
  .sap-tl-note { font-size: .78rem; color: var(--sap-text-muted); margin-top: .35rem;
    background: #fafbfc; border-left: 2px solid var(--sap-border-soft);
    padding: .35rem .6rem; border-radius: .25rem; white-space: pre-wrap; }

  .sap-comment { padding: .75rem .9rem; border-radius: .5rem;
    background: #fafbfc; border: 1px solid var(--sap-border-soft);
    margin-bottom: .55rem; font-size: .82rem; }
  .sap-comment:last-child { margin-bottom: 0; }
  .sap-comment-head { display: flex; align-items: baseline; gap: .5rem;
    margin-bottom: .25rem; flex-wrap: wrap; }
  .sap-comment-author { font-weight: 600; color: var(--sap-text); }
  .sap-comment-time { font-size: .7rem; color: var(--sap-text-muted); }
  .sap-comment-body { white-space: pre-wrap; line-height: 1.55; }

  .sap-attach { display: flex; align-items: center; gap: .65rem;
    padding: .55rem .7rem; border-radius: .5rem; background: #fafbfc;
    border: 1px solid var(--sap-border-soft); text-decoration: none;
    color: var(--sap-text); font-size: .82rem;
    transition: background .12s, border-color .12s; margin-bottom: .45rem; }
  .sap-attach:last-child { margin-bottom: 0; }
  .sap-attach:hover { background: #f4f9ff; border-color: #cfe2f8; color: var(--sap-brand); }
  .sap-attach-icon { width: 30px; height: 30px; border-radius: .4rem;
    background: #eaf4ff; color: var(--sap-brand);
    display: inline-flex; align-items: center; justify-content: center; font-size: .95rem; flex-shrink: 0; }
  .sap-attach-info { flex: 1; min-width: 0; }
  .sap-attach-name { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .sap-attach-meta { font-size: .7rem; color: var(--sap-text-muted); }
  .sap-attach-dl { color: var(--sap-text-muted); font-size: .95rem; flex-shrink: 0; }

  .sap-empty { text-align: center; padding: 1.25rem .75rem; color: var(--sap-text-muted); font-size: .82rem; }
  .sap-empty .bi { font-size: 1.5rem; opacity: .4; display: block; margin-bottom: .3rem; }

  .sap-worklog { border: 1px solid var(--sap-border-soft); border-radius: .5rem;
    padding: .85rem 1rem; margin-bottom: .65rem; background: #fafbfc; font-size: .82rem; }
  .sap-worklog:last-child { margin-bottom: 0; }
  .sap-worklog-head { display: flex; align-items: baseline; gap: .5rem;
    margin-bottom: .5rem; font-size: .75rem; color: var(--sap-text-muted); }
  .sap-worklog-row { display: flex; gap: .5rem; margin-bottom: .35rem; }
  .sap-worklog-row:last-child { margin-bottom: 0; }
  .sap-worklog-lbl { font-weight: 600; color: var(--sap-text-muted);
    text-transform: uppercase; font-size: .68rem; letter-spacing: .04em;
    min-width: 90px; flex-shrink: 0; }
  .sap-worklog-val { color: var(--sap-text); white-space: pre-wrap; }

  @media (prefers-reduced-motion: reduce) { .sap-btn, .sap-attach { transition: none !important; } }
</style>

<div class="sap-obj-header">
  <div class="sap-breadcrumb">
    <a href="dashboard.php"><i class="bi bi-house-door"></i> Home</a>
    <i class="bi bi-chevron-right" style="font-size:.65rem"></i>
    <a href="tickets.php">Team Tickets</a>
    <i class="bi bi-chevron-right" style="font-size:.65rem"></i>
    <strong style="color:var(--sap-text)"><?= e($t['ticket_number']) ?></strong>
  </div>

  <h1 class="sap-obj-title">
    <span class="sap-obj-id"><?= e($t['ticket_number']) ?></span>
    <span><?= e($t['subject']) ?></span>
  </h1>
  <p class="sap-obj-subject">
    Submitted by <strong><?= e($t['requester_name']) ?></strong>
    on <?= e(date('Y-m-d H:i', strtotime($t['created_at']))) ?>
  </p>

  <div class="sap-obj-pills">
    <span class="sap-status is-<?= e($statusTone) ?>">
      <i class="bi bi-<?= e($statusIcon) ?>"></i> <?= e($statusLabel) ?>
    </span>
    <span class="sap-prio" style="background:<?= e($prioHex) ?>">
      <span class="swatch"></span> <?= e($t['priority_name']) ?>
    </span>
  </div>

  <div class="d-flex gap-2 mt-3 flex-wrap">
    <a href="tickets.php" class="sap-btn"><i class="bi bi-arrow-left"></i> Back</a>
    <a href="<?= BASE_URL ?>/public/chat.php?ticket_id=<?= (int)$t['id'] ?>&subject=<?= urlencode('Chat: ' . $t['ticket_number']) ?>"
       class="sap-btn"><i class="bi bi-chat-dots"></i> Discuss in Chat</a>
    <?php if ($t['status'] === 'PENDING_TEAM_LEADER_APPROVAL'): ?>
      <a href="approvals.php" class="sap-btn sap-btn-warning">
        <i class="bi bi-check2-square"></i> Go to Approvals
      </a>
    <?php endif; ?>
  </div>
</div>

<?= wf_stepper($t, (string)($t['tech_name'] ?? '')) ?>

<?php if ($actionError): ?>
  <div class="sap-message is-error">
    <i class="bi bi-x-circle"></i><span><?= e($actionError) ?></span>
  </div>
<?php endif; ?>

<?php if ($awaitingMyConfirm): ?>
  <div class="sap-message is-warning">
    <i class="bi bi-patch-check"></i>
    <span>
      ICT has resolved your ticket. <strong>Please confirm the fix</strong> below so it can be closed,
      or send it back to ICT if the problem is still there.
    </span>
  </div>
<?php endif; ?>

<?php if ($needsAction): ?>
  <div class="sap-message is-warning">
    <i class="bi bi-exclamation-circle"></i>
    <span>
      This ticket requires your action.
      Open the <a href="approvals.php" style="color:var(--sap-critical);font-weight:600">Pending Approvals</a> page to approve, return, or reject it.
    </span>
  </div>
<?php endif; ?>

<div class="row g-3">
  <div class="col-lg-8">

    <?php if ($awaitingMyConfirm): ?>
      <?php
        $confirmMinutes = requester_confirm_minutes();
        $resolvedTs     = $t['resolved_at'] ? strtotime($t['resolved_at']) : time();
        $minutesLeft    = max(0, $confirmMinutes - (int) floor((time() - $resolvedTs) / 60));
        $lastWork       = $work[0] ?? null;   // newest work log first
      ?>
      <div class="sap-card" style="border-left:3px solid var(--sap-positive)">
        <div class="sap-card-header" style="color:var(--sap-positive)">
          <span class="title-wrap">
            <i class="bi bi-patch-check" style="color:var(--sap-positive)"></i>
            Action Required — Confirm Your Ticket Is Resolved
          </span>
        </div>
        <div class="sap-card-body">
          <p class="text-muted mb-2" style="font-size:.82rem">
            ICT marked this ticket as resolved on
            <strong><?= $t['resolved_at'] ? e(date('Y-m-d H:i', strtotime($t['resolved_at']))) : '—' ?></strong>.
            If the problem is fixed, confirm and the ticket will be closed. If it is not fixed,
            send it back to ICT with a short explanation.
          </p>

          <div class="sap-message is-warning" style="margin-bottom:.9rem">
            <i class="bi bi-clock-history"></i>
            <div>
              <strong>Please answer within <?= (int)$confirmMinutes ?> minutes</strong> —
              <?php if ($minutesLeft > 0): ?>
                about <strong><?= (int)$minutesLeft ?> minute<?= $minutesLeft === 1 ? '' : 's' ?></strong> left.
              <?php else: ?>
                this ticket is past its deadline and will close automatically on the next check.
              <?php endif; ?>
              If you do not confirm (or send it back to ICT), the ticket is closed automatically as confirmed.
            </div>
          </div>

          <?php if ($lastWork): ?>
            <div class="sap-info-label">Work Performed</div>
            <div class="sap-desc"><?= e($lastWork['action_taken'] ?? '—') ?></div>
            <div class="text-muted mt-1" style="font-size:.75rem">
              By <?= e($lastWork['full_name']) ?> · <?= e(date('Y-m-d H:i', strtotime($lastWork['created_at']))) ?>
            </div>
          <?php endif; ?>

          <form method="post" class="mt-3">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="confirm_resolution">
            <label class="sap-info-label">Comment (optional)</label>
            <textarea name="confirm_comment" class="sap-form-control" rows="2"
                      placeholder="Anything to add about the fix?"></textarea>
            <div class="mt-2 d-flex gap-2 flex-wrap">
              <button type="submit" class="sap-btn sap-btn-emphasized">
                <i class="bi bi-check2-circle"></i> Confirm &amp; Close Ticket
              </button>
              <button type="button" class="sap-btn" style="border:1px solid var(--sap-border)"
                      data-bs-toggle="modal" data-bs-target="#notResolvedModal">
                <i class="bi bi-arrow-return-right"></i> Not Resolved — Return to ICT
              </button>
            </div>
          </form>
        </div>
      </div>
    <?php endif; ?>

    <div class="sap-card">
      <div class="sap-card-header">
        <span class="title-wrap"><i class="bi bi-info-circle"></i> Ticket Details</span>
      </div>
      <div class="sap-card-body">
        <div class="sap-info-grid">
          <div><div class="sap-info-label">Requester</div><div class="sap-info-value"><?= e($t['requester_name']) ?></div></div>
          <div><div class="sap-info-label">Department</div><div class="sap-info-value"><?= e($t['department_name'] ?? '—') ?></div></div>
          <div><div class="sap-info-label">Category</div><div class="sap-info-value"><?= e($t['category_name']) ?></div></div>
          <div><div class="sap-info-label">Subcategory</div><div class="sap-info-value"><?= e($t['subcat_name'] ?? '—') ?></div></div>
          <div><div class="sap-info-label">Location</div><div class="sap-info-value"><?= e($t['location'] ?? '—') ?></div></div>
          <div><div class="sap-info-label">Asset / Equipment</div><div class="sap-info-value mono"><?= e($t['asset_number'] ?? '—') ?></div></div>
          <div><div class="sap-info-label">Preferred Contact</div><div class="sap-info-value"><?= e($t['preferred_contact'] ?? '—') ?></div></div>
          <div><div class="sap-info-label">Technician</div><div class="sap-info-value"><?= e($t['tech_name'] ?? '—') ?></div></div>
          <div><div class="sap-info-label">Approved</div><div class="sap-info-value mono"><?= $t['team_leader_approved_at'] ? e(date('Y-m-d H:i', strtotime($t['team_leader_approved_at']))) : '—' ?></div></div>
          <div><div class="sap-info-label">Closed</div><div class="sap-info-value mono"><?= $t['closed_at'] ? e(date('Y-m-d H:i', strtotime($t['closed_at']))) : '—' ?></div></div>
        </div>

        <div style="margin-top:1.25rem">
          <div class="sap-info-label">Description</div>
          <div class="sap-desc"><?= e($t['description']) ?></div>
        </div>

        <?php if ($t['rejection_reason']): ?>
          <div class="sap-message is-error" style="margin-top:1.15rem">
            <i class="bi bi-x-circle"></i>
            <div><strong>Rejection Reason:</strong><br><?= nl2br(e($t['rejection_reason'])) ?></div>
          </div>
        <?php endif; ?>
        <?php if ($t['clarification_reason']): ?>
          <div class="sap-message is-warning" style="margin-top:1.15rem">
            <i class="bi bi-question-circle"></i>
            <div><strong>Clarification Requested:</strong><br><?= nl2br(e($t['clarification_reason'])) ?></div>
          </div>
        <?php endif; ?>
        <?php if ($t['verification_comment']): ?>
          <div class="sap-message is-info" style="margin-top:1.15rem">
            <i class="bi bi-info-circle"></i>
            <div><strong>Requester Confirmation Comment:</strong><br><?= nl2br(e($t['verification_comment'])) ?></div>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <?php if ($work): ?>
      <div class="sap-card">
        <div class="sap-card-header">
          <span class="title-wrap"><i class="bi bi-tools"></i> ICT Work Logs</span>
        </div>
        <div class="sap-card-body">
          <?php foreach ($work as $w): ?>
            <div class="sap-worklog">
              <div class="sap-worklog-head">
                <strong><?= e($w['full_name']) ?></strong>
                · <?= e(date('Y-m-d H:i', strtotime($w['created_at']))) ?>
              </div>
              <?php foreach ([
                'Diagnosis' => $w['diagnosis'],
                'Action Taken' => $w['action_taken'],
                'Root Cause' => $w['root_cause'],
                'Resolution' => $w['resolution'],
                'Remarks' => $w['remarks'],
              ] as $lbl => $val): ?>
                <?php if (!empty($val)): ?>
                  <div class="sap-worklog-row">
                    <div class="sap-worklog-lbl"><?= e($lbl) ?></div>
                    <div class="sap-worklog-val"><?= e($val) ?></div>
                  </div>
                <?php endif; ?>
              <?php endforeach; ?>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    <?php endif; ?>

    <div class="sap-card">
      <div class="sap-card-header">
        <span class="title-wrap"><i class="bi bi-chat-square-text"></i> Add a Comment</span>
      </div>
      <div class="sap-card-body">
        <form method="post">
          <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
          <textarea name="comment" class="sap-form-control" rows="3" required
                    placeholder="Write a comment visible to the employee, ICT, and other TLs…"></textarea>
          <div class="mt-2">
            <button type="submit" class="sap-btn"><i class="bi bi-send"></i> Post Comment</button>
          </div>
        </form>
      </div>
    </div>

    <div class="sap-card">
      <div class="sap-card-header">
        <span class="title-wrap"><i class="bi bi-clock-history"></i> Timeline</span>
        <span style="font-size:.7rem;color:var(--sap-text-muted);font-weight:500;text-transform:none;letter-spacing:0">
          <?= count($history) ?> event<?= count($history) === 1 ? '' : 's' ?>
        </span>
      </div>
      <div class="sap-card-body">
        <?php if (!$history): ?>
          <div class="sap-empty"><i class="bi bi-clock-history"></i>No history yet.</div>
        <?php else: ?>
          <ul class="sap-timeline">
            <?php $lastIdx = count($history) - 1; foreach ($history as $i => $h): ?>
              <li class="<?= $i === $lastIdx ? 'is-latest' : '' ?>">
                <span class="sap-tl-action"><?= e($h['action']) ?></span>
                <div class="sap-tl-meta"><?= e($h['full_name']) ?> · <?= e(date('Y-m-d H:i', strtotime($h['created_at']))) ?></div>
                <?php if (!empty($h['comment'])): ?>
                  <div class="sap-tl-note"><?= e($h['comment']) ?></div>
                <?php endif; ?>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>
    </div>

  </div>

  <div class="col-lg-4">
    <div class="sap-card">
      <div class="sap-card-header">
        <span class="title-wrap"><i class="bi bi-paperclip"></i> Attachments</span>
        <?php if ($attachments): ?>
          <span style="font-size:.7rem;color:var(--sap-text-muted);font-weight:500;text-transform:none;letter-spacing:0"><?= count($attachments) ?></span>
        <?php endif; ?>
      </div>
      <div class="sap-card-body">
        <?php if (!$attachments): ?>
          <div class="sap-empty"><i class="bi bi-paperclip"></i>No attachments.</div>
        <?php else: foreach ($attachments as $a): ?>
          <a class="sap-attach" href="<?= UPLOAD_URL . e($a['stored_name']) ?>" target="_blank" rel="noopener">
            <span class="sap-attach-icon"><i class="bi bi-file-earmark"></i></span>
            <span class="sap-attach-info">
              <div class="sap-attach-name" title="<?= e($a['file_name']) ?>"><?= e($a['file_name']) ?></div>
              <div class="sap-attach-meta"><?= number_format($a['file_size']/1024, 1) ?> KB · <?= e(date('Y-m-d H:i', strtotime($a['uploaded_at']))) ?></div>
            </span>
            <span class="sap-attach-dl"><i class="bi bi-download"></i></span>
          </a>
        <?php endforeach; endif; ?>
      </div>
    </div>

    <div class="sap-card">
      <div class="sap-card-header">
        <span class="title-wrap"><i class="bi bi-chat-dots"></i> Comments</span>
        <?php if ($comments): ?>
          <span style="font-size:.7rem;color:var(--sap-text-muted);font-weight:500;text-transform:none;letter-spacing:0"><?= count($comments) ?></span>
        <?php endif; ?>
      </div>
      <div class="sap-card-body">
        <?php if (!$comments): ?>
          <div class="sap-empty"><i class="bi bi-chat-dots"></i>No comments yet.</div>
        <?php else: foreach ($comments as $c): ?>
          <div class="sap-comment">
            <div class="sap-comment-head">
              <span class="sap-comment-author"><?= e($c['full_name']) ?></span>
              <span class="sap-comment-time"><?= e(date('Y-m-d H:i', strtotime($c['created_at']))) ?></span>
            </div>
            <div class="sap-comment-body"><?= e($c['comment']) ?></div>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
  </div>
</div>

<?php if ($awaitingMyConfirm): ?>
<div class="modal fade" id="notResolvedModal" tabindex="-1">
  <div class="modal-dialog">
    <form method="post" class="modal-content">
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
      <input type="hidden" name="action" value="reject_resolution">
      <div class="modal-header">
        <h5 class="modal-title">Issue Not Resolved</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <label class="sap-info-label">What is still wrong? *</label>
        <textarea name="reason" class="sap-form-control" rows="3" required
                  placeholder="Explain what is still not working…"></textarea>
      </div>
      <div class="modal-footer">
        <button type="button" class="sap-btn" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="sap-btn sap-btn-emphasized">Return to ICT</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
