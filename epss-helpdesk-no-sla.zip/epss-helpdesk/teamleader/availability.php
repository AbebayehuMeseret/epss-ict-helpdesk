<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('TEAM_LEADER');
$pdo = db();

$error   = '';
$success = '';

/* -------------------------------------------------------------------------
 * Handle POST: TL updates someone's availability.
 * ------------------------------------------------------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf($_POST['csrf'] ?? null)) {
    $targetId = (int)($_POST['user_id'] ?? 0);
    $newStat  = $_POST['status'] ?? '';
    $note     = trim($_POST['note'] ?? '');

    $allowed = ['AVAILABLE', 'ON_LEAVE', 'BUSY', 'OFF_DUTY'];

    try {
        if (!$targetId || !in_array($newStat, $allowed, true)) {
            throw new RuntimeException('Invalid availability update.');
        }

        // Make sure the target user belongs to the TL's department (or is one
        // of the TL's own staff). Adjust the WHERE as needed for your schema.
        $chk = $pdo->prepare(
            "SELECT u.id
               FROM users u
              WHERE u.id = ?
                AND u.status = 'ACTIVE'
                AND (
                     u.department_id = (SELECT department_id FROM users WHERE id = ?)
                     OR u.team_leader_id = ?
                )"
        );
        $chk->execute([$targetId, $u['id'], $u['id']]);
        if (!$chk->fetchColumn()) {
            throw new RuntimeException('You can only manage availability for your own team.');
        }

        $pdo->beginTransaction();

        $stmt = $pdo->prepare(
            "INSERT INTO user_availability
                (user_id, status, note, updated_by, effective_from)
             VALUES (?, ?, ?, ?, NOW())
             ON DUPLICATE KEY UPDATE
                status       = VALUES(status),
                note         = VALUES(note),
                updated_by   = VALUES(updated_by),
                effective_from = NOW(),
                updated_at   = NOW()"
        );
        $stmt->execute([$targetId, $newStat, $note ?: null, $u['id']]);

        // Notify the affected user
        notify(
            $targetId,
            null,
            'Availability Updated',
            "Your TL set your availability to: {$newStat}"
              . ($note ? "\nNote: {$note}" : ''),
            'info'
        );

        audit('AVAILABILITY_UPDATE', 'users', $targetId, "status={$newStat}");

        $pdo->commit();
        $success = 'Availability updated.';
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $error = app_exception_message($e);
    }
}

/* -------------------------------------------------------------------------
 * Load the team members the TL is responsible for.
 * Falls back to "same department" if team_leader_id isn't populated.
 * ------------------------------------------------------------------------- */
$teamStmt = $pdo->prepare(
    "SELECT u.id, u.full_name, u.email, u.phone, u.role, u.status AS user_status,
            d.department_name,
            COALESCE(a.status, 'AVAILABLE') AS availability,
            a.note       AS availability_note,
            a.updated_at AS availability_updated_at,
            (SELECT COUNT(*) FROM tickets t
              WHERE t.assigned_technician_id = u.id
                AND t.status IN ('ASSIGNED_TO_ICT','IN_PROGRESS','RETURNED_TO_ICT'))
                AS open_tickets,
            (SELECT COUNT(*) FROM tickets t
              WHERE t.assigned_technician_id = u.id
                AND t.status IN ('WAITING_FOR_INFORMATION','WAITING_FOR_PARTS'))
                AS waiting_tickets
       FROM users u
       LEFT JOIN departments d ON d.id = u.department_id
       LEFT JOIN user_availability a ON a.user_id = u.id
      WHERE u.status = 'ACTIVE'
        AND (
             u.team_leader_id = ?
             OR u.department_id = (SELECT department_id FROM users WHERE id = ?)
        )
      ORDER BY FIELD(COALESCE(a.status,'AVAILABLE'),
                     'AVAILABLE','BUSY','ON_LEAVE','OFF_DUTY'),
               u.full_name"
);
$teamStmt->execute([$u['id'], $u['id']]);
$team = $teamStmt->fetchAll();

/* Summary counters */
$counts = ['AVAILABLE' => 0, 'BUSY' => 0, 'ON_LEAVE' => 0, 'OFF_DUTY' => 0];
foreach ($team as $m) {
    $counts[$m['availability']] = ($counts[$m['availability']] ?? 0) + 1;
}

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:#0070f2; --sap-brand-dark:#0057d2;
    --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500;
    --sap-negative:#aa0808; --sap-neutral:#5b738b;
    --sap-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
  }
  body, .main-content { background: var(--sap-bg) !important;
    font-family: "72","72full",Arial,Helvetica,sans-serif !important; color: var(--sap-text); }

  .sap-page-header { background: var(--sap-tile); border-radius: .75rem;
    box-shadow: var(--sap-shadow); padding: 1.1rem 1.4rem; margin-bottom: 1rem;
    display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap; }
  .sap-page-title { font-size: 1.375rem; font-weight: 600; margin: 0;
    display: flex; align-items: center; gap: .55rem; }
  .sap-page-title .bi { color: var(--sap-brand); }
  .sap-page-sub { font-size: .82rem; color: var(--sap-text-muted); margin: .2rem 0 0; }

  .sap-summary { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: .75rem; margin-bottom: 1rem; }
  .sap-summary .card { background: var(--sap-tile); border-radius: .75rem;
    box-shadow: var(--sap-shadow); padding: .85rem 1rem;
    display: flex; align-items: center; gap: .75rem; }
  .sap-summary .icon { width: 40px; height: 40px; border-radius: .6rem;
    display: inline-flex; align-items: center; justify-content: center;
    font-size: 1.2rem; flex-shrink: 0; }
  .sap-summary .num { font-size: 1.4rem; font-weight: 700; line-height: 1; }
  .sap-summary .lbl { font-size: .72rem; color: var(--sap-text-muted);
    text-transform: uppercase; letter-spacing: .05em; font-weight: 600; margin-top: .15rem; }

  .avail-good   .icon { background:#f1fdf6; color: var(--sap-positive); }
  .avail-busy   .icon { background:#fff8f1; color: var(--sap-critical); }
  .avail-leave  .icon { background:#fef4f4; color: var(--sap-negative); }
  .avail-off    .icon { background:#f4f5f7; color: var(--sap-neutral); }

  .sap-card { background: var(--sap-tile); border-radius: .75rem;
    box-shadow: var(--sap-shadow); overflow: hidden; margin-bottom: 1rem; }
  .sap-card-header { padding: .8rem 1.15rem; border-bottom: 1px solid var(--sap-border-soft);
    font-size: .8125rem; font-weight: 700; text-transform: uppercase; letter-spacing: .05em;
    color: var(--sap-text-muted); display: flex; align-items: center; justify-content: space-between; gap: .5rem; }
  .sap-card-header .title-wrap { display: flex; align-items: center; gap: .45rem; }
  .sap-card-header .bi { color: var(--sap-brand); font-size: .95rem; }

  .sap-table { width: 100%; border-collapse: separate; border-spacing: 0; font-size: .84rem; }
  .sap-table thead th { text-align: left; font-size: .7rem; text-transform: uppercase;
    letter-spacing: .04em; color: var(--sap-text-muted); font-weight: 700;
    padding: .7rem 1rem; border-bottom: 1px solid var(--sap-border-soft); background: #fafbfc; }
  .sap-table tbody td { padding: .85rem 1rem; border-bottom: 1px solid var(--sap-border-soft); vertical-align: middle; }
  .sap-table tbody tr:last-child td { border-bottom: 0; }
  .sap-table tbody tr:hover { background: #fafbfc; }
  .sap-person-name { font-weight: 600; color: var(--sap-text); }
  .sap-person-meta { font-size: .72rem; color: var(--sap-text-muted); margin-top: .1rem; }
  .sap-avatar { width: 34px; height: 34px; border-radius: 50%;
    background: #eaf4ff; color: var(--sap-brand); font-weight: 700;
    display: inline-flex; align-items: center; justify-content: center;
    font-size: .85rem; margin-right: .65rem; flex-shrink: 0; }

  .sap-chip { display: inline-flex; align-items: center; gap: .3rem;
    font-size: .72rem; font-weight: 600; padding: .22rem .6rem;
    border-radius: 999px; border: 1px solid transparent; }
  .sap-chip.is-good     { background:#f1fdf6; color: var(--sap-positive); border-color:#d6f0e0; }
  .sap-chip.is-critical { background:#fff8f1; color: var(--sap-critical); border-color:#fbe0c8; }
  .sap-chip.is-bad      { background:#fef4f4; color: var(--sap-negative); border-color:#f7d2d2; }
  .sap-chip.is-neutral  { background:#f4f5f7; color: var(--sap-neutral);  border-color:#e4e7eb; }

  .sap-count { display: inline-flex; align-items: center; gap: .35rem;
    font-size: .78rem; font-weight: 600; color: var(--sap-text); }
  .sap-count .dot { width: 8px; height: 8px; border-radius: 50%; display: inline-block; }
  .sap-count .dot.open    { background: var(--sap-brand); }
  .sap-count .dot.waiting { background: var(--sap-critical); }
  .sap-count .dot.overdue { background: var(--sap-negative); }

  .sap-form-control { width: 100%; font-size: .875rem; font-family: inherit;
    color: var(--sap-text); background: #fff; border: 1px solid var(--sap-border);
    border-radius: .5rem; padding: .55rem .75rem;
    transition: border-color .15s, box-shadow .15s; outline: none; }
  .sap-form-control:focus { border-color: var(--sap-brand);
    box-shadow: 0 0 0 3px rgba(0,112,242,.15); }

  .sap-btn { display: inline-flex; align-items: center; gap: .4rem;
    font-size: .8125rem; font-weight: 500; border-radius: .5rem;
    padding: .5rem .9rem; border: 1px solid transparent; background: transparent;
    color: var(--sap-brand); cursor: pointer; line-height: 1; text-decoration: none;
    white-space: nowrap; transition: background .15s, color .15s; font-family: inherit; }
  .sap-btn:hover { background: #eaf4ff; color: var(--sap-brand-dark); }
  .sap-btn.sap-btn-emphasized { background: var(--sap-brand); color: #fff; }
  .sap-btn.sap-btn-emphasized:hover { background: var(--sap-brand-dark); color: #fff; }
  .sap-btn[disabled] { opacity: .5; cursor: not-allowed; }

  .sap-message { display: flex; align-items: flex-start; gap: .6rem;
    padding: .75rem 1rem; border-radius: .5rem; font-size: .8125rem; line-height: 1.4;
    margin-bottom: 1rem; border-left: 3px solid; }
  .sap-message.is-error   { background: #fef4f4; color: var(--sap-negative); border-left-color: var(--sap-negative); }
  .sap-message.is-success { background: #f1fdf6; color: var(--sap-positive); border-left-color: var(--sap-positive); }

  .sap-empty { text-align: center; padding: 2rem 1rem; color: var(--sap-text-muted); font-size: .85rem; }
  .sap-empty .bi { font-size: 1.75rem; opacity: .4; display: block; margin-bottom: .4rem; }
</style>

<div class="sap-page-header">
  <div>
    <h1 class="sap-page-title"><i class="bi bi-calendar2-check"></i> Team Availability</h1>
    <p class="sap-page-sub">See who is available to take work right now, and adjust their status.</p>
  </div>
</div>

<?php if ($error): ?>
  <div class="sap-message is-error"><i class="bi bi-exclamation-circle"></i><span><?= e($error) ?></span></div>
<?php endif; ?>
<?php if ($success): ?>
  <div class="sap-message is-success"><i class="bi bi-check2-circle"></i><span><?= e($success) ?></span></div>
<?php endif; ?>

<div class="sap-summary">
  <div class="card avail-good">
    <div class="icon"><i class="bi bi-check2-circle"></i></div>
    <div><div class="num"><?= (int)($counts['AVAILABLE'] ?? 0) ?></div><div class="lbl">Available</div></div>
  </div>
  <div class="card avail-busy">
    <div class="icon"><i class="bi bi-hourglass-split"></i></div>
    <div><div class="num"><?= (int)($counts['BUSY'] ?? 0) ?></div><div class="lbl">Busy</div></div>
  </div>
  <div class="card avail-leave">
    <div class="icon"><i class="bi bi-airplane"></i></div>
    <div><div class="num"><?= (int)($counts['ON_LEAVE'] ?? 0) ?></div><div class="lbl">On Leave</div></div>
  </div>
  <div class="card avail-off">
    <div class="icon"><i class="bi bi-moon-stars"></i></div>
    <div><div class="num"><?= (int)($counts['OFF_DUTY'] ?? 0) ?></div><div class="lbl">Off Duty</div></div>
  </div>
</div>

<div class="sap-card">
  <div class="sap-card-header">
    <span class="title-wrap"><i class="bi bi-people"></i> Team Members</span>
    <span style="font-size:.7rem;color:var(--sap-text-muted);font-weight:500;text-transform:none;letter-spacing:0">
      <?= count($team) ?> member<?= count($team) === 1 ? '' : 's' ?>
    </span>
  </div>

  <?php if (!$team): ?>
    <div class="sap-empty"><i class="bi bi-person-x"></i>No team members found.</div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="sap-table">
        <thead>
          <tr>
            <th>Member</th>
            <th>Role</th>
            <th>Availability</th>
            <th>Workload</th>
            <th>Last Update</th>
            <th style="text-align:right">Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($team as $m): ?>
          <?php
            $av = $m['availability'];
            $chipClass = match ($av) {
                'AVAILABLE' => 'is-good',
                'BUSY'      => 'is-critical',
                'ON_LEAVE'  => 'is-bad',
                'OFF_DUTY'  => 'is-neutral',
                default     => 'is-neutral',
            };
            $chipIcon = match ($av) {
                'AVAILABLE' => 'bi-check2-circle',
                'BUSY'      => 'bi-hourglass-split',
                'ON_LEAVE'  => 'bi-airplane',
                'OFF_DUTY'  => 'bi-moon-stars',
                default     => 'bi-circle',
            };
            $chipLabel = ucwords(strtolower(str_replace('_', ' ', $av)));
            $initials  = '';
            foreach (preg_split('/\s+/', trim((string)$m['full_name'])) as $part) {
                if ($part !== '') $initials .= strtoupper($part[0]);
                if (strlen($initials) >= 2) break;
            }
          ?>
          <tr>
            <td>
              <div style="display:flex;align-items:center">
                <span class="sap-avatar"><?= e($initials ?: '?') ?></span>
                <div>
                  <div class="sap-person-name"><?= e($m['full_name']) ?></div>
                  <div class="sap-person-meta">
                    <?= e($m['department_name'] ?? '—') ?>
                    <?php if (!empty($m['email'])): ?>
                      · <?= e($m['email']) ?>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            </td>
            <td><?= e(ucwords(strtolower(str_replace('_', ' ', (string)$m['role'])))) ?></td>
            <td>
              <span class="sap-chip <?= e($chipClass) ?>">
                <i class="bi <?= e($chipIcon) ?>"></i> <?= e($chipLabel) ?>
              </span>
              <?php if (!empty($m['availability_note'])): ?>
                <div class="sap-person-meta" style="margin-top:.25rem">
                  <?= e($m['availability_note']) ?>
                </div>
              <?php endif; ?>
            </td>
            <td>
              <div class="sap-count" style="margin-bottom:.2rem">
                <span class="dot open"></span> <?= (int)$m['open_tickets'] ?> open
              </div>
              <?php if ((int)$m['waiting_tickets'] > 0): ?>
                <div class="sap-count" style="margin-bottom:.2rem">
                  <span class="dot waiting"></span> <?= (int)$m['waiting_tickets'] ?> waiting
                </div>
              <?php endif; ?>
            </td>
            <td>
              <span class="sap-person-meta" style="margin:0">
                <?= $m['availability_updated_at']
                      ? e(date('Y-m-d H:i', strtotime($m['availability_updated_at'])))
                      : '—' ?>
              </span>
            </td>
            <td style="text-align:right">
              <div style="display:inline-flex;gap:.35rem">
                <a class="sap-btn" href="tickets.php?technician_id=<?= (int)$m['id'] ?>">
                  <i class="bi bi-ticket-detailed"></i> Tickets
                </a>
                <button type="button" class="sap-btn sap-btn-emphasized"
                        data-bs-toggle="modal"
                        data-bs-target="#availModal"
                        data-user-id="<?= (int)$m['id'] ?>"
                        data-user-name="<?= e($m['full_name']) ?>"
                        data-user-status="<?= e($av) ?>"
                        data-user-note="<?= e($m['availability_note'] ?? '') ?>">
                  <i class="bi bi-pencil-square"></i> Update
                </button>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<!-- Update availability modal -->
<div class="modal fade" id="availModal" tabindex="-1">
  <div class="modal-dialog">
    <form method="post" class="modal-content">
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
      <input type="hidden" name="user_id" id="avail-user-id">
      <div class="modal-header">
        <h5 class="modal-title">Update Availability — <span id="avail-user-name"></span></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label class="sap-person-meta" style="font-weight:600;display:block;margin-bottom:.35rem">
            Status
          </label>
          <select name="status" id="avail-status" class="sap-form-control" required>
            <option value="AVAILABLE">Available</option>
            <option value="BUSY">Busy</option>
            <option value="ON_LEAVE">On Leave</option>
            <option value="OFF_DUTY">Off Duty</option>
          </select>
        </div>
        <div class="mb-0">
          <label class="sap-person-meta" style="font-weight:600;display:block;margin-bottom:.35rem">
            Note (optional)
          </label>
          <textarea name="note" id="avail-note" class="sap-form-control" rows="3"
                    placeholder="e.g. Back on Monday, on training, at HQ…"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="sap-btn" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="sap-btn sap-btn-emphasized">Save</button>
      </div>
    </form>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
  var modal = document.getElementById('availModal');
  if (!modal) return;
  modal.addEventListener('show.bs.modal', function (ev) {
    var b = ev.relatedTarget;
    if (!b) return;
    document.getElementById('avail-user-id').value   = b.getAttribute('data-user-id')     || '';
    document.getElementById('avail-user-name').textContent = b.getAttribute('data-user-name') || '';
    document.getElementById('avail-status').value    = b.getAttribute('data-user-status') || 'AVAILABLE';
    document.getElementById('avail-note').value      = b.getAttribute('data-user-note')   || '';
  });
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>