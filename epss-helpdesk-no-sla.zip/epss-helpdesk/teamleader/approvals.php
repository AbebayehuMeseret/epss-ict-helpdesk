<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('TEAM_LEADER');
$pageTitle = 'Pending Approvals';
$pdo = db(); $id = (int)$u['id']; $ok=''; $error='';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verify_csrf($_POST['csrf'] ?? null)) {
    $ticketId = (int)$_POST['ticket_id'];
    $stmt = $pdo->prepare("SELECT * FROM tickets WHERE id=? AND team_leader_id=?");
    $stmt->execute([$ticketId, $id]);
    $t = $stmt->fetch();
    if (!$t) { $error = 'Ticket not found or not in your team.'; }
    elseif ($t['status'] !== 'PENDING_TEAM_LEADER_APPROVAL') { $error = 'This ticket is no longer awaiting approval.'; }
    else {
        $action = $_POST['action'] ?? '';
        try {
            $pdo->beginTransaction();
            if ($action === 'approve') {
                $now = date('Y-m-d H:i:s');
                $pdo->prepare("UPDATE tickets SET status='APPROVED_FOR_ICT', team_leader_approved_at=? WHERE id=?")
                    ->execute([$now, $ticketId]);
                record_history($ticketId,$id,$t['status'],'APPROVED_FOR_ICT','Approved by Team Leader',$_POST['comment'] ?? null);
                $icts = $pdo->query("SELECT id FROM users WHERE role='ICT_STAFF' AND status='ACTIVE'")->fetchAll();
                foreach ($icts as $i) {
                    notify((int)$i['id'],$ticketId,'Ticket Approved',
                        "Ticket {$t['ticket_number']} is approved and ready for ICT.",'approval');
                }
                $ok = 'Ticket approved.';
            } elseif ($action === 'reject') {
                if (empty(trim($_POST['reason'] ?? ''))) throw new RuntimeException('Rejection reason required.');
                $pdo->prepare("UPDATE tickets SET status='REJECTED', rejection_reason=? WHERE id=?")
                    ->execute([trim($_POST['reason']), $ticketId]);
                record_history($ticketId,$id,$t['status'],'REJECTED','Rejected by Team Leader',$_POST['reason']);
                notify((int)$t['requester_id'],$ticketId,'Ticket Rejected',
                    "Your ticket {$t['ticket_number']} was rejected: {$_POST['reason']}",'danger');
                $ok = 'Ticket rejected.';
            } elseif ($action === 'return') {
                if (empty(trim($_POST['reason'] ?? ''))) throw new RuntimeException('Clarification reason required.');
                $pdo->prepare("UPDATE tickets SET status='RETURNED_TO_EMPLOYEE', clarification_reason=? WHERE id=?")
                    ->execute([trim($_POST['reason']), $ticketId]);
                record_history($ticketId,$id,$t['status'],'RETURNED_TO_EMPLOYEE','Returned for Clarification',$_POST['reason']);
                notify((int)$t['requester_id'],$ticketId,'Clarification Requested',
                    "Your ticket {$t['ticket_number']} requires clarification.",'warning');
                $ok = 'Ticket returned to employee.';
            }
            audit(strtoupper($action),'tickets',$ticketId,"TL action {$action} on {$t['ticket_number']}");
            $pdo->commit();

            /* Telegram -> ICT technicians (after commit; never blocks the approval) */
            if ($action === 'approve') {
                try {
                    require_once __DIR__ . '/../includes/telegram.php';
                    $rq = $pdo->prepare("SELECT full_name FROM users WHERE id=?");
                    $rq->execute([$t['requester_id']]);
                    telegram_notify_ict(
                        tg_msg_approved($t, (string)$u['full_name'], (string)($rq->fetchColumn() ?: ''),
                                        trim((string)($_POST['comment'] ?? '')) ?: null),
                        $ticketId);
                } catch (Throwable $e) { error_log('TG approve: ' . $e->getMessage()); }
            }
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = app_exception_message($e);
        }
    }
}

$stmt = $pdo->prepare("SELECT t.*, c.category_name, p.name AS priority_name, p.color AS priority_color,
    req.full_name AS requester_name, d.department_name
    FROM tickets t JOIN categories c ON c.id=t.category_id JOIN priorities p ON p.id=t.priority_id
    JOIN users req ON req.id=t.requester_id
    LEFT JOIN departments d ON d.id=t.department_id
    WHERE t.team_leader_id=? AND t.status='PENDING_TEAM_LEADER_APPROVAL'
    ORDER BY p.level DESC, t.created_at");
$stmt->execute([$id]);
$tickets = $stmt->fetchAll();

function prio_hex(string $c): string {
    return match ($c) {
        'danger'=>'#aa0808','warning'=>'#e76500','info'=>'#0070f2',
        'primary'=>'#0057d2','success'=>'#256f3a','secondary'=>'#5b738b',
        'dark'=>'#354a5f', default=>'#5b738b' };
}

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:#0070f2; --sap-brand-dark:#0057d2;
    --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500;
    --sap-negative:#aa0808; --sap-neutral:#5b738b;
    --sap-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
    --sap-shadow-hover: 0 0 0 1px rgba(34,53,72,.15), 0 8px 24px 0 rgba(34,53,72,.12);
  }
  body, .main-content { background: var(--sap-bg) !important;
    font-family: "72","72full",Arial,Helvetica,sans-serif !important; color: var(--sap-text); }

  .sap-page-header { display: flex; align-items: flex-start; justify-content: space-between; margin-bottom: 1rem; flex-wrap: wrap; gap: .75rem; }
  .sap-page-title { font-size: 1.625rem; font-weight: 400; margin: 0; }
  .sap-breadcrumb { font-size: .8125rem; color: var(--sap-text-muted); margin-bottom: .25rem; }

  .sap-message { display: flex; align-items: flex-start; gap: .6rem; padding: .75rem 1rem;
    border-radius: .5rem; font-size: .8125rem; line-height: 1.4; margin-bottom: .75rem; border-left: 3px solid; }
  .sap-message:last-child { margin-bottom: 0; }
  .sap-message .bi { flex-shrink: 0; font-size: .95rem; margin-top: .05rem; }
  .sap-message.is-success { background:#f1fdf6; color: var(--sap-positive); border-left-color: var(--sap-positive); }
  .sap-message.is-error   { background:#fef4f4; color: var(--sap-negative); border-left-color: var(--sap-negative); }

  .sap-card { background: var(--sap-tile); border-radius: .75rem; box-shadow: var(--sap-shadow);
    overflow: hidden; margin-bottom: 1rem; }
  .sap-card:last-child { margin-bottom: 0; }
  .sap-card-body { padding: 1rem 1.15rem; }

  .sap-prio { display: inline-flex; align-items: center; gap: .3rem; font-size: .72rem; font-weight: 600;
    padding: .2rem .6rem; border-radius: .75rem; color: #fff; white-space: nowrap; }
  .sap-prio .swatch { width: 6px; height: 6px; border-radius: 50%; background: rgba(255,255,255,.75); }

  .sap-approval {
    background: var(--sap-tile); border-radius: .75rem; box-shadow: var(--sap-shadow);
    overflow: hidden; margin-bottom: 1rem;
    transition: box-shadow .2s, transform .2s;
  }
  .sap-approval:hover { box-shadow: var(--sap-shadow-hover); }
  .sap-approval-head {
    padding: .95rem 1.15rem;
    display: flex; align-items: flex-start; justify-content: space-between; gap: .75rem;
    border-bottom: 1px solid var(--sap-border-soft);
    flex-wrap: wrap;
  }
  .sap-approval-id {
    font-family: "72Mono","Courier New",monospace;
    font-size: .82rem; color: var(--sap-brand);
    background: #eaf4ff; border: 1px solid #cfe2f8;
    padding: .12rem .5rem; border-radius: .35rem;
    margin-right: .55rem;
  }
  .sap-approval-subject {
    font-weight: 600; font-size: .95rem; color: var(--sap-text);
    line-height: 1.25;
  }
  .sap-approval-body { padding: 1rem 1.15rem; }
  .sap-info-grid {
    display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: .75rem 1.25rem; margin-bottom: 1rem;
  }
  .sap-info-label { font-size: .68rem; text-transform: uppercase; letter-spacing: .05em;
    font-weight: 600; color: var(--sap-text-muted); margin-bottom: .15rem; }
  .sap-info-value { font-size: .855rem; color: var(--sap-text); }

  .sap-desc {
    background: #fafbfc; border: 1px solid var(--sap-border-soft);
    border-radius: .5rem; padding: .85rem 1rem;
    font-size: .855rem; line-height: 1.6; color: var(--sap-text);
    white-space: pre-wrap; margin-top: .35rem;
  }

  .sap-btn { display: inline-flex; align-items: center; gap: .4rem;
    font-size: .8125rem; font-weight: 500;
    border-radius: .5rem; padding: .5rem .9rem; border: 1px solid transparent;
    background: transparent; color: var(--sap-brand); cursor: pointer;
    line-height: 1; text-decoration: none; white-space: nowrap;
    transition: background .15s, color .15s, box-shadow .15s; font-family: inherit; }
  .sap-btn:hover { background: #eaf4ff; color: var(--sap-brand-dark); }
  .sap-btn:focus-visible { outline: 2px solid var(--sap-brand); outline-offset: 2px; }
  .sap-btn.sap-btn-success { background: var(--sap-positive); color: #fff; }
  .sap-btn.sap-btn-success:hover { background: #1d5d2e; color: #fff; }
  .sap-btn.sap-btn-warning { background: var(--sap-critical); color: #fff; }
  .sap-btn.sap-btn-warning:hover { background: #cc5800; color: #fff; }
  .sap-btn.sap-btn-danger  { background: var(--sap-negative); color: #fff; }
  .sap-btn.sap-btn-danger:hover { background: #8a0606; color: #fff; }

  .sap-empty { text-align: center; padding: 2.5rem 1rem; color: var(--sap-text-muted); }
  .sap-empty .bi { font-size: 2.2rem; opacity: .4; }
  .sap-empty-title { font-size: .95rem; font-weight: 600; color: var(--sap-text); margin-top: .55rem; }

  .modal-content { border-radius: .75rem; border: 0; box-shadow: 0 8px 32px rgba(34,53,72,.18); }
  .form-label { font-size: .75rem; text-transform: uppercase; letter-spacing: .04em;
    font-weight: 600; color: var(--sap-text-muted); }
  .form-control:focus { border-color: var(--sap-brand); box-shadow: 0 0 0 3px rgba(0,112,242,.15); }
</style>

<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb"><i class="bi bi-house-door"></i> Home / <strong>Pending Approvals</strong></div>
    <h1 class="sap-page-title">Pending Approvals</h1>
  </div>
  <span class="sap-prio" style="background:var(--sap-critical);font-size:.75rem;padding:.3rem .7rem">
    <?= count($tickets) ?> awaiting review
  </span>
</div>

<div class="sap-message" style="background:#eaf4ff;color:var(--sap-brand);border-left-color:var(--sap-brand)">
  <i class="bi bi-clock-history"></i>
  <span>
    Tickets you do not answer within <strong><?= (int) tl_bypass_minutes() ?></strong> minutes are forwarded to ICT
    automatically on your team's behalf, and you are notified.
  </span>
</div>

<?php if ($error): ?>
  <div class="sap-message is-error"><i class="bi bi-exclamation-circle"></i><span><?= e($error) ?></span></div>
<?php endif; ?>
<?php if ($ok): ?>
  <div class="sap-message is-success"><i class="bi bi-check-circle"></i><span><?= e($ok) ?></span></div>
<?php endif; ?>

<?php if (!$tickets): ?>
  <div class="sap-card"><div class="sap-empty">
    <i class="bi bi-check2-all"></i>
    <div class="sap-empty-title">All caught up!</div>
    <div style="font-size:.82rem;margin-top:.3rem">No tickets are currently awaiting your approval.</div>
  </div></div>
<?php else: foreach ($tickets as $t):
    $hex = prio_hex($t['priority_color']);
?>
  <div class="sap-approval">
    <div class="sap-approval-head">
      <div>
        <div>
          <span class="sap-approval-id"><?= e($t['ticket_number']) ?></span>
          <span class="sap-approval-subject"><?= e($t['subject']) ?></span>
        </div>
        <div class="text-muted small mt-1">
          Submitted <?= e(date('Y-m-d H:i', strtotime($t['created_at']))) ?>
        </div>
      </div>
      <span class="sap-prio" style="background:<?= e($hex) ?>">
        <span class="swatch"></span> <?= e($t['priority_name']) ?>
      </span>
    </div>

    <div class="sap-approval-body">
      <div class="sap-info-grid">
        <div>
          <div class="sap-info-label">Requester</div>
          <div class="sap-info-value"><?= e($t['requester_name']) ?></div>
        </div>
        <div>
          <div class="sap-info-label">Department</div>
          <div class="sap-info-value"><?= e($t['department_name'] ?? '—') ?></div>
        </div>
        <div>
          <div class="sap-info-label">Category</div>
          <div class="sap-info-value"><?= e($t['category_name']) ?></div>
        </div>
        <div>
          <div class="sap-info-label">Location</div>
          <div class="sap-info-value"><?= e($t['location'] ?? '—') ?></div>
        </div>
      </div>

      <div class="sap-info-label">Description</div>
      <div class="sap-desc"><?= e($t['description']) ?></div>

      <div class="mt-3 d-flex gap-2 flex-wrap">
        <button class="sap-btn sap-btn-success"
                data-bs-toggle="modal" data-bs-target="#approveModal"
                data-id="<?= (int)$t['id'] ?>" data-num="<?= e($t['ticket_number']) ?>">
          <i class="bi bi-check2-circle"></i> Approve
        </button>
        <button class="sap-btn sap-btn-warning"
                data-bs-toggle="modal" data-bs-target="#returnModal"
                data-id="<?= (int)$t['id'] ?>" data-num="<?= e($t['ticket_number']) ?>">
          <i class="bi bi-arrow-return-left"></i> Return for Clarification
        </button>
        <button class="sap-btn sap-btn-danger"
                data-bs-toggle="modal" data-bs-target="#rejectModal"
                data-id="<?= (int)$t['id'] ?>" data-num="<?= e($t['ticket_number']) ?>">
          <i class="bi bi-x-circle"></i> Reject
        </button>
        <a href="<?= BASE_URL ?>/teamleader/ticket_view.php?id=<?= (int)$t['id'] ?>" class="sap-btn">
          <i class="bi bi-arrow-right"></i> View Details
        </a>
      </div>
    </div>
  </div>
<?php endforeach; endif; ?>

<?php foreach ([
    ['approveModal','Approve Ticket','approve','sap-btn-success','Comment (optional)',false,'check2-circle'],
    ['returnModal','Return for Clarification','return','sap-btn-warning','Clarification reason *',true,'arrow-return-left'],
    ['rejectModal','Reject Ticket','reject','sap-btn-danger','Rejection reason *',true,'x-circle'],
] as [$mid,$title,$act,$btn,$label,$req,$icon]): ?>
<div class="modal fade" id="<?= $mid ?>"><div class="modal-dialog"><div class="modal-content">
<form method="post">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<input type="hidden" name="action" value="<?= $act ?>">
<input type="hidden" name="ticket_id" id="<?= $mid ?>-id">
<div class="modal-header">
  <h5 class="modal-title"><i class="bi bi-<?= $icon ?>"></i> <?= e($title) ?></h5>
  <button class="btn-close" data-bs-dismiss="modal" type="button"></button>
</div>
<div class="modal-body">
  <p class="mb-2">Ticket: <strong id="<?= $mid ?>-num" style="font-family:'72Mono',monospace"></strong></p>
  <label class="form-label"><?= e($label) ?></label>
  <textarea name="<?= $act==='approve'?'comment':'reason' ?>" class="form-control" rows="3" <?= $req?'required':'' ?>></textarea>
</div>
<div class="modal-footer">
  <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Cancel</button>
  <button class="sap-btn <?= $btn ?>">Confirm</button>
</div>
</form></div></div></div>
<script>
document.getElementById('<?= $mid ?>').addEventListener('show.bs.modal', e => {
  document.getElementById('<?= $mid ?>-id').value = e.relatedTarget.dataset.id;
  document.getElementById('<?= $mid ?>-num').textContent = e.relatedTarget.dataset.num;
});
</script>
<?php endforeach; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
