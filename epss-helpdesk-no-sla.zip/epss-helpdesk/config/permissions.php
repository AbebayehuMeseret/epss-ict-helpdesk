<?php
declare(strict_types=1);

const ROLE_PERMISSIONS = [
    'ADMIN' => ['*'],

    'BRANCH_MANAGER' => [
        'tickets.view_team','tickets.approve','tickets.reject','tickets.return',
        'tickets.confirm',
        'reports.team','dashboard.team',
        'comments.add','attachments.view',
    ],

    'TEAM_LEADER' => [
        'tickets.view_team','tickets.approve','tickets.reject','tickets.return',
        'tickets.confirm',
        'reports.team','dashboard.team',
        'comments.add','attachments.view',
    ],

    'EMPLOYEE' => [
        'tickets.create','tickets.view_own','comments.add','attachments.view',
        'attachments.upload','dashboard.employee','tickets.respond','tickets.confirm',
    ],

    'ICT_STAFF' => [
        'tickets.view_approved','tickets.accept','tickets.work','tickets.resolve',
        'tickets.assign','tickets.wait_info','tickets.wait_parts',
        'comments.add','attachments.view','attachments.upload','dashboard.ict',
    ],
];

function user_can(string $permission): bool {
    $role = $_SESSION['role'] ?? null;
    if (!$role) return false;
    $perms = ROLE_PERMISSIONS[$role] ?? [];
    return in_array('*', $perms, true) || in_array($permission, $perms, true);
}

function require_permission(string $permission): void {
    if (!user_can($permission)) {
        require_once __DIR__ . '/../includes/errors.php';
        app_fail('E-AUTH-406', 'Your role is not allowed to perform this action (' . $permission . ').');
    }
}
