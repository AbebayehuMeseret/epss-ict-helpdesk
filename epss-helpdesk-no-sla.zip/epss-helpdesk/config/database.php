<?php
declare(strict_types=1);

/**
 * config/database.php
 *
 * Configuration ONLY. Do not declare functions here.
 * The db() connection function lives in includes/functions.php
 * and reads the array returned below.
 */

return [
    'host'    => 'localhost',
    'port'    => 3306,
    'name'    => 'epss_adama_helpdesk',
    'user'    => 'root',
    'pass'    => '',
    'charset' => 'utf8mb4',
];