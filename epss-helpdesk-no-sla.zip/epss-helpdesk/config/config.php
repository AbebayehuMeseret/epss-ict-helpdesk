<?php
declare(strict_types=1);

/**
 * config/config.php
 *
 * Application constants and session start ONLY.
 * Do not declare helper functions here. csrf_token(), verify_csrf(), e(),
 * setting() and generate_ticket_number() live in includes/functions.php.
 */

date_default_timezone_set('Africa/Addis_Ababa');

defined('BASE_URL')          || define('BASE_URL', '/epss-helpdesk');
defined('APP_NAME')          || define('APP_NAME', 'EPSS Adama ICT Helpdesk');
defined('UPLOAD_DIR')        || define('UPLOAD_DIR', __DIR__ . '/../uploads/tickets/');
defined('UPLOAD_URL')        || define('UPLOAD_URL', BASE_URL . '/uploads/tickets/');
defined('SESSION_TIMEOUT')   || define('SESSION_TIMEOUT', 3600);
defined('MAX_LOGIN_ATTEMPTS')|| define('MAX_LOGIN_ATTEMPTS', 5);
defined('LOCKOUT_MINUTES')   || define('LOCKOUT_MINUTES', 15);

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => isset($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    session_start();
}

// Make sure the shared helpers (db(), csrf_token(), e(), setting(), ...) are
// available to any page that only loads this file. Safe to load twice.
require_once __DIR__ . '/../includes/functions.php';