<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
$u = require_role('ADMIN','TEAM_LEADER');
$pageTitle = 'Ticket Report';

$from = $_GET['from'] ?? date('Y-m-01');
$to   = $_GET['to']   ?? date('Y-m-t');
$cat  = (int)($_GET['category_id'] ?? 0);
$dept = (int)($_GET['department_id'] ?? 0);
$stat = $_GET['status'] ?? '';

$sql = "SELECT t.*, c.category_name, d.department_name, p.name AS priority_name,
    req.full_name AS requester_name
    FROM tickets t JOIN categories c ON c.id=t.category_id
    JOIN priorities p ON p.id=t.priority_id JOIN users req ON req.id=t.requester_id
    LEFT JOIN departments d ON d.id=t.department_id
    WHERE t.created_at BETWEEN ? AND ?";
$params = [$from . ' 00:00:00', $to . ' 23:59:59'];
if ($cat)  { $sql .= " AND t.category_id=?";  $params[] = $cat; }
if ($dept) { $sql .= " AND t.department_id=?"; $params[] = $dept; }
if ($stat) { $sql .= " AND t.status=?";        $params[] = $stat; }
$sql .= " ORDER BY t.created_at DESC";
$stmt = db()->prepare($sql); $stmt->execute($params);
$rows = $stmt->fetchAll();

$cats = db()->query("SELECT * FROM categories ORDER BY category_name")->fetchAll();
$depts = db()->query("SELECT * FROM departments ORDER BY department_name")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<h4 class="mb-3">Ticket Report</h4>
<div class="card mb-3"><div class="card-body">
<form class="row g-2">
  <div class="col-md-2"><label class="form-label">From</label>
    <input type="date" name="from" value="<?= e($from) ?>" class="form-control"></div>
  <div class="col-md-2"><label class="form-label">To</label>
    <input type="date" name="to" value="<?= e($to) ?>" class="form-control"></div>
  <div class="col-md-2"><label class="form-label">Category</label>
    <select name="category_id" class="form-select"><option value="">All</option>
      <?php foreach ($cats as $c): ?><option value="<?= (int)$c['id'] ?>" <?= $cat==$c['id']?'selected':'' ?>><?= e($c['category_name']) ?></option><?php endforeach; ?>
    </select></div>
  <div class="col-md-2"><label class="form-label">Department</label>
    <select name="department_id" class="form-select"><option value="">All</option>
      <?php foreach ($depts as $d): ?><option value="<?= (int)$d['id'] ?>" <?= $dept==$d['id']?'selected':'' ?>><?= e($d['department_name']) ?></option><?php endforeach; ?>
    </select></div>
  <div class="col-md-2"><label class="form-label">Status</label>
    <select name="status" class="form-select"><option value="">All</option>
      <?php foreach (['PENDING_TEAM_LEADER_APPROVAL','APPROVED_FOR_ICT','IN_PROGRESS','RESOLVED_PENDING_REQUESTER_CONFIRMATION','CLOSED','REJECTED'] as $s): ?>
        <option value="<?= $s ?>" <?= $stat===$s?'selected':'' ?>><?= str_replace('_',' ',$s) ?></option>
      <?php endforeach; ?>
    </select></div>
  <div class="col-md-2 d-flex align-items-end gap-2">
    <button class="btn btn-primary w-100">Filter</button>
  </div>
</form>
</div></div>

<div class="mb-2 text-end">
  <button onclick="window.print()" class="btn btn-outline-secondary btn-sm">Print</button>
</div>

<div class="card"><div class="card-body">
  <div class="text-center mb-3">
    <h5>ETHIOPIAN PHARMACEUTICALS SUPPLY SERVICE — ADAMA BRANCH</h5>
    <div>ICT HELPDESK — TICKET REPORT</div>
    <div class="text-muted small"><?= e($from) ?> to <?= e($to) ?> · <?= count($rows) ?> tickets</div>
  </div>
  <div class="table-responsive">
  <table class="table table-sm table-bordered" id="reportTable">
  <thead class="table-light"><tr>
    <th>#</th><th>Subject</th><th>Requester</th><th>Dept</th><th>Category</th>
    <th>Priority</th><th>Status</th><th>Created</th><th>Closed</th>
  </tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= e($r['ticket_number']) ?></td>
      <td><?= e($r['subject']) ?></td>
      <td><?= e($r['requester_name']) ?></td>
      <td><?= e($r['department_name'] ?? '-') ?></td>
      <td><?= e($r['category_name']) ?></td>
      <td><?= e($r['priority_name']) ?></td>
      <td><?= e($r['status']) ?></td>
      <td><small><?= e(date('Y-m-d H:i', strtotime($r['created_at']))) ?></small></td>
      <td><small><?= $r['closed_at'] ? e(date('Y-m-d H:i', strtotime($r['closed_at']))) : '-' ?></small></td>
    </tr>
  <?php endforeach; ?>
  </tbody></table>
  </div>
</div></div>
<?php include __DIR__ . '/../includes/footer.php'; ?>