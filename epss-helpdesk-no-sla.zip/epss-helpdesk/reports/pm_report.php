<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/pm.php';
$u = require_role('ADMIN','TEAM_LEADER','BRANCH_MANAGER','ICT_STAFF');
$pageTitle = 'Preventive Maintenance Report';
$pdo = db();

/* =====================================================
   Filters
   ===================================================== */
$year    = (int)($_GET['year']    ?? date('Y'));
$quarter = (int)($_GET['quarter'] ?? pm_quarter_of(date('Y-m-d')));
$deptId  = (int)($_GET['department_id'] ?? 0);

/* Departments for filter */
$departments = $pdo->query("SELECT id, department_name FROM departments
                            ORDER BY department_name")->fetchAll();

/* =====================================================
   Load checklists
   ===================================================== */
$sql = "SELECT c.id, c.technician_id, c.technician_name, c.checklist_date,
               c.quarter_label, c.year, c.quarter,
               c.department_id, d.department_name,
               c.notes, c.submitted_at,
               COUNT(i.id) AS items_total,
               COALESCE(SUM(i.done),0) AS items_done,
               COUNT(DISTINCT i.employee_id) AS employees_count
        FROM pm_checklists c
        LEFT JOIN pm_checklist_items i ON i.checklist_id = c.id
        LEFT JOIN departments d ON d.id = c.department_id
        WHERE c.year = ? AND c.quarter = ?";
$params = [$year, $quarter];
if ($deptId) { $sql .= " AND c.department_id = ?"; $params[] = $deptId; }
$sql .= " GROUP BY c.id ORDER BY c.checklist_date DESC, c.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

/* =====================================================
   Summary calculations
   ===================================================== */
$totalChecklists = count($rows);
$totalItems      = 0;
$totalDone       = 0;
$technicians     = [];
$departmentsIn   = [];

foreach ($rows as $r) {
    $totalItems += (int)$r['items_total'];
    $totalDone  += (int)$r['items_done'];
    $technicians[$r['technician_name']] = true;
    if (!empty($r['department_name'])) {
        $departmentsIn[$r['department_name']] = true;
    }
}
$completionPct = $totalItems ? round($totalDone / $totalItems * 100, 1) : 0;

/* Per-category completion — how many checks were made for each of the 15 items */
$itemStats = [];
try {
    $sql = "SELECT i.item_code, i.item_number,
                   COUNT(*) AS total_rows,
                   SUM(i.done) AS done_rows
            FROM pm_checklist_items i
            JOIN pm_checklists c ON c.id = i.checklist_id
            WHERE c.year = ? AND c.quarter = ?";
    $params = [$year, $quarter];
    if ($deptId) { $sql .= " AND c.department_id = ?"; $params[] = $deptId; }
    $sql .= " GROUP BY i.item_code, i.item_number ORDER BY i.item_number";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    foreach ($stmt->fetchAll() as $s) {
        $itemStats[$s['item_code']] = [
            'number' => (int)$s['item_number'],
            'total'  => (int)$s['total_rows'],
            'done'   => (int)$s['done_rows'],
            'pct'    => (int)$s['total_rows'] ? round($s['done_rows'] / $s['total_rows'] * 100) : 0,
        ];
    }
} catch (Throwable $e) { $itemStats = []; }

/* Department breakdown for the chart */
$byDept = [];
foreach ($rows as $r) {
    $key = $r['department_name'] ?? 'Unassigned';
    $byDept[$key]['total']  = ($byDept[$key]['total']  ?? 0) + (int)$r['items_total'];
    $byDept[$key]['done']   = ($byDept[$key]['done']   ?? 0) + (int)$r['items_done'];
}

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:#0070f2; --sap-brand-dark:#0057d2;
    --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500;
    --sap-negative:#aa0808; --sap-neutral:#5b738b;
    --sap-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
    --sap-shadow-hover: 0 0 0 1px rgba(34,53,72,.15), 0 8px 24px 0 rgba(34,53,72,.12);
  }
  body, .main-content { background:var(--sap-bg) !important;
    font-family:"72","72full",Arial,Helvetica,sans-serif !important; color:var(--sap-text); }

  .sap-page-header { display:flex; justify-content:space-between; align-items:flex-start;
    margin-bottom:1rem; flex-wrap:wrap; gap:.75rem; }
  .sap-page-title { font-size:1.625rem; font-weight:400; margin:0; }
  .sap-breadcrumb { font-size:.8125rem; color:var(--sap-text-muted); margin-bottom:.25rem; }

  .sap-card { background:var(--sap-tile); border-radius:.75rem;
    box-shadow:var(--sap-shadow); overflow:hidden; margin-bottom:1rem; }
  .sap-card-header { padding:.75rem 1.15rem; border-bottom:1px solid var(--sap-border-soft);
    font-size:.875rem; font-weight:600; display:flex; align-items:center;
    justify-content:space-between; gap:.5rem; flex-wrap:wrap; }
  .sap-card-body { padding:1rem 1.15rem; }

  .sap-btn { display:inline-flex; align-items:center; gap:.35rem;
    font-size:.8125rem; font-weight:500; border-radius:.5rem;
    padding:.5rem .9rem; border:1px solid transparent; background:transparent;
    color:var(--sap-brand); cursor:pointer; text-decoration:none;
    white-space:nowrap; font-family:inherit; }
  .sap-btn:hover { background:#eaf4ff; color:var(--sap-brand-dark); }
  .sap-btn.sap-btn-emphasized { background:var(--sap-brand); color:#fff;
    box-shadow:0 1px 2px rgba(34,53,72,.15); }
  .sap-btn.sap-btn-emphasized:hover { background:var(--sap-brand-dark); color:#fff; }
  .sap-btn.sap-btn-outline { border-color:var(--sap-border); background:#fff; }
  .sap-btn.sap-btn-outline:hover { border-color:var(--sap-brand); background:#eaf4ff; }
  .sap-btn.sap-btn-success { background:var(--sap-positive); color:#fff; }
  .sap-btn.sap-btn-success:hover { background:#1d5d2e; color:#fff; }

  .sap-form-label { display:block; font-size:.72rem; text-transform:uppercase;
    letter-spacing:.04em; color:var(--sap-text-muted); font-weight:600; margin-bottom:.3rem; }
  .sap-form-control { width:100%; font-size:.875rem; font-family:inherit;
    background:#fff; border:1px solid var(--sap-border);
    border-radius:.5rem; padding:.5rem .7rem; outline:none; color:var(--sap-text); }
  .sap-form-control:focus { border-color:var(--sap-brand);
    box-shadow:0 0 0 3px rgba(0,112,242,.15); }

  /* Filter bar */
  .sap-filterbar { background:var(--sap-tile); border-radius:.75rem;
    box-shadow:var(--sap-shadow); padding:.85rem 1rem; margin-bottom:1rem; }

  /* Tiles */
  .sap-tile { background:var(--sap-tile); border-radius:.75rem;
    box-shadow:var(--sap-shadow); padding:1rem 1.15rem;
    position:relative; overflow:hidden; height:100%;
    transition: box-shadow .2s, transform .2s; }
  .sap-tile:hover { box-shadow:var(--sap-shadow-hover); transform:translateY(-2px); }
  .sap-tile::before { content:""; position:absolute; top:0; left:0; right:0; height:3px;
    background:var(--sap-brand); }
  .sap-tile.is-good::before     { background:var(--sap-positive); }
  .sap-tile.is-critical::before { background:var(--sap-critical); }
  .sap-tile.is-bad::before      { background:var(--sap-negative); }
  .sap-tile.is-neutral::before  { background:var(--sap-neutral); }
  .sap-tile-label { font-size:.72rem; text-transform:uppercase; letter-spacing:.04em;
    color:var(--sap-text-muted); font-weight:600; margin-bottom:.35rem;
    display:flex; align-items:center; gap:.4rem; }
  .sap-tile-value { font-family:"72Mono","Courier New",monospace; font-size:2rem;
    font-weight:600; line-height:1.05; color:var(--sap-text); }
  .sap-tile-value .unit { font-size:.85rem; color:var(--sap-text-muted);
    font-weight:500; margin-left:.15rem; font-family:"72",Arial,sans-serif; }
  .sap-tile-foot { font-size:.72rem; color:var(--sap-text-muted); margin-top:.35rem; }

  /* Status pills */
  .sap-status { display:inline-flex; align-items:center; gap:.25rem;
    font-size:.7rem; font-weight:600; padding:.15rem .55rem;
    border-radius:.75rem; white-space:nowrap; border:1px solid transparent; }
  .sap-status.is-good     { background:#f1fdf6; color:var(--sap-positive); border-color:#d6f0e0; }
  .sap-status.is-critical { background:#fff8f1; color:var(--sap-critical); border-color:#fbe0c8; }
  .sap-status.is-bad      { background:#fef4f4; color:var(--sap-negative); border-color:#f7d2d2; }
  .sap-status.is-info     { background:#eaf4ff; color:var(--sap-brand);    border-color:#cfe2f8; }
  .sap-status.is-neutral  { background:#f4f5f7; color:var(--sap-neutral);  border-color:#e4e7eb; }

  /* Table */
  .sap-table-wrap { background:var(--sap-tile); border-radius:.75rem;
    box-shadow:var(--sap-shadow); overflow:hidden; }
  table.sap-table { width:100%; border-collapse:separate; border-spacing:0;
    font-size:.8125rem; margin:0; }
  table.sap-table thead th { background:#f5f6f7; border-bottom:1px solid var(--sap-border);
    font-weight:600; color:var(--sap-text-muted); text-align:left;
    padding:.55rem .7rem; text-transform:uppercase; font-size:.68rem;
    letter-spacing:.04em; white-space:nowrap; }
  table.sap-table tbody td { padding:.6rem .7rem;
    border-bottom:1px solid var(--sap-border-soft); vertical-align:middle; }
  table.sap-table tbody tr:last-child td { border-bottom:0; }
  table.sap-table tbody tr:hover { background:#f8fbff; }
  table.sap-table tfoot td { padding:.55rem .7rem; background:#f5f6f7;
    border-top:1px solid var(--sap-border); font-weight:600; font-size:.78rem; }
  .sap-num { text-align:right; font-variant-numeric:tabular-nums; }

  /* Progress mini bar */
  .sap-progress { display:inline-block; width:80px; height:6px;
    background:#eef2f7; border-radius:3px; overflow:hidden; vertical-align:middle; }
  .sap-progress > span { display:block; height:100%; border-radius:3px;
    transition:width .9s cubic-bezier(.2,.8,.2,1); }
  .sap-progress.is-good > span     { background:var(--sap-positive); }
  .sap-progress.is-mid > span      { background:var(--sap-critical); }
  .sap-progress.is-bad > span      { background:var(--sap-negative); }

  /* Item code table */
  .pm-code { font-family:"72Mono","Courier New",monospace; font-size:.72rem;
    color:var(--sap-text-muted); background:#f5f6f7; padding:.1rem .45rem;
    border-radius:.35rem; }

  /* Print */
  @media print {
    body, .main-content { background:#fff !important; }
    .sidebar, .navbar, footer, .no-print,
    .sap-page-header, .sap-filterbar, .sap-btn { display:none !important; }
    .main-content { margin-left:0 !important; padding:0 !important; }
    .sap-card, .sap-tile, .sap-table-wrap { box-shadow:none !important;
      border:1px solid #d9d9d9 !important; page-break-inside:avoid; }
    .sap-tile { page-break-inside: avoid; }
    table.sap-table { font-size:10px; }
    table.sap-table thead th { background:#f0f3f7 !important;
      -webkit-print-color-adjust:exact; print-color-adjust:exact; }
    @page { size: A4 landscape; margin:10mm; }
  }

  @media (prefers-reduced-motion: reduce) {
    .sap-tile, table.sap-table tbody tr, .sap-btn, .sap-progress > span { transition:none !important; }
  }
</style>

<!-- ================= Page header ================= -->
<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb">
      <i class="bi bi-house-door"></i> Home / Reports / <strong>Preventive Maintenance</strong>
    </div>
    <h1 class="sap-page-title">Preventive Maintenance Report</h1>
  </div>
  <div class="d-flex gap-2 flex-wrap no-print">
    <a href="<?= BASE_URL ?>/reports/pm_form_report.php?year=<?= (int)$year ?>&quarter=<?= (int)$quarter ?>&department_id=<?= (int)$deptId ?>"
       class="sap-btn sap-btn-emphasized">
      <i class="bi bi-file-earmark-text"></i> Open as Form
    </a>
    <button onclick="window.print()" class="sap-btn sap-btn-outline">
      <i class="bi bi-printer"></i> Print
    </button>
    <a href="pm_export.php?year=<?= (int)$year ?>&quarter=<?= (int)$quarter ?>&department_id=<?= (int)$deptId ?>&fmt=csv"
       class="sap-btn sap-btn-success">
      <i class="bi bi-file-earmark-spreadsheet"></i> CSV
    </a>
    <a href="pm_export.php?year=<?= (int)$year ?>&quarter=<?= (int)$quarter ?>&department_id=<?= (int)$deptId ?>&fmt=xls"
       class="sap-btn sap-btn-success">
      <i class="bi bi-file-earmark-excel"></i> Excel
    </a>
  </div>
</div>

<!-- ================= Filter bar ================= -->
<div class="sap-filterbar no-print">
  <form method="get" class="row g-3 align-items-end">
    <div class="col-md-2">
      <label class="sap-form-label">Year</label>
      <select name="year" class="sap-form-control" onchange="this.form.submit()">
        <?php for ($y = date('Y') - 3; $y <= date('Y') + 1; $y++): ?>
          <option value="<?= $y ?>" <?= $year == $y ? 'selected' : '' ?>><?= $y ?></option>
        <?php endfor; ?>
      </select>
    </div>
    <div class="col-md-2">
      <label class="sap-form-label">Quarter</label>
      <select name="quarter" class="sap-form-control" onchange="this.form.submit()">
        <?php for ($q = 1; $q <= 4; $q++): ?>
          <option value="<?= $q ?>" <?= $quarter == $q ? 'selected' : '' ?>>Q<?= $q ?></option>
        <?php endfor; ?>
      </select>
    </div>
    <div class="col-md-3">
      <label class="sap-form-label">Department</label>
      <select name="department_id" class="sap-form-control" onchange="this.form.submit()">
        <option value="">All departments</option>
        <?php foreach ($departments as $d): ?>
          <option value="<?= (int)$d['id'] ?>" <?= $deptId == $d['id'] ? 'selected' : '' ?>>
            <?= e($d['department_name']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3">
      <label class="sap-form-label">&nbsp;</label>
      <button class="sap-btn sap-btn-emphasized w-100">
        <i class="bi bi-funnel"></i> Apply
      </button>
    </div>
    <div class="col-md-2">
      <label class="sap-form-label">&nbsp;</label>
      <?php if ($deptId || $year !== (int)date('Y') || $quarter !== pm_quarter_of(date('Y-m-d'))): ?>
        <a href="pm_report.php" class="sap-btn sap-btn-outline w-100">
          <i class="bi bi-x-circle"></i> Reset
        </a>
      <?php endif; ?>
    </div>
  </form>
</div>

<!-- ================= Print header ================= -->
<div style="display:none" class="print-only">
  <div style="text-align:center">
    <h5 style="margin:0">ETHIOPIAN PHARMACEUTICALS SUPPLY SERVICE — ADAMA BRANCH</h5>
    <div>PREVENTIVE MAINTENANCE REPORT — <?= (int)$year ?> Q<?= (int)$quarter ?></div>
  </div>
</div>

<!-- ================= Summary tiles ================= -->
<div class="row g-3 mb-3">
  <div class="col-6 col-md-3">
    <div class="sap-tile is-info">
      <div class="sap-tile-label"><i class="bi bi-clipboard-check"></i> Checklists</div>
      <div class="sap-tile-value" data-count="<?= (int)$totalChecklists ?>">0</div>
      <div class="sap-tile-foot">Submitted in <?= (int)$year ?>-Q<?= (int)$quarter ?></div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="sap-tile is-good">
      <div class="sap-tile-label"><i class="bi bi-check2-all"></i> Items Completed</div>
      <div class="sap-tile-value">
        <span data-count="<?= (int)$totalDone ?>">0</span>
        <span class="unit">/ <?= number_format($totalItems) ?></span>
      </div>
      <div class="sap-tile-foot"><?= $totalItems ? (int)$totalItems : 0 ?> total items checked</div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="sap-tile <?= $completionPct >= 90 ? 'is-good' : ($completionPct >= 70 ? 'is-critical' : 'is-bad') ?>">
      <div class="sap-tile-label"><i class="bi bi-speedometer2"></i> Completion</div>
      <div class="sap-tile-value">
        <span data-count="<?= $completionPct ?>" data-decimals="1">0</span><span class="unit">%</span>
      </div>
      <div class="sap-tile-foot">
        <span class="sap-status <?= $completionPct >= 90 ? 'is-good' : ($completionPct >= 70 ? 'is-critical' : 'is-bad') ?>">
          <?= $completionPct >= 90 ? 'On Target' : ($completionPct >= 70 ? 'At Risk' : 'Below Target') ?>
        </span>
      </div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="sap-tile is-neutral">
      <div class="sap-tile-label"><i class="bi bi-people"></i> Technicians</div>
      <div class="sap-tile-value"><?= number_format(count($technicians)) ?></div>
      <div class="sap-tile-foot">
        across <?= number_format(count($departmentsIn)) ?>
        department<?= count($departmentsIn) === 1 ? '' : 's' ?>
      </div>
    </div>
  </div>
</div>

<!-- ================= Item-by-item completion ================= -->
<?php if ($itemStats): ?>
<div class="sap-card">
  <div class="sap-card-header">
    <span><i class="bi bi-list-check" style="color:var(--sap-brand)"></i> Checklist items — completion rate across all submitted forms</span>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="sap-table">
        <thead>
          <tr>
            <th style="width:50px">#</th>
            <th>Item</th>
            <th class="sap-num">Checks made</th>
            <th class="sap-num">Total possible</th>
            <th style="width:160px">Rate</th>
          </tr>
        </thead>
        <tbody>
        <?php
        /* Order items by their canonical number */
        uksort($itemStats, function($a, $b) use ($itemStats) {
            return $itemStats[$a]['number'] <=> $itemStats[$b]['number'];
        });
        foreach ($itemStats as $code => $s):
            $cls = $s['pct'] >= 90 ? 'is-good' : ($s['pct'] >= 70 ? 'is-mid' : 'is-bad');
        ?>
          <tr>
            <td><strong><?= (int)$s['number'] ?></strong></td>
            <td>
              <?php
              $label = '';
              foreach (PM_ITEMS as $meta) {
                  if ($meta['code'] === $code) { $label = $meta['label']; break; }
              }
              ?>
              <?= e($label ?: $code) ?>
            </td>
            <td class="sap-num"><strong><?= (int)$s['done'] ?></strong></td>
            <td class="sap-num"><?= (int)$s['total'] ?></td>
            <td>
              <div class="d-flex align-items-center gap-2">
                <div class="sap-progress <?= $cls ?>"><span style="width:<?= (int)$s['pct'] ?>%"></span></div>
                <strong style="font-size:.78rem"><?= (int)$s['pct'] ?>%</strong>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- ================= Department breakdown ================= -->
<?php if (count($byDept) > 1): ?>
<div class="sap-card">
  <div class="sap-card-header">
    <span><i class="bi bi-building" style="color:var(--sap-brand)"></i> Completion by Department</span>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="sap-table">
        <thead>
          <tr>
            <th>Department</th>
            <th class="sap-num">Items Done</th>
            <th class="sap-num">Total Items</th>
            <th style="width:220px">Completion</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($byDept as $deptName => $v):
            $pct = $v['total'] ? round($v['done'] / $v['total'] * 100) : 0;
            $cls = $pct >= 90 ? 'is-good' : ($pct >= 70 ? 'is-mid' : 'is-bad');
        ?>
          <tr>
            <td><strong><?= e($deptName) ?></strong></td>
            <td class="sap-num"><?= (int)$v['done'] ?></td>
            <td class="sap-num"><?= (int)$v['total'] ?></td>
            <td>
              <div class="d-flex align-items-center gap-2">
                <div class="sap-progress <?= $cls ?>" style="width:140px">
                  <span style="width:<?= $pct ?>%"></span>
                </div>
                <strong style="font-size:.78rem"><?= $pct ?>%</strong>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- ================= Checklist detail table ================= -->
<div class="sap-card">
  <div class="sap-card-header">
    <span><i class="bi bi-card-checklist" style="color:var(--sap-brand)"></i> Submitted Checklists</span>
    <span class="sap-status is-info"><?= number_format(count($rows)) ?> row<?= count($rows) === 1 ? '' : 's' ?></span>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="sap-table">
        <thead>
          <tr>
            <th>Quarter</th>
            <th>Date</th>
            <th>Technician</th>
            <th>Department</th>
            <th class="sap-num">Employees</th>
            <th class="sap-num">Items Done</th>
            <th style="width:180px">Completion</th>
            <th class="no-print" style="text-align:right">Action</th>
          </tr>
        </thead>
        <tbody>
        <?php if (!$rows): ?>
          <tr>
            <td colspan="8" style="text-align:center;padding:2.5rem;color:var(--sap-text-muted)">
              <i class="bi bi-inbox" style="font-size:2rem;opacity:.4;display:block;margin-bottom:.5rem"></i>
              No preventive maintenance checklists submitted for this period.
            </td>
          </tr>
        <?php else: foreach ($rows as $r):
            $pct = (int)$r['items_total'] ? round((int)$r['items_done'] / (int)$r['items_total'] * 100) : 0;
            $cls = $pct >= 90 ? 'is-good' : ($pct >= 70 ? 'is-mid' : 'is-bad');
        ?>
          <tr>
            <td><strong><?= e($r['quarter_label']) ?></strong></td>
            <td><?= e(date('M j, Y', strtotime($r['checklist_date']))) ?></td>
            <td><?= e($r['technician_name']) ?></td>
            <td><?= e($r['department_name'] ?? '—') ?></td>
            <td class="sap-num"><?= (int)$r['employees_count'] ?></td>
            <td class="sap-num"><?= (int)$r['items_done'] ?> / <?= (int)$r['items_total'] ?></td>
            <td>
              <div class="d-flex align-items-center gap-2">
                <div class="sap-progress <?= $cls ?>"><span style="width:<?= $pct ?>%"></span></div>
                <strong style="font-size:.78rem"><?= $pct ?>%</strong>
              </div>
            </td>
            <td class="no-print" style="text-align:right">
              <a class="sap-btn sap-btn-outline"
                 href="pm_form_report.php?checklist_id=<?= (int)$r['id'] ?>&year=<?= (int)$year ?>&quarter=<?= (int)$quarter ?>"
                 style="padding:.3rem .6rem;font-size:.75rem">
                <i class="bi bi-file-earmark-text"></i> Open Form
              </a>
            </td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
        <?php if ($rows): ?>
        <tfoot>
          <tr>
            <td colspan="5">Overall</td>
            <td class="sap-num"><?= (int)$totalDone ?> / <?= (int)$totalItems ?></td>
            <td>
              <div class="d-flex align-items-center gap-2">
                <div class="sap-progress <?= $completionPct >= 90 ? 'is-good' : ($completionPct >= 70 ? 'is-mid' : 'is-bad') ?>">
                  <span style="width:<?= $completionPct ?>%"></span>
                </div>
                <strong style="font-size:.78rem"><?= number_format($completionPct, 1) ?>%</strong>
              </div>
            </td>
            <td class="no-print"></td>
          </tr>
        </tfoot>
        <?php endif; ?>
      </table>
    </div>
  </div>
</div>

<script>
/* Animated count-up */
function animateCount(el) {
  const target = parseFloat(el.dataset.count || '0');
  const decimals = parseInt(el.dataset.decimals || '0', 10);
  const start = performance.now();
  function step(now) {
    const t = Math.min(1, (now - start) / 900);
    const eased = 1 - Math.pow(1 - t, 3);
    const value = target * eased;
    el.textContent = decimals
      ? value.toFixed(decimals)
      : Math.round(value).toLocaleString();
    if (t < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-count]').forEach(animateCount);
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>