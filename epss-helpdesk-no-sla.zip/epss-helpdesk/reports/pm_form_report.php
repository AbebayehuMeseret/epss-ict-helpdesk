<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/pm.php';
$u = require_role('ADMIN','TEAM_LEADER','BRANCH_MANAGER','ICT_STAFF');
$pageTitle = 'Preventive Maintenance Form Report';
$pdo = db();

/* ============================================================
   Filters
   ============================================================ */
$checklistId = (int)($_GET['checklist_id'] ?? 0);
$deptId      = (int)($_GET['department_id'] ?? 0);
$year        = (int)($_GET['year']  ?? date('Y'));
$quarter     = (int)($_GET['quarter'] ?? pm_quarter_of(date('Y-m-d')));

/* ============================================================
   Load available checklists for the picker
   ============================================================ */
$sql = "SELECT c.id, c.technician_name, c.checklist_date, c.quarter_label,
               c.department_id, d.department_name
        FROM pm_checklists c
        LEFT JOIN departments d ON d.id = c.department_id
        WHERE c.year = ? AND c.quarter = ?";
$params = [$year, $quarter];
if ($deptId) { $sql .= " AND c.department_id = ?"; $params[] = $deptId; }
$sql .= " ORDER BY c.checklist_date DESC, c.id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$checklists = $stmt->fetchAll();

/* If none chosen yet, pick the newest */
if (!$checklistId && $checklists) {
    $checklistId = (int)$checklists[0]['id'];
}

/* ============================================================
   Load the chosen checklist + all items
   ============================================================ */
$checklist = null;
$employees = [];   // grouped by employee
$itemsByEmp = [];  // [empKey][itemCode] = done

if ($checklistId) {
    $stmt = $pdo->prepare("
        SELECT c.*, d.department_name
        FROM pm_checklists c
        LEFT JOIN departments d ON d.id = c.department_id
        WHERE c.id = ?
    ");
    $stmt->execute([$checklistId]);
    $checklist = $stmt->fetch();

    if ($checklist) {
        $stmt = $pdo->prepare("
            SELECT i.*, u.employee_id AS emp_code
            FROM pm_checklist_items i
            LEFT JOIN users u ON u.id = i.employee_id
            WHERE i.checklist_id = ?
            ORDER BY i.item_number, i.id
        ");
        $stmt->execute([$checklistId]);
        $items = $stmt->fetchAll();

        foreach ($items as $it) {
            $key = $it['employee_id'] ?: ('name:' . $it['employee_name']);
            if (!isset($employees[$key])) {
                $employees[$key] = [
                    'employee_id'   => $it['employee_id'],
                    'employee_name' => $it['employee_name'],
                    'employee_code' => $it['emp_code'] ?? '',
                ];
            }
            $itemsByEmp[$key][$it['item_code']] = [
                'done' => (int)$it['done'],
                'note' => $it['note'],
            ];
        }
    }
}

/* Departments for the filter dropdown */
$departments = $pdo->query("SELECT id, department_name FROM departments
                            WHERE status='ACTIVE' ORDER BY department_name")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:#0070f2; --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
  }
  body, .main-content { background:var(--sap-bg) !important;
    font-family:"72","72full",Arial,Helvetica,sans-serif !important; color:var(--sap-text); }

  .sap-page-header { display:flex; justify-content:space-between; align-items:flex-start;
    margin-bottom:1rem; flex-wrap:wrap; gap:.75rem; }
  .sap-page-title { font-size:1.625rem; font-weight:400; margin:0; }
  .sap-breadcrumb { font-size:.8125rem; color:var(--sap-text-muted); margin-bottom:.25rem; }

  .sap-card { background:var(--sap-tile); border-radius:.75rem;
    box-shadow:var(--sap-shadow); overflow:hidden; margin-bottom:1rem; }
  .sap-card-header { padding:.75rem 1.15rem; border-bottom:1px solid var(--sap-border-soft);
    font-size:.875rem; font-weight:600; }
  .sap-card-body { padding:1rem 1.15rem; }
  .sap-btn { display:inline-flex; align-items:center; gap:.35rem;
    font-size:.8125rem; font-weight:500; border-radius:.5rem;
    padding:.5rem .9rem; border:1px solid transparent; background:transparent;
    color:var(--sap-brand); cursor:pointer; text-decoration:none;
    white-space:nowrap; font-family:inherit; }
  .sap-btn:hover { background:#eaf4ff; color:var(--sap-brand-dark); }
  .sap-btn.sap-btn-emphasized { background:var(--sap-brand); color:#fff; }
  .sap-btn.sap-btn-emphasized:hover { background:#0057d2; }
  .sap-btn.sap-btn-outline { border-color:var(--sap-border); background:#fff; }
  .sap-btn.sap-btn-success { background:#256f3a; color:#fff; }
  .sap-btn.sap-btn-success:hover { background:#1d5d2e; }

  .sap-form-label { display:block; font-size:.72rem; text-transform:uppercase;
    letter-spacing:.04em; color:var(--sap-text-muted); font-weight:600; margin-bottom:.3rem; }
  .sap-form-control { width:100%; font-size:.875rem; font-family:inherit;
    background:#fff; border:1px solid var(--sap-border);
    border-radius:.5rem; padding:.5rem .7rem; outline:none; }

  /* =========================================================
     PAPER FORM — matches the original Word document layout
     ========================================================= */
  .pm-paper {
    background: #fff;
    padding: 20px 24px;
    border: 1px solid #000;
    font-family: Arial, "Times New Roman", sans-serif;
    color: #000;
    font-size: 11px;
  }

  /* Document header table (mimics the Word table at the top) */
  .pm-doc-header {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 12px;
  }
  .pm-doc-header td {
    border: 1px solid #000;
    padding: 4px 6px;
    vertical-align: top;
    font-size: 10px;
  }
  .pm-doc-header .doc-title {
    font-weight: 700;
    font-size: 12px;
    text-align: center;
  }
  .pm-doc-header .org {
    font-weight: 700;
    font-size: 12px;
  }
  .pm-doc-header .doc-num {
    white-space: nowrap;
    font-size: 10px;
  }

  .pm-dept-line {
    margin: 10px 0 8px;
    font-size: 12px;
  }
  .pm-dept-line strong { font-weight: 700; }

  /* Main checklist table */
  .pm-grid {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 12px;
    table-layout: fixed;
  }
  .pm-grid th,
  .pm-grid td {
    border: 1px solid #000;
    padding: 2px 3px;
    vertical-align: middle;
    text-align: center;
    font-size: 9px;
    word-wrap: break-word;
    line-height: 1.15;
  }
  .pm-grid thead th {
    background: #e8e8e8;
    font-weight: 700;
    font-size: 9px;
  }
  .pm-grid thead .rotated {
    writing-mode: vertical-rl;
    transform: rotate(180deg);
    white-space: nowrap;
    padding: 6px 2px;
    height: 130px;
    font-size: 8.5px;
    font-weight: 700;
  }
  .pm-grid td.col-no   { width: 26px; font-weight: 700; }
  .pm-grid td.col-name { width: 155px; text-align: left; padding-left: 5px; font-weight: 600; }
  .pm-grid th.col-no,
  .pm-grid th.col-name { width: auto; }
  .pm-grid td.cell-check {
    width: 42px;
    font-size: 12px;
    font-weight: 700;
  }
  .pm-grid td.cell-check.checked::before {
    content: "☑";       /* ballot box with check */
    color: #000;
    font-size: 13px;
  }
  .pm-grid td.cell-check.unchecked::before {
    content: "☐";       /* empty ballot box */
    color: #aaa;
    font-size: 13px;
  }
  .pm-grid tbody tr:nth-child(even) td { background: #fafafa; }

  /* Footer lines */
  .pm-footer {
    margin-top: 14px;
    font-size: 11px;
  }
  .pm-footer .row-line {
    display: flex;
    align-items: baseline;
    margin-bottom: 12px;
    gap: 6px;
  }
  .pm-footer .label {
    min-width: 130px;
    font-weight: 600;
  }
  .pm-footer .fill {
    flex: 1;
    border-bottom: 1px solid #000;
    padding: 0 6px;
    min-height: 18px;
  }

  /* Notes and legend */
  .pm-legend {
    margin-top: 10px;
    font-size: 9px;
    color: #333;
    border-top: 1px dashed #999;
    padding-top: 6px;
  }
  .pm-legend strong { font-weight: 700; }

  /* Print rules */
  @media print {
    body, .main-content { background: #fff !important; }
    .sidebar, .navbar, footer, .no-print, .sap-btn,
    .sap-page-header, .sap-card { display: none !important; }
    .main-content { margin-left: 0 !important; padding: 0 !important; }
    .pm-paper {
      border: 0;
      padding: 0;
      box-shadow: none;
    }
    .pm-grid thead th { background: #e8e8e8 !important;
      -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    .pm-grid tbody tr:nth-child(even) td { background: #fafafa !important;
      -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    .cell-check.checked::before { color: #000 !important; }
    @page { size: A4 landscape; margin: 10mm; }
  }
</style>

<!-- ================= Page header ================= -->
<div class="sap-page-header no-print">
  <div>
    <div class="sap-breadcrumb"><i class="bi bi-house-door"></i> Home / Reports / <strong>Preventive Maintenance Form</strong></div>
    <h1 class="sap-page-title">Preventive Maintenance Report</h1>
  </div>
  <div class="d-flex gap-2 flex-wrap">
    <a href="<?= BASE_URL ?>/reports/pm_report.php?year=<?= (int)$year ?>&quarter=<?= (int)$quarter ?>" class="sap-btn sap-btn-outline">
      <i class="bi bi-arrow-left"></i> Summary Report
    </a>
    <button onclick="window.print()" class="sap-btn sap-btn-success">
      <i class="bi bi-download"></i> Download / Print
    </button>
  </div>
</div>

<!-- ================= Filters ================= -->
<div class="sap-card no-print">
  <div class="sap-card-body">
    <form method="get" class="row g-3 align-items-end">
      <div class="col-md-2">
        <label class="sap-form-label">Year</label>
        <select name="year" class="sap-form-control">
          <?php for ($y = date('Y') - 3; $y <= date('Y') + 1; $y++): ?>
            <option value="<?= $y ?>" <?= $year==$y?'selected':'' ?>><?= $y ?></option>
          <?php endfor; ?>
        </select>
      </div>
      <div class="col-md-2">
        <label class="sap-form-label">Quarter</label>
        <select name="quarter" class="sap-form-control">
          <?php for ($q = 1; $q <= 4; $q++): ?>
            <option value="<?= $q ?>" <?= $quarter==$q?'selected':'' ?>>Q<?= $q ?></option>
          <?php endfor; ?>
        </select>
      </div>
      <div class="col-md-3">
        <label class="sap-form-label">Department</label>
        <select name="department_id" class="sap-form-control">
          <option value="">All departments</option>
          <?php foreach ($departments as $d): ?>
            <option value="<?= (int)$d['id'] ?>" <?= $deptId==$d['id']?'selected':'' ?>>
              <?= e($d['department_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-5">
        <label class="sap-form-label">Checklist</label>
        <div class="d-flex gap-2">
          <select name="checklist_id" class="sap-form-control">
            <?php if (!$checklists): ?>
              <option value="">No checklists for this period</option>
            <?php else: foreach ($checklists as $c): ?>
              <option value="<?= (int)$c['id'] ?>" <?= $checklistId==$c['id']?'selected':'' ?>>
                <?= e($c['quarter_label']) ?> ·
                <?= e(date('M j, Y', strtotime($c['checklist_date']))) ?> ·
                <?= e($c['technician_name']) ?>
                <?= $c['department_name'] ? ' · ' . e($c['department_name']) : '' ?>
              </option>
            <?php endforeach; endif; ?>
          </select>
          <button class="sap-btn sap-btn-emphasized">
            <i class="bi bi-funnel"></i> Apply
          </button>
        </div>
      </div>
    </form>
  </div>
</div>

<!-- ================= THE FORM ================= -->
<?php if (!$checklist): ?>
  <div class="sap-card no-print"><div class="sap-card-body text-center text-muted" style="padding:3rem">
    <i class="bi bi-inbox" style="font-size:2rem;opacity:.4;display:block;margin-bottom:.5rem"></i>
    No preventive maintenance checklist found for this period.<br>
    Try a different year, quarter, or department.
  </div></div>
<?php else: ?>

  <div class="pm-paper" id="pmPaper">
    <!-- Document header, mimicking the Word table -->
    <table class="pm-doc-header">
      <tr>
        <td rowspan="2" class="org" style="width:35%">
          Ethiopian Pharmaceuticals Supply Service
        </td>
        <td class="doc-num" style="width:20%">Document No: OF/ICTD/BR-06</td>
        <td rowspan="2" class="doc-title" style="width:45%">
          Preventive Maintenance Checklist
        </td>
      </tr>
      <tr>
        <td class="doc-num">
          Effective date: 05/04/2025 &nbsp;|&nbsp; Rev. No.: 0 &nbsp;|&nbsp; Page 1 of 1
        </td>
      </tr>
    </table>

    <!-- Department -->
    <div class="pm-dept-line">
      <strong>Department:</strong>
      <?= e($checklist['department_name'] ?? '—') ?>
    </div>

    <!-- The 15-column checklist matrix -->
    <table class="pm-grid">
      <thead>
        <tr>
          <th class="col-no">No</th>
          <th class="col-name">Full Employee Name</th>
          <?php foreach (PM_ITEMS as $num => $meta): ?>
            <th><div class="rotated"><?= e($meta['label']) ?></div></th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tbody>
        <?php $i = 0; foreach ($employees as $key => $emp): $i++; ?>
          <tr>
            <td class="col-no"><?= $i ?></td>
            <td class="col-name">
              <?= e($emp['employee_name']) ?>
              <?php if (!empty($emp['employee_code'])): ?>
                <div style="font-size:8px;color:#666;font-weight:400">
                  ID: <?= e($emp['employee_code']) ?>
                </div>
              <?php endif; ?>
            </td>
            <?php foreach (PM_ITEMS as $meta):
                $code  = $meta['code'];
                $entry = $itemsByEmp[$key][$code] ?? null;
                $done  = $entry && (int)$entry['done'] === 1;
                $note  = $entry['note'] ?? '';
            ?>
              <td class="cell-check <?= $done ? 'checked' : 'unchecked' ?>"
                  <?= $note ? 'title="' . e($note) . '"' : '' ?>>
                <?php if ($note): ?>
                  <div style="font-size:7px;color:#555;margin-top:1px">•</div>
                <?php endif; ?>
              </td>
            <?php endforeach; ?>
          </tr>
        <?php endforeach; ?>
        <?php if (!$employees): ?>
          <tr>
            <td colspan="<?= 2 + count(PM_ITEMS) ?>" style="padding:1rem;color:#888">
              No employees recorded in this checklist.
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>

    <!-- Notes from the checklist (if any) -->
    <?php if (!empty($checklist['notes'])): ?>
      <div style="font-size:10px;margin-bottom:8px">
        <strong>Notes:</strong> <?= e($checklist['notes']) ?>
      </div>
    <?php endif; ?>

    <!-- Legend -->
    <div class="pm-legend">
      <strong>Legend:</strong>
      ☑ = Checked / Performed &nbsp;·&nbsp;
      ☐ = Not performed &nbsp;·&nbsp;
      • = Note attached (hover for details)
    </div>

    <!-- Footer lines: Technician / Signature / Date -->
    <div class="pm-footer">
      <div class="row-line">
        <span class="label">Technician Name:</span>
        <span class="fill"><?= e($checklist['technician_name']) ?></span>
      </div>
      <div class="row-line">
        <span class="label">Signature:</span>
        <span class="fill">&nbsp;</span>
      </div>
      <div class="row-line">
        <span class="label">Date:</span>
        <span class="fill"><?= e(date('d/m/Y', strtotime($checklist['checklist_date']))) ?></span>
      </div>
    </div>
  </div>

  <!-- Print button (also in the header, this one is right below) -->
  <div class="text-center my-3 no-print">
    <button onclick="window.print()" class="sap-btn sap-btn-success">
      <i class="bi bi-download"></i> Download / Print this form
    </button>
  </div>

<?php endif; ?>

<script>
/* Auto-submit the filter form when department or year/quarter changes */
document.querySelectorAll('.no-print select[name="year"], .no-print select[name="quarter"], .no-print select[name="department_id"]').forEach(sel => {
  sel.addEventListener('change', () => sel.form.submit());
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>