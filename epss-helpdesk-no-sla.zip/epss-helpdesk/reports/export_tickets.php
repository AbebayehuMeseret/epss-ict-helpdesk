<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/kpi_calculator.php';

/* ---------- Load Dompdf (Composer or manual) ---------- */
$dompdfLoaded = false;
if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require_once __DIR__ . '/../vendor/autoload.php';
    $dompdfLoaded = class_exists('Dompdf\Dompdf');
} elseif (file_exists(__DIR__ . '/../vendor/dompdf/autoload.inc.php')) {
    require_once __DIR__ . '/../vendor/dompdf/autoload.inc.php';
    $dompdfLoaded = class_exists('Dompdf\Dompdf');
}

$u = require_role('ADMIN','TEAM_LEADER');

/* ---------- Filters ---------- */
/* Same default window as the Reports page: the last 12 months up to today,
   so a direct export link never comes back with an empty ticket list. */
$from   = $_GET['from']        ?? date('Y-m-01', strtotime('-11 months'));
$to     = $_GET['to']          ?? date('Y-m-d');
$catId  = (int)($_GET['category_id'] ?? 0);
$deptId = (int)($_GET['department_id'] ?? 0);
$tlId   = (int)($_GET['team_leader_id'] ?? 0);
$status = $_GET['status']      ?? '';
$fmt    = strtolower($_GET['fmt'] ?? 'csv');

/* Team Leaders can only export their own team */
if ($u['role'] === 'TEAM_LEADER') $tlId = (int)$u['id'];

/* =====================================================================
   PART 1 — TICKET DATA
   ===================================================================== */
$sql = "SELECT t.id, t.ticket_number, t.subject,
               req.id AS requester_id,
               req.full_name AS requester,
               reqd.department_name AS requester_department,
               d.department_name,
               c.category_name,
               p.name AS priority, p.color AS priority_color,
               t.status,
               tl.full_name AS team_leader,
               tech.full_name AS technician,
               t.created_at,
               t.team_leader_approved_at,
               t.ict_started_at,
               t.resolved_at,
               t.closed_at
        FROM tickets t
        JOIN categories c ON c.id = t.category_id
        JOIN priorities p ON p.id = t.priority_id
        JOIN users req    ON req.id = t.requester_id
        LEFT JOIN users tl   ON tl.id = t.team_leader_id
        LEFT JOIN users tech ON tech.id = t.assigned_technician_id
        LEFT JOIN departments d ON d.id = t.department_id
        LEFT JOIN departments reqd ON reqd.id = req.department_id
        WHERE t.created_at BETWEEN ? AND ?";
$params = [$from . ' 00:00:00', $to . ' 23:59:59'];
if ($catId)  { $sql .= " AND t.category_id = ?";    $params[] = $catId; }
if ($deptId) { $sql .= " AND t.department_id = ?";  $params[] = $deptId; }
if ($tlId)   { $sql .= " AND t.team_leader_id = ?"; $params[] = $tlId; }
if ($status) { $sql .= " AND t.status = ?";         $params[] = $status; }
$sql .= " ORDER BY t.created_at DESC";
$stmt = db()->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

/* Aggregated counts for the pie/bar charts */
$byStatus = [];
$byCatCount = [];
$byPriority = [];
foreach ($rows as $r) {
    $byStatus[$r['status']]           = ($byStatus[$r['status']] ?? 0) + 1;
    $byCatCount[$r['category_name']]  = ($byCatCount[$r['category_name']] ?? 0) + 1;
    $byPriority[$r['priority']]       = ($byPriority[$r['priority']] ?? 0) + 1;
}

/* =====================================================================
   PART 3 — REQUESTS QUANTITY PER REQUESTER
   ===================================================================== */
$statusBuckets = [
    'PENDING_TEAM_LEADER_APPROVAL'              => 'pending',
    'APPROVED_FOR_ICT'                          => 'approved',
    'ASSIGNED_TO_ICT'                           => 'approved',
    'IN_PROGRESS'                               => 'progress',
    'WAITING_FOR_INFORMATION'                   => 'progress',
    'WAITING_FOR_PARTS'                         => 'progress',
    'RETURNED_TO_ICT'                           => 'progress',
    'RESOLVED_PENDING_REQUESTER_CONFIRMATION'   => 'resolved',
    'RESOLVED_PENDING_TEAM_LEADER_VERIFICATION' => 'resolved',
    'CLOSED'                                    => 'closed',
];
$byRequester = [];
foreach ($rows as $r) {
    $key = (int)$r['requester_id'] . '|' . $r['requester'];
    if (!isset($byRequester[$key])) {
        $byRequester[$key] = [
            'requester'  => $r['requester'],
            'department' => $r['requester_department'] ?: ($r['department_name'] ?? '—'),
            'total' => 0, 'pending' => 0, 'approved' => 0,
            'progress' => 0, 'resolved' => 0, 'closed' => 0, 'other' => 0,
        ];
    }
    $byRequester[$key]['total']++;
    $byRequester[$key][$statusBuckets[$r['status']] ?? 'other']++;
}
uasort($byRequester, fn($a, $b) => ($b['total'] <=> $a['total']) ?: strcmp($a['requester'], $b['requester']));
$reqTotals = ['total' => 0, 'pending' => 0, 'approved' => 0, 'progress' => 0,
              'resolved' => 0, 'closed' => 0, 'other' => 0];
foreach ($byRequester as $g) {
    foreach ($reqTotals as $k => $unused) { $reqTotals[$k] += (int)$g[$k]; }
}

/* =====================================================================
   ROUTE BY FORMAT
   ===================================================================== */
if ($fmt === 'pdf') {
    if (!$dompdfLoaded) {
        app_fail('E-RPT-501');
    }

    /* ---- Build chart image URLs via QuickChart ---- */
    function qc_url(array $cfg): string {
        return 'https://quickchart.io/chart?w=520&h=260&bkg=white&c='
            . rawurlencode(json_encode($cfg));
    }

    /* Pie chart — tickets by status */
    $statusColors = [
        'PENDING_TEAM_LEADER_APPROVAL'              => '#f0ab00',
        'RETURNED_TO_EMPLOYEE'                      => '#0a6ed1',
        'APPROVED_FOR_ICT'                          => '#0070f2',
        'ASSIGNED_TO_ICT'                           => '#0057d2',
        'IN_PROGRESS'                               => '#1b90ff',
        'WAITING_FOR_INFORMATION'                   => '#8396a8',
        'WAITING_FOR_PARTS'                         => '#5b738b',
        'RESOLVED_PENDING_REQUESTER_CONFIRMATION'   => '#00a6a6',
        'RESOLVED_PENDING_TEAM_LEADER_VERIFICATION' => '#00a6a6',
        'RETURNED_TO_ICT'                           => '#e76500',
        'REJECTED'                                  => '#bb0000',
        'CLOSED'                                    => '#256f3a',
        'CANCELLED'                                 => '#354a5f',
    ];
    $pieLabels = array_keys($byStatus);
    $pieData   = array_values($byStatus);
    $pieColors = array_map(fn($s) => $statusColors[$s] ?? '#8396a8', $pieLabels);

    $pieConfig = [
        'type' => 'doughnut',
        'data' => [
            'labels' => $pieLabels,
            'datasets' => [[
                'data' => $pieData,
                'backgroundColor' => $pieColors,
                'borderColor' => '#fff',
                'borderWidth' => 2,
            ]]
        ],
        'options' => [
            'plugins' => [
                'legend' => ['position' => 'right', 'labels' => ['fontSize' => 11]],
                'title'  => ['display' => true, 'text' => 'Tickets by Status'],
            ]
        ]
    ];

    /* Bar chart — tickets by category */
    $barConfig = [
        'type' => 'bar',
        'data' => [
            'labels' => array_keys($byCatCount),
            'datasets' => [[
                'label' => 'Tickets',
                'data'  => array_values($byCatCount),
                'backgroundColor' => '#0070f2',
                'borderRadius' => 4,
            ]]
        ],
        'options' => [
            'plugins' => [
                'legend' => ['display' => false],
                'title'  => ['display' => true, 'text' => 'Tickets by Category'],
            ],
            'scales' => ['y' => ['beginAtZero' => true]]
        ]
    ];

    /* Pie chart — tickets by priority */
    $prioConfig = [
        'type' => 'pie',
        'data' => [
            'labels' => array_keys($byPriority),
            'datasets' => [[
                'data' => array_values($byPriority),
                'backgroundColor' => ['#5b738b','#0070f2','#e76500','#bb0000'],
            ]]
        ],
        'options' => [
            'plugins' => [
                'legend' => ['position' => 'right'],
                'title'  => ['display' => true, 'text' => 'Tickets by Priority'],
            ]
        ]
    ];

    $pieUrl  = qc_url($pieConfig);
    $barUrl  = qc_url($barConfig);
    $prioUrl = qc_url($prioConfig);

    /* Dompdf can only embed PNG/JPEG bytes through the GD extension. Without it
       Cpdf::addPngFromFile() throws and the whole download dies, so skip the
       chart images (the tables above still carry every number). */
    $gdOk = extension_loaded('gd');

    /* ---- Build HTML for Dompdf ---- */
    ob_start();
    ?>
    <!DOCTYPE html>
    <html><head><meta charset="UTF-8">
    <style>
      body   { font-family: DejaVu Sans, sans-serif; font-size: 10px; color: #1d2d3e; }
      h1     { font-size: 15px; margin: 0 0 2px; text-align: center; }
      h2     { font-size: 12px; margin: 12px 0 6px; }
      h3     { font-size: 11px; margin: 14px 0 6px; color: #0057d2; border-bottom: 1px solid #d9d9d9; padding-bottom: 3px; }
      .meta  { text-align: center; font-size: 9px; color: #556b82; margin-bottom: 8px; }
      table  { width: 100%; border-collapse: collapse; margin-top: 4px; }
      th     { background: #f0f3f7; color: #1d2d3e; font-weight: bold; text-align: left;
               border: 1px solid #d9d9d9; padding: 4px; font-size: 9px; }
      td     { border: 1px solid #e5e5e5; padding: 3px 4px; font-size: 9px; }
      tr:nth-child(even) td { background: #fafbfc; }
      .num   { text-align: right; }
      .overall td { background: #eaf4ff !important; font-weight: bold; }
      .chart-row { text-align: center; margin-bottom: 6px; }
      .chart-row img { max-width: 100%; }
      .chart-off { font-size: 9px; color: #556b82; font-style: italic; margin: 2px 0 0; }
      .kpi-variance-good { color: #256f3a; font-weight: bold; }
      .kpi-variance-bad  { color: #bb0000; font-weight: bold; }
      .badge { display: inline-block; padding: 1px 5px; border-radius: 8px;
               font-size: 8px; color: #fff; }
      .page-break { page-break-before: always; }
    </style>
    </head><body>

    <h1>ETHIOPIAN PHARMACEUTICALS SUPPLY SERVICE</h1>
    <h1>ADAMA BRANCH — ICT HELPDESK REPORT</h1>
    <div class="meta">
      Period: <strong><?= e($from) ?></strong> → <strong><?= e($to) ?></strong><br>
      Total ticket requests: <strong><?= count($rows) ?></strong>
      from <strong><?= count($byRequester) ?></strong> requester(s)<br>
      Generated by <?= e($u['full_name']) ?> (<?= e(str_replace('_',' ', $u['role'])) ?>)
      on <?= e(date('Y-m-d H:i')) ?>
      <?php if ($catId || $deptId || $tlId || $status): ?>
        <br>Filters:
        <?php
          $fs = [];
          if ($catId)  $fs[] = 'Category ID=' . $catId;
          if ($deptId) $fs[] = 'Department ID=' . $deptId;
          if ($tlId)   $fs[] = 'Team Leader ID=' . $tlId;
          if ($status) $fs[] = 'Status=' . $status;
          echo e(implode(' | ', $fs));
        ?>
      <?php endif; ?>
    </div>

    <!-- ============ CHARTS ============ -->
    <h3>1. Charts</h3>
    <?php if (!$gdOk): ?>
      <p class="chart-off">Chart images are omitted because the PHP GD extension is not enabled on this server.
      All figures are available in the tables above.</p>
    <?php else: ?>
    <div class="chart-row">
      <img src="<?= e($barUrl) ?>" alt="Tickets by Category">
    </div>
    <table style="border:none">
      <tr style="border:none">
        <td style="border:none; width:50%;"><img src="<?= e($pieUrl) ?>" style="width:100%"></td>
        <td style="border:none; width:50%;"><img src="<?= e($prioUrl) ?>" style="width:100%"></td>
      </tr>
    </table>
    <?php endif; ?>

    <!-- ============ REQUESTS PER REQUESTER ============ -->
    <div class="page-break"></div>
    <h3>2. Ticket Requests by Requester</h3>
    <table>
      <thead>
        <tr>
          <th>Requester</th>
          <th>Department</th>
          <th class="num">Total</th>
          <th class="num">Pending</th>
          <th class="num">Approved</th>
          <th class="num">In&nbsp;Progress</th>
          <th class="num">Resolved</th>
          <th class="num">Closed</th>
          <th class="num">Other</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($byRequester as $g): ?>
        <tr>
          <td><?= e($g['requester']) ?></td>
          <td><?= e($g['department']) ?></td>
          <td class="num"><?= (int)$g['total'] ?></td>
          <td class="num"><?= (int)$g['pending'] ?></td>
          <td class="num"><?= (int)$g['approved'] ?></td>
          <td class="num"><?= (int)$g['progress'] ?></td>
          <td class="num"><?= (int)$g['resolved'] ?></td>
          <td class="num"><?= (int)$g['closed'] ?></td>
          <td class="num"><?= (int)$g['other'] ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$byRequester): ?>
        <tr><td colspan="9" style="text-align:center;color:#556b82">No ticket requests in this period.</td></tr>
      <?php endif; ?>
        <tr class="overall">
          <td colspan="2">TOTAL — <?= count($byRequester) ?> requester(s)</td>
          <td class="num"><?= (int)$reqTotals['total'] ?></td>
          <td class="num"><?= (int)$reqTotals['pending'] ?></td>
          <td class="num"><?= (int)$reqTotals['approved'] ?></td>
          <td class="num"><?= (int)$reqTotals['progress'] ?></td>
          <td class="num"><?= (int)$reqTotals['resolved'] ?></td>
          <td class="num"><?= (int)$reqTotals['closed'] ?></td>
          <td class="num"><?= (int)$reqTotals['other'] ?></td>
        </tr>
      </tbody>
    </table>

    <!-- ============ TICKET DETAIL ============ -->
    <div class="page-break"></div>
    <h3>3. Ticket Detail (<?= count($rows) ?> tickets)</h3>
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Ticket #</th>
          <th>Subject</th>
          <th>Requester</th>
          <th>Requested By Dept</th>
          <th>Dept</th>
          <th>Category</th>
          <th>Priority</th>
          <th>Status</th>
          <th>Created</th>
          <th>Closed</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><?= (int)$r['id'] ?></td>
          <td><?= e($r['ticket_number']) ?></td>
          <td><?= e($r['subject']) ?></td>
          <td><?= e($r['requester']) ?></td>
          <td><?= e($r['requester_department'] ?: '—') ?></td>
          <td><?= e($r['department_name'] ?? '—') ?></td>
          <td><?= e($r['category_name']) ?></td>
          <td><?= e($r['priority']) ?></td>
          <td><?= e(str_replace('_',' ',$r['status'])) ?></td>
          <td><?= e(date('Y-m-d', strtotime($r['created_at']))) ?></td>
          <td><?= $r['closed_at'] ? e(date('Y-m-d', strtotime($r['closed_at']))) : '—' ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>

    </body></html>
    <?php
    $html = ob_get_clean();

    /* ---- Dompdf options ---- */
    $options = new \Dompdf\Options();
    $options->set('isRemoteEnabled', true);   // needed to fetch QuickChart images
    $options->set('isHtml5ParserEnabled', true);
    $options->set('defaultFont', 'DejaVu Sans');
    $options->set('chroot', __DIR__ . '/..');

    $dompdf = new \Dompdf\Dompdf($options);
    $dompdf->loadHtml($html, 'UTF-8');
    $dompdf->setPaper('A4', 'portrait');
    try {
        $dompdf->render();
    } catch (\Throwable $ex) {
        while (ob_get_level() > 0) { ob_end_clean(); }
        app_fail('E-RPT-500', 'The PDF could not be generated. Use the CSV / Excel export instead, or try again.', $ex);
    }

    $filename = "tickets_{$from}_{$to}.pdf";
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $dompdf->stream($filename, ['Attachment' => true]);
    exit;
}

/* =====================================================================
   CSV / XLS EXPORT  (fixed fputcsv usage)
   ===================================================================== */
$filename = "tickets_{$from}_{$to}.{$fmt}";
header('Content-Type: ' . ($fmt === 'xls'
    ? 'application/vnd.ms-excel; charset=UTF-8'
    : 'text/csv; charset=UTF-8'));
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Pragma: no-cache');
header('Expires: 0');

$out = fopen('php://output', 'w');
fwrite($out, "\xEF\xBB\xBF");   // UTF-8 BOM for Excel

/* Header block */
fputcsv($out, ['ETHIOPIAN PHARMACEUTICALS SUPPLY SERVICE - ADAMA BRANCH']);
fputcsv($out, ['ICT HELPDESK TICKET REPORT']);
fputcsv($out, ['Period', $from, 'to', $to]);
fputcsv($out, ['Generated by', $u['full_name'] . ' (' . str_replace('_',' ', $u['role']) . ')']);
fputcsv($out, ['Generated at', date('Y-m-d H:i:s')]);
fputcsv($out, []);

$filterParts = [];
if ($catId)  $filterParts[] = 'Category ID=' . $catId;
if ($deptId) $filterParts[] = 'Department ID=' . $deptId;
if ($tlId)   $filterParts[] = 'Team Leader ID=' . $tlId;
if ($status) $filterParts[] = 'Status=' . $status;
if ($filterParts) {
    fputcsv($out, ['Filters', implode(' | ', $filterParts)]);
    fputcsv($out, []);
}

/* Ticket detail */
fputcsv($out, ['=== TICKET DETAIL ===']);
fputcsv($out, []);
fputcsv($out, [
    'Ticket #','Subject','Requester','Department','Category','Priority','Status',
    'Team Leader','Technician','Created','Approved','ICT Started','Resolved','Closed'
]);
foreach ($rows as $r) {
    fputcsv($out, [
        $r['ticket_number'],$r['subject'],$r['requester'],
        $r['department_name'] ?? '',$r['category_name'],$r['priority'],$r['status'],
        $r['team_leader'] ?? '',$r['technician'] ?? '',
        $r['created_at'],$r['team_leader_approved_at'] ?? '',
        $r['ict_started_at'] ?? '',$r['resolved_at'] ?? '',
        $r['closed_at'] ?? '',
    ]);
}
fputcsv($out, []);
fputcsv($out, ['Total ticket rows', count($rows)]);

fclose($out);
exit;
