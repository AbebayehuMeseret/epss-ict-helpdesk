<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';

/**
 * Ticket totals and average resolution time for a date range and optional category.
 * (Resolution time = Team Leader approval -> closed.)
 */
function calculate_kpi_achievement(string $fromDate, string $toDate, ?int $categoryId = null): array {
    $pdo = db();
    $sql = "SELECT COUNT(*) AS total,
                   AVG(CASE WHEN team_leader_approved_at IS NOT NULL
                            THEN TIMESTAMPDIFF(SECOND, team_leader_approved_at, closed_at) END) AS avg_sec
            FROM tickets
            WHERE closed_at BETWEEN ? AND ?";
    $params = [$fromDate, $toDate];
    if ($categoryId) { $sql .= " AND category_id=?"; $params[] = $categoryId; }
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $row = $stmt->fetch() ?: ['total' => 0, 'avg_sec' => null];

    return [
        'total'             => (int)$row['total'],
        'avg_resolution_hr' => $row['avg_sec'] !== null ? round((float)$row['avg_sec'] / 3600, 2) : 0,
    ];
}
