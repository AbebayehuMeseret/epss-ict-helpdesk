<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/kpi_calculator.php';
$u = require_role('ADMIN','TEAM_LEADER','BRANCH_MANAGER');
$pageTitle = 'KPI Report';
$pdo = db();

$from = $_GET['from'] ?? date('Y-m-01');
$to   = $_GET['to']   ?? date('Y-m-t');

/* ---- Strategic / Process / Output KPIs from kpi_measurements ---- */
$strategicRows = [];
try {
    $stmt = $pdo->prepare("
        SELECT k.id, k.kpi_code, k.kpi_name, k.kpi_type, k.kpi_formula,
               k.target_value, k.target_unit, k.target_percentage,
               k.measurement_period, k.strategic_objective,
               m.period_label, m.actual_value, m.numerator, m.denominator,
               m.recorded_at, u.full_name AS recorder
        FROM kpis k
        LEFT JOIN kpi_measurements m ON m.kpi_id = k.id
            AND m.period_year = ?
            AND (
                (k.measurement_period = 'QUARTERLY' AND m.period_quarter = ?)
             OR (k.measurement_period = 'MONTHLY'   AND m.period_month = ?)
            )
        LEFT JOIN users u ON u.id = m.recorded_by
        WHERE k.status = 'ACTIVE'
          AND k.kpi_type IN ('PROCESS','OUTPUT','CUSTOM')
        ORDER BY k.kpi_code, k.kpi_name
    ");
    $year    = (int)date('Y', strtotime($from));
    $quarter = (int)ceil((int)date('n', strtotime($from)) / 3);
    $month   = (int)date('n', strtotime($from));
    $stmt->execute([$year, $quarter, $month]);
    $strategicRows = $stmt->fetchAll();
} catch (Throwable $e) {
    $strategicRows = [];
}

include __DIR__ . '/../includes/header.php';
?>

<style>
  :root {
    --sap-brand:#0070f2; --sap-bg:#f5f6f7; --sap-tile:#ffffff;
    --sap-text:#1d2d3e; --sap-text-muted:#556b82;
    --sap-border:#d9d9d9; --sap-border-soft:#eaecf0;
    --sap-positive:#256f3a; --sap-critical:#e76500;
    --sap-negative:#aa0808; --sap-neutral:#5b738b;
    --sap-shadow: 0 0 0 1px rgba(34,53,72,.10), 0 2px 8px 0 rgba(34,53,72,.06);
  }
  body, .main-content { background:var(--sap-bg) !important;
    font-family:"72","72full",Arial,Helvetica,sans-serif !important; color:var(--sap-text); }
  .sap-page-header { display:flex; justify-content:space-between; align-items:flex-start;
    margin-bottom:1rem; flex-wrap:wrap; gap:.75rem; }
  .sap-page-title { font-size:1.625rem; font-weight:400; margin:0; }
  .sap-breadcrumb { font-size:.8125rem; color:var(--sap-text-muted); margin-bottom:.25rem; }
  .sap-card { background:var(--sap-tile); border-radius:.75rem;
    box-shadow:var(--sap-shadow); overflow:hidden; margin-bottom:1rem; }
  .sap-card-header { padding:.75rem 1.15rem; border-bottom:1px solid var(--sap-border-soft);
    font-size:.875rem; font-weight:600; display:flex; align-items:center; gap:.45rem; }
  .sap-card-header .bi { color:var(--sap-brand); }
  .sap-card-body { padding:1rem 1.15rem; }
  .sap-section-label { font-size:.75rem; text-transform:uppercase; letter-spacing:.06em;
    color:var(--sap-brand); font-weight:700; margin:1rem 0 .5rem;
    display:flex; align-items:center; gap:.4rem; }
  .sap-section-label::before { content:""; display:inline-block; width:3px; height:12px;
    background:var(--sap-brand); border-radius:2px; }

  table.sap-table { width:100%; border-collapse:separate; border-spacing:0; font-size:.8125rem; }
  table.sap-table thead th { background:#f5f6f7; border-bottom:1px solid var(--sap-border);
    font-weight:600; color:var(--sap-text-muted); text-align:left;
    padding:.55rem .7rem; text-transform:uppercase; font-size:.68rem; letter-spacing:.04em; white-space:nowrap; }
  table.sap-table tbody td { padding:.55rem .7rem;
    border-bottom:1px solid var(--sap-border-soft); }
  table.sap-table tbody tr:last-child td { border-bottom:0; }
  table.sap-table tfoot td { padding:.55rem .7rem; background:#f5f6f7;
    border-top:1px solid var(--sap-border); font-weight:600; }
  .sap-num { text-align:right; font-variant-numeric:tabular-nums; }
  .sap-code { font-family:"72Mono","Courier New",monospace; font-size:.72rem; font-weight:700;
    background:#eaf4ff; color:var(--sap-brand); padding:.1rem .5rem; border-radius:.35rem; }
  .sap-status { display:inline-flex; align-items:center; gap:.2rem;
    font-size:.7rem; font-weight:600; padding:.1rem .5rem; border-radius:.75rem; }
  .sap-status.is-good { background:#f1fdf6; color:var(--sap-positive); border:1px solid #d6f0e0; }
  .sap-status.is-bad  { background:#fef4f4; color:var(--sap-negative); border:1px solid #f7d2d2; }
  .sap-status.is-mid  { background:#fff8f1; color:var(--sap-critical); border:1px solid #fbe0c8; }
  .sap-btn { display:inline-flex; align-items:center; gap:.35rem;
    font-size:.8125rem; font-weight:500; border-radius:.5rem;
    padding:.45rem .8rem; border:1px solid var(--sap-border); background:#fff;
    color:var(--sap-brand); cursor:pointer; text-decoration:none; }
  .sap-btn:hover { background:#eaf4ff; }
  .sap-form-label { display:block; font-size:.72rem; text-transform:uppercase;
    letter-spacing:.04em; color:var(--sap-text-muted); font-weight:600; margin-bottom:.3rem; }
  .sap-form-control { width:100%; font-size:.875rem; font-family:inherit;
    background:#fff; border:1px solid var(--sap-border);
    border-radius:.5rem; padding:.5rem .7rem; outline:none; }
</style>

<div class="sap-page-header">
  <div>
    <div class="sap-breadcrumb"><i class="bi bi-house-door"></i> Home / Reports / <strong>KPI Report</strong></div>
    <h1 class="sap-page-title">KPI Report</h1>
  </div>
  <div class="d-flex gap-2 flex-wrap">
    <a href="kpi_export.php?from=<?= e($from) ?>&to=<?= e($to) ?>&fmt=csv" class="sap-btn">
      <i class="bi bi-file-earmark-spreadsheet"></i> CSV
    </a>
    <a href="kpi_export.php?from=<?= e($from) ?>&to=<?= e($to) ?>&fmt=xls" class="sap-btn">
      <i class="bi bi-file-earmark-excel"></i> Excel
    </a>
    <button onclick="window.print()" class="sap-btn">
      <i class="bi bi-printer"></i> Print
    </button>
  </div>
</div>

<!-- Filters -->
<div class="sap-card">
  <div class="sap-card-body">
    <form method="get" class="row g-3 align-items-end">
      <div class="col-md-3"><label class="sap-form-label">From</label>
        <input type="date" name="from" value="<?= e($from) ?>" class="sap-form-control"></div>
      <div class="col-md-3"><label class="sap-form-label">To</label>
        <input type="date" name="to" value="<?= e($to) ?>" class="sap-form-control"></div>
      <div class="col-md-2">
        <button class="sap-btn" style="background:var(--sap-brand);color:#fff;border-color:var(--sap-brand)">
          <i class="bi bi-funnel"></i> Apply
        </button>
      </div>
    </form>
  </div>
</div>

<!-- ================= Strategic / Process / Output KPIs ================= -->
<div class="sap-section-label">
  Strategic KPIs (SO-5: Transform Supply Chain Technologies and Information System)
</div>
<div class="sap-card">
  <div class="sap-card-body p-0">
    <table class="sap-table">
      <thead>
        <tr>
          <th style="width:70px">Code</th>
          <th>KPI</th>
          <th>Type</th>
          <th>Period</th>
          <th class="sap-num">Actual</th>
          <th class="sap-num">Target</th>
          <th class="sap-num">Variance</th>
          <th>Status</th>
          <th>Formula</th>
        </tr>
      </thead>
      <tbody>
      <?php if (!$strategicRows): ?>
        <tr><td colspan="9" class="text-center text-muted" style="padding:1.5rem">
          No strategic KPI measurements recorded for this period.
          <a href="<?= BASE_URL ?>/admin/kpi_measurements.php">Record one →</a>
        </td></tr>
      <?php else: foreach ($strategicRows as $r):
          $target = $r['target_value'] !== null ? (float)$r['target_value'] : (float)$r['target_percentage'];
          $actual = $r['actual_value'] !== null ? (float)$r['actual_value'] : 0;
          $variance = round($actual - $target, 2);
          /* For MTTR, lower is better */
          $isGood = $variance >= 0;
          $isMid  = false;
          if ($r['kpi_code'] === 'ICT-3') {
              $isGood = $variance <= 0;
              $isMid  = !$isGood && $variance <= 2;
          } elseif ($r['kpi_code'] === 'ICT-1') {
              $isMid = !$isGood && $variance >= -5;
          }
          $statusClass = $isGood ? 'is-good' : ($isMid ? 'is-mid' : 'is-bad');
          $statusLabel = $isGood ? 'On Target' : ($isMid ? 'At Risk' : 'Below Target');
      ?>
        <tr>
          <td><span class="sap-code"><?= e($r['kpi_code'] ?? '—') ?></span></td>
          <td><?= e($r['kpi_name']) ?></td>
          <td><span class="sap-status is-mid"><?= e($r['kpi_type']) ?></span></td>
          <td><?= e($r['measurement_period']) ?></td>
          <td class="sap-num"><strong><?= number_format($actual, 2) ?></strong>
            <span style="font-size:.7rem;color:var(--sap-text-muted)"><?= e($r['target_unit'] ?? '') ?></span>
          </td>
          <td class="sap-num"><?= number_format($target, 2) ?>
            <span style="font-size:.7rem;color:var(--sap-text-muted)"><?= e($r['target_unit'] ?? '') ?></span>
          </td>
          <td class="sap-num">
            <span class="sap-status <?= $statusClass ?>">
              <?= $variance >= 0 ? '+' : '' ?><?= number_format($variance, 2) ?>
            </span>
          </td>
          <td><span class="sap-status <?= $statusClass ?>"><?= e($statusLabel) ?></span></td>
          <td style="font-size:.72rem;color:var(--sap-text-muted);font-family:'72Mono',monospace">
            <?= e(mb_strimwidth($r['kpi_formula'] ?? '', 0, 60, '…')) ?>
          </td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>