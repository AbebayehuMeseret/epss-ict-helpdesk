-- Telegram notification support -------------------------------------------
ALTER TABLE `users`
  ADD COLUMN `telegram_chat_id`    BIGINT NULL DEFAULT NULL AFTER `phone`,
  ADD COLUMN `telegram_link_token` VARCHAR(64) NULL DEFAULT NULL AFTER `telegram_chat_id`,
  ADD UNIQUE KEY `uq_users_telegram_chat` (`telegram_chat_id`),
  ADD UNIQUE KEY `uq_users_telegram_token` (`telegram_link_token`);

CREATE TABLE IF NOT EXISTS `telegram_log` (
  `id`         BIGINT NOT NULL AUTO_INCREMENT,
  `user_id`    INT NULL,
  `chat_id`    BIGINT NOT NULL,
  `ticket_id`  BIGINT NULL,
  `message`    TEXT NOT NULL,
  `status`     ENUM('QUEUED','SENT','FAILED') NOT NULL DEFAULT 'QUEUED',
  `response`   TEXT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `sent_at`    DATETIME NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `system_settings` (`setting_key`,`setting_value`,`description`) VALUES
 ('tg_enabled','1','Telegram notifications on/off (1/0)'),
 ('tg_bot_token','8957196590:AAFq7-JERdU_0Er20Zs0qYjtoJO5U2fBZa4','Token from @BotFather'),
 ('tg_bot_username','epssICTbot','Bot username without @'),
 ('tg_mode','polling','polling = local server, webhook = public HTTPS'),
 ('tg_update_offset','0','Last Telegram update id handled (polling)'),
 ('tg_public_url','','Public HTTPS base URL for the webhook'),
 ('tg_webhook_secret','e224f4684664eba52bf5c88f6012823372706c4303b217d7','Secret for Telegram webhook header')
ON DUPLICATE KEY UPDATE setting_key=setting_key;
