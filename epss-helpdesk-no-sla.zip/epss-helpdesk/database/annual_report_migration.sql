-- ---------------------------------------------------------------------------
-- EPSS Adama Helpdesk — annual ICT report
-- ---------------------------------------------------------------------------
-- Stores the narrative sections the administrator edits for each Ethiopian
-- calendar year. The statistics in the report itself are calculated live from
-- tickets and preventive maintenance records.
--
-- Safe to run more than once.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `annual_ict_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ec_year` smallint(4) NOT NULL,
  `presenter` varchar(150) DEFAULT NULL,
  `report_date` date DEFAULT NULL,
  `overview` text DEFAULT NULL,
  `work_done_notes` text DEFAULT NULL,
  `impact_notes` text DEFAULT NULL,
  `challenges` text DEFAULT NULL,
  `recommendations` text DEFAULT NULL,
  `conclusion` text DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_annual_report_year` (`ec_year`),
  KEY `idx_annual_report_user` (`updated_by`),
  CONSTRAINT `fk_annual_report_user` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
