-- ---------------------------------------------------------------------------
-- EPSS Adama Helpdesk — preventive maintenance approval by the Branch Manager
-- ---------------------------------------------------------------------------
-- New flow:
--   ICT technician submits a quarterly PM checklist → Branch Manager reviews it
--   → Approve / Reject (with remarks) → the technician is notified.
--
-- Safe to run more than once.
-- ---------------------------------------------------------------------------

-- ---------------------------------------------------------------------------
-- 1. Base PM tables (fresh installs). No-op on installations that already
--    have them, e.g. when this file is run only for the approval columns.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `pm_checklists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `technician_id` int(11) NOT NULL,
  `technician_name` varchar(150) NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  `checklist_date` date NOT NULL,
  `quarter_label` varchar(20) NOT NULL COMMENT 'YYYY-QN',
  `year` smallint(4) NOT NULL,
  `quarter` tinyint(1) NOT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `approval_remarks` text DEFAULT NULL,
  `submitted_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_pm_checklists_tech` (`technician_id`),
  KEY `idx_pm_checklists_period` (`year`,`quarter`),
  KEY `idx_pm_checklists_date` (`checklist_date`),
  KEY `idx_pm_checklists_dept` (`department_id`),
  KEY `idx_pm_checklists_status` (`status`),
  CONSTRAINT `fk_pm_checklists_dept` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pm_checklists_tech` FOREIGN KEY (`technician_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pm_checklists_approver` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `pm_checklist_items` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `checklist_id` int(11) NOT NULL,
  `item_number` tinyint(2) NOT NULL COMMENT '1..15, matches PM_ITEMS in includes/pm.php',
  `employee_id` int(11) DEFAULT NULL,
  `employee_name` varchar(150) DEFAULT NULL,
  `item_code` varchar(60) NOT NULL,
  `done` tinyint(1) NOT NULL DEFAULT 0,
  `note` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_pm_items_checklist` (`checklist_id`),
  KEY `idx_pm_items_number` (`item_number`),
  KEY `idx_pm_items_employee` (`employee_id`),
  CONSTRAINT `fk_pm_items_checklist` FOREIGN KEY (`checklist_id`) REFERENCES `pm_checklists` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `pm_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year` smallint(4) NOT NULL,
  `quarter` tinyint(1) NOT NULL,
  `sent_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pm_reminder_period` (`year`,`quarter`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ---------------------------------------------------------------------------
-- 2. Add the approval columns to an existing installation.
--    A checklist that was submitted before this workflow existed is treated as
--    already approved, so it does not appear as a new task for the Branch
--    Manager. New rows default to PENDING.
-- ---------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS `pm_apply_approval_columns`;
DELIMITER $$
CREATE PROCEDURE `pm_apply_approval_columns`()
BEGIN
  IF NOT EXISTS (
      SELECT 1 FROM information_schema.COLUMNS
       WHERE TABLE_SCHEMA = DATABASE()
         AND TABLE_NAME = 'pm_checklists'
         AND COLUMN_NAME = 'status') THEN
    ALTER TABLE `pm_checklists`
      ADD COLUMN `status` enum('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'APPROVED' AFTER `notes`;
    ALTER TABLE `pm_checklists`
      MODIFY COLUMN `status` enum('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING';
  END IF;

  IF NOT EXISTS (
      SELECT 1 FROM information_schema.COLUMNS
       WHERE TABLE_SCHEMA = DATABASE()
         AND TABLE_NAME = 'pm_checklists'
         AND COLUMN_NAME = 'approved_by') THEN
    ALTER TABLE `pm_checklists`
      ADD COLUMN `approved_by` int(11) DEFAULT NULL AFTER `status`;
  END IF;

  IF NOT EXISTS (
      SELECT 1 FROM information_schema.COLUMNS
       WHERE TABLE_SCHEMA = DATABASE()
         AND TABLE_NAME = 'pm_checklists'
         AND COLUMN_NAME = 'approved_at') THEN
    ALTER TABLE `pm_checklists`
      ADD COLUMN `approved_at` datetime DEFAULT NULL AFTER `approved_by`;
  END IF;

  IF NOT EXISTS (
      SELECT 1 FROM information_schema.COLUMNS
       WHERE TABLE_SCHEMA = DATABASE()
         AND TABLE_NAME = 'pm_checklists'
         AND COLUMN_NAME = 'approval_remarks') THEN
    ALTER TABLE `pm_checklists`
      ADD COLUMN `approval_remarks` text DEFAULT NULL AFTER `approved_at`;
  END IF;

  IF NOT EXISTS (
      SELECT 1 FROM information_schema.STATISTICS
       WHERE TABLE_SCHEMA = DATABASE()
         AND TABLE_NAME = 'pm_checklists'
         AND INDEX_NAME = 'idx_pm_checklists_status') THEN
    ALTER TABLE `pm_checklists` ADD KEY `idx_pm_checklists_status` (`status`);
  END IF;

  IF NOT EXISTS (
      SELECT 1 FROM information_schema.TABLE_CONSTRAINTS
       WHERE CONSTRAINT_SCHEMA = DATABASE()
         AND TABLE_NAME = 'pm_checklists'
         AND CONSTRAINT_NAME = 'fk_pm_checklists_approver') THEN
    ALTER TABLE `pm_checklists`
      ADD CONSTRAINT `fk_pm_checklists_approver`
      FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;
  END IF;
END$$
DELIMITER ;

CALL `pm_apply_approval_columns`();
DROP PROCEDURE `pm_apply_approval_columns`;

-- Historical rows have no approver recorded; date them when they were handed in.
UPDATE `pm_checklists`
   SET `approved_at` = `submitted_at`
 WHERE `status` = 'APPROVED' AND `approved_at` IS NULL;
