-- Run this if you ALREADY ran telegram_migration.sql with the old bot (@epssotmsbot).
-- (Or just paste the new token/username on Admin -> Telegram Bot and run the last two lines.)
UPDATE system_settings SET setting_value='8957196590:AAFq7-JERdU_0Er20Zs0qYjtoJO5U2fBZa4' WHERE setting_key='tg_bot_token';
UPDATE system_settings SET setting_value='epssICTbot' WHERE setting_key='tg_bot_username';
UPDATE system_settings SET setting_value='0' WHERE setting_key='tg_update_offset';
-- Chat IDs belong to a specific bot, so users must link again with the new bot:
UPDATE users SET telegram_chat_id=NULL, telegram_link_token=NULL;
