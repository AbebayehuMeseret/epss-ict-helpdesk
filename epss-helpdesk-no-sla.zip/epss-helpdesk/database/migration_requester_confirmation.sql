-- ---------------------------------------------------------------------------
-- EPSS Adama Helpdesk — workflow change: requester confirms the resolution
-- ---------------------------------------------------------------------------
-- New flow:
--   Employee → Team Leader approves → ICT accepts → ICT resolves
--   → Requester confirms → Closed
--
-- A Team Leader who raises a ticket himself is its requester: ICT resolves it,
-- he gets the confirmation request (page, in-app and Telegram), and the ticket
-- only closes on his answer or when the 30-minute window expires.
--
-- Run once against the application database. Every statement is safe to repeat.
-- ---------------------------------------------------------------------------

-- 1. Tickets that were waiting for a Team Leader to verify a resolution now
--    wait for the requester instead.
UPDATE `tickets`
   SET `status` = 'RESOLVED_PENDING_REQUESTER_CONFIRMATION'
 WHERE `status` = 'RESOLVED_PENDING_TEAM_LEADER_VERIFICATION';

-- 2. Tickets resolved by an ICT technician who pressed "Mark Resolved" without
--    Accept/Assign carry no assigned_technician_id, so the confirmation notice
--    had nobody to go to. Point them at the technician who logged the work.
UPDATE `tickets` t
   SET t.`assigned_technician_id` = (
         SELECT w.`technician_id` FROM `ticket_work_logs` w
          WHERE w.`ticket_id` = t.`id`
          ORDER BY w.`created_at` DESC, w.`id` DESC LIMIT 1)
 WHERE t.`assigned_technician_id` IS NULL
   AND t.`status` = 'RESOLVED_PENDING_REQUESTER_CONFIRMATION'
   AND EXISTS (SELECT 1 FROM `ticket_work_logs` w WHERE w.`ticket_id` = t.`id`);

-- 3. The same tickets have no resolution timestamp, which the confirmation
--    deadline is measured from. Use the work log's completion time.
UPDATE `tickets` t
   SET t.`resolved_at` = (
         SELECT COALESCE(w.`completed_at`, w.`created_at`) FROM `ticket_work_logs` w
          WHERE w.`ticket_id` = t.`id`
          ORDER BY w.`created_at` DESC, w.`id` DESC LIMIT 1)
 WHERE t.`resolved_at` IS NULL
   AND t.`status` = 'RESOLVED_PENDING_REQUESTER_CONFIRMATION';

-- Telegram support (bot commands, linking and the Confirm / Not Resolved
-- buttons) needs database/telegram_migration.sql applied as well.
