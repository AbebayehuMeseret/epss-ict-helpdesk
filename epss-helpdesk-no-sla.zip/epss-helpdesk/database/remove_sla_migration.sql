-- =====================================================================
-- OPTIONAL clean-up after removing SLA from the helpdesk.
-- The application no longer reads or writes any of this, so running the
-- script is NOT required for the system to work. Run it in phpMyAdmin
-- (database epss_adama_helpdesk) only if you want the leftovers gone.
-- Take a backup first - DROP COLUMN / DROP TABLE cannot be undone.
-- =====================================================================

-- 1) SLA settings that used to appear on the Settings > SLA tab
DELETE FROM system_settings
 WHERE setting_key IN (
   'sla_start_point', 'sla_use_working_hours', 'sla_default_hours',
   'sla_resolve_hours', 'sla_resolve_hours_critical', 'sla_resolve_hours_high',
   'sla_resolve_hours_medium', 'sla_resolve_hours_low'
 );

-- 2) SLA pause history table
DROP TABLE IF EXISTS sla_pauses;

-- 3) SLA columns on tickets
ALTER TABLE tickets
  DROP COLUMN sla_deadline,
  DROP COLUMN sla_paused_minutes;

-- 4) Priority response / resolution targets (no longer shown or edited)
ALTER TABLE priorities
  DROP COLUMN response_target_minutes,
  DROP COLUMN resolution_target_minutes;

-- 5) Old "SLA Compliance" KPI definitions - hide them from the KPI list.
--    (Needs the kpi_type column added by the KPI migration; skip if you get
--     "Unknown column 'kpi_type'".)
-- UPDATE kpis SET status = 'INACTIVE' WHERE kpi_type = 'SLA';
